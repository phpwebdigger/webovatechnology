  

         <?php $__env->startSection('content'); ?>
                        <!-- BEGIN PAGE HEADER-->
                        <!-- BEGIN PAGE BAR -->
                        <div class="page-bar">
                            <ul class="page-breadcrumb" >
                                <li>
									<span>Set Password</span>
                                </li>
                            </ul>
                        </div>
                        <!-- END PAGE BAR -->
                        <!-- BEGIN PAGE TITLE-->
                        <h1 class="page-title"> 
                        </h1>
                        <!-- END PAGE TITLE-->

                        <?php if($errors->any()): ?>
                                <div class="clerifix">&nbsp;</div>
                                    <div class="alert alert-danger">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <?php if(\Illuminate\Support\Facades\Session::has('success')): ?>
                                <div class="clerifix">&nbsp;</div>
                                    <div class="alert alert-success">
                                        <button class="close" data-close="alert"></button>
                                        <?php echo e(Session::get('success')); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(\Illuminate\Support\Facades\Session::has('fail')): ?>
                                <div class="clerifix">&nbsp;</div>
                                    <div class="alert alert-danger">
                                        <button class="close" data-close="alert"></button>
                                        <ul>
                                            
                                                <li><?php echo e(Session::get('fail')); ?></li>
                                           
                                        </ul>
                                    </div>
                                <?php endif; ?>

                        <!-- END PAGE HEADER-->
						<?php 
								$tdate = strtotime("now");
								$todate = strtotime("-24 hours");
								if($intro->linkval >= $tdate && $intro->expirelink == 0) {
						?>
                        <form class="form-horizontal" method="post" role="form" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?> 
							<div class="form-group">
                                <label for="name" class="col-md-2 control-label">New password<span class="required">*</span></label>
                                <div class="col-md-4">
                                    <div class="input-icon">
                                        <input type="hidden" name="uid" value="<?php if(isset($intro->id) && !empty($intro->id)){ echo  $intro->id; } ?>" class="form-control" id="" placeholder=""> 
                                        <input type="password" required onkeyup="change_pass" name="password" id="password" class="form-control" id="" placeholder=""> 
										<span class="error" id="error_password">
										<span><b>Note: </b> Password must contain minimum 8 letter from which at least one lowercase , one uppercase , one digit , special character letter  </span>
									</div>
                                </div>
                            </div>
							<div class="form-group">
                                <label for="name" class="col-md-2 control-label">Confirm password<span class="required">*</span></label>
                                <div class="col-md-4">
                                    <div class="input-icon">
                                        <input type="password" onkeyup="change_pass" required name="cpassword" id="cpassword" class="form-control" id="" placeholder=""> 
										<span class="error" id="error_cpassword">
									</div>
                                </div>
                            </div>
							
							<div class="form-group">
                                <div class="col-md-offset-2 col-md-10">
                                    <button type="submit"  class="btn green">Submit</button>
                                </div>
                            </div>
                        </form>
						<?php } else if($intro->expirelink == 1) {?>
						<div class="form-group">
							<label for="name" class="col-md-12 control-label">Now you are able to login in application from this set passowrd...</label>
						</div>
						<?php  } else { ?>
						<div class="form-group">
							<label for="name" class="col-md-12 control-label">Your password link has expired. Please use the 'forgot password' option in the application to send a new link to your registered email ID</label>
						</div>
						<?php } ?>

                    <?php $__env->stopSection(); ?>  
             <?php $__env->startPush('pagelevelplugin'); ?> 
            <?php $__env->stopPush(); ?> 

            <?php $__env->startPush('pagelevelscript'); ?>
					
            <?php $__env->stopPush(); ?>
             <?php $__env->startPush('customscripts'); ?>
			 <?php $__env->stopPush(); ?>
<?php echo $__env->make('adminsource', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>