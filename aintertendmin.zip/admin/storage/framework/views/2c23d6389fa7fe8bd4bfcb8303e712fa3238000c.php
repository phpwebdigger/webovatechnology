<table class="table table-bordered">
    <thead>
        <tr>
            <th>Sr. No.</th>
			<th>Title</th>
			<th>User Name</th>
			<th>Image / video</th>
			<th>Value</th>
			<th>Data</th>
			<th>Status</th>
			<th>Action</th>
        </tr>
    </thead>

    <?php
    if (isset($result) && !empty($result['result'])) 
	{
        $i = $start + 1;
		foreach ($result['result'] as $introlist) 
		{
			
			?>
            <tbody>
                <tr align="left">
                    <td><?php echo $i ;?></td>
                    <td>
						<?php echo isset($introlist->content_title) && (strlen(strip_tags($introlist->content_title))>20) ? substr(strip_tags($introlist->content_title),'0', '20').'...' : strip_tags($introlist->content_title);  ?>
					</td>
					<td>
						<?php echo $introlist->name;  ?>
					</td>
					<?php if($introlist->type_name =='images') { ?>
					<td onclick="set_id('<?php echo $introlist->id; ?>')" data-toggle="modal" data-target="#myModal">
						<img src="<?php echo $introlist->thumbnail_image; ?>" alt="No Image" width="100" height="50">
					</td>
					<?php } else {  ?>
					<td onclick="set_id('<?php echo $introlist->id; ?>')" data-toggle="modal" data-target="#myModal">
						<!--<iframe height="75" width="75" src="<?php echo $introlist->thumbnail_image; ?>"></iframe>-->
						<video width="100" height="50" controls="controls" type="video/mp4" autoplay="false" preload="none"><source src="<?php echo $introlist->thumbnail_image; ?>">Your browser does not support the video tag.</video>
					</td>
					<?php } ?>
					<td>
						<?php echo isset($introlist->content_value) && (strlen(strip_tags($introlist->content_value))>20) ? substr(strip_tags($introlist->content_value),'0', '20').'...' : strip_tags($introlist->content_value);  ?>
					</td>
					<td>
						<?php echo isset($introlist->content_data) && (strlen(strip_tags($introlist->content_data))>20) ? substr(strip_tags($introlist->content_data),'0', '20').'...' : strip_tags($introlist->content_data);  ?>
					</td>
					<td>
						<?php echo $introlist->content_status; ?>
					</td>
					<td>
						<span>
							<a href="/editcontent/<?php echo e(Crypt::encrypt($introlist->id)); ?>" class="btn btn-outline btn-circle btn-sm purple">
								<i class="fa fa-edit"></i>Edit 
							</a>
						</span>
						<a href="/deletecontent/<?php echo e(Crypt::encrypt($introlist->id)); ?>" onclick=" return confirm('Are you really want to delete?')" class="btn btn-outline btn-circle dark btn-sm black">
							<i class="fa fa-trash-o"></i>Delete 
						</a>
						<!--<span>
							<form action="<?php echo e(url('deletecontent', [$introlist->id])); ?>" method="POST">
							   <?php echo e(method_field('DELETE')); ?>

							   <?php echo csrf_field(); ?> 
							   <input type="submit" onclick=" return confirm('Are you really want to delete?')" class="btn btn-outline btn-circle dark btn-sm black" value="Delete"/>
							</form>
						</span>-->
					</td>
                </tr>
            </tbody>
		<?php $i++; }
    } 
	else 
	{ ?>
        <tbody>
            <tr>
                <td colspan="6" align="center"> <strong>No Result Found </strong></td>
            </tr>
        </tbody>
	<?php } ?>
</table>
<?php
$paging = custompaging($cur_page, $no_of_paginations, $previous_btn, $next_btn, $first_btn, $last_btn);
echo $paging;
?>
<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title pull-left">View Content Data</h4>
				<button type="button" class="btn btn-default pull-right" data-dismiss="modal" style="margin:0px 0px 0px 0px;">Close</button>
			</div>
			<div class="modal-body" id="gallery_content">
				
			</div>
			<div class="modal-footer">
				<!--<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>-->
			</div>
		</div>
	</div>
</div>

 <!--<div class="modal fade" id="myModal2" role="dialog" style="background:red; z-index:999999; width:100%; height:100%;">
    
  </div>-->
  
  
 
<!-- Modal -->
<script>
	function set_id(gallery_id)
	{
		mypopup_data(gallery_id);
	}
	function mypopup_data(gallery_id)
	{
		$.ajax({
			headers: {
					  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
					},
			type : 'POST',
			url : 'gallery_popup',
			data : { gallery_id:gallery_id },
			beforeSend : function()
			{
				//$('.modal-body').html();				
				//$('.modal-body').html();				
				$('#gallery_content').html();				
			},
			success : function(res)
			{
				//$('.modal-body').html(res);										
				//$('.modal-body').html(res);										
				$('#gallery_content').html(res);										
			}
		});
	}
</script>