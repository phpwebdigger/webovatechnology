<!-- BEGIN FOOTER -->
            <div class="page-footer">
                <div class="page-footer-inner"> <?php echo date('Y'); ?> &copy;
                    <span>Checkapp</span>
                </div>
                <div class="scroll-to-top">
                    <i class="icon-arrow-up"></i>
                </div>
            </div>
            <!-- END FOOTER -->
        </div>
        
        <!--[if lt IE 9]>
        <script src="../assets/global/plugins/respond.min.js"></script>
        <script src="../assets/global/plugins/excanvas.min.js"></script> 
        <script src="../assets/global/plugins/ie8.fix.min.js"></script> 
        <![endif]-->
        <!-- BEGIN CORE PLUGINS -->
        <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/js/js.cookie.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/js/jquery.slimscroll.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/js/jquery.blockui.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/js/bootstrap-switch.min.js')); ?>" type="text/javascript"></script>
        <!-- END CORE PLUGINS -->
        <!-- BEGIN PAGE LEVEL SCRIPTS -->
       
         <?php echo $__env->yieldPushContent('counterplugin'); ?>
        <script src="<?php echo e(asset('assets/js/moment.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/js/morris.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/js/raphael-min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/js/amcharts.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/js/serial.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/js/pie.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/js/radar.js')); ?>" type="text/javascript"></script>
       
            <?php echo $__env->yieldPushContent('pagelevelplugin'); ?>
       
        <!-- END PAGE LEVEL PLUGINS -->
		<!-- BEGIN PAGE LEVEL PLUGINS -->
        <script src="<?php echo e(asset('assets/global/plugins/bootstrap-wysihtml5/wysihtml5-0.3.0.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/global/plugins/bootstrap-wysihtml5/bootstrap-wysihtml5.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/global/plugins/bootstrap-markdown/lib/markdown.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/global/plugins/bootstrap-markdown/js/bootstrap-markdown.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/global/plugins/bootstrap-summernote/summernote.min.js')); ?>" type="text/javascript"></script>
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
        <script src="<?php echo e(asset('assets/js/app.min.js')); ?>" type="text/javascript"></script>
        <!-- END THEME GLOBAL SCRIPTS -->
		<script src="<?php echo e(asset('assets/pages/scripts/components-editors.min.js')); ?>" type="text/javascript"></script>
        <!-- BEGIN PAGE LEVEL SCRIPTS -->
            <?php echo $__env->yieldPushContent('pagelevelscript'); ?>
        <!-- END PAGE LEVEL SCRIPTS -->
        <!-- BEGIN THEME LAYOUT SCRIPTS -->
        <script src="<?php echo e(asset('assets/js/layout.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/js/demo.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/js/quick-sidebar.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/js/quick-nav.min.js')); ?>" type="text/javascript"></script>
        <!-- END THEME LAYOUT SCRIPTS -->
        
        <?php echo $__env->yieldPushContent('customscripts'); ?>
    </body>

</html>