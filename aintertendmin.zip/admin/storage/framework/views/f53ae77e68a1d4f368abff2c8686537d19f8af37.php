           

         <?php $__env->startSection('content'); ?>

                        
                        <!-- BEGIN PAGE HEADER-->
                        <!-- BEGIN PAGE BAR -->
                        <div class="page-bar">
                            <ul class="page-breadcrumb">
                                <li>
                                    <a href="/">Home</a>
                                    <i class="fa fa-circle"></i>
                                </li>
                                <li>
                                    <span>Dashboard</span>
                                </li>
                            </ul>
                        </div>
                        <!-- END PAGE BAR -->
                        <!-- BEGIN PAGE TITLE-->
						<div><b>Coming Soon</b></div>
                        <!-- End PAGE TITLE-->
                          <?php $__env->stopSection(); ?>  
            

            


                    
                       
                  
    
<?php echo $__env->make('adminsource', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>