  

         <?php $__env->startSection('content'); ?>
		 <?php $segment1 =  Request::segment(1); ?>
                        <!-- BEGIN PAGE HEADER-->
                        <!-- BEGIN PAGE BAR -->
                        <div class="page-bar">
                            <ul class="page-breadcrumb">
                                <li>
                                    <a href="/">Home</a>
                                    <i class="fa fa-circle"></i>
                                </li>
                                <li>
                                    <span><?php if($segment1=='editappuser'){ echo 'Edit';} else { echo 'Add';} ?> Application User</span>
                                </li>
                            </ul>
                        </div>
                        <!-- END PAGE BAR -->
                        <!-- BEGIN PAGE TITLE-->
                        <h1 class="page-title"> 
                        </h1>
                        <!-- END PAGE TITLE-->

                        <?php if($errors->any()): ?>
                                <div class="clerifix">&nbsp;</div>
                                    <div class="alert alert-danger">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <?php if(\Illuminate\Support\Facades\Session::has('success')): ?>
                                <div class="clerifix">&nbsp;</div>
                                    <div class="alert alert-success">
                                        <button class="close" data-close="alert"></button>
                                        <?php echo e(Session::get('success')); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(\Illuminate\Support\Facades\Session::has('fail')): ?>
                                <div class="clerifix">&nbsp;</div>
                                    <div class="alert alert-danger">
                                        <button class="close" data-close="alert"></button>
                                        <ul>
                                            
                                                <li><?php echo e(Session::get('fail')); ?></li>
                                           
                                        </ul>
                                    </div>
                                <?php endif; ?>

                        <!-- END PAGE HEADER-->
                        <form class="form-horizontal" method="post" role="form" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?> 
							<div class="form-group">
								<div class="col-md-6">
									<label for="name" class="col-md-4 control-label">Name<span class="required">*</span></label>
									<div class="col-md-8">
										<div class="input-icon">
											<i class="icon-user"></i>
											<input type="hidden" name="uid" value="<?php if(isset($intro->id) && !empty($intro->id)){ echo  $intro->id; } ?>" class="form-control" id="" placeholder=""> 
											<input type="text" required name="name" value="<?php if(isset($intro->name) && !empty($intro->name)){ echo  $intro->name; } ?>" class="form-control" id="" placeholder=""> 
										</div>
									</div>
								</div>
								<div class="col-md-6">
									<label for="name" class="col-md-4 control-label">Email<span class="required">*</span></label>
									<div class="col-md-8">
										<div class="input-icon">
											<i class="icon-user"></i>
											<input type="hidden" name="uid" value="<?php if(isset($intro->id) && !empty($intro->id)){ echo  $intro->id; } ?>" class="form-control" id="" placeholder=""> 
											<input type="text" required name="email" value="<?php if(isset($intro->email) && !empty($intro->email)){ echo  $intro->email; } ?>" class="form-control" id="" placeholder=""> 
										</div>
									</div>
								</div>
                            </div>
							<div class="form-group">
								<div class="col-md-6">
									<label for="name" class="col-md-4 control-label">Age<span class="required">*</span></label>
									<div class="col-md-8">
										<div class="input-icon">
											<i class="icon-user"></i>
											<input type="hidden" name="uid" value="<?php if(isset($intro->id) && !empty($intro->id)){ echo  $intro->id; } ?>" class="form-control" id="" placeholder=""> 
											<input type="text" required name="age" value="<?php if(isset($intro->age) && !empty($intro->age)){ echo  $intro->age; } ?>" class="form-control" id="" placeholder=""> 
										</div>
									</div>
								</div>
								<div class="col-md-6">
									<label for="name" class="col-md-4 control-label">Phone<span class="required">*</span></label>
									<div class="col-md-8">
										<div class="input-icon">
											<i class="icon-user"></i>
											<input type="hidden" name="uid" value="<?php if(isset($intro->id) && !empty($intro->id)){ echo  $intro->id; } ?>" class="form-control" id="" placeholder=""> 
											<input type="text" required name="phone" value="<?php if(isset($intro->phone) && !empty($intro->phone)){ echo  $intro->phone; } ?>" class="form-control" id="" placeholder=""> 
										</div>
									</div>
								</div>
                            </div>
							<div class="form-group">
                                <div class="col-md-12 text-center">
                                    <button type="submit" class="btn green">Submit</button>
                                </div>
                            </div>
                        </form>

                    <?php $__env->stopSection(); ?>  
             <?php $__env->startPush('pagelevelplugin'); ?> 
            <?php $__env->stopPush(); ?> 

            <?php $__env->startPush('pagelevelscript'); ?> 
            <?php $__env->stopPush(); ?>
             <?php $__env->startPush('customscripts'); ?>
              <?php $__env->stopPush(); ?>
<?php echo $__env->make('adminsource', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>