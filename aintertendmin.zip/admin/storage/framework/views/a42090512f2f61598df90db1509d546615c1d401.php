   
    <?php $__env->startSection('content'); ?>
                        <!-- BEGIN PAGE HEADER-->
                        <!-- BEGIN PAGE BAR -->
                        <div class="page-bar">
                            <ul class="page-breadcrumb">
                                <li>
                                    <a href="/">Home</a>
                                    <i class="fa fa-angle-right"></i>
                                </li>
                                <li>
                                    <span>Media for Upload List</span>
                                </li>
                            </ul>
                        </div>
                               <?php if($errors->any()): ?>
                                <div class="clerifix">&nbsp;</div>
                                    <div class="alert alert-danger">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <?php if(\Illuminate\Support\Facades\Session::has('success')): ?>
                                <div class="clerifix">&nbsp;</div>
                                    <div class="alert alert-success">
                                        <button class="close" data-close="alert"></button>
                                        <?php echo e(Session::get('success')); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(\Illuminate\Support\Facades\Session::has('fail')): ?>
                                <div class="clerifix">&nbsp;</div>
                                    <div class="alert alert-danger">
                                        <button class="close" data-close="alert"></button>
                                        <ul>
                                            
                                                <li><?php echo e(Session::get('fail')); ?></li>
                                           
                                        </ul>
                                    </div>
                                <?php endif; ?>
                        <!-- END PAGE BAR -->
                        <!-- BEGIN PAGE TITLE-->
                        <h1 class="page-title"> </h1>
              
            <div id="content">
              <div class="row">
		
                <div class="col-md-12">
             
                
		   <div class="col-md-5">
         <p id="mesrdss"> </p>
                  <select name="source" class="form-control col-md-6 lsscss"  data-selected-text-format="count" id="source">
			<option value=''>-- Select Source--</option>
                     <?php  foreach ($source as $key => $value) { ?>
                       <option value="<?php echo $value->source; ?>" ><?php echo $value->source; ?></option>
                <?php  }?> 
                  </select>
                </div>
		
		              <div class="col-md-5">
                    <p id="mesrd"> </p>
                  <select name="channel_name" class="form-control col-md-4 lsscs" id="channel_name">
                    <option value=''>-- Select Channel--</option>
                   
                  </select>
                </div>

                   <div class="col-md-2">
                 <input type="button" name="filter_data" id="filter_data" value="Filter"> 
                </div>
              </div>


                <div class="col-md-12">
                  <!-- BEGIN SAMPLE FORM PORTLET-->
                  <div class="portlet box yellow">
                    <div class="portlet-title">
                      <div class="caption" style="width: 100%;">
                        Media Upload file List
                      
                      </div>


                    </div>
                       <div class="portlet-body">
                        <input type="hidden" name="perpage" id="perpage" value="10">
                      
                        <input type="button" name="" id="Upload" value="Upload" class="btn btn-primary pull-right">
                          <div id="edit-count-checked-checkboxes">
     
                            </div>
                      <div class="row">   
                        <div class="col-md-12">
                          <div class="" id="post_data">
                            <!-- async hit comes here -->
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- END SAMPLE FORM PORTLET-->
                </div>
              </div>
          </div>

            <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Media Upload</h4>
		 <p id="gty"></p>

        </div>
         <form class="form-group" name="postvalue" id="postvalue"  method="post">

          <input type="hidden" name="media_source_id" id="media_source_id" value="" >

        <div class="modal-body">
        
            <label for="status">Status</label>
          <select name="action_status" id="action_status" required class="form-control data_select" placeholder="Select">
               <option value="pending">Pending</option>
              <option value="reject">Reject</option>
              <option value="approve">Approve</option>
            </select>
         <label for="language">Language Choose</label>   
         <select name="language_choose[]" multiple="multiple" required data-selected-text-format="count"  style="width:100%; display:block;"   id="language_choose" class="form-control ac">
            <option value="">Select Language</option>
              <?php  foreach ($lang_list as $key => $value) { ?>
              <option value="<?php echo $value->id; ?>" ><?php echo $value->name_locale; ?></option>
    
                <?php  }?> 

            </select> 
         <label for="category">category</label>   
        <select name="category_choose[]" multiple="multiple" required data-selected-text-format="count"  id="category_choose" class="form-control ls"  style="width:100%; display:block;">
              <option value="">Select category</option>
              <?php  foreach ($cat_list as $key => $value) { ?>
                <option value="<?php echo $value->id; ?>"><?php echo $value->cat_name; ?></option>
    
                <?php  }?> 

            </select>

              <label for="category">Content Title</label>   
              <input type="text" name="content_title" class="form-control" id="content_title" placeholder="Content Title" autocomplete="off">

                <label for="category">Content Value</label>   
             <textarea name="description" cols="4" rows="4"  class="form-control" class="widebox" id="description"></textarea>

                <label for="category">Start Date</label>   
             <input type="text" name="start_date" class="form-control datepicker" data-date-format="dd/mm/yyyy"  id="start_date" value="" autocomplete="off" placeholder="dd/mm/yyyy">



                <label for="category">End Date</label>   
           <input type="text" name="end_date" id="end_date" class="form-control datepicker" data-date-format="dd/mm/yyyy"  value="" autocomplete="off" placeholder="dd/mm/yyyy">

		        <label for="category">priority</label>   
        <select name="priority"  required data-selected-text-format="count"  id="priority" class="form-control lsp"  style="width:100%; display:block;">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            </select>

            </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" id="submitmodal">Submit</button>
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
        </form>
      </div>
      <input type="hidden" name="pagination_number" id="current_page">
    </div>
  </div>
            <!-- END PAGE CONTENT-->

                    <?php $__env->stopSection(); ?>
  <?php $__env->startPush('pagelevelplugin'); ?>        

  <link rel="stylesheet" href="<?php echo e(asset('assets/css/grid.css?v=2')); ?>">

  <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css">
  <?php $__env->stopPush(); ?>

  <?php $__env->startPush('customscripts'); ?>  
  <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>

<script type="text/javascript">
$(document).ready(function() {
 var page_no;
  $.fn.select2.defaults.set("theme", "classic");
                $('.ac').select2({ placeholder: "Select a Language",allowClear: true});

                $('.lsscs').select2({ closeOnSelect : true, placeholder: "Select a Source",allowClear: true,allowHtml: true,
      allowClear: true,
      tags: true});

                $('.lsscss').select2({ closeOnSelect : true,placeholder: "Select a channel",allowClear: true,allowHtml: true,
                allowClear: true,
                 tags: true});
        
$('.ls').select2({ placeholder: "Select a Category",  allowClear: true});
 
 var _token = $('input[name="_token"]').val();

 load_data('','','', _token,'');


$('#language_choose').select2({
  closeOnSelect : false,placeholder: "Select a channel",allowClear: true,allowHtml: true,
      allowClear: true,
      tags: true,
    dropdownParent: $('#myModal')
  });



$('#category_choose').select2({
  closeOnSelect : false,placeholder: "Select a channel",allowClear: true,allowHtml: true,
      allowClear: true,
      tags: true,
    dropdownParent: $('#myModal')
  });

 // $(document).on('click', '#load_more_button', function(){
 //  var id = $(this).data('id');
 //  $('#load_more_button').html('<b>Loading...</b>');
 //  load_datas(id, '','',_token);
 // });





// sync the state to the input
 $(document).on("click", ".image-checkbox", function (e) {
  $(this).toggleClass('image-checkbox-checked');
  
  var $checkbox = $(this).find('input[type="checkbox"]');

  $checkbox.prop("checked",!$checkbox.prop("checked"));
  
    count = 0;
    $("#edit-count-checked-checkboxes").html('');
    $("input[name='image[]']").each(function(index, checkbox){
      if(checkbox.checked)
        count = parseInt(count) + 1; // convert to integer
    })

    $("#edit-count-checked-checkboxes").append('<strong style="color:red">You Have Select Total Number of Images= </strong>  <b>'+ count +'</b>');
  e.preventDefault();

});




             
$(".image-checkbox").each(function () {
  if ($(this).find('input[type="checkbox"]').first().attr("checked")) {
    $(this).addClass('image-checkbox-checked');
  }
  else {
    $(this).removeClass('image-checkbox-checked');
  }
});
  

  $('#start_date').datepicker({
        autoclose: true, 
        todayHighlight: true,
        format: 'dd/mm/yyyy',

  });

  $('#end_date').datepicker({

 autoclose: true, 
        todayHighlight: true,format: 'dd/mm/yyyy',
  });

});

$('#filter_data').on("click",function(){
  var channel_name=$("#channel_name option:selected" ).val();
  var source=$("#source option:selected" ).val();
  var _token = $('input[name="_token"]').val();
   load_data("", channel_name,source,_token,'');
});


$("#source").on("change",function() {
  var select_channel = $(this).val();
  var _token = $('input[name="_token"]').val();
  $("#channel_name").html('');
 $.ajax({
   url:"<?php echo e(route('loadchannel_data')); ?>",
   method:"GET",
   data:{select_channel:select_channel,_token:_token},
   beforeSend : function()
      {
            $("#mesrd").html('Please Wait');
      },
   success:function(data)
   {
    $.each(data, function (key, value) {
    $("#channel_name").append($('<option>', {
        value: value.channel_name,
        text: value.channel_name,
        'data-mark': value.channel_name
    }));
    });
     $("#mesrd").html('');
   }
  });
});

$('body').on('click', '.pagination a', function(e) {
        e.preventDefault();
  var _token = $('input[name="_token"]').val();

        $('.data li').removeClass('active');
        $(this).parent('li').addClass('active');
       page_no =$(this).attr('href').split('page=')[1]; 

 //       load_data("","","",_token,page_no);

		var channel_name=$("#channel_name option:selected" ).val();
  var source=$("#source option:selected" ).val();
  var _token = $('input[name="_token"]').val();
   load_data("", channel_name,source,_token,page_no);

        $("#current_page").val(page_no);
        // location.hash = page_no;
        
    });





$('#Upload').on("click",function(){
 var source = [];
 $('input[name="image[]"]:checked').each(function() {
 source.push($(this).val());   
 });
 if (source.length === 0) {
  alert("first select some Images");
}
else{
  $("#media_source_id").val(source);

   $('#myModal').modal(); 
}

});


$("#submitmodal").on('click',function() {

  

    var select_value = $("#action_status").val();
    var category_choose = $("#category_choose").val();
    var language_choose = $("#language_choose").val();
    var content_title = $("#content_title").val();
    var description = $("#description").val();
    var source = $("#sources").val();
    var start_date = $("#start_date").val();
    var end_date = $("#end_date").val();
    var table_id = $("#media_source_id").val();
	var priority = $("#priority").val();	
  var curt_pag=$("#current_page").val();
    $.ajax({
      headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          },
      type : 'POST',
      url : 'loadaddforuploa',
      data : { 
          'table_id':table_id,
          'select_value':select_value,
          'language_choose':language_choose,
          'category_choose':category_choose,
          'content_title':content_title,
          'description':$.trim(description),
          'source':source,
          'start_date':start_date,'end_date':end_date,'priority':priority,
          '_rts':Math.floor(Math.random() * (100 - 1)) + 1 },
      beforeSend : function()
      {
		$("#gty").html("Please Wait...........");            
      },
      success : function(res)
      {
        	 alert(res.success); 
	    var channel_name=$("#channel_name option:selected" ).val();
  var source=$("#source option:selected" ).val();
  var _token = $('input[name="_token"]').val();
   load_data("", channel_name,source,_token,curt_pag);
   $("#edit-count-checked-checkboxes").html('');
	$("#gty").html("");
          $('#myModal').modal('hide');


	   }
    });



});

 function load_data(id="",channel="",source="", _token,page)
 {
  $('#post_data').html('');
  $.ajax({
   url:"<?php echo e(route('loadmore.load_data')); ?>",
   method:"GET",
   data:{id:id,channel:channel,source:source,_token:_token,'page':page},
   success:function(data)
   {
    $('#load_more_button').remove();
    
    $('#post_data').html(data);
   }
  })
 }

   function YourMethod(){
    
                                       var curt_pag = parseInt($('.goto').val());
                 
                    var no_of_pages = parseInt($('#total_number').val());
                    if(curt_pag != 0 && curt_pag <= no_of_pages){
				var channel_name=$("#channel_name option:selected" ).val();
  var source=$("#source option:selected" ).val();
  var _token = $('input[name="_token"]').val();
   load_data("", channel_name,source,_token,page_no);

                       //load_data("", "","","",curt_pag);//  gridloader(page);
                    }else{
                        alert('Enter a PAGE between 1 and '+no_of_pages);
                        $('.goto').val("").focus();
                        return false;
                    }
                  
      }

</script>
  
 <?php $__env->stopPush(); ?>

<?php echo $__env->make('adminsource', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>