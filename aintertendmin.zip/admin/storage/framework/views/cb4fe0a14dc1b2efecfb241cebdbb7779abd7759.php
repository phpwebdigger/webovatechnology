<style type="text/css">
	.select2-search__field{
		width: 135px !important;
	}
	.data_select{
		width: 114px !important;
	}
</style>
 <?php if($errors->any()): ?>
                                <div class="clerifix">&nbsp;</div>
                                    <div class="alert alert-danger">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <?php if(\Illuminate\Support\Facades\Session::has('success')): ?>
                                <div class="clerifix">&nbsp;</div>
                                    <div class="alert alert-success">
                                        <button class="close" data-close="alert"></button>
                                        <?php echo e(Session::get('success')); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(\Illuminate\Support\Facades\Session::has('fail')): ?>
                                <div class="clerifix">&nbsp;</div>
                                    <div class="alert alert-danger">
                                        <button class="close" data-close="alert"></button>
                                        <ul>
                                            
                                                <li><?php echo e(Session::get('fail')); ?></li>
                                           
                                        </ul>
                                    </div>
                                <?php endif; ?>
<table class="table table-bordered" id="example">
    <thead>
        <tr>
            <th>Sr. No.</th>
			<th>Source</th>
			<th>Channel Name</th>
			<th>Media Path</th>
			<th>File</th>
			<th>Status</th>
			<th>Language</th>
			<th>Category</th>
			<th>Content Title</th>
			<th>Content Value</th>
			<th>Start Date</th>
			<th>End Date</th>
			<th>Action</th>
        </tr>
    </thead>

    <?php
    $file_imges_mime=array('jpg','png','jpeg','gif','webp','jfif');

    $allowedExts_video = array('mp4', 'mpg', 'mpeg', 'mov', 'avi', 'flv', 'wmv','ogg','3gp','mobi','m4b','mov');
    	
   	//echo count($result['result']);
    if (isset($result) && !empty($result['result'])) 
	{

        $i = $start + 1;
		foreach ($result['result'] as $introlist) 
		{
		?>
          <tbody>
                <tr align="left">

                    <td><?php echo $i ;?></td>
  <input type="hidden" value="<?php echo $introlist->source;?>"  name="source" id="sources<?php echo $i;?>">
<input type="hidden" value="<?php echo $introlist->id;?>"  name="new_media_id" id="new_media_id<?php echo $i;?>">  
                    <td><?php echo $introlist->source;?></td>
 <input type="hidden" value="<?php echo $introlist->channel_name;?>"  name="channel_name" id="channel_names<?php echo $i;?>">
					<td><?php echo $introlist->channel_name; ?></td>
					  <input type="hidden" value="<?php echo str_replace("/var/www/html/", "http://134.209.157.201/", $introlist->media_path); ?>"  name="media_path" id="media_path<?php echo $i;?>">
					<?php if(in_array($introlist->file_type,$file_imges_mime)) { ?>
					<td onclick="set_id('<?php echo $introlist->id; ?>')" data-toggle="modal" data-target="#myModal">
						<img src="<?php echo str_replace("/var/www/html/", "http://134.209.157.201/", $introlist->media_path); ?>" alt="No Image" width="100" height="50">
					</td>
					<?php } else if(in_array($introlist->file_type,$allowedExts_video)) {  ?>
					<td onclick="set_id('<?php echo $introlist->id; ?>')" data-toggle="modal" data-target="#myModal">
						<video width="100" height="50" controls="controls" type="video/mp4" autoplay="false" preload="none"><source src="<?php echo str_replace("/var/www/html/", "http://134.209.157.201/", $introlist->media_path); ?>">Your browser does not support the video tag.</video>
					</td>
					<?php } ?>
					 <input type="hidden" value="<?php echo $introlist->file_type; ?>"  name="file_type" id="file_types<?php echo $i;?>">
					<td><?php echo $introlist->file_type; ?></td>

					<td>

							<select name="action_status" id="action_status<?php echo $i;//$introlist->id; ?>" class="form-control data_select"  onChange="onChangedisplay()">
							<option value="--" <?php  echo isset($introlist->current_status) ? (is_null($introlist->current_status)) ? 'selected':'':'';?>  >--</option>
							<option value="pending" <?php  echo isset($introlist->current_status) ? ($introlist->current_status=='pending') ? 'selected':'':'';?>  >Pending</option>
							<option value="reject" <?php  echo isset($introlist->current_status) ? ($introlist->current_status=='reject') ? 'selected':'':'';?>>Reject</option>
							<option value="approve" <?php  echo isset($introlist->current_status) ? ($introlist->current_status=='approve') ? 'selected':'':'';?>>Approve</option>
						</select>
					
					</td>
					<td> 
						<div id="selects">
						<select name="language_choose"  required multiple="multiple" data-selected-text-format="count"  style="width:100%; display:block;"   id="language_choose<?php echo $i;//$introlist->id; ?>" class="form-control lc  ">
						<option value="">Select Language</option>
							<?php  foreach ($lang_list as $key => $value) { ?>
							<option value="<?php echo $value->id; ?>" ><?php echo $value->name_locale; ?></option>
		
								<?php  }?> 

						</select> 
					</div>
					</td>

					
						<td> 
							
							<select name="category_choose" required data-selected-text-format="count"  id="category_choose<?php echo $i;//$introlist->id; ?>" class="ac " multiple="multiple">
							<option value="">Select category</option>
							<?php  foreach ($cat_list as $key => $value) { ?>
			<option value="<?php echo $value->id; ?>"><?php echo $value->cat_name; ?></option>
		
								<?php  }?> 

						</select>
					
						 </td>
						 <td>
				<input type="text" name="content_title" id="content_title<?php echo $introlist->id; ?>" placeholder="Content Title">
						 </td>
						 <td>
		
				 <textarea name="description" cols="4" rows="4" class="widebox" id="description<?php echo $i;//introlist->id; ?>">
                </textarea>
						 </td>
						 <td>
						 	<input type="date" name="start_date" id="start_date<?php echo $i;//introlist->id; ?>" value="<?php echo('Y-m-d');?>">
						 </td>
						  <td>
						 	<input type="date" name="end_date" id="end_date<?php echo $i;//introlist->id; ?>" value="<?php echo('Y-m-d');?>">
						 </td>

						 <td>

						<span>
						<a  href="#" id="save_status" onClick="save_status('<?php echo  $i;//$introlist->id; ?>')" class="btn btn-outline btn-circle btn-sm purple">
							<i class="fa fa-save"></i> Update </a>
						
						</span>
					
					</td>
                </tr>
            </tbody>
		<?php $i++; }
    } 
	else 
	{ ?>
        <tbody>
            <tr>
                <td colspan="6" align="center"> <strong>No Result Found </strong></td>
            </tr>
        </tbody>
	<?php } ?>
</table>
<?php
$paging = custompaging($cur_page, $no_of_paginations, $previous_btn, $next_btn, $first_btn, $last_btn);
echo $paging;
?>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title pull-left">View Media from Upload Data</h4>
				<button type="button" class="btn btn-default pull-right" data-dismiss="modal" style="margin:0px 0px 0px 0px;">Close</button>
			</div>
			<div class="modal-body" id="gallery_content">
				
			</div>
			<div class="modal-footer">
				<!--<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>-->
			</div>
		</div>
	</div>
</div>

 <!--<div class="modal fade" id="myModal2" role="dialog" style="background:red; z-index:999999; width:100%; height:100%;">
    
  </div>-->
  
  
 
<!-- Modal -->
<script>
	$(document).ready( function(){
		$.fn.select2.defaults.set("theme", "classic");
	 	            $('.ac').select2({ placeholder: "Select a Category",
    allowClear: true});
        
$('.lc').select2({ placeholder: "Select a Language",
    allowClear: true});

// 	 	  $('ac,.lc').on('select2:opening select2:closing', function( event ) {
//     var $searchfield = $(this).parent().find('.select2-search__field');
//     $searchfield.prop('disabled', true);
// });
 	
	});
	function set_id(gallery_id)
	{
		mypopup_data(gallery_id);
	}

	function save_status(table_id) {
		save_media_upload_file(table_id);
	}


	function mypopup_data(gallery_id)
	{
		$('#gallery_content').html('<p>Loading...</p>');	
		$.ajax({
			headers: {
					  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
					},
			type : 'POST',
			url : 'media_gallery_popup',
			data : { gallery_id:gallery_id },
			beforeSend : function()
			{
				$('#gallery_content').html();		
			},
			success : function(res)
			{
					$('#gallery_content').html(res);	
			}
		});
	}


	function save_media_upload_file(table_id){

		var select_value = $("#action_status"+table_id).val();
		var category_choose = $("#category_choose"+table_id).val();
		var language_choose = $("#language_choose"+table_id).val();
		var content_title = $("#content_title"+table_id).val();
		var description = $("#description"+table_id).val();
		var source = $("#sources"+table_id).val();
		var channel_name = $("#channel_names"+table_id).val();
		var media_path = $("#media_path"+table_id).val();
		var file_type = $("#file_types"+table_id).val();
		var new_media_id = $("#new_media_id"+table_id).val();
		var start_date = $("#start_date"+table_id).val();
		var end_date = $("#end_date"+table_id).val();
		$.ajax({
			headers: {
					  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
					},
			type : 'POST',
			url : 'testing_addmediaforuploa',
			data : { 'table_id':table_id,
					'select_value':select_value,
					'language_choose':language_choose,
					'category_choose':category_choose,
					'content_title':content_title,
					'description':$.trim(description),
					'source':source,
					'channel_name':channel_name,
					'media_path':media_path,
					'file_type':file_type,
					'new_media_id':new_media_id,'start_date':start_date,'end_date':end_date,
					'_rts':Math.floor(Math.random() * (100 - 1)) + 1 },
			beforeSend : function()
			{
						
			},
			success : function(res)
			{
				 // alert(res.success);
				 // var page = $('.current').attr('p');
				  //gridloader(page);
			}
		});


	}


	function onChangedisplay(){
		// if(document.getElementById("action_status").value != "")
  //        document.getElementById("save_status").classList.remove('disabled');
		// else
		//  document.getElementById("save_status").classList.add('disabled');
	}



</script>
