Hi, <?php echo e($name); ?>

Sending Mail to reset your password
Please click here <?php echo e(url('forgotpassword/'.$id)); ?>