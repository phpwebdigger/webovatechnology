<table class="table table-bordered">
    <thead>
        <tr>
            <th>Sr. No.</th>
			<th>Subject</th>
			<th>Title</th>
			<th>Description</th>
			<th>Request Date</th>
			<th>Action</th>
        </tr>
    </thead>

    <?php
    if (isset($result) && !empty($result['result'])) 
	{
        $i = $start + 1;
		foreach ($result['result'] as $introlist) 
		{
			
			?>
            <tbody>
                <tr align="left">
                    <td><?php echo $i ;?></td>
                    <td><?php echo $introlist->subject;?></td>
					<td><?php echo $introlist->title;?></td>
					<td><?php echo isset($introlist->description) && (strlen(strip_tags($introlist->description))>20) ? substr(strip_tags($introlist->description),'0', '20').'...' : strip_tags($introlist->description);  ?></td>
					<td><?php echo date('M d, Y',strtotime($introlist->request_date));?></td>
					<td>
						<!--<span>
							<a href="/editfeedback/<?php echo e(Crypt::encrypt($introlist->id)); ?>" class="btn btn-outline btn-circle btn-sm purple">
								<i class="fa fa-edit"></i>Edit 
							</a>
						</span>-->
						<a href="/deletefeedback/<?php echo e(Crypt::encrypt($introlist->id)); ?>" onclick=" return confirm('Are you really want to delete?')"class="btn btn-outline btn-circle dark btn-sm black">
							<i class="fa fa-trash-o"></i>Delete 
						</a>
						<!--<span>
							<form action="<?php echo e(url('deletefeedback', [$introlist->id])); ?>" method="POST">
							   <?php echo e(method_field('DELETE')); ?>

							   <?php echo csrf_field(); ?> 
							   <input type="submit" onclick=" return confirm('Are you really want to delete?')" class="btn btn-outline btn-circle dark btn-sm black" value="Delete"/>
							</form>
						</span>-->
					</td>
                </tr>
            </tbody>
		<?php $i++; }
    } 
	else 
	{ ?>
        <tbody>
            <tr>
                <td colspan="6" align="center"> <strong>No Result Found </strong></td>
            </tr>
        </tbody>
	<?php } ?>
</table>
<?php
$paging = custompaging($cur_page, $no_of_paginations, $previous_btn, $next_btn, $first_btn, $last_btn);
echo $paging;
?>