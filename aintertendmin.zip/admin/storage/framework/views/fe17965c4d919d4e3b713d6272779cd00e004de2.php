  

         <?php $__env->startSection('content'); ?>
		 <?php $segment1 =  Request::segment(1); ?>
                        <!-- BEGIN PAGE HEADER-->
                        <!-- BEGIN PAGE BAR -->
                        <div class="page-bar">
                            <ul class="page-breadcrumb">
                                <li>
                                    <a href="/">Home</a>
                                    <i class="fa fa-circle"></i>
                                </li>
                                <li>
                                    <span><?php if($segment1=='editcontent'){ echo 'Edit';} else { echo 'Add';} ?> Clinic Cases</span>
                                </li>
                            </ul>
                        </div>
                        <!-- END PAGE BAR -->
                        <!-- BEGIN PAGE TITLE-->
                        <h1 class="page-title"> 
                        </h1>
                        <!-- END PAGE TITLE-->

                        <?php if($errors->any()): ?>
                                <div class="clerifix">&nbsp;</div>
                                    <div class="alert alert-danger">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <?php if(\Illuminate\Support\Facades\Session::has('success')): ?>
                                <div class="clerifix">&nbsp;</div>
                                    <div class="alert alert-success">
                                        <button class="close" data-close="alert"></button>
                                        <?php echo e(Session::get('success')); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(\Illuminate\Support\Facades\Session::has('fail')): ?>
                                <div class="clerifix">&nbsp;</div>
                                    <div class="alert alert-danger">
                                        <button class="close" data-close="alert"></button>
                                        <ul>
                                            
                                                <li><?php echo e(Session::get('fail')); ?></li>
                                           
                                        </ul>
                                    </div>
                                <?php endif; ?>

                        <!-- END PAGE HEADER-->
                        <form class="form-horizontal" method="post" role="form" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?> 
							<div class="form-group">
                                <label for="name" class="col-md-2 control-label">Content Title<span class="required">*</span></label>
                                <div class="col-md-4">
                                    <div class="input-icon">
                                        <input type="hidden" name="uid" value="<?php if(isset($intro->id) && !empty($intro->id)){ echo  $intro->id; } ?>" class="form-control" id="" placeholder=""> 
                                        <input type="title" required name="content_title" value="<?php if(isset($intro->content_title) && !empty($intro->content_title)){ echo  $intro->content_title; } ?>" class="form-control" id="" placeholder=""> 
                                    </div>
                                </div>
                            </div>
							<div class="form-group">
                                <label for="name" class="col-md-2 control-label">Content Value<span class="required">*</span></label>
                                <div class="col-md-10">
                                    <div class="input-icon">
                                        <textarea  name="content_value" class="summernote_1"><?php if(isset($intro->content_value) && !empty($intro->content_value)){ echo  $intro->content_value; } ?></textarea>
                                    </div>
                                </div>
                            </div>
							<div class="form-group">
                                <label for="name" class="col-md-2 control-label">Content data<span class="required">*</span></label>
                                <div class="col-md-10">
                                    <div class="input-icon">
                                        <textarea  name="content_data" class="summernote_1"><?php if(isset($intro->content_data) && !empty($intro->content_data)){ echo  $intro->content_data; } ?></textarea>
                                    </div>
                                </div>
                            </div>
							<div class="form-group">
                                <div class="col-md-offset-2 col-md-10">
                                    <button type="submit" class="btn green">Submit</button>
                                </div>
                            </div>
                        </form>

                    <?php $__env->stopSection(); ?>  
             <?php $__env->startPush('pagelevelplugin'); ?> 
            <?php $__env->stopPush(); ?> 

            <?php $__env->startPush('pagelevelscript'); ?> 
            <?php $__env->stopPush(); ?>
             <?php $__env->startPush('customscripts'); ?>
              <?php $__env->stopPush(); ?>
<?php echo $__env->make('adminsource', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>