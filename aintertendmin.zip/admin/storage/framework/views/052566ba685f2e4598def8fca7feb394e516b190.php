  

         <?php $__env->startSection('content'); ?>
                        <!-- BEGIN PAGE HEADER-->
                        <!-- BEGIN PAGE BAR -->
                        <div class="page-bar">
                            <ul class="page-breadcrumb">
                                <li>
                                    <a href="/">Home</a>
                                    <i class="fa fa-circle"></i>
                                </li>
                                <li>
                                    <span>Edit Contact</span>
                                </li>
                            </ul>
                        </div>
                        <!-- END PAGE BAR -->
                        <!-- BEGIN PAGE TITLE-->
                        <h1 class="page-title"> 
                        </h1>
                        <!-- END PAGE TITLE-->

                        <?php if($errors->any()): ?>
                                <div class="clerifix">&nbsp;</div>
                                    <div class="alert alert-danger">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <?php if(\Illuminate\Support\Facades\Session::has('success')): ?>
                                <div class="clerifix">&nbsp;</div>
                                    <div class="alert alert-success">
                                        <button class="close" data-close="alert"></button>
                                        <?php echo e(Session::get('success')); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(\Illuminate\Support\Facades\Session::has('fail')): ?>
                                <div class="clerifix">&nbsp;</div>
                                    <div class="alert alert-danger">
                                        <button class="close" data-close="alert"></button>
                                        <ul>
                                            
                                                <li><?php echo e(Session::get('fail')); ?></li>
                                           
                                        </ul>
                                    </div>
                                <?php endif; ?>

                        <!-- END PAGE HEADER-->
                        <form class="form-horizontal" method="post" role="form" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?> 
							<div class="form-group">
                                <label for="name" class="col-md-2 control-label">Email<span class="required">*</span></label>
                                <div class="col-md-4">
                                    <div class="input-icon">
                                        <i class="icon-user"></i>
                                        <input type="hidden" name="uid" value="<?php if(isset($intro->id) && !empty($intro->id)){ echo  $intro->id; } ?>" class="form-control" id="" placeholder=""> 
                                        <input type="email" pattern="[^ @]*@[^ @]*" required name="email" value="<?php if(isset($intro->email) && !empty($intro->email)){ echo  $intro->email; } ?>" class="form-control" id="" placeholder=""> 
                                    </div>
                                </div>
                            </div>
							<div class="form-group">
                                <label for="name" class="col-md-2 control-label">Mobile<span class="required">*</span></label>
                                <div class="col-md-4">
                                    <div class="input-icon">
                                        <i class="icon-user"></i>
                                        <input type="text" maxlength="10" required name="mobile" value="<?php if(isset($intro->mobile) && !empty($intro->mobile)){ echo  $intro->mobile; } ?>" class="form-control" id="" placeholder=""> 
                                    </div>
                                </div>
                            </div>
							<div class="form-group">
                                <label for="name" class="col-md-2 control-label">Address<span class="required">*</span></label>
                                <div class="col-md-4">
                                    <div class="input-icon">
                                        <textarea rows="4" name="address" cols="100"><?php if(isset($intro->address) && !empty($intro->address)){ echo  $intro->address; } ?></textarea>
									</div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-offset-2 col-md-10">
                                    <button type="submit" class="btn green">Submit</button>
                                </div>
                            </div>
                        </form>

                    <?php $__env->stopSection(); ?>  
             <?php $__env->startPush('pagelevelplugin'); ?> 
            <?php $__env->stopPush(); ?> 

            <?php $__env->startPush('pagelevelscript'); ?> 
            <?php $__env->stopPush(); ?>
             <?php $__env->startPush('customscripts'); ?>
              <?php $__env->stopPush(); ?>
<?php echo $__env->make('adminsource', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>