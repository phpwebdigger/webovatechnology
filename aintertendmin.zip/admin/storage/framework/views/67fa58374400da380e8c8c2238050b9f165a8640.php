      
    <?php $__env->startSection('content'); ?>
                        <!-- BEGIN PAGE HEADER-->
                        <!-- BEGIN PAGE BAR -->
                        <div class="page-bar">
                            <ul class="page-breadcrumb">
                                <li>
                                    <a href="/">Home</a>
                                    <i class="fa fa-angle-right"></i>
                                </li>
                                <li>
                                    <span>Country List</span>
                                </li>
                            </ul>
                        </div>
                        <!-- END PAGE BAR -->
                        <!-- BEGIN PAGE TITLE-->
                        <h1 class="page-title"> </h1>
                        <!-- END PAGE TITLE-->
                        <!-- END PAGE HEADER-->
                        <!-- BEGIN PAGE CONTENT-->
						<div id="content">
							<div class="row ">
								<div class="col-md-12">
									<!-- BEGIN SAMPLE FORM PORTLET-->
									<div class="portlet box yellow">
										<div class="portlet-title">
											<div class="caption" style="width: 100%;">
												Country List
												<span style="float: right; margin-right: 10px; display:none">
													<div class="icon-bg pull-left btn btn-success btn-sm">
														<a href="/addcountry" id="" class="btn sbold green gap-right"> Add New
															<i class="fa fa-plus-circle"></i>
														</a>
													</div>
												</span>  
											</div>
										</div>
										<div class="portlet-body">
											<div><?php //echo get_flashmsg(); ?></div>
											<?php //echo form_open('', 'method="post"'); ?>
											<form class="form-horizontal" method="post" role="form" enctype="multipart/form-data">
												<div class="row" style="padding-bottom: 10px;">
													<div class="col-md-6">
														<div class="show-left col-md-2">Show</div>
														<div class="col-md-4">
															<select class="form-control" id="perpage" name="perpage">
																<option value="10">10</option>
																<option value="20">20</option>
																<option value="30">30</option>
																<option value="50">50</option>
																<option value="100">100</option>
																<option value="1">All</option>
															</select>
														</div>
														<div class="show-right">Rows</div>
													</div>
													<div class="col-md-6">
														<div class="col-md-5 pull-right">
														<input type="text" name="search" id="search" class="form-control" placeholder="Search" /> </div>
													</div>
												</div>
											</form>
											<div class="row">   
												<div class="col-md-12">
													<div class="table-responsive confirms margin-sm-top" id="gridlisting">
														<!-- async hit comes here -->
													</div>
												</div>
											</div>
										</div>
									</div>
									<!-- END SAMPLE FORM PORTLET-->
								</div>
							</div>
						</div>
						<!-- END PAGE CONTENT-->

                    <?php $__env->stopSection(); ?>

         <?php $__env->startPush('pagelevelplugin'); ?>           
         <!-- BEGIN PAGE LEVEL SCRIPTS -->
        <script src="<?php echo e(asset('assets/js/datatable.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/js/datatables.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/js/datatables.bootstrap.js')); ?>" type="text/javascript"></script>
        <!-- END PAGE LEVEL SCRIPTS -->
        <?php $__env->stopPush(); ?> 
         <?php $__env->startPush('pagelevelscript'); ?>
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
        <script src="<?php echo e(asset('assets/js/app.min.js')); ?>" type="text/javascript"></script>
        <!-- END THEME GLOBAL SCRIPTS -->


        <!-- BEGIN PAGE LEVEL SCRIPTS -->
        <script src="<?php echo e(asset('assets/js/table-datatables-responsive.min.js')); ?>" type="text/javascript"></script>
        <!-- END PAGE LEVEL SCRIPTS -->

          <?php $__env->stopPush(); ?>

            <?php $__env->startPush('customscripts'); ?>  
			<script>
			$(document).ready(function() {
				gridloader('<?php echo $pageno; ?>');
				//==========Page click==========//
				$('#gridlisting').on('click','li.active',function(){
					var page = $(this).attr('p');
					gridloader(page);
				});
				//==========Close Page click==========//
				//==========Change Per Page==========//
				$('#perpage').change(function () {
					gridloader(1);
				});
				//==========Close Change Per Page==========//
				//==========On Search Load Grid============//
				$('#gridsearch').click(function(){
					gridloader(1);
				});
				$("#search").keyup(function(){
					gridloader(1);
				});
				//=========Close On Search Load Grid======//
				
			});
			function gridloader(page)
			{
				$.blockUI();
				var perpage = $("#perpage").val();
				var search = $("#search").val();
				//var token_value=$( "input[name='"+token_name+"']" ).val();
				$.ajax
				({
					headers: {
					  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
					},
					type: "POST",
					url: '/ajax_list_items',
					data: "page="+page+"&perpage="+perpage+"&search="+search,
					success: function(response)
					{
					   $("#gridlisting").html(response);
					   $.unblockUI();
					}
				}); 
			}
			</script>
                  <?php $__env->stopPush(); ?>
<?php echo $__env->make('adminsource', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>