      
    <?php $__env->startSection('content'); ?>
                        <!-- BEGIN PAGE HEADER-->
						 <link href="<?php echo e(asset('assets/global/plugins/bootstrap-multiselect/css/bootstrap-multiselect.css')); ?>" rel="stylesheet" type="text/css" />
                        <!-- BEGIN PAGE BAR -->
                        <div class="page-bar">
                            <ul class="page-breadcrumb">
                                <li>
                                    <a href="/">Home</a>
                                    <i class="fa fa-angle-right"></i>
                                </li>
                                <li>
                                    <span>Upload Data</span>
                                </li>
                            </ul>
                        </div>
                        <!-- END PAGE BAR -->
                        <!-- BEGIN PAGE TITLE-->
                        <h1 class="page-title"> </h1>
                        <!-- END PAGE TITLE-->
                        <!-- END PAGE HEADER-->
                        <div class="row">
                            <div class="col-md-12">
                                <!-- BEGIN EXAMPLE TABLE PORTLET-->
                                <div class="portlet light bordered">
                                    <div class="portlet-title">
                                        <div class="caption font-dark">
                                            <!--<i class="icon-basket-loaded font-dark"></i>-->
                                            <span class="caption-subject bold uppercase">Upload Data</span>
                                        </div>
                                        <div class="actions" style="display:none;">
                                            <div class="btn-group">
                                                <a href="/addcategory" id="" class="btn sbold green gap-right"> Add New
                                                    <i class="fa fa-plus"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="portlet-body customer">
										<button type="button" class="waves-effect waves-light btn modal-trigger" data-toggle="modal" data-target="#myModal"> Upload Data</button>
									</div>
                                </div>
                                <!-- END EXAMPLE TABLE PORTLET-->
                            </div>
                        </div>
<!-- Modal -->
<style>
.choose-txt{text-align:left; width:100%;}
.form-group{margin-left:50px;padding-bottom: 31px;}
.choose-txt {text-align: center;width: 100%;font-size: 22px;}
</style>
<div id="myModal" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<!-- <button type="button" class="close" data-dismiss="modal">&times;</button> -->
				<h4 class="modal-title pull-left">Add Gallery</h4>
				<a href="#!" class="modal-action modal-close waves-effect btn waves-green btn-flat" style="float: right;
				margin-top: -70px;">close</a>
			</div>
			<div class="modal-content" id="gallery_content">
				<form class="form-horizontal" method="post" role="form" enctype="multipart/form-data">
				
					<div class="form-group">
						<!--<div class="row" style="margin-top: 10px;">
							<div class="col-md-6">
								<label>Language</label>
								<select class="mt-multiselect btn btn-default" multiple="multiple" data-width="50%">
									<option value="1">Option 1</option>
									<option value="2" selected="selected">Option 2</option>
									<option value="3" selected="selected">Option 3</option>
									<option value="4">Option 4</option>
									<option value="5">Option 5</option>
									<option value="6">Option 6</option>
								</select>
							</div>
							<div class="col-md-6">
								<label>Zone</label>
								<select class="mt-multiselect btn btn-default" multiple="multiple" data-width="50%">
									<option value="1">Option 1</option>
									<option value="2" selected="selected">Option 2</option>
									<option value="3" selected="selected">Option 3</option>
									<option value="4">Option 4</option>
									<option value="5">Option 5</option>
									<option value="6">Option 6</option>
								</select>
							</div>
						</div>-->
						<div class="row" >
							<label class="choose-txt">Choose Files</label>
							<input type="file" class="upload_6" id="userfile" name="files[]" />
							<button type="button" id="uploadimage" onclick="upload_Image()" class="btn green">Submit</button>
							
						</div>
					</div>
					
				 </form>
			</div>
		</div>
	</div>
</div>
<!-- Modal -->
                    <?php $__env->stopSection(); ?>

         <?php $__env->startPush('pagelevelplugin'); ?>           
         <!-- BEGIN PAGE LEVEL SCRIPTS -->
        <script src="<?php echo e(asset('assets/js/datatable.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/js/datatables.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/js/datatables.bootstrap.js')); ?>" type="text/javascript"></script>
        <!-- END PAGE LEVEL SCRIPTS -->
        <?php $__env->stopPush(); ?> 
         <?php $__env->startPush('pagelevelscript'); ?>
		  <!-- BEGIN PAGE LEVEL PLUGINS -->
        <script src="<?php echo e(asset('assets/global/plugins/bootstrap-multiselect/js/bootstrap-multiselect.js')); ?>" type="text/javascript"></script>
        <!-- END PAGE LEVEL PLUGINS -->
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
        <script src="<?php echo e(asset('assets/js/app.min.js')); ?>" type="text/javascript"></script>
        <!-- END THEME GLOBAL SCRIPTS -->


        <!-- BEGIN PAGE LEVEL SCRIPTS -->
        <script src="<?php echo e(asset('assets/js/table-datatables-responsive.min.js')); ?>" type="text/javascript"></script>
		<script src="<?php echo e(asset('assets/pages/scripts/components-bootstrap-multiselect.min.js')); ?>" type="text/javascript"></script>
        <!-- END PAGE LEVEL SCRIPTS -->

          <?php $__env->stopPush(); ?>

            <?php $__env->startPush('customscripts'); ?> 
			<link href="<?php echo e(asset('assets/jquery-filer/css/jquery.filer.css')); ?>" rel="stylesheet"/>
			<link href="<?php echo e(asset('assets/jquery-filer/css/themes/jquery.filer-dragdropbox-theme.css')); ?>" rel="stylesheet"/>
			<script src="<?php echo e(asset('assets/jquery-filer/js/jquery.filer.js')); ?>" type="text/javascript"></script> 
			<script src="<?php echo e(asset('assets/jquery-filer/js/custom.js')); ?>" type="text/javascript"></script>
			<script>
				function upload_data()
				{
					$.ajax({
						headers: {
								  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
								},
						type : 'POST',
						url : 'gallery_popup',
						data : { gallery_id:gallery_id },
						success : function(res)
						{
							//$('.modal-body').html(res);										
							//$('.modal-body').html(res);										
							$('#gallery_content').html(res);										
						}
					});
				}
				function upload_Image()
				{
					$.ajax({
						headers: {
								  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
								},
						type : 'POST',
						url : 'gallery_popup',
						data : { gallery_id:gallery_id },
						beforeSend : function()
						{
							//$('.modal-body').html();				
							//$('.modal-body').html();				
							$('#gallery_content').html();				
						},
						success : function(res)
						{
							//$('.modal-body').html(res);										
							//$('.modal-body').html(res);										
							$('#gallery_content').html(res);										
						}
					});
				}
			</script>




            <?php $__env->stopPush(); ?>
<?php echo $__env->make('adminsource', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>