
  

         <?php $__env->startSection('content'); ?>
		 <?php $segment1 =  Request::segment(1); ?>
                        <!-- BEGIN PAGE HEADER-->
                        <!-- BEGIN PAGE BAR -->
                        <div class="page-bar">
                            <ul class="page-breadcrumb">
                                <li>
                                    <a href="/">Home</a>
                                    <i class="fa fa-circle"></i>
                                </li>
                                <li>
                                    <span><?php if($segment1=='editcontent'){ echo 'Edit';} else { echo 'Add';} ?> Content</span>
                                </li>
                            </ul>
                        </div>
                        <!-- END PAGE BAR -->
                        <!-- BEGIN PAGE TITLE-->
                        <h1 class="page-title"> 
                        </h1>
                        <!-- END PAGE TITLE-->

                        <?php if($errors->any()): ?>
                                <div class="clerifix">&nbsp;</div>
                                    <div class="alert alert-danger">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <?php if(\Illuminate\Support\Facades\Session::has('success')): ?>
                                <div class="clerifix">&nbsp;</div>
                                    <div class="alert alert-success">
                                        <button class="close" data-close="alert"></button>
                                        <?php echo e(Session::get('success')); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(\Illuminate\Support\Facades\Session::has('fail')): ?>
                                <div class="clerifix">&nbsp;</div>
                                    <div class="alert alert-danger">
                                        <button class="close" data-close="alert"></button>
                                        <ul>
                                            
                                                <li><?php echo e(Session::get('fail')); ?></li>
                                           
                                        </ul>
                                    </div>
                                <?php endif; ?>

                        <!-- END PAGE HEADER-->
                <form class="form-horizontal" method="post" role="form" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?> 
                                <div class="form-group">
                                <label for="name" class="col-md-2 control-label">Content Id</label>
                                <div class="col-md-4">
                                    <div class="input-icon">
                                    <span ><?php echo $intro->id;?></span>
                                    </div>
                                </div>
                            </div>

							<div class="form-group">
                                <label for="name" class="col-md-2 control-label">Content Title</label>
                                <div class="col-md-4">
                                    <div class="input-icon">
                                        <input type="hidden" name="uid" value="<?php if(isset($intro->id) && !empty($intro->id)){ echo  $intro->id; } ?>" class="form-control" id="" placeholder=""> 
                                        <input type="title"  name="content_title" value="<?php if(isset($intro->content_title) && !empty($intro->content_title)){ echo  $intro->content_title; } ?>" class="form-control" id="" placeholder=""> 
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="name" class="col-md-2 control-label">Ocr Text</label>
                                <div class="col-md-4">
                                    <div class="input-icon">
                                          <input type="text"  name="ocr_text" value="<?php if(isset($intro->ocr_text) && !empty($intro->ocr_text)){ echo  $intro->ocr_text; } ?>" class="form-control" id="" placeholder=""> 
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="name" class="col-md-2 control-label">Language</label>
                                    <div class="col-md-4">
                                    <div class="input-icon">
                                    <select name="language_list[]"   multiple="multiple" data-selected-text-format="count"  style="width:100%; display:block;"   id="language_choose<?php echo $intro->id; ?>" class="form-control lc  ">
                        <option value="">Select Language</option>
                            <?php  
                              $Hiddenlanguage_list = explode(",",$intro->language_list);  
                              
                              $Hiddencat_list= explode(",",$intro->cat_list);
                            
                            foreach ($lang_list as $key => $value) { 
                                 if(in_array($value->id,$Hiddenlanguage_list)) 
                                 {  
                                ?>
                            <option value="<?php echo $value->id; ?>" selected='selected' ><?php echo $value->name_locale; ?></option>

                                <?php }else{?>

                                  <option value="<?php echo $value->id; ?>"  ><?php echo $value->name_locale; ?></option>

                                <?php 
                            }


                                 }
                                 ?> 

                        </select> 
                                    </div>
                                </div>
                            </div>
                               <div class="form-group">
                                <label for="name" class="col-md-2 control-label">Cateory</label>
                                    <div class="col-md-4">
                                    <div class="input-icon">
                                  <select name="cat_list[]"  data-selected-text-format="count"  id="category_choose<?php echo $intro->id; ?>" class="ac " multiple="multiple">
                            <option value="">Select category</option>
                            <?php  foreach ($cat_list as $key => $value) { 
                                  if(in_array($value->id,$Hiddencat_list)) 
                                 {  
                                ?>
                                     <option value="<?php echo $value->id; ?>" selected="selected"><?php echo $value->cat_name;?></option>
        
                                <?php  }else{?>
                                     <option value="<?php echo $value->id; ?>"><?php echo $value->cat_name; ?></option>
                                <?php 
                            }
                            }
                                ?> 

                        </select>
                                    </div>
                                </div>
                            </div>
							<div class="form-group">
                                <label for="name" class="col-md-2 control-label">Content Value</label>
                                <div class="col-md-10">
                                    <div class="input-icon">
                                        <textarea  name="content_value" class="summernote_1"><?php if(isset($intro->content_value) && !empty($intro->content_value)){ echo  $intro->content_value; } ?></textarea>
                                    </div>
                                </div>
                            </div>
		 <div class="form-group">
                                <label for="name" class="col-md-2 control-label">Content Staus</label>
                                    <div class="col-md-4">
                                    <div class="input-icon">
                                        <style type="text/css">
                                            .select2{
                                                width: 141px !important;
                                            }
                                        </style>
                                <select name="content_status" id="content_status<?php echo $intro->id; ?>" class="ac srt" >
                                <option value="ACTIVE" <?php echo ($intro->content_status=="ACTIVE") ? 'selected':''?>>ACTIVE</option>
                                <option value="PENDING" <?php echo ($intro->content_status=="PENDING") ? 'selected':''?>>PENDING</option>
                                </select>
                            </div>
                            </div>
                            </div>
							<div class="form-group">
                                <label for="name" class="col-md-2 control-label">Start date</label>
                                <div class="col-md-10">
                                    <div class="input-icon">
						 <?php 
                                            if(!empty($intro->start_time))
                                            { 
                                             $ex_date=  date("Y-m-d", strtotime($intro->start_time));
                                            } else{ 
                                                $ex_date= date('Y-m-d'); 
                                            } ?>
                            <input type="date" name="start_date" value="<?php echo $ex_date;?>" />
                                    </div>
                                </div>
                            </div>
                                <div class="form-group">
                                <label for="name" class="col-md-2 control-label">End date</label>
                                <div class="col-md-10">
                                    <div class="input-icon">
						 <?php 
                                            if(!empty($intro->expiry_time))
                                            { 
                                             $ex_date=  date("Y-m-d", strtotime($intro->expiry_time));
                                            } else{ 
                                                $ex_date='0000-00-00 00:00:00'; 
                                            } ?>
                                     <input type="date" name="end_date" value="<?php echo $ex_date; ?>"/>

                                    </div>
                                </div>
                            </div>
					
				  <div class="form-group">
                                <label for="name" class="col-md-2 control-label">Priority</label>
                                <div class="col-md-10">
                                    <div class="input-icon">
                                          
                                    <select name="priority" id="priority" class="form-control" Placeholder='Priority'>
                                    <option value="0" <?php if($intro->priority == 0) { echo ' selected="selected"'; } ?>>0</option>
                                    <option value="1" <?php if($intro->priority == 1) { echo ' selected="selected"'; } ?>>1</option>
                                    <option value="2" <?php if($intro->priority == 2) { echo ' selected="selected"'; } ?>>2</option>
                                    <option value="3" <?php if($intro->priority == 3) { echo ' selected="selected"'; } ?>>3</option>
                                    <option value="4" <?php if($intro->priority == 4) { echo ' selected="selected"'; } ?>>4</option>
                                    <option value="5" <?php if($intro->priority == 5) { echo ' selected="selected"'; } ?>>5</option>
                            </select>
                                    </div>
                                </div>
                            </div>


				<div class="form-group">
                                <div class="col-md-offset-2 col-md-10">
                                    <button type="submit" class="btn green">Submit</button>
                                </div>
                            </div>
                        </form>

                    <?php $__env->stopSection(); ?>  
             <?php $__env->startPush('pagelevelplugin'); ?> 
            <?php $__env->stopPush(); ?> 

            <?php $__env->startPush('pagelevelscript'); ?> 
            <?php $__env->stopPush(); ?>
             <?php $__env->startPush('customscripts'); ?>
            
<script type="text/javascript">
    $(document).ready( function(){
        $.fn.select2.defaults.set("theme", "classic");
                    $('.ac').select2({ placeholder: "Select a Category",
    allowClear: true});
        
$('.lc').select2({ placeholder: "Select a Language",
    allowClear: true});

 
    });
</script>
  <?php $__env->stopPush(); ?>

<?php echo $__env->make('adminsource', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>