Hi, <?php echo e($name); ?>

Sending Mail to set your password
Please click here <?php echo e(url('setpassword/'.$id)); ?>