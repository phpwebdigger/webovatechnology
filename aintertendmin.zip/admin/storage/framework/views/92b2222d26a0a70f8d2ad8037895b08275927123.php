<table class="table table-bordered">
    <thead>
        <tr>
            <th>Sr. No.</th>
			<th>Name</th>
			<th>ISO Code</th>
			<th>Un Code</th>
			<th>Dialling Code</th>
			<th>Status</th>
			<th>Action</th>
        </tr>
    </thead>

    <?php
    if (isset($result) && !empty($result['result'])) 
	{
        $i = $start + 1;
		foreach ($result['result'] as $row) 
		{
			
			?>
            <tbody>
                <tr align="left">
                    <td><?php echo $i ;?></td>
                    <td><?php echo $row->con_name;?></td>
					<td><?php echo $row->con_code_iso;?></td>
					<td><?php echo $row->con_code_un;?></td>
					<td><?php echo $row->con_dialling_code;?></td>
					<td><?php if($row->con_status==1){ echo 'Active';} else { echo 'Inactive';};?></td>
					<td>
						<span>
							<a href="/editcountry/<?php echo e(Crypt::encrypt($row->id)); ?>" class="btn btn-outline btn-circle btn-sm purple">
								<i class="fa fa-edit"></i>Edit 
							</a>
						</span>
						<!--<a href="/deletecontent/<?php echo e(Crypt::encrypt($row->id)); ?>" class="btn btn-outline btn-circle dark btn-sm black">
							<i class="fa fa-trash-o"></i>Delete 
						</a>-->
						<span style="display:none;">
							<form action="<?php echo e(url('deletecountry', [$row->id])); ?>" method="POST">
							   <?php echo e(method_field('DELETE')); ?>

							   <?php echo csrf_field(); ?> 
							   <input type="submit" onclick=" return confirm('Are you really want to delete?')" class="btn btn-outline btn-circle dark btn-sm black" value="Delete"/>
							</form>
						</span>
					</td>
                </tr>
            </tbody>
		<?php $i++; }
    } 
	else 
	{ ?>
        <tbody>
            <tr>
                <td colspan="6" align="center"> <strong>No Result Found </strong></td>
            </tr>
        </tbody>
	<?php } ?>
</table>
<?php
$paging = custompaging($cur_page, $no_of_paginations, $previous_btn, $next_btn, $first_btn, $last_btn);
echo $paging;
?>