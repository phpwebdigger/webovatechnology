      
    <?php $__env->startSection('content'); ?>
                        <!-- BEGIN PAGE HEADER-->
						 <link href="<?php echo e(asset('assets/global/plugins/bootstrap-multiselect/css/bootstrap-multiselect.css')); ?>" rel="stylesheet" type="text/css" />
                        <!-- BEGIN PAGE BAR -->
                        <div class="page-bar">
                            <ul class="page-breadcrumb">
                                <li>
                                    <a href="/">Home</a>
                                    <i class="fa fa-angle-right"></i>
                                </li>
                                <li>
                                    <span>Ftp Upload Data</span>
                                </li>
                            </ul>
                        </div>
                        <!-- END PAGE BAR -->
                        <!-- BEGIN PAGE TITLE-->
                        <h1 class="page-title"> </h1>
                        <!-- END PAGE TITLE-->
                        <!-- END PAGE HEADER-->
                        <div class="row">
                            <div class="col-md-12">
                                <!-- BEGIN EXAMPLE TABLE PORTLET-->
                                <div class="portlet light bordered">
                                    <div class="portlet-title">
                                        <div class="caption font-dark">
                                            <!--<i class="icon-basket-loaded font-dark"></i>-->
                                            <span class="caption-subject bold uppercase">Ftp Upload Data</span>
                                        </div>
                                        <div class="actions" style="display:none;">
                                            <div class="btn-group">
                                                <a href="/addcategory" id="" class="btn sbold green gap-right"> Add New
                                                    <i class="fa fa-plus"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
									<div class="portlet-body customer">
										<form class="form-horizontal" method="post" role="form" enctype="multipart/form-data">
											<?php echo csrf_field(); ?> 
											<div class="form-group" style="margin-left:0px;">
												<label for="exampleInputFile">Choose File</label>
												<input type="file" name="ftpupload"  id="exampleInputFile" />
											</div>
											<button type="submit" class="btn btn-default">Submit</button>
										</form>
									</div>
                                </div>
                                <!-- END EXAMPLE TABLE PORTLET-->
                            </div>
                        </div>

                    <?php $__env->stopSection(); ?>

         <?php $__env->startPush('pagelevelplugin'); ?>           
         <!-- BEGIN PAGE LEVEL SCRIPTS -->
        <script src="<?php echo e(asset('assets/js/datatable.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/js/datatables.min.js')); ?>" type="text/javascript"></script>
        <script src="<?php echo e(asset('assets/js/datatables.bootstrap.js')); ?>" type="text/javascript"></script>
        <!-- END PAGE LEVEL SCRIPTS -->
        <?php $__env->stopPush(); ?> 
         <?php $__env->startPush('pagelevelscript'); ?>
		
        <!-- BEGIN THEME GLOBAL SCRIPTS -->
        <script src="<?php echo e(asset('assets/js/app.min.js')); ?>" type="text/javascript"></script>
        <!-- END THEME GLOBAL SCRIPTS -->


        <!-- BEGIN PAGE LEVEL SCRIPTS -->
        <script src="<?php echo e(asset('assets/js/table-datatables-responsive.min.js')); ?>" type="text/javascript"></script>
		
        <!-- END PAGE LEVEL SCRIPTS -->

          <?php $__env->stopPush(); ?>

            <?php $__env->startPush('customscripts'); ?> 
			

            <?php $__env->stopPush(); ?>
<?php echo $__env->make('adminsource', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>