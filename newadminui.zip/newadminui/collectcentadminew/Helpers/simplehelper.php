<?php
/**
* change plain number to formatted currency
*
* @param $number
* @param $currency
*/
#namespace App\Helpers;
#use Illuminate\Support\Facades\DB;

class SimpleHelper{

	public static function getpercentage($param1, $param2){
	  if($param2 == 0 ){return 0;} 	
	   $percent =  ($param1/$param2)*100;
	   return number_format($percent,2, '.', '.');
	 }


	public static function numFormat($param1){
		if($param1 == 0 ){return 0;}
	    $formatedNumber = number_format($param1, 2, '.', ',');
	    return '$ '.$formatedNumber;
	}


  public static function intoRupees($param1){
		if($param1 == 0 ){return 0;}
	    $intoRupees = number_format($param1*65, 2, '.', ',');
	    return 'INR '.$intoRupees;
	}

	/* To check when crc_records_new was last updated 
     * Developer: Sumit Manchanda
     * Date : 25 July 2017 #12.43PM
     */
    public static function lastUpdated(){
     $lastUpdated = DB::select("SELECT max(create_time) as create_time from crc_records_new limit 1");
	 $lastUpdated_count = count($lastUpdated);
	 if($lastUpdated_count > 0)
	    if($lastUpdated[0]->create_time){
		  return $lastUpdated[0]->create_time;	
		}
      return "No Update time";  
   	}
 


}
		
							



?>
