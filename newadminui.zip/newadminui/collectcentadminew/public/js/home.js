// define application
$(function() {
    $('body').on('click', '.pagination a', function(e) {
        e.preventDefault();
        var url = $(this).attr('href');  
        getCampaignsAjax(url);
        window.history.pushState("", "", url);
    });
    $(document).ajaxStart(function(){
        $(".preloader").css("display", "block");
    });
    $(document).ajaxComplete(function(){
        $(".preloader").css("display", "none");
    });
   
});

$(function() {
	var start = moment().subtract(0, 'days');
    var end = moment();
	function cb(start, end) {
        $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
    }
	$('#reportrange').daterangepicker({
		locale: {
		format: 'YYYY-MM-DD'
		},
        startDate: start,
        endDate: end,
        ranges: {
           'Today': [moment(), moment()],
           'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
           'Last 7 Days': [moment().subtract(6, 'days'), moment()],
           'Last 15 Days': [moment().subtract(14, 'days'), moment()]
        }
    }, cb);
	cb(start, end);
   	});

    $('#reportrange').on('apply.daterangepicker', function(ev, picker) {
  	   $("input:radio").attr("checked", false);
    });
