$(document).ready(function() {
// Initializing arrays with app server names.

//Imageperfect -> 162.243.3.184

var Imageperfect = [{
display: "App5a",value: "162.243.32.94"},
{display: "App5b", value: "162.243.3.184"},
{display: "App5c(31)",value: "192.241.188.192"}];

// collectcent -> null

var collectcent = [{
display: "App2",value: "107.170.154.51"},
{display: "App3",value: "162.243.254.216"},
{display: "App6",value: "107.170.173.141"},
{display: "App8",value: "162.243.221.193"},
{display: "App10",value: "162.243.80.250"},
{display: "App12",value: "162.243.73.231"},
{display: "App13",value: "162.243.74.32"},
{display: "App15",value: "192.241.191.139"},
{display: "App16",value: "192.241.188.214"},
{display: "App17",value: "162.243.199.134"},
{display: "App18",value: "162.243.200.63"},
{display: "App20",value: "162.243.83.66"},
{display: "App21",value: "162.243.112.118"},
{display: "App22",value: "192.241.166.247"},
{display: "App25",value: "192.241.242.242"},
{display: "App26",value: "192.241.242.234"},
{display: "App27",value: "192.241.174.146"},
{display: "App28",value: "192.241.180.55"},
{display: "App29",value: "192.241.181.88"},
{display: "App30",value: "192.241.254.170"},
{display: "App38",value: "192.241.249.228"},
{display: "App39",value: "192.241.251.97"},
{display: "App40",value: "192.241.178.46"},
{display: "App41",value: "192.241.162.245"},
{display: "App48",value: "162.243.25.229"}];

//Moiads -> 162.243.7.210
var Moiads =[{display: "App34",value: "162.243.7.210" },{display: "App19",value: "162.243.80.140" }];

//SF -> 162.243.9.35
var SF =[{display: "App32",value: "162.243.9.35" }];

//MVN -> 162.243.18.13
var MVN =[{display: "App45",value: "162.243.18.13" }];

//sixTseconds -> 192.241.184.246
var sixTseconds =[{display: "App44",value: "192.241.184.246" }];

//Vacastudios -> 162.243.1.46
  var Vacastudios =[{display: "App7a(33)",value: "162.243.1.46" }];

//Adsjoy -> 192.241.245.208
  var Adsjoy =[{display: "App35",value: "192.241.245.208" },
  {display: "App35A",value: "162.243.13.141"},
  {display: "App35B",value: "162.243.13.218"}

  ];


// Function executes on change of first select option field.
$("#network_postback_source").change(function() {
var select = $("#network_postback_source option:selected").val();
switch (select) {
case "null":
selected_campany(collectcent);
break;
case "162.243.3.184":
selected_campany(Imageperfect);
break;
case "192.241.245.208":
selected_campany(Adsjoy);
break;
case "162.243.1.46":
selected_campany(Vacastudios);
break;
case "192.241.184.246":
selected_campany(sixTseconds);
break;
case "162.243.18.13":
selected_campany(MVN);
break;
case "162.243.9.35":
selected_campany(SF);
break;
case "162.243.7.210":
selected_campany(Moiads);
break;
default:
$("#Server").empty();
$("#Server").append("<option>--Select--</option>");
break;
}
});
// Function To List out campany_list in Second Select tags
function selected_campany(arr) {
$("#Server").empty(); //To reset cities
$("#Server").append("<option>--Select--</option>");
$(arr).each(function(i) { //to list cities
$("#Server").append("<option value=" + arr[i].value + ">" + arr[i].display + "</option>")
});
}

      // $("#network").change(function(){
      

});

	 $(document).on("change","#network",function(event){
      	 	
            alert("Network Name");
      var selected_network = $("#network").val();
      var datastring ="network_value="+selected_network;
      $("#country").html('');
        $.ajax({
          type: "POST",
          url:"/new_campaign_new_display_geo",
          data:datastring,
          datatype: "html",
          success:function(data){
              $("#country").append(data);
              $("#country")[0].sumo.reload();
          }
      }).done(function(data){
            $('#LoadingImage').hide();
        });
      });