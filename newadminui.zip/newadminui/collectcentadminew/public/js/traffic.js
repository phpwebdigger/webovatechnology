            var BASE_PATH     =  "/cr_new/";
             // BASE_PATH = "/c.collectcent.com29jan/www/cr_new/";
            $(window).on('load',function(){ 
                $('#overlay').fadeOut();
            });

            $(function(){
                var col = [     
                    'text_70px',
                    'text_70px',     
                    "text_70px",
                    "text_70px",
                    "text_70px",
                    "text_70px",
                    "text_70px",
                    "text_70px",
                    "text_70px",
                    'text'
                ];
            /* To Search request*/
            $('#search').click(function(){
                var network = $("#network").val();
                var status = $("#status").val();
                var operator = $("#operator").val();
                var parent_cca = $("#parent_cca").val();
                if(network == '' && status == '' && operator == '' && parent_cca == ''){
                 alert('Please choose the any option');
                 return false;
                }
                $.ajax({
                    url: BASE_PATH+"allAjax.php",
                    type: 'POST',
                    cache: false,
                    async: true,
                    data: "action=getTrfcData&network="+network+"&status="+status+"&operator="+operator+"&parent_cca="+parent_cca,
                    beforeSend: function(res){
                       $("#overlay").show();
                    },
                    success: function(res){
                        response = JSON.parse(res);
                        if(response.status == "1"){
                           $("#tableLazy").dataTable().fnClearTable();
                            $("#tableLazy").dataTable().fnDestroy();
                            $("#tableLazy .new").remove();
                            createTableWithLazyLoad("#tableLazy",response.data,200,col);
                        }else if(response.status == "2"){
                           alert('Please search again there is no result');
                        }else{
                            alert('there is some error');
                        }
                        $("#overlay").hide();
                    },
                    fail:function(err){
                      alert('Something went wrong');  
                      $("#overlay").hide();
                    },
                });
            });

        /* submit hold percentage */
        $(document).on('click','.percentange',function(){
             var percentange_id = $(this).attr('id');
             var id;
             percentange_id = percentange_id.split("_");
             if(percentange_id.length > 0){
                id = percentange_id[1];
                var hold_percentage = $("#percentage_"+id).val();
                if(hold_percentage > 0){
                    $.ajax({
                    url: BASE_PATH+"allAjax.php", // make sure you set an action attribute to your form
                    type: 'POST',
                    cache: false,
                    async: false,
                    data: "action=updateTrafficPercentage&id="+id+"&hold_percentage="+hold_percentage,
                    beforeSend: function(res){
                       $("#overlay").show();
                    },
                    success:function(res){
                        var resp = JSON.parse(res);
                        if(resp.status == 1){
                            $('#percentage_'+id).val(resp.hold_percentage);
                        }else{
                            alert('There is something went wrong');
                        }
                        $("#overlay").hide();
                        }
                    });
                }
             
             }
        });

            $(document).on("change",'.status',function(){  
                if($(this).prop('checked') === true){
                    var id = $(this).attr('id');
                    var checked_value = '1';
                }else{
                     var id = $(this).attr('id');
                     var checked_value = '0';
                }
                $.ajax({
                    url: BASE_PATH+"allAjax.php", // make sure you set an action attribute to your form
                    type: 'POST',
                    cache: false,
                    async:false,
                    data: "action=updateTrfcStatus&rand="+Math.random()+"&id="+id+"&check_value="+checked_value,
                    beforeSend: function(res){
                       $("#overlay").show();
                    },
                    success: function(response){
                         var res = JSON.parse(response);
                         if(res.status == 1){
                            $('#message_'+id).html("Active");
                         }else if(res.status == 0){
                            $('#message_'+id).html("Inactive");
                         }else{
                            alert('There is some error in it');
                         }
                         $("#overlay").hide();
                        }
                    });
            });
             
        });     