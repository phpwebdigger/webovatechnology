/* First Step call */
$(document). ready(function(){ 
            var col = [
                    'text_55px',
                    '', 
                    '',
                    '',
                    '',
                    '',
                    '',
                    '',
                    'text_55px',     
                    'text_55px',     
                    "text_55px",
                ];
        $("#search").click(function(){
        var optionValue = $("#groupby option:selected").val();
        var net_id = $("#net_id").val();
        var advertiser_id = $("#advertiser_id").val();
        var dateRange = $("#reportrange").val();
        if(optionValue == 'Group By'){
            alert("Please select any GroupBy Option");
            return false;
        }
        $.ajax({
                async: true, 
                url : '/network/getdata',
                type: 'GET',
                'data': {'type':optionValue,'daterange':dateRange,'net_id':net_id,'advertiser_id':advertiser_id}  
            }).done(function (response){
                var resp = JSON.parse(response);
                $("#tableLazy").dataTable().fnClearTable();
                $("#tableLazy").dataTable().fnDestroy();
                $("#tableLazy .new").remove();
                var head ='<thead class="new"><tr>';
                $(resp.lastRow).each(function(key,val){
                    head +='<th data-index="'+key+'" data-val="'+val+'">'+val+'</th>';
                });
                head +='</tr></thead>';
                $("#tableLazy thead").after(head);
                if(resp.status == 1){
                    createTableWithLazyLoad("#tableLazy",resp.items,200,col);
                }
            }).fail(function () {
                alert('Data could not be loaded.');
            });
       });
        $(".close").click(function(){
            var closeDivClass = $(this).attr("data-value");
            $("."+closeDivClass).remove();
        });
    });
   

