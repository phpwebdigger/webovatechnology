var BASE_PATH     =  "/cr_new/";
// BASE_PATH = "/c.collectcent.com29jan/www/cr_new/";
var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
  $(window).on('load',function(){ 
                $('#overlay').fadeOut();
            });

           var col = [     
                    "text_70px",
                    "text_70px",
                    "text_70px",
                    "text_70px",
                    "text_70px",
                    "text_70px",
                    "text_70px",
                    "text",
                    "text",
                    "text_70px"

                ];
            /* To Search request*/
            $('#search').click(function(){
                var network = $("#network").val();
                var status = $("#status").val();
                var operator = $("#operator").val();
                var parent_cca = $("#parent_cca").val();
                var id_ad = $("#id_ad_advertiser").val();
                var id_advertiser = $("#advertiser").val();
                var permanentStatus = $("#permStat").val();
                if(network == '' && status == '' && operator == '' && parent_cca == '' && id_ad=='' && id_advertiser=='' && permanentStatus==''){
                 alert('Please choose the any option');
                 return false;
                }
                $.ajax({
                    url: '/smart-traffic/filterSmartTrfcData',
                    type: 'POST',
                    cache: false,
                    async: true,
                    data: "action=getTrfcData&network="+network+"&status="+status+"&advertiser="+id_advertiser+"&permanentStatus="+permanentStatus+"&operator="+operator+"&parent_cca="+parent_cca+"&id_ad="+id_ad+"&_token="+CSRF_TOKEN,
                    beforeSend: function(res){
                       $("#overlay").show();
                    },
                    success: function(res){
                       $("#tableLazy").dataTable().fnClearTable();
                            $("#tableLazy").dataTable().fnDestroy();
                            $("#tableLazy").dataTable().fnDraw();
                        response = JSON.parse(res);
                        if(response.status == "1"){
                            $("#tableLazy").dataTable().fnClearTable();
                            $("#tableLazy").dataTable().fnDestroy();
                           
                            $("#tableLazy.new").remove();
                            createTableWithLazyLoad("#tableLazy",response.data,200,col);
                             // $("#tableLazy").dataTable().fnReloadAjax();

                        }else if(response.status == "2"){
                           $("#tableLazy").dataTable().fnClearTable();
                            $("#tableLazy").dataTable().fnDestroy();
                            $("#tableLazy").dataTable().fnDraw();
                           alert('Please search again there is no result');
                        }else{
                           $("#tableLazy").dataTable().fnClearTable();
                            $("#tableLazy").dataTable().fnDestroy();
                            alert('there is some error');
                            $("#tableLazy").dataTable().fnDraw();
                        }

                        $("#overlay").hide();
                        $('td:nth-child(10)').hide();
                    },
                    fail:function(err){
                      alert('Something went wrong');  
                      $("#overlay").hide();
                    },
                });
            });

   
            var advertiser_campaign_option = '';
            $(document).on('click','.change-campaign', function(){
                var id_ad = $(this).attr('data-value');
                var smart_trfc_config_id = $(this).attr('data-smart_id');
              
                // console.log(smart_trfc_config_id);
                var divId = $(this).attr('id');
                var id = 0;
                $('#msg').html("");
                divId  = divId.split("-");
                if(divId.length > 1){
                    id = divId[1];
                } 
                if(id_ad > 0){
                    $.ajax({
			                  url : 'urls/getUrlDataSmart',
                        type: 'GET',
                        async: true,
                        cache: false,
                        data: "id_ad="+id_ad+"&campaign_id="+smart_trfc_config_id,
                        beforeSend: function() {
                            $("#overlay").show();
                            $(".preloader").show();
                        },    
                        }).done(function (response) {
                        $(".preloader").hide();      
                        var res = response;
                        var data = res;
                       // console.log(data);
                        if(res.status == 1){
                             if(res.url_change == 1 && res.is_primary_campaign == 1){
                              alert('URL change is not allowed on this CCA');
                              return false;
                           }else{
                            advertiser_campaign_option = '';
		                $('#default_radio').prop('checked', true);
                              $('#is_smart_cpa').prop('checked', false);
                              $('#is_smart_cpi').prop('checked', false);		
                            $("#id_ad").val(data.id_ad);
			                      $("#smart_trfc_id").val(data.smarttrfc_id);	
                            $("#adv_id").val(data.advertiser_id);
                            $("#title").val(data.etitle);
                            $("#network_name").val(data.network_name);
                            $("#traffic_typ").val(data.traffic_type);
                            $("#click_url").val(data.click_url); 
                            $("#operator_name").val(data.operator_name);
                            $(data.advertiser_campaign_name).each(function(key,campaign){
                                advertiser_campaign_option += '<option value="'+campaign.id+'"">('+campaign.id+')'+campaign.name+'</option>';
                            });
                            $("#id_advertiser").html(advertiser_campaign_option).selectpicker('refresh');
                            $('#editUrl').modal({backdrop:'static'});
                            $("#div_id").val(id);
                            $("#smart_trfc_config_id").val(smart_trfc_config_id);
                          }
                        }else if(response.status == 2){
                             alert('There is something went wrong');
                        }else{
                            alert('response failed');
                        }
                        $("#overlay").hide();
                        $(".preloader").hide();      
                    }).fail(function () {
                            alert('Data could not be loaded.');
                            $("#overlay").hide();
                            $(".preloader").hide();
                    });
                }
             });   


            $(document).on("click",".radiobox", function(){
                var is_selected = $(this).attr('checked', true);
                var is_smart = $(this).val();
                var advertiser_campaign;
                if(is_smart == 'DEFAULT'){
                   $("#id_advertiser").html(advertiser_campaign_option).selectpicker('refresh');
                }else{
                if(is_selected && is_smart){
                    $("#spinner").show();
                    $.ajax({
                        url : 'urls/getCpiCpa/',
                        type: 'GET',
                        async: true,
                        cache: false,
                        data: "is_smart="+is_smart+"&_token="+CSRF_TOKEN
                    }).done(function (response){
                          try{
                          if(response.status == 1){
                                if(response.advertiser_campaign){
                                    $(response.advertiser_campaign).each(function(key,campaign){
                                       advertiser_campaign += '<option value="'+campaign.id+'"">'+campaign.name+'</option>';
                                    });
                                 }else{
                                    alert('there is no campaign');
                                 }
                               $("#spinner").hide();
                               $("#id_advertiser").html(advertiser_campaign).selectpicker('refresh');
                            }
                          }catch(err){
                             $("#spinner").hide();
                             console.log('There is some issue');
                          }  
                        // }
                        // $('#editUrl').modal({backdrop:'static'});
                    }).fail(function () {
                            alert('Data could not be loaded.');
                            $("#spinner").hide();
                    });
                }
                }        
            });


             // BASE_PATH = "/c.collectcent.com29jan/www/cr_new/";
             BASE_PATH = "";
             $(".selectpicker2").selectpicker();
                $(document).on("click",".edit-percentage", function(){
                   var hold_percentage = $(this).attr('data-value');
                   var cca = $(this).attr('data-cca');
                   var container_id = $(this).attr('id');
                   var scrollTop = $(window).scrollTop();
                   var elementOffset = $('#'+container_id).offset().top;
                   var currentElementOffset = (elementOffset - scrollTop);
                   currentElementOffset = currentElementOffset -100;
                   container_id = container_id.split("-");
                   // console.log(container_id);
                   $('.percentage-container').css({
                      "position": "relative",
                      "display": "table", 
                      "overflow-y": "auto",    
                      "overflow-x": "auto",
                      "width": "auto",
                      "min-width": "300px",
                      "margin-top":currentElementOffset, 
                      "margin-right":"35%"
                   });
                   if(container_id.length > 1){
                     $("#container_id").val(container_id[1]);
                   }
                   var content = '';
                   $.ajax({
                        url : 'smart-traffic/getPercentageOnCampaignsByCca',
                        type: 'POST',
                         async: true,
                        cache: false,
                        data: "cca="+cca+"&_token="+CSRF_TOKEN
                    }).done(function (res){
                        var response = res;
                            if(response.status == 1){
                                 // content +='<div><label>';
                                 $(response.data).each(function(key,trfc){
                                  content += '<div><label>'+trfc.campaign_name+'('+trfc.campaign_id+')</label>\n\
                                  <input type="text" class="form-control" name="hold_percentage[]" value="'+trfc.hold_percentage+'">\n\
                                  <input type="hidden" class="form-control" name="id[]" value="'+trfc.id+'"></div>';
                                 });
                                 $("#cca").val(cca);
                                 $(".editPercentageBody").html(content);
                                 ToggleEditPercentageModel();
                            }
                        $(".preloader").hide();
                    }).fail(function () {
                            alert('Data could not be loaded.');
                            $("#spinner").hide();
                    });
                    $("#hold_percentage").val(hold_percentage);
                });

                  var ToggleEditPercentageModel = function(){
                    $('#editPercentageModel').modal({
                    backdrop: 'static',
                    keyboard: false,  // to prevent closing with Esc button (if you want this too)
                    show: true
                    });
                  }

                $(document).on("click","#percentage_submit", function(){
                    var formdata = $("#smartTrfcconfig").serialize();
                    var container_id = $("#container_id").val();
                    if(formdata){
                        $.ajax({
                        url: 'smart-traffic/updateTrafficPercentage', // make sure you set an action attribute to your form
                        type: 'POST',
                         async: true,
                        cache: false,
                        data: formdata,
                        beforeSend: function(res){
                           $("#overlay").show();
                        },
                        success:function(res){
                            var resp = JSON.parse(res);
                            if(resp.status == 1){
                                $(resp.hold_percentage).each(function(val,percentage){
                                  $('#percentage-container_'+percentage.id).html(percentage.hold_percentage);
                                  $("#percentage-"+percentage.id).attr("data-value",percentage.hold_percentage); 
                                });
                            }else{
                                alert('There is something went wrong');
                            }
                            $("#overlay").hide();
                            $('#editPercentageModel').modal('hide');
                            }
                        });
                    } 

                });


              var ToggleEditWaitage = function(){
            $('#EditWaitage').modal({
            backdrop: 'static',
            keyboard: false,  // to prevent closing with Esc button (if you want this too)
            show: true,
            "width": "auto",
            "max-width": "3300px",
            refresh: true,
            // "margin-right":"35%"
            });
          }

      
         

    $(document).on('click','.btn_remove',function(){  
      var button_id = $(this).attr("id");   
        $('#row'+button_id+'').remove();  
    });  

    $("#operator_id").change(function(){
        var operator_id = $(this).val();
        var ccz = $("#ccz").val();
        var cca = '';
        $("#add_cca").empty();
        $.ajax({
          type:'post',
          url: '/smart-traffic/ccas',
          dataType:'json',
          data: {
            _token: CSRF_TOKEN,
            operator_id: operator_id,
            ccz: ccz
          },
          success: function(response){
                 if(response.status == 1){
                   $.each(response.data, function(key,value){
                      cca += '<option value="'+value.id_ad+'_'+value.campaign_id+'_'+value.cco+'">'+value.cca+'</option>';
                   });
                   $("#add_cca").html(cca).selectpicker('refresh');
                 }else {
                    alert(response.message);
                 }
              }
          });
        });

        function campaign_list(ccz,operator_id){
          $.ajax({
          type:'post',
          url: '/campaign_name_parent_cca',
          dataType:'json',
          data: {
            _token: CSRF_TOKEN,
            operator_id: operator_id,
            ccz: ccz,
          },
          success: function(response){
           $(".campaign_list"+i).append('<option value="">--Select Campagin Name--</option>');
           $.each(response, function(key,value){
                 $(".campaign_list"+i).append($('<option></option>').attr("value",key).text(value)); 
           });
                }
        });
        }
         
        $("#addSmartTrfcConfig").submit(function(e){
            $flag = 0;
            $(".hold_percentage_arr").each(function(){
               // check if value was selected
               if ($(this).val() == "") {
                   // if value is not selected set state to false
                   alert('Please add percentage for all the fields');
                   return false;
                   e.preventDefault();
                   $flag  = 1; 
               }
            });
            if($flag == 1){
              return false;
              e.preventDefault();
            } 
            var url = "/smart-traffic/create"; // the script where you handle the form input.
            $.ajax({
               type: "POST",
               url: url,
               data: $(this).serialize(), // serializes the form's elements.
               success: function(data){
                 var res = data;
                  if(res.status == 1){
                    $('#EditWaitage').modal('hide');
                     window.location.href = window.location.href;
                  }else{
                    alert('There is something went wrong'+res.message);
                  }
               }
             });
            e.preventDefault();  //avoid to execute the actual submit of the form.
        });


   $("#smartupdate").click(function(){
     var id_advertiser = $('#id_advertiser').val();
     var id_ad = $("#id_ad").val();
     var url = $("#url").val();
     //var trfc_id = $("#smart_trfc_config_id").val();
     var trfc_id = $("#smart_trfc_id").val(); 
       var smart_trfc_config_id = $('.change-campaign').attr('data-smart_id');
       $("#cca_"+trfc_id).html('');
     var msg = $('#msg');
     if(id_advertiser == "" && id_advertiser == null){
        alert('<span class="alert alert-danger">Please select valid Advertiser Name and ID !!!</span>');
        return false;
     }else if(id_ad !='' && id_advertiser !=''){
     msg.html('<span class="alert alert-info">please wait... !</span>');
     $.ajax({
        url: '/smart-traffic/UpdateCampaign/',
        data : { id_ad:id_ad,id_advertiser: id_advertiser,url:url,trfc_id:trfc_id},
        success: function(response){  // Get the result and asign to each cases
        if(response.status == 0){
          //alert(response.message);
	  // msg.html('');	
		msg.html('<span class="alert alert-success">'+response.message+'!</span>');   
        }else if(response.status == 1){
           // msg.html('<span class="alert alert-success">URL sucsessfully updated!</span>');   
           //alert(response.message);
		// msg.html('<span class="alert alert-success">'+response.message+'!</span>');   
		
           // $('#editUrl').find('form')[0].reset();
	 // msg.html('<span class="alert alert-success">'+response.message+'!</span>');   				
           //$('#editUrl').modal('hide');
           //$("#cca_"+trfc_id).html(response.data);
           //$("#cca_"+trfc_id).attr('data-smart_id',response.parent_cca);
	   //$(".preloader").hide();
	   //$('#editUrl').find('form')[0].reset();
           //$('#editUrl').modal('hide');;
		 msg.html('<span class="alert alert-success">'+response.message+'!</span>'); 
           $("#cca_"+trfc_id).html(response.data);
           $("#cca_"+trfc_id).attr('data-smart_id',response.parent_cca);
           $("#id_ad-"+trfc_id).attr('data-smart_id',response.parent_cca);
           $(".preloader").hide(); 
           setTimeout("$('#editUrl').modal('hide');",2000);

		
        }else if(response.status == 2){
          alert('<span class="alert alert-info">Problem while Tracking</span>');                                        
        }else if(response.status == 3){
          alert('<span class="alert alert-info">You are not authorised to changes Url</span>');                                        
        }
       }
    });             
    }else{
     msg.html('<span class="alert alert-danger">Oopss... !</span>');
    }
    });

    /* To change status value */
$(document).on('click', '.addMore-status',function(){ 
    var is_active = 0;

    if($(this).is(':checked')){ 
        is_active = 1;

        $(this).next().text('Active');  
    }else{
        $(this).next().text('InActive');
    }
    $(this).val(is_active);

}); //campaign-percentages



    /* Add more pop up */
    $(document).on("click",".add-more", function(){
      var content = '';
       var id = $(this).attr('data-id');
       var cco = $(this).attr('data-cco');
       var campaigns_option = '';
       $.ajax({
            url : 'smart-traffic/getPercentageOnCampaignsByCca',
            type: 'POST',
             async: true,
                        cache: false,
            data: "cca="+id+"&cco="+cco+"&_token="+CSRF_TOKEN
        }).done(function (res){
            var response = res;
              if(response.status == 1){
                     $(response.data).each(function(key,trfc){
                      var is_checked = "";
                      var status = 0;
                      var string_msg ='';
                      if(trfc.status == 1){
                        is_checked = "checked=checked";
                        status = 1;
                        string_msg ='Active';
                      }else{
                        string_msg ='Inactive';
                      }
                      content += '<div class="row margin10">\n\
                      <div class="col-sm-2">\n\
                      <label>'+trfc.network_name+'('+trfc.id_zone+')</label>\n\
                      </div>\n\
                      <div class="col-sm-2">\n\
                      <label>'+trfc.operator_name+'</label>\n\
                      </div>\n\
                      <div class="col-sm-4">\n\
                      <label>'+trfc.campaign_name+'('+trfc.campaign_id+')</label>\n\
                      </div>\n\
                      <div class="col-sm-2">\n\
                      <input type="text" class="form-control addMorePercentage" name="hold_percentage_exist['+key+']" value="'+trfc.hold_percentage+'">\n\
                      <input type="hidden" class="form-control" name="id['+key+']" value="'+trfc.id+'">\n\
                      <input type="hidden" name="campaign_id_exist['+key+']" value="'+trfc.campaign_id+'">\n\
                      </div>\n\
                      <div class="col-sm-2">\n\
                      <input type="checkbox" name="status_exist['+key+']" '+is_checked+' value="'+status+'" class="addMore-status">\n\
                      <span class="StatusText">'+string_msg+'</span>\n\
                      </div>\n\
                      </div>';
                     });
                     campaigns_option +='<div class="col-sm-4"><select id="campaignsByOperator" class="selectpicker" data-style="btn-danger" data-live-search="true" title="campaigns" data-actions-box="true" multiple>';
                     $(response.advertiser_campaigns).each(function(key,campaign){
                          campaigns_option += '<option value="'+campaign.id+'">'+campaign.name+'('+campaign.id+')--</option>';
                     });
                     campaigns_option +='</select></div><div class="col-sm-4"><input type="radio" name="is_smart" data_att="'+id+'_'+cco+'" id="default_radio" class="radiobox3" value="DEFAULT" class="radiobox2" checked="checked">\n\
                             Default<input type="radio" name="is_smart" id="is_smart_cpa" value="CPA" class="radiobox3">\n\
                             CPA<input type="radio" name="is_smart" id="is_smart_cpi" value="CPI" class="radiobox3">CPI\n\ </div>';
                     $(".addCampaign").html(campaigns_option);
                     $(".cca").html(id);
                     $("#addMore-cca").val(id);
                     $(".addMoreBody").html(content);
                     $("#campaignsByOperator").selectpicker();
                     ToggleaddMoreModel();
                     $("#campaign-percentages").html('');
                }
            $(".preloader").hide();
        }).fail(function(){
                alert('Data could not be loaded.');
                $("#spinner").hide();
        });
     });


      $(document).on("click",".radiobox3", function(){
                  var is_selected = $(this).attr('checked', true);
                var is_smart = $(this).val();
                var advertiser_campaign="";
                if(is_smart == 'DEFAULT'){
                  $("#campaignsByOperator").html('').selectpicker('refresh');;
                  var cca = $(this).attr('data_att');
                  // alert(cca);
                  cca = cca.split("_");
                 var id = cca[0];
                 var cco = cca[1];
                  $.ajax({
                    url : 'smart-traffic/getPercentageOnCampaignsByCca',
                    type: 'POST',
                    async: true,
                    data: "cca="+id+"&cco="+cco+"&_token="+CSRF_TOKEN,
               success: function(response){
                   // var response = res;
                    if(response.status == 1){
                                if(response.advertiser_campaigns){
                                    $(response.advertiser_campaigns).each(function(key,campaign){
                                       advertiser_campaign += '<option value="'+campaign.id+'"">'+campaign.name+'('+campaign.id+')--</option>';
                                    });
                                 }else{
                                    alert('there is no campaign');
                                 }
                               $("#spinner").hide();
                               $("#campaignsByOperator").html(advertiser_campaign).selectpicker('refresh');
                               $("#addCampaignsByOperator").selectpicker();
                            }
                        }
                });
                
                } else{
                if(is_selected && is_smart){
                    $("#spinner").show();
                    $.ajax({
                        url : 'urls/getCpiCpa/',
                        type: 'GET',
                        async: true,
                        data: "is_smart="+is_smart+"&_token="+CSRF_TOKEN
                    }).done(function (response){
                          try{
                          if(response.status == 1){
                                if(response.advertiser_campaign){
                                    $(response.advertiser_campaign).each(function(key,campaign){
                                       advertiser_campaign += '<option value="'+campaign.id+'"">'+campaign.name+'('+campaign.id+')--</option>';
                                    });
                                 }else{
                                    alert('there is no campaign');
                                 }
                               $("#spinner").hide();
                               $("#campaignsByOperator").html(advertiser_campaign).selectpicker('refresh');
                               $("#addCampaignsByOperator").selectpicker();
                            }
                          }catch(err){
                             $("#spinner").hide();
                             console.log('There is some issue');
                          }  
                        // }
                        // $('#editUrl').modal({backdrop:'static'});
                    }).fail(function () {
                            alert('Data could not be loaded.');
                            $("#spinner").hide();
                    });
                }
                 }     
            });

      var ToggleaddMoreModel = function(){
            $('#addMoreModel').modal({
            backdrop: 'static',
            keyboard: false,  // to prevent closing with Esc button (if you want this too)
            show: true,
            "width": "auto",
            // "margin-right":"35%"
            });
          } 
      
            /* Add more pop up */
            $(document).on("click","#addSmartTrfc", function(){
               var cca = $("#add_cca").val();
               var campaigns_option = '';
              if(cca == ""){
                alert('Please select all the option first');
                return false;
               }else{
                 cca = cca.split("_");
                 var id = cca[0];
                 var cco = cca[2];
               }
               $.ajax({
                    url : 'smart-traffic/getPercentageOnCampaignsByCca',
                    type: 'POST',
                    async: true,
                    data: "cca="+id+"&cco="+cco+"&_token="+CSRF_TOKEN
                }).done(function (res){
                    var response = res;
                        if(response.status == 1){
                            campaigns_option +='<div class="col-sm-3"><select id="addCampaignsByOperator" class="form-control selectpicker" data-style="btn-danger" data-live-search="true" title="campaigns" data-actions-box="true" multiple>';
                             $(response.advertiser_campaigns).each(function(key,campaign){
                                  campaigns_option += '<option value="'+campaign.id+'">'+campaign.name+'('+campaign.id+')--</option>';
                             });
                             campaigns_option +='</select></div><div class="col-sm-2">\n\
                             <input type="radio" name="is_smart" id="default_radio" value="DEFAULT" class="radiobox2" checked="checked">\n\
                             Default<input type="radio" name="is_smart" id="is_smart_cpa" value="CPA" class="radiobox2">\n\
                             CPA<input type="radio" name="is_smart" id="is_smart_cpi" value="CPI" class="radiobox2">CPI\n\
                             </div><div class="row"></div>\n\
                             <div class="row"><div class="col-sm-12" id="addCampaign-percentages"></div></div>';

                             $(".addMultipleCampaigns").html(campaigns_option);
                             // $("#addMore-cca").val(id);
                             // $(".addMoreBody").html(content);
                             $("#addCampaignsByOperator").selectpicker();
                             // ToggleaddMoreModel();
                        }
                    $(".preloader").hide();
                }).fail(function(){
                        alert('Data could not be loaded.');
                        $(".preloader").hide();
                });
             });


            $(document).on("click",".radiobox2", function(){
                var is_selected = $(this).attr('checked', true);
                var is_smart = $(this).val();
                var advertiser_campaign='';
                
                if(is_smart == 'DEFAULT'){
                $("#addCampaignsByOperator").html('').selectpicker('refresh');
                  var cca = $("#add_cca").val();
                  cca = cca.split("_");
                 var id = cca[0];
                 var cco = cca[2];
                  $.ajax({
                    url : 'smart-traffic/getPercentageOnCampaignsByCca',
                    type: 'POST',
                    async: true,
                    data: "cca="+id+"&cco="+cco+"&_token="+CSRF_TOKEN,
               success: function(response){
                   // var response = res;
                    if(response.status == 1){
                                if(response.advertiser_campaigns){
                                    $(response.advertiser_campaigns).each(function(key,campaign){
                                       advertiser_campaign += '<option value="'+campaign.id+'"">'+campaign.name+'('+campaign.id+')--</option>';
                                    });
                                 }else{
                                    alert('there is no campaign');
                                 }
                               $("#spinner").hide();
                               $("#addCampaignsByOperator").html(advertiser_campaign).selectpicker('refresh');
                               $("#addCampaignsByOperator").selectpicker();
                            }
                        }
                });
                
                } else{
                if(is_selected && is_smart){
                    $("#spinner").show();
                    $.ajax({
                        url : 'urls/getCpiCpa/',
                        type: 'GET',
                        async: true,
                        data: "is_smart="+is_smart+"&_token="+CSRF_TOKEN
                    }).done(function (response){
                          try{
                          if(response.status == 1){
                                if(response.advertiser_campaign){
                                    $(response.advertiser_campaign).each(function(key,campaign){
                                       advertiser_campaign += '<option value="'+campaign.id+'"">'+campaign.name+'('+campaign.id+')--</option>';
                                    });
                                 }else{
                                    alert('there is no campaign');
                                 }
                               $("#spinner").hide();
                               $("#addCampaignsByOperator").html(advertiser_campaign).selectpicker('refresh');
                                $("#addCampaignsByOperator").selectpicker();
                            }
                          }catch(err){
                             $("#spinner").hide();
                             console.log('There is some issue');
                          }  
                        // }
                        // $('#editUrl').modal({backdrop:'static'});
                    }).fail(function () {
                            alert('Data could not be loaded.');
                            $("#spinner").hide();
                    });
                }
                }        
            });


            $(document).on("change","#addCampaignsByOperator",function(){
                var camp_id = $(this).val();

                var campaign_name = $("#addCampaignsByOperator :selected").text();
                var camp_string = ""+camp_id+""; 
                $("#addCampaign-percentages").html("");
                if(camp_id == null){
                     $("#addCampaign-percentages").html("");
                     return false;
                } 
                if(camp_string.indexOf(',') != -1){
                  var  total = camp_string.split(',').length;
                  var camp_array = camp_string.split(',');
                  campaign_name = campaign_name.split('--');
                  var text = "";
                  for (i = 0; i < total;i++){
                      text += '<div class="recordRow"><div class="col-md-6"><label>'+campaign_name[i]+'</label></BR><label>Percentage:</label><input type="text" name="hold_percentage[]" class="hold_percentage_arr"><input type="hidden" name="campaign_id[]" value="'+camp_array[i]+'"></div>';
                    }
                    $("#addCampaign-percentages").html(text);
                }else{
                  text = '<div class="recordRow"><div class="col-md-6"><label>'+campaign_name+'</label></BR><label><label>Percentage:</label><input type="text" name="hold_percentage[]"><input type="hidden" name="campaign_id[]" value="'+camp_id+'"></div>';
                   $("#addCampaign-percentages").html(text);
                }
            });




         $(document).on("change","#campaignsByOperator",function(){
                var camp_id = $(this).val();
                var camp_string = ""+camp_id+""; 
          var status_text =" Inactive";
                var campaign_name = $("#campaignsByOperator :selected").text();
                if(camp_id == null) {
                     $("#campaign-percentages").html("");
                     return false;
                } 
                if(camp_string.indexOf(',') != -1) {
                  var  total = camp_string.split(',').length;
                  var camp_array = camp_string.split(',');
                  var text = "";
                  campaign_name = campaign_name.split('--');
                  var status_text =" Inactive";
                  for(i = 0; i < total; i++) {
                      text += '<div class="row margin10"><div class="col-sm-4"><label>'+campaign_name[i]+'</label>\n\
                      </div>\n\
                      <div class="col-sm-4"><input type="text" name="hold_percentage[]" class="form-control addMorePercentage" placeholder="Percentage">\n\
                      </div><div class="col-sm-4">\n\
                      <input type="hidden" name="campaign_id[]" value="'+camp_array[i]+'">\n\
                      <input type="checkbox" name="status[]" value="0" class="addMore-status"><span class="StatusText">'+status_text+'</span></div></div>';
                  }
                    $("#campaign-percentages").html(text);
                }else {
                  text = '<div class="row margin10"><div class="col-sm-4"><label>'+campaign_name+'</label></div>\n\
                  <div class="col-sm-4"><input type="text" name="hold_percentage[]" class="form-control addMorePercentage" placeholder="Percentage"></div>\n\
                  <div class="col-sm-4"><input type="hidden" name="campaign_id[]" value="'+camp_id+'">\n\
                  <input type="checkbox" name="status[]" value="0" class="addMore-status"><span class="StatusText">'+status_text+'</span></div></div>';
                   $("#campaign-percentages").html(text);
                }
            });  

        $(document).on("click","#addMore_submit", function(){
                  var flag = false;
                  $(".addMorePercentage").each(function(){
                     // check if value was selected
                     if ($(this).val() == "") {
                         
                         flag  = true;
                         // if value is not selected set state to false
                         alert('Please add percentage for all the fields');
                         return false;
                         
                     }
                  });
                  
                  if(flag){
                    return false;
                  } 
                  
                  
                  var formdata = $("#smartTrfcconfigCreate").serialize();
                  // console.log(formdata);
                   var values = jQuery("#smartTrfcconfigCreate").serializeArray();
                   // Because serializeArray() ignores unset checkboxes and radio buttons: 
                   values = values.concat(
                   jQuery('#smartTrfcconfigCreate input[type=checkbox]:not(:checked)').map(
                    function() {
                        return {"name": this.name, "value": this.value}
                    }).get()
                    );
                    var container_id = $("#container_id").val();
                    if(formdata){
                        $.ajax({
                        url: 'smart-traffic/createSmartCampaign', // make sure you set an action attribute to your form
                        type: 'POST',
                        cache: false,
                        async: false,
                        data: values,
                        beforeSend: function(res){
                           $("#overlay").show();
                        },
                        success:function(res){
                            var resp = res;
                            if(resp.status == 1){
                              $('#addMoreModel').modal('hide');
                              window.location.reload();   
                            }else{
                                
                                if(!flag){
                                alert('There is something went wrong');
                                }
                            }
                            $("#overlay").hide();
                            $('#addMoreModel').modal('hide');
                            }
                        });
                    } 

                });   


    

  $(document).on("click","input[name='is_smarttrfc_active[]']",function(event){ 
   // confirm("Would you reallylike to really make it");
   var is_active = 0;
    if($(this).is(':checked')){ 
        is_active = 1;  
    }
    $("#spinner").show();
    var id  = $(this).attr('id'); 
    $.ajax({
    url : '/smart-traffic-diversion/updatesmarttrfc',
    type: 'GET',
    data: 'action=status&status='+is_active+'&id='+id,
    async: false,
    }).done(function (response) {
        if(response.status == 1){
            $("#status-"+id).html(response.data);
        }
        $("#spinner").hide();
    }).fail(function () {
        alert('Data could not be loaded.');
        $("#spinner").hide();
    });  
});




