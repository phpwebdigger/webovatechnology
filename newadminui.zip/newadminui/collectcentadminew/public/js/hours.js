/* for date frop down*/
$(function() {

    var start = moment().subtract(0, 'days');
    var end = moment();
    function cb(start, end) {
        $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
    }
    $('#reportrange').daterangepicker({
        locale: {
        format: 'YYYY-MM-DD'
        },
        startDate: start,
        endDate: end,
        ranges: {
           'Today': [moment(), moment()],
           'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
        }
    }, cb);
    cb(start, end);
    });

    $('#reportrange').on('apply.daterangepicker', function(ev, picker) {
    $("input:radio").attr("checked", false);
    $(".main-content").html("");
    });


/* For Operator DropDown*/
function getOperators(){
     var dataSource = '';
     $.ajax({
            url : 'hourly/getoperators',
            type: 'GET',
            async: true,
        }).done(function (response) {
            dataSource =  JSON.parse(response);
            operatorDropdown(dataSource)
        }).fail(function () {
            alert('Data could not be loaded.');
        });
   }
        /*call the function for auto search*/
function operatorDropdown(dataSource){
    var OperatorOptions;
    OperatorOptions = "<option value='0'>All Operator</option>";
    $.each( dataSource, function(key,value){
        OperatorOptions += "<option value="+value.id+">"+value.operator+"</option>";  
    }); 
    $('#operator').html(OperatorOptions);  
    selectRefresh();
  }

    /* For netwok Drop down*/
    function getnetworks(){   
     var networkSource = '';
     $.ajax({
            url : 'hourly/getnetworks',
            type: 'GET',
            async: true,
        }).done(function (response) {
            networkSource =  JSON.parse(response);
            networkDropdown(networkSource)
        }).fail(function () {
            alert('Data could not be loaded.');
        });
      }
        /*call the function for auto search*/
function networkDropdown(dataSource){
         var NetworkOptions;
         // console.log(dataSource);
        $.each( dataSource, function(key,value){
          NetworkOptions += "<option value='"+value.ccz+"'>"+value.networkWithCCZ +"</option>";  
        });  
         $('#network').html(NetworkOptions); 
         selectRefresh();
    }

  function getadvertisers(){    
    /* For Advertiser Drop down*/   
     var advertiserSource = '';
     $.ajax({
            url : 'hourly/getadvertisers',
            type: 'GET',
            async: true,
        }).done(function (response) {
            advertiserSource = JSON.parse(response);
            advertiserDropdown(advertiserSource)
        }).fail(function () {
            alert('Data could not be loaded.');
        });
   }
       /*call the function for auto search*/
function advertiserDropdown(dataSource){
    var advertiserOptions;
        $.each( dataSource, function(key,value){
          advertiserOptions += "<option value="+value.id+">"+value.advertiser+"</option>";  
        });  
          $('#advertiser').html(advertiserOptions); 
          selectRefresh();  
    }

  function getcampaigns(){    
    /* For Advertiser Drop down*/   
     var campaignSource = '';
     $.ajax({
            url : 'hourly/getcampaigns',
            type: 'GET',
            async: true,
        }).done(function (response){
            var result = JSON.parse(response);
            if(result.status == "1"){  
              campaignSource =  result.data;
              campaignDropdown(campaignSource)
            }else{
             alert('Data could not be loaded.');  
            }
        }).fail(function () {
            alert('Data could not be loaded.');
        });
   }
       /*call the function for auto search*/
function campaignDropdown(dataSource){
    var campaignOptions;
        $.each( dataSource, function(key,value){
          campaignOptions += "<option value="+value.id+">"+value.name+"</option>";  
        });  
         $('#idadvt').html(campaignOptions); 
         selectRefresh();
    }    


/* Group by */
// $("#groupby").SumoSelect({search: true, searchText: 'Enter Group By.'});   
// $("#hour,#traffic_type,#report_type").SumoSelect({search:true});
// $("#country").SumoSelect({search:true});
$('#parent_cca,#id_ad').keypress(function(event){
         var theEvent = event || window.event;
          var key = theEvent.keyCode || theEvent.which;
          key = String.fromCharCode(key);
          if (key.length == 0) return;
          var regex = /^[0-9.,\b]+$/;
          if (!regex.test(key)) {
              theEvent.returnValue = false;
              if (theEvent.preventDefault) theEvent.preventDefault();
          }
});

 getadvertisers();
 getcampaigns();
 getnetworks();

function selectRefresh(){
  $('.selectpicker').selectpicker('refresh');
}

function resetFilters(){
  $(".selectpicker").val('default');
  $(".selectpicker").selectpicker("refresh");
  $("#parent_cca,#id_ad").val("");
}
