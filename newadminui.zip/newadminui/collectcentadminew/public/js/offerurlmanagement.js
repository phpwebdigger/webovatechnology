$( document ).ready(function() {

  ApplyToggle();

$("#error_country_config").hide();
  $("#responsce_after,#error_diversion_config").hide();
	var advertiser_campaign_option = '';
var count_row=$('#total_row').val();

	
	$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('[name="_token"]').val()
    }
});
	
  $(document).on("change","#smart_live",function(event){

  	  var select_row=$(this).val();

  var row_index = $(this).index();

  
  var row_value=$(this).attr('dta-val');

  var data_tag=$(this).attr('data-tag');

  var myHtml = "";
  $.ajax({
      url: '/offer-url-management-report_update',
      type: 'post',
      data: {
        id : row_value,
        data_tag:data_tag,
      status: select_row,
      action_step:'is_offer_direct'
      },
      dataType: 'html',
      success: function(response){
    	// alert(response);
    	$("#message_"+row_value).show().append(response);
    	window.setTimeout(function(){ } ,1000);
        location.reload();

       }
      
    });
});    


     

$("#edit_operator").change(function () {
	var operator_id = $(this).val();
	$("#edit_waitage").empty();
	$.ajax({
		type:'post',
		url: '/campaigns_list_operatorwaise',
		dataType:'json',
		data: {
			operator_id: operator_id
		},
		success: function(response){
			
			$("#edit_waitage").append('<option value="">--Select Campagin Name--</option>');
			$.each(response, function(key,value){
				$("#edit_waitage").append($('<option></option>').attr("value",value.id_advertiser).text(value.titles +'('+ value.id_advertiser +')')); 

			});
		}
	});


});


$("#country_oprator_edit_waitage").change(function () {
	var operator_id = $(this).val();
	$.ajax({
		type:'post',
		url: '/campaigns_list_operatorwaise',
		dataType:'json',
		data: {
			operator_id: operator_id
		},
		success: function(response){
			$("#country_name_list").empty();
			$("#country_name_list").append('<option value="">--Select Campagin Name--</option>');
			$.each(response, function(key,value){
				$("#country_name_list").append($('<option></option>').attr("value",value.id_advertiser).text(value.titles +'('+ value.id_advertiser +')')); 

			});
		}
	});


});


	


$(document).on("change",".edit_operator_append",function(event){

			// alert($(this).index());

			var row_tag= $(this).attr('data-tag');
			var operator_id = $(this).val();
	$.ajax({
		type:'post',
		url: '/campaigns_list_operatorwaise',
		dataType:'json',
		data: {
			operator_id: operator_id
		},
		success: function(response){
		
			$(".edit_waitage"+row_tag).empty();
			$(".edit_waitage"+row_tag).append('<option value="">--Select Campagin Name--</option>');
			$.each(response, function(key,value){
				$(".edit_waitage"+row_tag).append($('<option></option>').attr("value",value.id_advertiser).text(value.titles +'('+ value.id_advertiser +')')); 

			});
		}
	});
});




   $("#update_type").on('click',function(){ 
	   var mess='';
	   
	   $("#responsce_after,#error_country_config,#error_diversion_config").html('');

		var percentage =$("#percentage_value").attr('value');
		var id_value= $("#waitage_id").val();
		
		try {
		var redirect_operator_config = $.parseJSON($("#redirect_operator_config").val());
		 $("#error_country_config").hide();
		}
		catch (err) {
		  $("#error_country_config").show().append("Json is not valid "+err);
		  $("#error_country_config").focus();
		  return false;
		}
		try{
		var redirect_country_config =$.parseJSON($("#redirect_country_config").val());
				 $("#error_diversion_config").hide();
		}catch(err){
				$("#error_diversion_config").show().append("Json is not valid "+err);
				$("#error_diversion_config").focus();
				return false;
		}

		var arr=[];
	    var campagin_name = $("#edit_waitage option:selected").map(function(){
		return  $.trim(this.value)
		}).get().join(',');

	 
	   $.ajax({
      url: '/updateOfferurl_redirect_operator_config',
      type: 'post',
      data: {
        id : id_value,
        status: $(this).prop('checked'),
        action_step:'is_offer_direct',
        percentage : percentage,
        campagin_name:campagin_name,
        redirect_operator_config: {json: JSON.stringify(redirect_operator_config)},
        redirect_country_config: {json: JSON.stringify(redirect_country_config)},
        
      },
      dataType: 'json',
      success: function(response){
	   if(response.success_status == 'success'){
	   	$("#responsce_after").removeClass('label-danger').addClass('label-success').show().append("Update Successfull ");
	   	hid_modal();
	   }																																																														
      }
      
    });
	   
	     });    
       
    

       
       
         });
         
			function hid_modal(){
			setTimeout(function(){
 		 	$('#EditWaitage').modal('hide')
			}, 2000);

			}

         function ApplyToggle() {
				$('#is_offer_direct').bootstrapToggle();
		        $('[id*=is_offer_direct]').bootstrapToggle({
                    on: '<i class="fa fa-paper-plane-o"/> Send',
                    off: '<i class="fa fa-ban"/> Dont send',
                    onstyle: 'success',
                    offstyle: 'danger'
                });
            }




		function append_add_row_opertor(id,row_id){
			 $("#process").show().html('Processing....');
			  $.ajax({
			      url: '/offerurlmgntopratordiversion',
			      type: 'post',
			      data: {
			        id : id,
			      },
			      dataType: 'json',
			      success: function(response){
			      	var select_opratoe = $("#dynamic_field .edit_operator"+row_id);
			        select_opratoe.append('<option value="">--Select Operator Name--</option>');
			        $.each(response.operator_list,function(index,json){
			        select_opratoe.append($("<option></option>").attr("value", json.op_id).text(json.operator_name +"("+  json.country_code +")"));
			        }); 
			     	$("#process").hide();    
			      }
			    });


		}

	function append_country_add_row_country(id,row_id){
			 $("#process").show().html('Processing....');
			  $.ajax({
			      url: '/country_list_append',
			      type: 'get',
			      dataType: 'json',
			      success: function(response){
			      	var select_opratoe = $("#dynamic_field_country .country_list_waitage_append"+row_id);
			         select_opratoe.append('<option value="">--Select Operator Name--</option>');
			       $.each(response,function(index,json){
        select_opratoe.append($("<option></option>").attr("value", json.iso).text(json.nicename));
        
       });  
			     	$("#process").hide();    
			      }
			    });


		}



		//function append_add_row_diversion(id,row_value){
 function append_diversion_add_row_diversion(id,row_id){
	 		$("#process2").show().html('Processing....');
			  $.ajax({
			     url: '/offerurlmgntdiversion',
			type: 'post',
			data: {
				id : id,
			},
			dataType: 'json',
			success: function(response){
				var select=$("#dynamic_field_diversion .campagin_name_diversion"+row_id);
 					select.append('<option value="">--Select campaign Name--</option>');
				$.each(response.campaigns,function(index,json){
				select.append($("<option></option>").attr("value", json.campaign_id).text(json.offer_url +'('+json.campaign_id+')'));
				
			 });   
			$("#process2").hide();    
			}
			
			    });
	}



$(document).on("change",".country_list_waitage_appends",function(event){

		 // alert($(this).index());

			var row_tag= $(this).attr('data-tag-counytry');
			var operator_id = $(this).val();
	$.ajax({
		type:'post',
		url: '/campaigns_list_operatorwaise',
		dataType:'json',
		data: {
			operator_id: operator_id
		},
		success: function(response){
			
			$(".country_name_list_append"+row_tag).empty();
			$(".country_name_list_append"+row_tag).append('<option value=""> --Select Campagin Name-- </option>');
			$.each(response, function(key,value){
				$(".country_name_list_append"+row_tag).append($('<option></option>').attr("value",value.id_advertiser).text(value.titles +'('+ value.id_advertiser +')')); 

			});
		}
	});
});

function getdiversiondata(id){
	$('#data_list').html('');
	$("#mess").show().html('Processing....');
$.ajax({
		type:'post',
		url: '/diversionliststatus',
		dataType:'html',
		data: {
			id: id,
		},
		success: function(response){
	        $('#data_list').append(response);
 			$("#mess").hide();
		}
	});
}

$(".diversion_list_table").on("click",".remove_diversion",function(event){

var id_value=$(this).attr('data_value').split('_');
var id=id_value[0];
var campaigns=id_value[1];
var percentage=id_value[2];
$("#mess").show().html('Processing....');
$.ajax({
		type:'post',
		url: '/offerurlmgntdiversion_remove',
		data: {
			id: id,
			parent_cca:campaigns,
			percentage:percentage
		},
		dataType:'html',
		success: function(response){
	   	 alert(response);
	   	 getdiversiondata(id);
		 $("#mess").hide();
		}
		
	});
});


function hide_button(btn){
	// $('#diversion_list_table').on('click', btn, function(){
    $(this).closest ('tr').remove();
	// });
}

function getcountrydata(id){
	$('#data_list_country').html('');
	$("#mess1").show().html('Processing....');
$.ajax({
		type:'post',
		url: '/country_list_status',
		dataType:'html',
		data: {
			id: id,
		},
		success: function(response){
	        $('#data_list_country').append(response);
 			$("#mess1").hide();
		}
	});
}


$(".country_list_table").on("click",".remove_country_list",function(event){

var id_value=$(this).attr('data_value').split('_');
var id=id_value[0];
var country_iso=id_value[1];
var campaigns=id_value[2];
$("#mess1").show().html('Processing....');
$.ajax({
		type:'post',
		url: '/country_list_remove',
		data: {
			id: id,
			country_iso:country_iso,
			campaigns:campaigns
		},
		dataType:'html',
		success: function(response){
	   	 alert(response);
	   	  getcountrydata(id);
		 $("#mess1").hide();
		}
		
	});
});

$(".operator_list_table").on("click",".remove_operator_list",function(event){

var id_value=$(this).attr('data_value').split('_');
var id=id_value[0];
var operator_id=id_value[1];
var campaigns=id_value[2];
$("#mess1").show().html('Processing....');
$.ajax({
		type:'post',
		url: '/operator_list_remove',
		data: {
			id: id,
			operator_id:operator_id,
			campaigns:campaigns
		},
		dataType:'html',
		success: function(response){
	   	 alert(response);
	   	  getoperatordata(id);
		 $("#mess1").hide();
		}
		
	});
});





function getoperatordata(id){
	$('#data_list_operator').html('');
	$("#mess2").show().html('Processing....');
$.ajax({
		type:'post',
		url: '/operator_list_status',
		dataType:'html',
		data: {
			id: id,
		},
		success: function(response){
	        $('#data_list_operator').append(response);
 			$("#mess2").hide();
		}
	});
}


function checkForm(form)
  {
    if(this.name.value == "") {
      alert("Please enter your Name in the form");
      this.name.focus();
      return false;
    }
    if(this.email.value == "" || !this.valid_email.checked) {
      alert("Please enter a valid Email address");
      this.email.focus();
      return false;
    }
    if(this.age.value == "" || !this.valid_age.checked) {
      alert("Please enter an Age between 16 and 100");
      this.age.focus();
      return false;
    }
    alert("Success!  The form has been completed, validated and is ready to be submitted...");
    return false;
 
}

