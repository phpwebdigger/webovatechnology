
 /* First Step call */
$(document). ready(function(){ 
    $("#search").click(function(){
        var optionValue = $("input[name='option']:checked"). val();
        var dateRange = $("#reportrange").val();
        if(!optionValue){
            alert("Please select any option");
            return false;
        }  
        $.ajax({
                async: true, 
                url : 'getdata',
                type: 'GET',
                'data': {'type':optionValue,'daterange':dateRange}  
            }).done(function (response) {
                $(".main-content").html(response);
                    var table =  $('.table-striped').DataTable({"lengthMenu": [ [100, 200,300, -1], [100, 200,300, "All"] ],
                        scrollY: 1500,
                        scrollX: true,
                        scrollCollapse: true,
                        paging: false,
                        fixedColumns: true 
                });
                    $('#country-search').on( 'keyup', function () {table.columns(1)
                        .search(this.value).draw();});
                }).fail(function () {
                    alert('Data could not be loaded.');
                });
       });
        $(".close").click(function(){
        var closeDivClass = $(this).attr("data-value");
        $("."+closeDivClass).remove();
        });
});
   
   /* Second step call */
   function getCountry(country_id,country){
      var dateRange = $("#reportrange").val(); 
      $.ajax({
            async: true, 
            url : 'getcountry',
            type: 'GET',
            'data': {'country':country,'daterange':dateRange}  
        }).done(function (response) {
             showdata(country_id,response);
        }).fail(function () {
            alert('Data could not be loaded.');
        });
    }

    function showdata(rowId,content){
    $('.operator-data').remove();
    $("#"+rowId).after("<tr class='operator-data'><td colspan='13'>"+content+"</td></tr>");
    var operator = $(".country").DataTable({"lengthMenu": [ [25, 50,100, -1], [25, 50,100, "All"] ]});
    $('#operator-search').on( 'keyup', function () {operator.columns(1)
                    .search(this.value).draw();});
    closeTable();
    }




function getPublisher(row_id,op_id){
      var dateRange = $("#reportrange").val(); 
      $(".loader").css("display", "block");
      $.ajax({
            async: true,
            url : "getcountry",
            type: 'GET',
            'data': {'op_id':op_id,'daterange':dateRange}  
        }).done(function (response) {
            $(".loader").css("display", "none");
            showPublishers(row_id,response);
        }).fail(function () {
            alert('Data could not be loaded.');
        });
    }

 
function showPublishers(rowId,content){
    $('.publishers-data').remove();
    $("#"+rowId).after("<tr class='publishers-data'><td colspan='13'>"+content+"</td></tr>");
    var publisher = $(".publishers").DataTable({"lengthMenu": [ [25, 50,100, -1], [25, 50,100, "All"] ]});
    $('#publisher-search').on( 'keyup', function () {publisher.columns(1)
                    .search(this.value).draw();});
    closeTable();                 
    
} 

function getAdvertisers(rowId,op_id,pub_id){
      var dateRange = $("#reportrange").val(); 
      $.ajax({
            async: true, 
            url : "getcountry",
            type: 'GET',
            'data': {'op_id':op_id,'pub_id':pub_id,'daterange':dateRange}  
        }).done(function (response) {
            showAdvertisers(rowId,response);
        }).fail(function () {
            alert('Data could not be loaded.');
        });
    }       

function showAdvertisers(rowId,content){
   // alert(rowId);
    $('.advertiser-data').remove();
    $("#"+rowId).after("<tr class='advertiser-data'><td colspan='12'>"+content+"</td></tr>");
    var adv = $(".advertisers").DataTable({"lengthMenu": [ [25, 50,100, -1], [25, 50,100, "All"] ]});
    $('#advertiser-search').on( 'keyup', function () {adv.columns(1)
                    .search(this.value).draw();});
    closeTable();
}

function getCampaigns(row_id,op_id,pub_id,adv_id){
    var dateRange = $("#reportrange").val(); 
      $.ajax({
            async: true, 
            url : "getcampaigns",
            type: 'GET',
            'data': {'op_id':op_id,'pub_id':pub_id,'adv_id':adv_id,'daterange':dateRange}  
        }).done(function (response) {
            showCampaigns(row_id,response);
        }).fail(function () {
            alert('Data could not be loaded.');
        });
}

function getCampaignsAjax(url){
      $.ajax({
            url : url,
            type: 'GET',
            async: true,
        }).done(function (response) {
            // showCampaigns(response);
        }).fail(function () {
            alert('Data could not be loaded.');
        });
}         
 function showCampaigns(rowId,content){
    $('.campaign-data').remove();
    $("#"+rowId).after("<tr class='campaign-data'><td colspan='13'>"+content+"</td></tr>");
    var campaign = $(".campaigns").DataTable({"lengthMenu": [ [25, 50,100, -1], [25, 50,100, "All"] ]});
    $('#campaign-search').on( 'keyup', function () {campaign.columns(1)
                    .search(this.value).draw();});
    
    closeTable();
 }

function closeTable(){
    $(".close").click(function(){
    var closeDivClass = $(this).attr("data-value");
    $("."+closeDivClass).remove();
    });
}

