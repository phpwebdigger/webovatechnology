var advertiser_campaign_option = '';
function EditUrl(id_ad){
	$(".preloader").show();
  $("#id_advertiser").html('');
    if(id_ad > 0){
        $.ajax({
            url : 'urls/getUrlData/',
            type: 'GET',
            async: true,
            cache: false,
            data: "id_ad="+id_ad,
            dataType: 'json'
        }).done(function (response) {
            if(response.url_change==1) 
            {
              alert('URL change is not allowed on this CCA');
              return false;
            }else{
            $(".id_ads").val(response.id_ad);
            $("#adv_id").val(response.advertiser_id);
            $("#title").val(response.etitle);
            $("#network_name").val(response.network_name);
            $("#traffic_typ").val(response.traffic_type);
            $("#click_url").val(response.click_url); 
            $("#operator_name").val(response.operator_name);
            var advertiser_campaign_option ='';
           $("#id_advertiser").selectpicker('destroy');
            $(response.advertiser_campaign_name).each(function(key,campaign){
              advertiser_campaign_option += '<option value='+campaign.id+'>('+campaign.id+')'+campaign.name+'</option>';
            });
            // console.log(advertiser_campaign+"here");
            $("#id_advertiser").empty().html(advertiser_campaign_option);
            $("#id_advertiser").selectpicker('refresh');
            $('#editUrl').modal({backdrop:'static'});
            $(".preloader").hide();   
            }   
        }).fail(function () {
                alert('Data could not be loaded.');
                $(".preloader").hide();
        });
    }
 }   


$(".radiobox").click(function(){
    var is_selected = $(this).attr('checked', true);
    var is_smart = $(this).val();
    var advertiser_campaign;
    if(is_smart == 'DEFAULT'){
       $("#id_advertiser").html(advertiser_campaign_option).selectpicker('refresh');
    }else{
    if(is_selected && is_smart){
        $("#spinner").show();
        $.ajax({
            url : 'urls/getCpiCpa/',
            type: 'GET',
            async: true,
            data: "is_smart="+is_smart
        }).done(function (response){
            if(response.status==1){
				$(response.advertiser_campaign).each(function(key,campaign){
					advertiser_campaign += '<option value="'+campaign.id+'"">'+campaign.name+'</option>';
				});
			   $("#spinner").hide();
			   $("#id_advertiser").html(advertiser_campaign).selectpicker('refresh');
            }
            // $('#editUrl').modal({backdrop:'static'});
        }).fail(function () {
                alert('Data could not be loaded.');
                $("#spinner").hide();
        });
    }
    }        
});

$("#update").click(function(){
   var id_advertiser = $('#id_advertiser').val();
     var id_ad = $("#id_ad").val();
     var url = $("#url").val();
     var msg = $('#msg');
     if(id_advertiser == "" && id_advertiser == null){
		msg.html('<span class="alert alert-danger">Please select valid Advertiser Name and ID !!!</span>');
     return false;
     }else if(id_ad !='' && id_advertiser !=''){
		 msg.html('<span class="alert alert-info">please wait... !</span>');
		 $.ajax({
				url: 'urls/getUpdateUrl/',
    //  data: 'id_ad='+id_ad+'&id_advertiser='+id_advertiser+'&url='+url,
        data : { id_ad:id_ad,id_advertiser: id_advertiser,url:url},
        success: function(response){  // Get the result and asign to each cases
				if(response.status == 0){
					msg.html('<span class="alert alert-danger">Oops, something went wrong!</span>');
				}else if(response.status == 1){
					msg.html('<span class="alert alert-success">URL sucsessfully updated!</span>');   
					window.location.href = window.location.href;
				}else if(response.status == 2){
					msg.html('<span class="alert alert-info">Problem while Tracking</span>');                                        
				}else if(response.status == 3){
					msg.html('<span class="alert alert-info">You are not authorised to changes Url</span>');                                        
				}else if(response.status == 4){
          msg.html('<span class="alert alert-info">This campaign already exist on smart trfc</span>');                                        
        }else{
          console.log(res);
          alert('there is something went wrong');
        }

			 }
		});             
	  }else{
		 msg.html('<span class="alert alert-danger">Oopss... !</span>');
		}
    });



$("input[name=is_child]").click(function(){
  $(".child-element").hide();
  if($(this).val() == 1){
    $(".child-element").show();
  }


});


function submitCronForm(){
    var reg = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
    var cca = $('#cca').val();
    var activation = $('#activation').val();
    var is_child = $('input[name=is_child').val();
    var child_id = $('#child_id').val();
    var price = $('#price').val();
    var priority = $("select[name=priority]").val(); 
    if(cca.trim() == '' ){
        alert('Please enter your CCA.');
        $('#cca').focus();
        return false;
    }else if(activation.trim() == '' ){
        alert('Please enter your activation.');
        $('#activation').focus();
        return false;
    }else if(is_child.trim() == ''){
        alert('Please select is child.');
        $('#is_child').focus();
        return false;
    }else{
        
        var tr = "<tr><td class='sorting_1'>"+cca+"</td><td>"+is_child+"</td><td>"+child_id+"</td><td>"+activation+"</td><td>"+priority+"</td><td><span class='showUrl' data-toggle='modal' data-target='.bs-example-modal-lg'>No Data</span></td><td><button class='btn btn-success'>In process</button></td></tr>";

        $.ajax({
            type:'get',
            url:'add-manual-cron',
            data:'cca='+cca+'&activation='+activation+'&is_child='+is_child+'&child_id='+child_id+'&price='+price+'&priority='+priority,
            beforeSend: function () {
                $('.submitBtn').attr("disabled","disabled");
                $('.modal-body').css('opacity', '.5');
            },
            success:function(response){
                if(response.status == '1'){
                    $('#activation').val('');
                    $('#cca').val('');
                    $('#child_id').val('');
                    $('#price').val('');
                    // $('.statusMsg').html('<span style="color:green;">Cron sucsessfully saved.</p>');
                    // $('.statusMsg').html('');
                    $('.child-element').hide();
                    $('input[name=is_child]').attr('checked', false);
                    $('#tableLazy tr:first').after(tr)
                     // location.reload(true);
                }else{
                    $('.statusMsg').html('<span style="color:red;">Some problem occurred, please try again.</span>');
                }
                $('.submitBtn').removeAttr("disabled");
                $('.modal-body').css('opacity', '');
                $('#add-manual-cron').modal('hide');

            },
            fail:function(res){
             $('.submitBtn').removeAttr("disabled");
             $('.modal-body').css('opacity', '');
            }
        });
    }
}




 /*Change URL implemenetation */
  $(function(){

  $(document).on("change","[data-change=ajax-call]",function(event){
    var $selector = $(this),
        redirect_url = $selector.attr('data-onchange-url'),
        action = $selector.attr('data-onchange-action'),
        action_id = $selector.attr('data-onchange-id'),
        id = $(this).val();
    $("#camp_data,#id_camps,#clivecca,#id_advertiser").html("").selectpicker('refresh');
    $.ajax({
            url : redirect_url,
            type: 'GET',
            async: true,
            data: "op_id="+id+"&action="+action
        }).done(function (response){
            if(response.status == 1){
                $("#camp_data").html(response.data);
                $("#id_camps").html(response.data);
                $(".selectpicker").selectpicker('refresh');
            }    
        }).fail(function () {
                alert('Data could not be loaded.');
        });
});

$(document).on("change","#id_camps",function(event){
    var camp_id = $(this).val(),
    title = $('#cad_'+camp_id).attr("data-title");
    if(title != 'undefined'){
        $("#new-campaign-url").html('New Campaing URL:'+title).addClass('text-danger');
    }    
});

$(document).on("change","#op_data",function(event){
    $("#cmpurl").html('');   
});

/*
$(document).on("change","#camp_data,#campaign",function(event){
    var $selector = $(this),
    camp_id = $(this).val(),
    op_id = $("#op_data").val(),
    title = $('#cad_'+camp_id).attr("data-title"),
    redirect_url = $selector.attr('data-onchange-url'),
    type =  $selector.attr('data-type');    
    if(title != 'undefined'){
        $("#cmpurl").html('Campaing URL:'+title);
    }
    $('#clivecca').html("").selectpicker('refresh');
       $.get("/url/getcampaign?action=livecca&op_id="+op_id+"&camp_id="+camp_id+"&type="+type, 
            function(data){
                // $('#clivecca').html(response.data).selectpicker('refresh');
                var response = data;
                var fixedCampaigns = '';
                var changeableCampaigns = '';
                var SmartCampaigns = '';
                var total_fixed = 0, total_change = 0, total_smart_ccas = 0;
                if(response.status == 1){
                    $(response.data).each(function(key,fixed){ 
                     if(fixed.url_change == 1){
                        total_fixed++;
                        fixedCampaigns +='<option value="'+fixed.id_ad+'">('+fixed.id_ad+')'+fixed.network_name+'('+fixed.traffic_type+')</option>';
                      }else{
                        total_change++;
                        changeableCampaigns +='<option value="'+fixed.id_ad+'">('+fixed.id_ad+')'+fixed.network_name+'('+fixed.traffic_type+')</option>'; 
                      }
                    });
                    $(response.smart_cca).each(function(key,fixed){
                      total_smart_ccas++; 
                      SmartCampaigns +='<option value="'+fixed.id+'">('+fixed.cca+')'+fixed.network_name+'('+fixed.traffic_type+')</option>';
                    });
                $("#changeable-ccas").html(changeableCampaigns);
                $("#fixed-ccas").html(fixedCampaigns);
                if(SmartCampaigns && type =='smart'){
                  $("#smart-ccas").html(SmartCampaigns);
                  $('.total_smart_ccas').html('('+total_smart_ccas+')');
                }else if(type == 'smart'){
                  $("#smart-ccas").html("");
                  $('.total_smart_ccas').html('(0)');
                }
                $('.total_changeable_ccas').html('('+total_change+')');
                $('.total_fixed_ccas').html('('+total_fixed+')');
                $(".selectpicker").selectpicker('refresh');   
                }else{
                  alert('there is no campaign available that cca');
                }
            });
                   
    });
  
update 2018-10-15
$(document).on("change","#camp_data,#campaign",function(event){
    var $selector = $(this),
    camp_id = $(this).val(),
    op_id = $("#op_data").val(),
    title = $('#cad_'+camp_id).attr("data-title"),
    redirect_url = $selector.attr('data-onchange-url'),
    type =  $selector.attr('data-type');    
    if(title != 'undefined'){
        $("#cmpurl").html('Campaing URL:'+title);
    }
    $('#clivecca').html("").selectpicker('refresh');
       $.get("/url/getcampaign?action=livecca&op_id="+op_id+"&camp_id="+camp_id+"&type="+type, 
            function(data){
                // $('#clivecca').html(response.data).selectpicker('refresh');
                var response = data;
                var fixedCampaigns = '';
                var changeableCampaigns = '';
                var SmartCampaigns = '';
                var total_fixed = 0, total_change = 0, total_smart_ccas = 0;
                if(response.status == 1){
                    total_fixed = response.total_fixed;
                    total_change = response.total_change;
                    $(response.data).each(function(key,fixed){ 
			 if(fixed.url_change == 0){
                      total_fixed = 0;
                     }  
                     if(fixed.url_change == 1){
                        // total_fixed++;
                        fixedCampaigns +='<option value="'+fixed.id_ad+'">('+fixed.id_ad+')'+fixed.network_name+'('+fixed.traffic_type+')</option>';
                      }else{
                        // total_change++;
                        changeableCampaigns +='<option value="'+fixed.id_ad+'">('+fixed.id_ad+')'+fixed.network_name+'('+fixed.traffic_type+')</option>'; 
                      }
                    });
                    $(response.smart_cca).each(function(key,fixed){
                      total_smart_ccas++; 
                      SmartCampaigns +='<option value="'+fixed.id+'">('+fixed.cca+')'+fixed.network_name+'('+fixed.traffic_type+')</option>';
                    });
                $("#changeable-ccas").html(changeableCampaigns);
                $("#fixed-ccas").html(fixedCampaigns);
                if(SmartCampaigns && type =='smart'){
                  $("#smart-ccas").html(SmartCampaigns);
                  $('.total_smart_ccas').html('('+total_smart_ccas+')');
                }else if(type == 'smart'){
                  $("#smart-ccas").html("");
                  $('.total_smart_ccas').html('(0)');
                }
                $('.total_changeable_ccas').html('('+total_change+')');
                $('.total_fixed_ccas').html('('+total_fixed+')');
                $(".selectpicker").selectpicker('refresh');   
                }else{
                  alert('there is no campaign available that cca');
                }
            });
                   
    });     
        */




	$(document).on("change","#camp_data,#campaign",function(event){
    var $selector = $(this),
    camp_id = $(this).val(),
    op_id = $("#op_data").val(),
    title = $('#cad_'+camp_id).attr("data-title"),
    redirect_url = $selector.attr('data-onchange-url'),
    type =  $selector.attr('data-type'); 
    smart_link_type =  $selector.attr('data-type-smart'); 

    if(title != 'undefined'){
        $("#cmpurl").html('Campaing URL:'+title);
    }
    $('#clivecca').html("").selectpicker('refresh');
       $.get("url/getcampaign?action=livecca&op_id="+op_id+"&camp_id="+camp_id+"&type="+type+"&smart_link_type="+smart_link_type, 
            function(data){
              console.log(data);
                // $('#clivecca').html(response.data).selectpicker('refresh');
                var response = data;
                var fixedCampaigns = '';
                var changeableCampaigns = '';
                var SmartlinkCampaigns ='';
                var SmartCampaigns = '';
                var total_fixed = 0, total_change = 0, total_smakrt_link_change = total_smart_ccas = 0;
                if(response.status == 1){
                    // total_fixed = response.total_fixed;
                    // total_change = response.total_change;
              
                    $(response.data).each(function(key,fixed){ 
                       if(fixed.url_change == 1){
                        total_fixed++;
                        fixedCampaigns +='<option value="'+fixed.id_ad+'">('+fixed.id_ad+')'+fixed.network_name+'('+fixed.traffic_type+')</option>';

                      }else{
                        total_change++;
                        changeableCampaigns +='<option value="'+fixed.id_ad+'">('+fixed.id_ad+')'+fixed.network_name+'('+fixed.traffic_type+')</option>'; 
                      }
                    });

                    $(response.smart_link_cca).each(function(key,fixed){
                      total_smakrt_link_change++; 
                      SmartlinkCampaigns +='<option value="'+fixed.id+'">'+fixed.operator_name+'('+fixed.country_code+')'+'('+fixed.ads_cat+')</option>';
                    });
                    $(response.smart_cca).each(function(key,fixed){
                      total_smart_ccas++; 
                      SmartCampaigns +='<option value="'+fixed.id+'">('+fixed.cca+')'+fixed.network_name+'('+fixed.traffic_type+')</option>';
                    });
                $("#changeable-ccas").html(changeableCampaigns);
                $("#fixed-ccas").html(fixedCampaigns);
                if(SmartCampaigns && type =='smart'){
                  $("#smart-ccas").html(SmartCampaigns);
                  $('.total_smart_ccas').html('('+total_smart_ccas+')');
                }else if(type == 'smart'){
                  $("#smart-ccas").html("");
                  $('.total_smart_ccas').html('(0)');
                }
                  if(SmartlinkCampaigns && smart_link_type =='smart_link'){
                  $("#smart-links").html(SmartlinkCampaigns);
                  $('.total_smart_links').html('('+total_smakrt_link_change+')');
                }else if(type == 'smart'){
                  $("#smart-links").html("");
                  $('.total_smart_links').html('(0)');
                }
                $('.total_changeable_ccas').html('('+total_change+')');
                $('.total_fixed_ccas').html('('+total_fixed+')');
                $(".selectpicker").selectpicker('refresh');   
                }else{
                  alert('there is no campaign available that cca');
                }
            });
                   
    });




          

    $("input[name=campaign_option]").click(function(){
         var optype_val = $(this).val();
         console.log(optype_val);
         $('.container-body').show();
         $('#op_data,#camp_data').val("");
         $("#changeable-ccas option,#fixed-ccas option").remove().selectpicker('refresh');
         $("#cmpurl").html("");
         if(optype_val == 1){
                $("#camp_data,#fixed-ccas,#changeable-ccas,#smart-ccas,#smart-links,#id_camps").html('').selectpicker('refresh');;
                     $('.total_changeable_ccas,.total_fixed_ccas,.total_smart_ccas,.total_smart_links').html(''); 			
               $(".operator-campaign").show();
               $(".single-campaign").hide();
               $(".replace-camp").show();
                $("#cpacpistep2").show();
               $("#cpacpi").show();			
               $(".apply-campaign").hide();
         }else if(optype_val == 2){
	       $("#camp_data,#fixed-ccas,#changeable-ccas,#smart-ccas,#smart-links,#id_camps").html('').selectpicker('refresh');;
                     $('.total_changeable_ccas,.total_fixed_ccas,.total_smart_ccas,.total_smart_links').html('');		
               $(".operator-campaign").hide();
               $(".single-campaign").show();
               $(".replace-camp").hide();
	       $("#cpacpistep2").hide();
               $("#cpacpi").hide();	
               $(".apply-campaign").show();
               DeafultCampaign();                
         } 

    });

     var DeafultCampaign = function(){
        changeableCampaigns = '';
       changeableCampaigns += '<option value="">Replace Camp</option>'; 
       $(campaigns).each(function(key,campaign){
         changeableCampaigns +='<option value="'+campaign.id+'" data-title="'+campaign.url+'" id="cad_'+campaign.id+'">('+campaign.id+')'+campaign.name+'</option>';   
       });
       $("#id_camps").html(changeableCampaigns).selectpicker('refresh');     
     }
}); 


   
    function CheckBalancedCca(){
          var $selector = $("#camp_data");
          var camp_id = $("#camp_data").val(),
          op_id = $("#op_data").val(),
          title = $('#cad_'+camp_id).attr("data-title"),
          redirect_url = $selector.attr('data-onchange-url'),
          type =  $selector.attr('data-val');
          var fixedCampaigns = '';
          var changeableCampaigns = '';
          var SmartCampaigns = '';    
          if(title != 'undefined'){
              $("#cmpurl").html('Campaing URL:'+title);
          }
          $('#clivecca').html("").selectpicker('refresh');
             $.get("url/getcampaign?action=livecca&op_id="+op_id+"&camp_id="+camp_id+"&type="+type, 
                  function(data){
                      // $('#clivecca').html(response.data).selectpicker('refresh');
                      var response = data;
                      if(response.status == 1){
                          $(response.data).each(function(key,fixed){ 
                           if(fixed.url_change == 1){
                              fixedCampaigns +='<option value="'+fixed.id_ad+'">('+fixed.id_ad+')'+fixed.network_name+'('+fixed.traffic_type+')</option>';
                            }else{
                              changeableCampaigns +='<option value="'+fixed.id_ad+'">('+fixed.id_ad+')'+fixed.network_name+'('+fixed.traffic_type+')</option>'; 
                            }
                          });
                          $(response.smart_cca).each(function(key,fixed){ 
                            SmartCampaigns +='<option value="'+fixed.id+'">('+fixed.cca+')'+fixed.network_name+'('+fixed.traffic_type+')</option>';
                          });
                      $("#changeable-ccas").html(changeableCampaigns);
                      $("#fixed-ccas").html(fixedCampaigns);
                      if(SmartCampaigns){
                        $("#smart-ccas").html(SmartCampaigns);
                      }
                      $(".selectpicker").selectpicker('refresh');   
                      }else{
                        alert('there is no campaign available that cca');
                      }
                  });
      }


       $('#changeable-ccas').on('changed.bs.select', function (e){  
            var count = $("#changeable-ccas :selected").length;
            counter = 0;
            if(count > 990){
              $.each($("#changeable-ccas :selected"), function() {
                   counter++
                   if(counter > 990){
                      $(this).prop('selected', false);
                      // console.log(counter);
                   }
                });
            }
        });





$(document).on("click",".radiobox_smart", function(){
                  var is_selected = $(this).attr('checked', true);
                var is_smart = $(this).val();

                var advertiser_campaign="";
                if(is_smart == 'DEFAULT'){
                  $("#id_camps").html('').selectpicker('refresh');;
                 //  var cca = $(this).attr('data_att');
                 //  // alert(cca);
                 //  cca = cca.split("_");
                 // var id = cca[0];
                 // var cco = cca[1];
                  var op_data = $("#op_data").val();
                  var cca='';
                  $.ajax({
                    url : 'getPercentageOnCampaignsByCca',
                    type: 'get',
                    async: true,
                    data: "cca="+cca+"&cco="+op_data,

               success: function(response){
                   // var response = res;
                    if(response.status == 1){
                                if(response.advertiser_campaigns){
                                    $(response.advertiser_campaigns).each(function(key,campaign){
                                       advertiser_campaign += '<option value="'+campaign.id+'"" data-title="'+campaign.url+'">'+campaign.name+'('+campaign.id+')'+'</option>';
                                    });
                                 }else{
                                    alert('there is no campaign');
                                 }
                               $("#spinner").hide();
                               $("#id_camps").html(advertiser_campaign).selectpicker('refresh');
                               // $("#addCampaignsByOperator").selectpicker();
                            }
                        }
                });
                
                } else{
                if(is_selected && is_smart){
                    $("#spinner").show();
                     var op_data = $("#op_data").val();
                    $.ajax({
                        url : 'getCpiCpa_smarturl',
                        type: 'GET',
                        async: true,
                        data: "is_smart="+is_smart+"&op_data="+op_data
                    }).done(function (response){
                          try{
                          if(response.status == 1){
                                if(response.advertiser_campaign){
                                    $(response.advertiser_campaign).each(function(key,campaign){
                                       advertiser_campaign += '<option value="'+campaign.id+'"" data-title="'+campaign.url+'">'+campaign.name+'('+campaign.id+')'+'</option>';
                                    });
                                 }else{
                                    alert('there is no campaign');
                                 }
                               $("#spinner").hide();
                               $("#id_camps").html(advertiser_campaign).selectpicker('refresh');
                               // $("#id_camps").selectpicker();
                            }
                          }catch(err){
                             $("#spinner").hide();
                             console.log('There is some issue');
                          }  
                        // }
                        // $('#editUrl').modal({backdrop:'static'});
                    }).fail(function () {
                            alert('Data could not be loaded.');
                            $("#spinner").hide();
                    });
                }
                 }     
            });



$(document).on("click",".radiobox_smart1", function(){
                  var is_selected = $(this).attr('checked', true);
                var is_smart = $(this).val();

                var advertiser_campaign="";
                if(is_smart == 'DEFAULT'){
                  //$("#camp_data").html('').selectpicker('refresh');;
              	  $("#camp_data,#fixed-ccas,#changeable-ccas,#smart-ccas,#smart-links").html('').selectpicker('refresh');
                     $('.total_changeable_ccas,.total_fixed_ccas,.total_smart_ccas,.total_smart_links').html('');
                  var op_data = $("#op_data").val();
                  var cca='';
                  $.ajax({
                    url : 'getPercentageOnCampaignsByCca',
                    type: 'get',
                    async: true,
                    data: "cca="+cca+"&cco="+op_data,

               success: function(response){
                   // var response = res;
                    if(response.status == 1){
                                if(response.advertiser_campaigns){
                                    $(response.advertiser_campaigns).each(function(key,campaign){
                                       advertiser_campaign += '<option value="'+campaign.id+'"" data-title="'+campaign.url+'">'+'('+campaign.id+')'+campaign.name+'</option>';
                                    });
                                 }else{
                                    alert('there is no campaign');
                                 }
                               $("#spinner").hide();
                               $("#camp_data").html(advertiser_campaign).selectpicker('refresh');
                               // $("#addCampaignsByOperator").selectpicker();
                            }
                        }
                });
                
                } else{
                if(is_selected && is_smart){
                    $("#spinner").show();
			 $("#camp_data,#fixed-ccas,#changeable-ccas,#smart-ccas,#smart-links").html('').selectpicker('refresh');;
                     $('.total_changeable_ccas,.total_fixed_ccas,.total_smart_ccas,.total_smart_links').html('');
                     var op_data = $("#op_data").val();
                    $.ajax({
                        url : 'getCpiCpa_smarturl',
                        type: 'GET',
                        async: true,
                        data: "is_smart="+is_smart+"&op_data="+op_data
                    }).done(function (response){
                          try{
                          if(response.status == 1){
                                if(response.advertiser_campaign){
                                    $(response.advertiser_campaign).each(function(key,campaign){
                                       advertiser_campaign += '<option value="'+campaign.id+'"" data-title="'+campaign.url+'">'+campaign.name+'</option>';
                                    });
                                 }else{
                                    alert('there is no campaign');
                                 }
                               $("#spinner").hide();
                               $("#camp_data").html(advertiser_campaign).selectpicker('refresh');
                               // $("#id_camps").selectpicker();
                            }
                          }catch(err){
                             $("#spinner").hide();
                             console.log('There is some issue');
                          }  
                        // }
                        // $('#editUrl').modal({backdrop:'static'});
                    }).fail(function () {
                            alert('Data could not be loaded.');
                            $("#spinner").hide();
                    });
                }
                 }     
            });
