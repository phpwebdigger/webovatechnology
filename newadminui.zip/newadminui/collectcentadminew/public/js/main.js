/*
    Script Init Select 2 with ajax result
*/
function createTableWithLazyLoad(dom,data,howMany,column=[]) {
    // body...
 $(dom).find('thead:not(".new") th').each(function(){
    var title = $(dom).find('thead:not(".new") th').eq($(this).index()).text();
    var widthPx = "";
    widthPx = "60px"
    if(title &&  column.length != 0 && column[$(this).index()] != ""){
        var width = column[$(this).index()].split("_");
        if(width.length > 1){
            widthPx = width[1];
        }
       $(this).find("input[type='text']").remove();
       $(this).find("br").remove();
       $(this).append("<br><input type='text' style='color:black;width:"+widthPx+"' placeholder='Search..'/>");
    }else if(title && column[$(this).index()] != "" ){
        $(this).append("<br><input type='text' style='color:black;' placeholder='Search..'/>");
    }
    });


        
        window.tableLazyNew =  $(dom).DataTable({
            data: data,
            "aaSorting": [],
            "autoWidth": false,
            "pageLength": howMany||100,
            "oLanguage": {
                "sLengthMenu": "_MENU_ "
            },
            deferRender:true,
            CustomRenderpages:howMany||100,
            scrollCollapse: true,
            "lengthMenu": [[100, 200, 500, -1], [100, 200, 500, "All"]],
            scroller: true,
             fixedHeader: {
                    header: true,
                    footer: true
            }

        });
        
        tableLazyNew.columns().eq(0).each(function(colIdx) {
            $('input', tableLazyNew.column(colIdx).header()).on('keyup change', function() {
                tableLazyNew
                    .column(colIdx)
                    .search(this.value)
                    .draw();
            });
         
            $('input', tableLazyNew.column(colIdx).header()).on('click', function(e) {
                e.stopPropagation();
            });
        });

  
}
$(document).ready(function() {
    $("#navToggle").on("click",function(){
            $("#wrapper").toggleClass("hideMenuWrapper");
            if($(this).find(".fa-angle-double-up").length > 0){
                $(this).find(".fa-angle-double-up").removeClass("fa-angle-double-up").addClass("fa-angle-double-down")
            }else{
                $(this).find(".fa").removeClass("fa-angle-double-down").addClass("fa-angle-double-up")
            }

    })
    $('.mySelect').each(function(){$(this).select2()});
    $('[data-act=ajax-select]').each(function() {
        var $selectElm = $(this);
        var minimumInputLength = $selectElm.attr('data-min-input') || 3;
        var multiple = $selectElm.attr('data-is-multiple') || "";
        var initialSelect = $selectElm.attr('data-initial-id') || false;
        var selectAjaxUrl = $selectElm.attr('data-ajax-url') || '/setect2/fetch';
        var contentType = $selectElm.attr('data-content-type') || 'application/json';
        var data_Obj = {};
        var cbSelect = $selectElm.attr('data-cb-select') || undefined;
        var selectPlaceHolder = $selectElm.attr('data-placeholder') || "Please Select an option";
        var ajaxPreload = $selectElm.attr('data-preload') || false;
        var tags = $selectElm.attr('data-allow-tags') || false;
        $(this).each(function() {
            $.each(this.attributes, function() {
                if (this.specified && this.name.match("^data-post-")) {
                    var dataName = this.name.replace("data-post-", "");
                    data_Obj[dataName] = this.value;
                }
            });
        });

        if(ajaxPreload == 'true'){
            $.ajax({
                    type: "POST",
                    url: selectAjaxUrl,
                    dataType: 'json',
                    data: data_Obj,
                    success: function(res) {
                        var $obj = $selectElm.select2({
                            multiple: multiple,
                            data: res.results,
                            placeholder : selectPlaceHolder
                        });
                        if(initialSelect != ""){
                            $obj.val(initialSelect).trigger('change');
                        }
                        
                    }
             });
        }else{
            var configObj = {
                minimumInputLength: minimumInputLength,
                placeholder : selectPlaceHolder,
                multiple : multiple,
                tags : tags,
                closeOnSelect:false,
                quietMillis: 1500,
                delay: 1500,
                tokenSeparators: [',', ' '],
                ajax: {
                    type: "POST",
                    url: selectAjaxUrl,
                    dataType: 'json',
                    delay: 250,
                    data: function(params) {
                        data_Obj.keyword = params;
                        return data_Obj;
                    },
                    results: function(data, page, query) {
                        debugger;
                        var results = [];
                        if (cbSelect) {
                            cbSelect(data, page, query);
                        } else {
                            $.each(data, function(index, item) {
                                results.push({
                                    id: item.id,
                                    text: item.text                                    
                                });
                            });
                            return {
                                results: results
                            };
                        }
                    }
                },
            };
            $selectElm.select2(configObj);
        }
    })


//Generic Function to Show ALert
var showAlert = function(obj) {
    $("#ajaxModalTitle").html(obj.heading || '');
    if (obj.heading == undefined || obj.heading == '') {
        $("#ajaxModalTitle").addClass('noHeading');
    } else {
        $("#ajaxModalTitle").removeClass('noHeading');
    }
    $("#ajaxModalContent").html('<div class="modal-body text-center">' + obj.data + '</div>');
    $("#ajaxModal").modal('show');
}

var showLoader = function(elem) {
    elem.after('<img class="image-responsive-height demo-mw-50" id="loader-img" src="/img/demo/progress.svg" alt="Progress">');
    elem.hide();
}

var hideLoader = function(elem) {
    elem.show();
    elem.parent().find('#loader-img').remove();
}

var log = function(msg) {
    console.log(msg);
}

//custom dialog
    $.ajaxSetup({
        cache: false
    });

    //Delete Modal
    $('body').on('click', '[data-act=delete-modal]', function() {
        var isLargeModal = $(this).attr('data-modal-lg'),
            actUrl = $(this).attr('data-url'),
            removeParent = $(this).attr('data-remove-parent'),
            parentElm = $(this).attr('data-parent-elm'),
            methodType = $(this).attr('data-method'),
            selfElm = $(this),
            data = {};

        if(methodType == 'POST'){
            $(this).each(function() {
                $.each(this.attributes, function() {
                    if (this.specified && this.name.match("^data-post-")) {
                        var dataName = this.name.replace("data-post-", "");
                        data[dataName] = this.value;
                    }
                });
            });
        }
        var delHtml = '<div class="modal-body text-center">' +
            '<button id="del-btn-ajax-modal" class="btn btn-success m-r-20" type="button"><i class="fa fa-check"></i>Yes</button>' +
            '<button class="btn btn-default" type="button" data-dismiss="modal"><i class="pg-close"></i> No</button>'
        '</div>';
        if (isLargeModal === "1") {
            $("#ajaxModal").find(".modal-dialog").addClass("modal-lg");
        }
        $("#ajaxModalTitle").html('Are you Sure ?');
        if (delHtml) {
            $("#ajaxModalContent").html(delHtml);
        } else {
            $("#ajaxModalContent").html('');
        }
        $('#del-btn-ajax-modal').unbind('click').click(function() {
            $.ajax({
                url: actUrl,
                cache: false,
                type: methodType || 'GET',
                data : data,
                success: function(response) {
                    if (removeParent == 'true') {
                        $(selfElm).closest(parentElm).remove();
                    }
                    $("#ajaxModal").modal('hide');
                },
                error: function(e) {
                    $("#ajaxModal").modal('hide');
                }
            });
        });
        $("#ajaxModal").modal('show');
    });

    //Message Modal
    $('body').on('click', '[data-act=message-modal]', function() {
        var isLargeModal = $(this).attr('data-modal-lg'),
            title = $(this).attr('data-title'),
            content = $(this).attr('data-content');
        if (isLargeModal === "1") {
            $("#ajaxModal").find(".modal-dialog").addClass("modal-lg");
        }
        if (title) {
            $("#ajaxModalTitle").html(title);
        } else {
            $("#ajaxModalTitle").html($("#ajaxModalTitle").attr('data-title'));
        }
        if (content) {
            $("#ajaxModalContent").html('<div class="modal-body text-center">' + content + '</div>');
        } else {
            $("#ajaxModalContent").html('');
        }
        $("#ajaxModal").modal('show');
    });

    $('body').on('click', '[data-act=ajax-modal]', function() {
        var data = {
                ajaxModal: 1
            },
            url = $(this).attr('data-action-url'),
            isLargeModal = $(this).attr('data-modal-lg'),
            callback = $(this).attr("data-callback"),
            title = $(this).attr('data-title'),
            method = $(this).attr('data-ajax-method');

        if (!url) {
            console.log('Ajax Modal: Set data-action-url!');
            return false;
        }
        if (title) {
            $("#ajaxModalTitle").html(title);
        } else {
            $("#ajaxModalTitle").html($("#ajaxModalTitle").attr('data-title'));
        }

        $("#ajaxModalContent").html($("#ajaxModalOriginalContent").html());
        $("#ajaxModalContent").find(".original-modal-body").removeClass("original-modal-body").addClass("modal-body");
        $("#ajaxModal").modal('show');

        $(this).each(function() {
            $.each(this.attributes, function() {
                if (this.specified && this.name.match("^data-post-")) {
                    var dataName = this.name.replace("data-post-", "");
                    data[dataName] = this.value;
                }
            });
        });
        ajaxModalXhr = $.ajax({
            url: url,
            data: data,
            cache: false,
            type: method || 'POST',
            success: function(response) {
                $("#ajaxModal").find(".modal-dialog").removeClass("mini-modal");
                if (isLargeModal === "1") {
                    $("#ajaxModal").find(".modal-dialog").addClass("modal-lg");
                }
                var renderedData = new EJS({
                    url: '/' + response.pageName + '.ejs'
                }).render({
                    data: response,
                    res: response.data,
                    imgUrl: response.imgUrl
                });


                $("#ajaxModalContent").html(renderedData);

                if (callback && typeof callback == 'function') {
                    callback();
                }
                var $scroll = $("#ajaxModalContent").find(".modal-body"),
                    height = $scroll.height(),
                    maxHeight = $(window).height() - 200;
                if (height > maxHeight) {
                    height = maxHeight;
                    $scroll.scrollbar({
                        alwaysVisible: true,
                        height: height + "px",
                        color: "#98a6ad",
                        borderRadius: "0"
                    });
                }
            },
            statusCode: {
                404: function() {
                    $("#ajaxModalContent").find('.modal-body').html("");
                    //  appAlert.error("404: Page not found.", {container: '.modal-body', animate: false});
                }
            },
            error: function() {
                $("#ajaxModalContent").find('.modal-body').html("");
                //appAlert.error("500: Internal Server Error.", {container: '.modal-body', animate: false});
            }
        });
        return false;
    });

    //abort ajax request on modal close.
    $('#ajaxModal').on('hidden.bs.modal', function(e) {
        ajaxModalXhr.abort();
        $("#ajaxModal").find(".modal-dialog").removeClass("modal-lg");
        $("#ajaxModal").find(".modal-dialog").addClass("mini-modal");

        $("#ajaxModalContent").html("");
    });
    //common ajax request
    $('body').on('click', '[data-act=ajax-request]', function() {
        var data = {},
            $selector = $(this),
            url = $selector.attr('data-action-url'),
            removeOnSuccess = $selector.attr('data-remove-on-success'),
            removeOnClick = $selector.attr('data-remove-on-click'),
            inlineLoader = $selector.attr('data-inline-loader'),
            reloadOnSuccess = $selector.attr('data-reload-on-success');
        var callback = $selector.attr('data-action-callback');

        var $target = "";
        if ($selector.attr('data-real-target')) {
            $target = $($selector.attr('data-real-target'));
        } else if ($selector.attr('data-closest-target')) {
            $target = $selector.closest($selector.attr('data-closest-target'));
        }

        if (!url) {
            console.log('Ajax Request: Set data-action-url!');
            return false;
        }

        if (removeOnClick) {
            $(removeOnClick).remove();
        }

        $selector.each(function() {
            $.each(this.attributes, function() {
                if (this.specified && this.name.match("^data-post-")) {
                    var dataName = this.name.replace("data-post-", "");
                    data[dataName] = this.value;
                }
            });
        });
        if (inlineLoader === "1") {
            $selector.addClass("inline-loader");
        } else {
            //appLoader.show();
        }

        ajaxRequestXhr = $.ajax({
            url: url,
            data: data,
            cache: false,
            type: 'POST',
            success: function(response) {
                $selector.removeClass("inline-loader");
                if (reloadOnSuccess) {
                    location.reload();
                }
                if (removeOnSuccess) {
                    $(removeOnSuccess).remove();
                }
                //appLoader.hide();
                if ($target.length) {
                    $target.html(response);
                }
                if (callback) {
                    var f = eval(callback);
                    f(response, $selector);
                }
                //eval(callback(response);
            },
            statusCode: {
                404: function() {
                    //appLoader.hide();
                    //appAlert.error("404: Page not found.");
                }
            },
            error: function() {
                //appLoader.hide();
                //appAlert.error("500: Internal Server Error.");
            }
        });

    });
    //custom app form controller
    (function($) {
        $.fn.appForm = function(options) {
            var defaults = {
                ajaxSubmit: true,
                isModal: true,
                dataType: "json",
                onModalClose: function() {},
                onSuccess: function() {},
                onError: function() {
                    return true;
                },
                onSubmit: function() {},
                onAjaxSuccess: function() {},
                beforeAjaxSubmit: function(data, self, options) {}
            };

            var settings = $.extend({}, defaults, options);
            this.each(function() {
                if (settings.ajaxSubmit) {
                    validateForm($(this), function(form) {
                        if (settings.onSubmit($(form)) == false) {
                            return false;
                        }
                        if (settings.isModal) {
                            maskModal($("#ajaxModalContent").find(".modal-body"));
                        }
                        $(form).ajaxSubmit({
                            dataType: settings.dataType,
                            beforeSubmit: function(data, self, options) {
                                settings.beforeAjaxSubmit(data, self, options);
                            },
                            success: function(result) {
                                settings.onAjaxSuccess(result, $(form));

                                if (result.success) {
                                    settings.onSuccess(result);
                                    if (settings.isModal) {
                                        closeAjaxModal(true);
                                    }
                                } else {
                                    if (settings.onError(result)) {
                                        if (settings.isModal) {
                                            unmaskModal();
                                            if (result.message) {
                                                //appAlert.error(result.message, {container: '.modal-body', animate: false});
                                            }
                                        } else if (result.message) {
                                            //appAlert.error(result.message);
                                        }
                                    }
                                }
                            }
                        });
                    });
                } else {
                    validateForm($(this));
                }
            });
            /*
             * @form : the form we want to validate;
             * @customSubmit : execute custom js function insted of form submission. 
             * don't pass the 2nd parameter for regular form submission
             */
            function validateForm(form, customSubmit) {
                //add custom method
                $.validator.addMethod("greaterThanOrEqual",
                    function(value, element, params) {
                        var paramsVal = params;
                        if (params && (params.indexOf("#") === 0 || params.indexOf(".") === 0)) {
                            paramsVal = $(params).val();
                        }
                        if (!/Invalid|NaN/.test(new Date(value))) {
                            return new Date(value) >= new Date(paramsVal);
                        }
                        return isNaN(value) && isNaN(paramsVal) ||
                            (Number(value) >= Number(paramsVal));
                    }, 'Must be greater than {0}.');
                $(form).validate({
                    submitHandler: function(form) {
                        if (customSubmit) {
                            customSubmit(form);
                        } else {
                            return true;
                        }
                    },
                    highlight: function(element) {
                        $(element).closest('.form-group').addClass('has-error');
                    },
                    unhighlight: function(element) {
                        $(element).closest('.form-group').removeClass('has-error');
                    },
                    errorElement: 'span',
                    errorClass: 'help-block',
                    ignore: ":hidden:not(.validate-hidden)",
                    errorPlacement: function(error, element) {
                        if (element.parent('.input-group').length) {
                            error.insertAfter(element.parent());
                        } else {
                            error.insertAfter(element);
                        }
                    }
                });
                //handeling the hidden field validation like select2
                $(".validate-hidden").click(function() {
                    $(this).closest('.form-group').removeClass('has-error').find(".help-block").hide();
                });
            }

            //show loadig mask on modal before form submission;
            function maskModal($maskTarget) {
                var padding = $maskTarget.height() - 80;
                if (padding > 0) {
                    padding = Math.floor(padding / 2);
                }
                $maskTarget.append("<div class='modal-mask'><div class='circle-loader'></div></div>");
                //check scrollbar
                var height = $maskTarget.height();
                var $slimScrollDiv = $maskTarget.closest(".modal-content").find(".slimScrollDiv");
                if ($slimScrollDiv.length && $slimScrollDiv.find(".modal-body").length) {
                    height = 20000;
                    $slimScrollDiv.removeClass("slimScrollDiv").addClass("slimScrollDiv-deleted");
                    $maskTarget.closest(".modal-content").find(".slimScrollBar").css({
                        "z-index": "-1"
                    });
                }
                $('.modal-mask').css({
                    "width": $maskTarget.width() + 30 + "px",
                    "height": height + "px",
                    "padding-top": padding + "px"
                });
                $maskTarget.closest('.modal-dialog').find('[type="submit"]').attr('disabled', 'disabled');
            }

            //remove loadig mask from modal
            function unmaskModal() {
                var $maskTarget = $(".modal-body");
                $maskTarget.closest('.modal-dialog').find('[type="submit"]').removeAttr('disabled');
                $maskTarget.closest(".modal-content").find(".slimScrollDiv-deleted").removeClass("slimScrollDiv-deleted").addClass("slimScrollDiv");
                $maskTarget.closest(".modal-content").find(".slimScrollBar").css({
                    "z-index": "auto"
                });
                $(".modal-mask").remove();
            }

            //colse ajax modal and show success check mark
            function closeAjaxModal(success) {
                if (success) {
                    $(".modal-mask").html("<div class='circle-done'><i class='fa fa-check'></i></div>");
                    setTimeout(function() {
                        $(".modal-mask").find('.circle-done').addClass('ok');
                    }, 30);
                }
                setTimeout(function() {
                    $(".modal-mask").remove();
                    $("#ajaxModal").modal('toggle');
                    settings.onModalClose();
                }, 1000);
            }
        };
    })(jQuery);

/*
|
||||Get Elements Ajax Function||||
|
|   data => to be passed,
|   actUrl => url to which req is sent for data
|   divElem => element that is to be apended,
|   page => page name respect to ajax folder in views to be rendered with data
|
*/
var getElemView = function(postData, actUrl, divElem, page, cb, type) {
    var $elem = $(divElem);
    $.ajax({
        url: actUrl,
        data: postData,
        type: 'POST',
        success: function(data) {
            if (data.status) {
                var callback = new EJS({
                    url: page
                }).render({
                    data: data.data,
                    res: data,
                    imgUrl: imgUrl
                });
                if (type == undefined) {
                    $elem.append(callback);
                } else if (type == 'html') {
                    $elem.html(callback);
                }
                if (cb) {
                    cb(data);
                }
            }

        },
        error: function(err) {
            if (cb) {
                cb(undefined);
            }
            console.error(err);
        }
    });
}

$(document).on("click", ".clickable-element", function(event) {
    if ($(this).data("href") == undefined)
        return false;
    if ($(this).attr('target') == '_blank')
        window.open($(this).data("href"), '_blank');
    else
        window.document.location = $(this).data("href");

});

$(document).on("change","[data-act=ajax-call]",function(event){
    var id = $(this).val();
    $.ajax({
            url : '/urls/getCpiCpa/',
            type: 'GET',
            async: true,
            data: "op_id="+id
        }).done(function (response){
            if(response.status==1){
                $("#url").val(response.url);
            }
        }).fail(function () {
                alert('Data could not be loaded.');
       });
});

$(document).on("click","input[name='is_active[]']",function(event){ 
   confirm("Would you reallylike to really make it");
   var is_active = 0;
    if($(this).is(':checked')){ 
        is_active = 1;  
    }
    var id  = $(this).attr('id'); 
    $.ajax({
    url : '/traffic-diversion/update',
    type: 'GET',
    data: 'action=status&status='+is_active+'&id='+id,
    async: false,

    }).done(function (response) {
        if(response.status == 1){
            $("#status-"+id).html(response.data);
        }
    }).fail(function () {
        alert('Data could not be loaded.');
    });  
});

$(document).on("click",'.change-percent', function(){   
   var percentId  = $(this).attr('data-val');
   var actualVal = $('#percentVal-'+percentId).html();
   if(percentId){
      $('#editPercent-'+percentId).show();
      $("#mainPercent-"+percentId).hide();
      $('#percentText-'+percentId).val(actualVal);  
   } 

});

$(document).on("click",'.cancel', function(){   
   var percentId  = $(this).attr('data-id');
   if(percentId){
      $('#editPercent-'+percentId).hide();
      $("#mainPercent-"+percentId).show();  
   } 

});

$(document).on("click",".savePercent",function(event){ 
    
   var id  = $(this).attr('data-id');
   var updatedPercentage = $('#percentText-'+id).val();
   if(updatedPercentage < 0 || updatedPercentage ==''){ 
   alert('Please insert postive integer');
   return false;
    } 
    $.ajax({
    url : '/traffic-diversion/update',
    type: 'GET',
    data: 'action=percent&percent='+updatedPercentage+'&id='+id,
    async: false,
    }).done(function (response) {
        if(response.status == 1){
            $('#percentVal-'+id).html(updatedPercentage);
            $('#editPercent-'+id).hide();
            $("#mainPercent-"+id).show();
        }
    }).fail(function () {
        alert('Data could not be loaded.');
    });  
});

$(document).on("click",".savesmarttrfcPercent",function(event){ 
    
   var id  = $(this).attr('data-id');
   var updatedPercentage = $('#percentText-'+id).val();
   if(updatedPercentage < 0 || updatedPercentage ==''){ 
   alert('Please insert postive integer');
   return false;
    } 
    $.ajax({
    url : '/smart-traffic-diversion/updatesmarttrfc',
    type: 'GET',
    data: 'action=percent&percent='+updatedPercentage+'&id='+id,
    async: false,
    }).done(function (response) {
        if(response.status == 1){
            $('#percentVal-'+id).html(updatedPercentage);
            $('#editPercent-'+id).hide();
            $("#mainPercent-"+id).show();
        }
    }).fail(function () {
        alert('Data could not be loaded.');
    });  
});

});
    