$(document).ready(function() {
    $('table.country').DataTable();
} );