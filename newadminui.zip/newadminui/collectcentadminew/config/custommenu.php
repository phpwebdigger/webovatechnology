 <?php                              
return [
    'all' => array(
               'dashboard' =>  array(
                    'name' => "Dashboard",
                    'icon' => "fa-home",
                    'link' => '',
                    'class' => '',
                    'child' => []
                    ),
                'CPI' => array(
                    'name' => "CPI",
                    'icon' => "fa-wifi",
                    'link' => '#',
                    'class'=> '',
                    'child' => array(

                                    'CpaCpi'=>array(
                                        'name' => "CpaCpi Network Cr Update",
                                        'icon' => "fa-home",
                                        'link' => 'http://162.243.33.148/cr_new/cpicpa_cr_update.php',
                                        'target' => "true",
                                        'child' =>  []
                                    ),
                                    'Compare'=>array(
                                        'name' => "Hourly Compare",
                                        'icon' => "fa-home",
                                        'link' => 'crchourlycamapaire',
                                        'target' => "false",
                                        'child' =>  []
                                    ),
                                    'Conversion'=>array(
                                        'name' => "Conversions Interface",
                                        'icon' => "fa-home",
                                        'link' => 'cttiitwsieconversion',
                                        'target' => "false",
                                        'child' =>  []
                                    ),
                                    'CrcHourly'=>array(
                                        'name' => "Crc Hourly",
                                        'icon' => "fa-home",
                                        'link' => 'http://162.243.33.148/cr_new/crc_hourly_records.php',
                                        'target' => "true",
                                        'child' =>  []
                                    ),
                                    'HourlyConversions'=>array(
                                        'name' => "Hourly Conversions",
                                        'icon' => "fa-home",
                                        'link' => '162.243.33.148/cr_new/conversion_status_report.php',
                                        'target' => "true",
                                        'child' =>  []
                                    ),
                                    'NetworkUpdate'=>array(
                                        'name' => "Adnetwork update",
                                        'icon' => "fa-home",
                                        'link' => 'http://162.243.33.148/cr_new/cczbasedreport.php',
                                        'target' => "true",
                                        'child' =>  []
                                    ),
                                ),
                    ),
                    
                    'CRC' =>  array(
                                      'name' => "CRC",
                                      'icon' => "fa-clock-o",
                                      'link' => '#',
                                      'class' => '',
                                      'child' => array(
                                                'Hourly'=>array(
                                                              'name' => "Hourly",
                                                                'icon' => "fa-clock",
                                                                'link' => 'hourly',
                                                                'target' => "true",
                                                                'child' =>  []
                                                              ),
                                                  'crc'=>array(
                                                                'name' => "Crc",
                                                                'icon' => "fa-home",
                                                                'link' => 'crc',
                                                                'target' => "true",
                                                                'child' =>  []
                                                              ),
                                                   'Smart Report'=>array(
                                                         'name' => "Smart Report",
                                                          'icon' => "fa-home",
                                                          'link' => 'http://admin.cccontrol.in/smartreport?directauth=1',
                                                          'target' => "true",
                                                          'child' =>  []
                                                        ),
                                                    'CRC Siteid Hourly'=>array(
                                                         'name' => "CRC Siteid Hourly",
                                                          'icon' => "fa-home",
                                                          'link' => 'cpacpihourly',
                                                          'target' => "true",
                                                          'child' =>  []
                                                        ),
                                                    
                                                  ),
//                        'Cpi' =>  array(
//                            'name' => "cpi",
//                            'icon' => "fa-phone",
//                            'link' => '#',
//                            'class' => 'hide',
//
//                            'child' => array(
//                                
//                            ),
//                        ),

                                       ),  
                            
                    'Offers' => array(
                                              'name' => "Offers",
                                              'icon' => "fa-life-saver",
                                              'link' => '#',
                                              'class'=> '',
                                              'child' => array(
                                                         'Offerwall'=>array(
                                                                  'name' => "Offerwall",
                                                                  'icon' => "fa-home",
                                                                  'link' => 'offerwall',
                                                                  'target' => "false",
                                                                  'child' =>  []
                                                                ),
                                                          'Hourly'=>array(
                                                                  'name' => "Hourly",
                                                                  'icon' => "fa-home",
                                                                  'link' => 'crc-hourly',
                                                                  'target' => "false",
                                                                  'child' =>  []
                                                                ), 
                                                          'offerwalurllistdata'=>array(
                                                                  'name' => "Trfc",
                                                                  'icon' => "fa-home",
                                                                  'link' => 'offerwalurllistdata',
                                                                  'target' => "false",
                                                                  'child' =>  []
                                                                ),
                                                          'offer-delivery'=>array(
                                                                  'name' => "Delivery",
                                                                  'icon' => "fa-home",
                                                                  'link' => 'offer-delivery',
                                                                  'target' => "false",
                                                                  'child' =>  []
                                                                ),
                                                          'offer-networkwise'=>array(
                                                                'name' => "Networkwise",
                                                                  'icon' => "fa-home",
                                                                  'link' => 'offer-networkwise-newpage',
                                                                  'target' => "false",
                                                                  'child' =>  []
                                                           ),
                                                          'offer-networkwise-details'=>array(
                                                                'name' => "Networkwise Details",
                                                                  'icon' => "fa-home",
                                                                  'link' => 'offer-networkwise-details',
                                                                  'target' => "false",
                                                                  'child' =>  []
                                                           ),
                                                          'offer-advertiserwise'=>array(
                                                                'name' => "Advertiserwise",
                                                                'icon' => "fa-home",
                                                                'link' => 'offer-advertiserwise',
                                                                'target' => "false",
                                                                'child' =>  []
                                                          ),  
                                                          'offer-url-management'=>array(
                                                                'name' => "Url Management",
                                                                'icon' => "fa-home",
                                                                'link' => 'offer-url-management-report',
                                                                'target' => "false",
                                                                'child' =>  []
                                                          ),                        
                                                          'Publishers Offer List'=>array(
                                                                'name' => "Publishers Offer",
                                                                'icon' => "fa-home",
                                                                'link' => 'publisherOfferListnewpage',
                                                                'target' => "false",
                                                                'child' =>  []
                                                          ),
							
							'offerwalmaunalcron'=>array(
                                                            'name' => "Offerwal Maunal Cron",
                                                            'icon' => "fa-home",
                                                            'link' => 'http://162.243.33.148/cr_new/MannualCronProcess_offerwall.php',
                                                            'target' => "true",
                                                            'child' =>  []
                                                        ),
                                                        'offerwalmothlyreport'=>array(
                                                            'name' => "Offerwal Mothly Reports",
                                                            'icon' => "fa-home",
                                                            'link' => 'http://adminoffer.cccontrol.in/offerwallmonthlyreports',
                                                            'target' => "true",
                                                            'child' =>  []
                                                        ),
                                                        'event-delivery'=>array(
                                                            'name' => "Event Delivery",
                                                            'icon' => "fa-home",
                                                            'link' => 'event-delivery',
                                                            'target' => "true",
                                                            'child' =>  []
                                                        ),
                                                        'Advertiser Report TimeZone Wise'=>array(
                                                            'name' => "TimeZone Wise Advertiser Report",
                                                            'icon' => "fa-home",
                                                            'link' => 'advertiser-report-timezonewise',
                                                            'target' => "true",
                                                            'child' =>  []
                                                        ),


							                        
                              ),
                        ),   
                    'Network' => array(
                            'name' => "Network",
                            'icon' => "fa-wifi",
                            'link' => '#',
                            'class'=> '',
                            'child' => array(
                                                                              
                                         'smart-network-cr-update'=>array(
                                                         'name' => "Smart Network CR Update",
                                                          'icon' => "fa-home",
                                                          'link' => 'smart-network-cr-update',
                                                          'target' => "true",
                                                          'child' =>  []
                                                        ),
                                         'smarthomeCariar'=>array(
                                                    'name' => "Carrier Specific Default A",
                                                      'icon' => "fa-home",
                                                      'link' => 'smart-carrier-specific-default-a',
                                                      'target' => "true",
                                                      'child' =>  []
                                                    ),
                                        'smarthomeCariarC'=>array(
                                                      'name' => "Carrier Specific Default C",
                                                      'icon' => "fa-home",
                                                      'link' => 'smart-carrier-specific-default-c',
                                                      'target' => "true",
                                                      'child' =>  []
                                                    ),
                                        'smarthomeCariarWIFIA'=>array(
                                                            'name' => "Smart WiFi Specific Default A",
                                                              'icon' => "fa-home",
                                                              'link' => 'smart-wifi-specific-default-a',
                                                              'target' => "true",
                                                              'child' =>  []
                                                            ),
                                        'smarthomeCariarWIFIC'=>array(
                                                      'name' => "Smart WiFi Specific Default C",
                                                      'icon' => "fa-home",
                                                      'link' => 'smart-wifi-specific-default-c',
                                                      'target' => "true",
                                                      'child' =>  []
                                                    ),
                                       
                                  
                                      
                                        
                                        ),
                              ),
                                        'Advertiser' =>  array(
                                            'name' => "Advertiser",
                                            'icon' => "fa-tv",
                                            'link' => '#',
                                            'class'=> '',
                                            'child' => array(
                                                'advertiserList'=>array(
                                                            'name' => "Advertiser CR Update",
                                                              'icon' => "fa-home",
                                                              'link' => 'advertiser-cr-update',
                                                              'target' => "true",
                                                              'child' =>  []
                                                            ),
                                                'advertiser_campaign_management'=>array(
                                                              'name' =>"Advertiser Campaign Management",
                                                              'icon'=>"fa-home",
                                                              'link' => "http://162.243.33.148/cr_new/adsManagement.php?users=1",
                                                              'target' =>"true",
                                                              'child'=>[]
                                                      ),
                                                      ),
                                            ),
                                            'TRFC/URL' =>  array(
                                                        'name' => "Trfc/Urls",
                                                        'icon' => "fa-globe",
                                                        'link' => '#',
                                                        'class' => '',
                                                        'child' => array(
                                                                     
                                                                        'smart-traffic-diversion'=>array(
                                                         'name' => "Smart Traffic Diversion",
                                                          'icon' => "fa-home",
                                                          'link' => 'smart-traffic-diversion',
                                                          'target' => "true",
                                                          'child' =>  []
                                                        ),
                                                                         'urls'=>  array(
                                                                                      'name' => "Url Management",
                                                                                      'icon' => "fa-home",
                                                                                      'link' => 'urls',
                                                                                      'target' => "true",
                                                                                      'child' =>  []
                                                                                    ),
                                                                      
                                                                      'Replace Url'=>array(
                                                                          'name' => "Replace Url",
                                                                          'icon' => "fa-home",
                                                                          'link' => 'smarturls/edit-smarturlnew',
                                                                          'target' => "true",
                                                                          'child' =>  []
                                                                         ),
                                                                    ), 
                                                            ),

                                            'Ads' => array(

                                                   'name' => "Ads",
                                                            'icon' => "fa-table",
                                                            'link' => '#',
                                                            'class' => '',
                                                            'child' => array(
                                                                 'create campaign'=> array(
                                                                          'name' => "Create New Campaign",
                                                                          'icon' => "fa-home",
                                                                          'link' => 'http://admin.cccontrol.in/create_campaign_new',
                                                                          'target' => "true",
                                                                          'child' =>  []
                                                                         ),
                                                                  'create campaign with Https'=> array(
                                                                          'name' => "Create New Campaign with Https",
                                                                          'icon' => "fa-home",
                                                                          'link' => 'http://admin.cccontrol.in/new_campaign_https',
                                                                          'target' => "true",
                                                                          'child' =>  []
                                                                         ),
                                                                        'ads_management'=>array(
                                                                        'name' =>"Ads management",
                                                                        'icon'=>"fa-home",
                                                                        'link' => "ads",
                                                                        'target' =>"true",
                                                                        'child'=>[]
                                                                         ),
                                                                        'cca_list'=>array(
                                                                          'name' => 'CCA Url List',
                                                          'icon' => 'fa-home',
                                                          'link' => 'cca/list',
                                                          'target' => 'true',
                                                          'child' =>[]
                                                          ),
                                                         ),
                                                          

                                              ),
                                              'Query' =>  array(
                                                            'name' => "Query DB",
                                                            'icon' => "fa-table",
                                                            'link' => '#',
                                                            'class' => '',
                                                            'child' => array(
                                                                      'query'=>array(
                                                                                    'name' => "Execute Query",
                                                                                      'icon' => "fa-home",
                                                                                      'link' => 'query',
                                                                                      'target' => "true",
                                                                                      'child' =>  []
                                                                                    ),
                                                                    'Pgtable'=>array(
                                                      'name' => "Pg Table",
                                                      'icon' => "fa-home",
                                                      'link' => 'http://162.243.33.148/cr_new/mongo_interface2.php',
                                                      'target' => "true",
                                                      'child' =>  []
                                                    ),
                                                                        ),
                                                             ),
                                            'Cron/Delivery' =>  array(
                                                            'name' => "Cron",
                                                            'icon' => "fa-table",
                                                            'link' => '#',
                                                            'class' => '',
                                                            'child' => array(
                                                                      'query'=>array(
                                                                                    'name' => "S2S Manual Cron",
                                                                                      'icon' => "fa-home",
                                                                                      'link' => 'http://162.243.33.148/cr_new/ManualCronProcess.php?users=1',
                                                                                      'target' => "true",
                                                                                      'child' =>  []
                                                                                    ),
                                                                      'manual_temp'=>array(
                                                                                    'name' => "S2S Manual Cron with Pubid",
                                                                                      'icon' => "fa-home",
                                                                                      'link' => 'http://162.243.33.148/cr_new/MannualCronProcess_temp.php?users=1',
                                                                                      'target' => "true",
                                                                                      'child' =>  []
                                                                                    ),
                                                                        'cron-delivery-management'=>array(
                                                                                     'name' => "Cron Management",
                                                                                      'icon' => "fa-home",
                                                                                      'link' => 'cron',
                                                                                      'target' => "true",
                                                                                      'child' =>  []
                                                                                    ), 
                                                                        'smart-delivery'=>array(
                                                                                      'name' => "Delivery Management",
                                                                                        'icon' => "fa-home",
                                                                                         'link' => 'smart-delivery',
                                                                                        'target' => "true",
                                                                                        'child' =>  []
                                                                        ),
                                                                        'SmartDeliveryAdd'=>array(
                                                                          'name' => "Smart Add Cron Delivery",
                                                                          'icon' => "fa-home",
                                                                          'link' => 'smart-delivery/add',
                                                                          'target' => "true",
                                                                          'child' =>  []
                                                                        ),
                                                                        'smart-delivery-event'=>array(
                                                                          'name' => "Event Delivery",
                                                                          'icon' => "fa-home",
                                                                          'link' => 'smart-delivery-event',
                                                                          'target' => "true",
                                                                          'child' =>  []
                                                                        ),
                                                                    ),     
                                                             ),           
                                                            'Property' =>  array(
                                                            'name' => "Property",
                                                            'icon' => "fa-table",
                                                            'link' => '#',
                                                            'class' => '',
                                                            'child' => array(
                                                                      'StopCampaign'=>array(
                                                                                    'name' => "Stop Campaign",
                                                                                      'icon' => "fa-home",
                                                                                      'link' => 'http://162.243.39.72/SmartCampaignTraffic/StopCampaignTraffic.jsp',
                                                                                      'target' => "true",
                                                                                      'child' =>  []
                                                                                    ),
                                                                        'CityExcludeLogic'=>array(
                                                                                    'name' => "City Exclude Logic",
                                                                                      'icon' => "fa-home",
                                                                                    //  'link' => 'http://162.243.39.72/SmartCampaignTraffic/CityCampaignReplace.jsp',
									'link' => 'citymapping',		
                                                                                      'target' => "true",
                                                                                      'child' =>  []
                                                                                    ),
                                                                        'DynamicPubidConfiguration'=>array(
                                                                                    'name' => "Dynamic Pubid Configuration",
                                                                                      'icon' => "fa-home",
                                                                                      'link' => 'http://162.243.39.72/Interfaces/specialProperties.jsp?file=DynamicPubID',
                                                                                      'target' => "true",
                                                                                      'child' =>  []
                                                                                    ),
                                                                        'IosProperties'=>array('name' => "Ios Properties Configuration",
                                                                            'icon' => "fa-home",
                                                                            'link' => 'http://162.243.39.72/Interfaces/specialProperties.jsp?file=IosDiv',
                                                                            'target' => "true",
                                                                           'child' =>  []
                                                                            ),
                                                                        'AndroidDivProperties'=>array('name' => "Android Div Properties Configuration",
                                                                            'icon' => "fa-home",
                                                                            'link' => 'http://162.243.39.72/Interfaces/specialProperties.jsp?file=AndroidDiv',
                                                                            'target' => "true",
                                                                           'child' =>  []
                                                                            ),
                                                                       'AndroidSiteProperties'=>array('name' => "Siteid Wise Redirection Traffic",
                                                                            'icon' => "fa-home",
                                                                            'link' => 'http://162.243.39.72/Interfaces/specialProperties.jsp?file=siteDiv',
                                                                            'target' => "true",
                                                                           'child' =>  []
                                                                            ),
                                                                       'OsVersion'=>array('name' => "Os Version",
                                                                            'icon' => "fa-home",
                                                                            'link' => 'http://162.243.39.72/Interfaces/specialProperties.jsp?file=androidVersion',
                                                                            'target' => "true",
                                                                           'child' =>  []
                                                                            ),
                                                                       'DynamicAppName'=>array('name'=>"Dynamic AppName and AppId",
                                                                          'icon'=>"fa-home",
                                                                          'link'=>'http://162.243.39.72/Interfaces/specialProperties.jsp?file=DynamicAppName',
                                                                          'target'=>"true",
                                                                          'child' =>[]
                                                                          ),
                                                                         'idfaLogic'=>array('name'=>"GAID and IDFA Mandatory",
                                                                          'icon'=>"fa-home",
                                                                          'link'=>'http://162.243.39.72/Interfaces/specialProperties.jsp?file=idfaLogic',
                                                                          'target'=>"true",
                                                                          'child' =>[]
                                                                          ),

                                                                          'Include_Exclude'=>array(
 'name' => "Include Exclude Siteid Wise",
 'icon' => "fa-home",
 'link' => 'siteidwsiediversion',
 'target' => "true",
 'child' =>  []
),      
								
                                                                        ),
                                                            ),
                                                            'Domain' =>  array(
                                                            'name' => "Domain",
                                                            'icon' => "fa-users",
                                                            'link' => '#',
                                                            'class' => '',
                                                            'child' => array(
                                                                      'domain-info'=>array(
                                                                                    'name' => "Domain Info",
                                                                                      'icon' => "fa-home",
                                                                                      'link' => 'domain-info',
                                                                                      'target' => "true",
                                                                                      'child' =>  []
                                                                                    ),
                                                                      'info-domain'=>array(
                                                                                    'name' => "Add Domain Info",
                                                                                      'icon' => "fa-home",
                                                                                      'link' => 'info-domain',
                                                                                      'target' => "true",
                                                                                      'child' =>  []
                                                                                    ),
                                                                      'redirect-info'=>array(
                                                                                    'name' => "Domain Redirection",
                                                                                      'icon' => "fa-home",
                                                                                      'link' => 'redirect-info',
                                                                                      'target' => "true",
                                                                                      'child' =>  []
                                                                                    )
                                                                        ),
                                                            ),
                                                            'Deactivation' =>  array(
                                                            'name' => "Deactivation",
                                                            'icon' => "fa-users",
                                                            'link' => '#',
                                                            'class' => '',
                                                            'child' => array(
                                                                      'DeactivationData'=>array(
                                                                                    'name' => "Domain Info",
                                                                                      'icon' => "fa-home",
                                                                                      'link' => 'deactivation-data',
                                                                                      'target' => "true",
                                                                                      'child' =>  []
                                                                                    ),
                                                                      'Report'=>array(
                                                                                    'name' => "Deactivation Report",
                                                                                      'icon' => "fa-home",
                                                                                      'link' => 'http://162.243.33.148/cr_new/deactivation_list.php',
                                                                                      'target' => "true",
                                                                                      'child' =>  []
                                                                                    )
                                                            )
                                                        ),
                                                        'Smart' =>  array(
                                            'name' => "Smart Link",
                                            'icon' => "fa-tv",
                                            'link' => '#',
                                            'class'=> '',
                                            'child' => array(
                                                'smartList'=>array(
                                                                'name' => "Smart Link Campaign List",
                                                                'icon' => "fa-home",
                                                                'link' => 'smart-interface-new',
                                                                'target' => "true",
                                                                'child' =>  []
                                                            ),
                                                'query'=>array(
                                                                'name' => "Smart Manual Cron",
                                                                  'icon' => "fa-home",
                                                                  'link' => 'smart-manual-cron',
                                                                  'target' => "true",
                                                                  'child' =>  []
                                                                ),
                                                
                                                      ),
                                            ),
                      'Other' =>  array(
                                            'name' => "Other",
                                            'icon' => "fa-clock-o",
                                            'link' => '#',
                                            'class'=> '',
                                            'child' => array(
                                                'appserverList'=>array(
                                                              'name' => "App Server Wise Report",
                                                              'icon' => "fa-home",
                                                              'link' => 'http://162.243.33.148/cr_new/appserverwise_report.php?users=1',
                                                              'target' => "true",
                                                              'child' =>  []
                                                            ),
                                                'addResources'=>array(
                                                              'name' => "Add Resources",
                                                              'icon' => "fa-home",
                                                              'link' => 'http://162.243.33.148/cr_new/new_resources.php?users=1',
                                                              'target' => "true",
                                                              'child' =>  []
                                                            ),
                                                'previewList'=>array(
                                                              'name' => "Preview List",
                                                              'icon' => "fa-home",
                                                              'link' => 'http://admin.cccontrol.in/preview_list?directauth=1',
                                                              'target' => "true",
                                                              'child' =>  []
                                                            ),
                                                'specialDelivery'=>array(
                                                              'name' => "Special Delivery",
                                                              'icon' => "fa-home",
                                                              'link' => 'special-delivery',
                                                              'target' => "true",
                                                              'child' =>  []
                                                            ),
				     'Fraud Info'=>array('name' => "Fraud Click Info",'icon' => "fa-home",'link' => 'fraud-click-info','target'=>"true",'child' =>  []),
             'showaddnetwork'=>array('name' => "Add Network Resources",'icon' => "fa-home",'link' => 'Resources/add-network','target' => "false",                    'child' =>  []
                                                        ),
                                            'showAdv'=>array(
                                                          'name' => "Add Advertiser Resources",
                                                          'icon' => "fa-home",
                                                          'link' => 'Resources/add-advertiser',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'showAddOptview'=>array(
                                                          'name' => "Add Operator Resources",
                                                          'icon' => "fa-home",
                                                          'link' => 'Resources/add-operator',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            // 'addip'=>array(
                                            //               'name' => "Add Operator IP",
                                            //               'icon' => "fa-home",
                                            //               'link' => 'Resources/add-ip',
                                            //               'child' =>  []
                                            //             ),
                                            'getnetworklist'=>array(
                                                          'name' => "List Network Resources",
                                                          'icon' => "fa-home",
                                                          'link' => 'Resources/list-network',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'getAdvlist'=>array(
                                                          'name' => "List Advertiser Resources",
                                                          'icon' => "fa-home",
                                                          'link' => 'Resources/list-advertiser',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'getOptlist'=>array(
                                                          'name' => "List Operator Resources",
                                                          'icon' => "fa-home",
                                                          'link' => 'Resources/list-operator',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        )                                                   
						 ),
                                            ),
                                                        'Analytics' =>  array(
                                            'name' => "Analytics",
                                            'icon' => "fa-clock-o",
                                            'link' => '#',
                                            'class'=> '',
                                            'child' => array(
                                                'smartAnalyticsNew'=>array(
                                                              'name' => "Smart Analytics New",
                                                              'icon' => "fa-home",
                                                              'link' => 'smart-analytics-new',
                                                              'target' => "true",
                                                              'child' =>  []
                                                            ),
                                                'SmartAnalyticsReports'=>array(
                                                              'name' => "Smart Analytics Reports",
                                                              'icon' => "fa-home",
                                                              'link' => 'smart-analytics-reports',
                                                              'target' => "true",
                                                              'child' =>  []
                                                            ),
                                                
                                                      ),
                                            )
                )
    
];
