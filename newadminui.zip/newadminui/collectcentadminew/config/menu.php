 <?php                              
return [
    'all' => array(
               'dashboard' =>  array(
                                'name' => "Dashboard",
                                'icon' => "fa-home",
                                'link' => '',
                                'class' => '',
                                'child' => []
                                ),
                    'network' =>  array(
                                'name' => "Network",
                                'icon' => "fa-users",
                                'link' => '#',
                                'class' => 'hide',
                                'child' => array(
                                           'home'=>array(
                                                         'name' => "Network CR Update",
                                                          'icon' => "fa-home",
                                                          'link' => 'network-cr-update',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'homeCPA'=>array(
                                                          'name' => "CPA Network CR Update",
                                                          'icon' => "fa-home",
                                                          'link' => 'network-cpa-cr-update',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'homeCPI'=>array(
                                                          'name' => "CPI Network CR Update",
                                                          'icon' => "fa-home",
                                                          'link' => 'network-cpi-cr-update',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                             'homeCPS'=>array(
                                                          'name' => "CPS Network CR Update",
                                                          'icon' => "fa-home",
                                                          'link' => 'network-cps-cr-update',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'homeCPICPA'=>array(
                                                          'name' => "CPICPA Network CR Update",
                                                          'icon' => "fa-home",
                                                          'link' => 'network-cpicpa-cr-update',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'backCampaign'=>array(
                                                        'name' => "Back Logic",
                                                          'icon' => "fa-home",
                                                          'link' => 'network-back-campaign',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'publisherCr'=>array(
                                                        'name' => "Publisher CR Update",
                                                          'icon' => "fa-home",
                                                          'link' => 'publisher-cr-update',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                             'homeCariarRotator'=>array(
                                                        'name' => "Rotator CR Update",
                                                          'icon' => "fa-home",
                                                          'link' => 'network-cr-update-rotator',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                              'homeOrganizr'=>array(
                                                        'name' => "Organizr CPI Report",
                                                          'icon' => "fa-home",
                                                          'link' => 'organizr-cr-update',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        )

                                                
                                            )
                                
                               ),
                 'network' =>  array(
                                'name' => "Network",
                                'icon' => "fa-users",
                                'link' => '#',
                                'class' => '',
                                'child' => array(
                                           'home'=>array(
                                                         'name' => "Network CR Update",
                                                          'icon' => "fa-home",
                                                          'link' => 'network-cr-update',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'homeCPARedis'=>array(
                                                          'name' => "CPA Network CR Update",
                                                          'icon' => "fa-home",
                                                          'link' => 'network-cpa-cr-update-redis',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'homeCPIRedis'=>array(
                                                          'name' => "CPI Network CR Update",
                                                          'icon' => "fa-home",
                                                          'link' => 'network-cpi-cr-update-redis',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'homeCPSRedis'=>array(
                                                          'name' => "CPS Network CR Update",
                                                          'icon' => "fa-home",
                                                          'link' => 'network-cps-cr-update-redis',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'homeCPICPARedis'=>array(
                                                          'name' => "CPICPA Network CR Update",
                                                          'icon' => "fa-home",
                                                          'link' => 'network-cpicpa-cr-update-redis',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                          'internatinal'=>array(
                                                          'name' => "International Network CR Update",
                                                          'icon' => "fa-home",
                                                          'link' => 'network-international',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),            
                                          'internationalrotatormgnt_list'=>array(
                                                        'name' => "Smartlink Diversion Management",
                                                          'icon' => "fa-home",
                                                          'link' => 'internationalrotatormgnt_list',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                          'homeCariarRotator'=>array(
                                                        'name' => "Rotator CR Update",
                                                          'icon' => "fa-home",
                                                          'link' => 'network-cr-update-rotator',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                          'listblockcca'=>array(
                                                        'name' => "Block CCA",
                                                          'icon' => "fa-home",
                                                          'link' => 'listblockcca',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                          'networkDayWise'=>array(
                                                        'name' => "Network Day Wise",
                                                          'icon' => "fa-home",
                                                          'link' => 'network',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),

                                           'offernetworkwise'=>array(
                                                        'name' => "Offer Networkwise",
                                                          'icon' => "fa-home",
                                                          'link' => 'offer-networkwise',
                                                          'target' => "true",
                                                          'child' =>  []
                                                        ),


                                                      )
                                
                                                    ), 
                          'careerspecific' =>  array(
                            'name' => "Carrier",
                            'icon' => "fa-phone",
                            'link' => '#',
                            'class'=> '', 
                            'child' => array(
                                      'homeCariar'=>array(
                                                    'name' => "Carrier Specific Default A",
                                                      'icon' => "fa-home",
                                                      'link' => 'carrier-specific-default-a',
                                                      'target' => "false",
                                                      'child' =>  []
                                                    ),
                                        'homeCariarC'=>array(
                                                      'name' => "Carrier Specific Default C",
                                                      'icon' => "fa-home",
                                                      'link' => 'carrier-specific-default-c',
                                                      'target' => "false",
                                                      'child' =>  []
                                                    ),
                                        'homeCariarWIFIA'=>array(
                                                            'name' => "WiFi Specific Default A",
                                                              'icon' => "fa-home",
                                                              'link' => 'wifi-specific-default-a',
                                                              'target' => "false",
                                                              'child' =>  []
                                                            ),
                                        'homeCariarWIFIC'=>array(
                                                      'name' => "WiFi Specific Default C",
                                                      'icon' => "fa-home",
                                                      'link' => 'wifi-specific-default-c',
                                                      'target' => "false",
                                                      'child' =>  []
                                                    )
                                        )
                           ),
                      'Smart' => array(
                            'name' => "Smart",
                            'icon' => "fa-wifi",
                            'link' => '#',
                            'class'=> '',
                            'child' => array(
                                        'smartLinkWG'=>array(
                                                    'name' => "Smart Link WG",
                                                      'icon' => "fa-home",
                                                      'link' => 'smart-link-wg',
                                                      'target' => "false",
                                                      'child' =>  []
                                                    ),
                                        'smartLinkWM'=>array(
                                                      'name' => "Smart Link WM",
                                                      'icon' => "fa-home",
                                                      'link' => 'smart-link-wm',
                                                      'target' => "false",
                                                      'child' =>  []
                                                    ),
                                        'smartLinkWIFIWG'=>array(
                                                      'name' => "Smart Link Wifi WG",
                                                      'icon' => "fa-home",
                                                      'link' => 'smart-link-wifi-wg',
                                                      'target' => "false",
                                                      'child' =>  []
                                                    ),
                                        'smartLinkWIFIWM'=>array(
                                                      'name' => "Smart Link WIFI WM",
                                                      'icon' => "fa-home",
                                                      'link' => 'smart-link-wifi-wm',
                                                      'target' => "false",
                                                      'child' =>  []
                                                    ),
                                        'smart-interface'=>array(
                                                        'name' => "Smart Interface",
                                                          'icon' => "fa-home",
                                                          'link' => 'smart-interface',
                                                          'target' => "false",
                                                          'child' =>  []

                                                        ),
                                        'smart-countrywise'=>array(
                                                        'name' => "Smart CountryWise",
                                                          'icon' => "fa-home",
                                                          'link' => 'smart-countrywise',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                        'smart-hourly'=>array(
                                                        'name' => "Smart hourly",
                                                          'icon' => "fa-home",
                                                          'link' => 'smart-hourly',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                        'smart-interface-advertiser'=>array(
                                                        'name' => "Smart advertiser wise",
                                                          'icon' => "fa-home",
                                                          'link' => 'smart-interface-advertiser',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                         'smart-network-cr-update'=>array(
                                                         'name' => "Smart Network CR Update",
                                                          'icon' => "fa-home",
                                                          'link' => 'smart-network-cr-update',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                         'SmartadvertiserList'=>array(
                                                            'name' => "Smart Advertiser CR Update",
                                                              'icon' => "fa-home",
                                                              'link' => 'smart-advertiser-cr-update',
                                                              'target' => "false",
                                                              'child' =>  []
                                                            ),
                                         'smarthomeCariar'=>array(
                                                    'name' => "Smart Carrier Specific Default A",
                                                      'icon' => "fa-home",
                                                      'link' => 'smart-carrier-specific-default-a',
                                                      'target' => "false",
                                                      'child' =>  []
                                                    ),
                                        'smarthomeCariarC'=>array(
                                                      'name' => "Smart Carrier Specific Default C",
                                                      'icon' => "fa-home",
                                                      'link' => 'smart-carrier-specific-default-c',
                                                      'target' => "false",
                                                      'child' =>  []
                                                    ),
                                        'smarthomeCariarWIFIA'=>array(
                                                            'name' => "Smart WiFi Specific Default A",
                                                              'icon' => "fa-home",
                                                              'link' => 'smart-wifi-specific-default-a',
                                                              'target' => "false",
                                                              'child' =>  []
                                                            ),
                                        'smarthomeCariarWIFIC'=>array(
                                                      'name' => "Smart WiFi Specific Default C",
                                                      'icon' => "fa-home",
                                                      'link' => 'smart-wifi-specific-default-c',
                                                      'target' => "false",
                                                      'child' =>  []
                                                    ),
                                        'smart-alldays'=>array(
                                                        'name' => "Smart crc daywise",
                                                          'icon' => "fa-home",
                                                          'link' => 'smart-alldays',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                                    ),
                                                  ),
                                  
                            'Advertiser' =>  array(
                                            'name' => "Advertiser",
                                            'icon' => "fa-tv",
                                            'link' => '#',
                                            'class'=> '',
                                            'child' => array(
                                                
                                                'advertiserList'=>array(
                                                            'name' => "Advertiser CR Update",
                                                              'icon' => "fa-home",
                                                              'link' => 'advertiser-cr-update',
                                                              'target' => "false",
                                                              'child' =>  []
                                                            ),
                                                'AdhomeCPA'=>array(
                                                              'name' => "CPA Advertiser CR Update",
                                                              'icon' => "fa-home",
                                                              'link' => 'advertiser-cpa-cr-update',
                                                              'target' => "false",
                                                              'child' =>  []
                                                            ),
                                                'AdhomeCPI'=>array(
                                                              'name' => "CPI Advertiser CR Update",
                                                              'icon' => "fa-home",
                                                              'link' => 'advertiser-cpi-cr-update',
                                                              'target' => "false",
                                                              'child' =>  []
                                                            ),
                                                'AdhomeCPS'=>array(
                                                              'name' => "CPS Advertiser CR Update",
                                                              'icon' => "fa-home",
                                                              'link' => 'advertiser-cps-cr-update',
                                                              'target' => "false",
                                                              'child' =>  []
                                                            ),
                                                'AdhomeCPICPA'=>array(
                                                              'name' => "CPICPA Advertiser CR Update",
                                                              'icon' => "fa-home",
                                                              'link' => 'advertiser-cpicpa-cr-update',
                                                              'target' => "false",
                                                              'child' =>  []
                                                            )
                                            )
                               ),
            
                      'Fraud Info' =>  array(
                                'name' => "Fraud Info",
                                'icon' => "fa fa-info-circle",
                                'link' => '#',
                                'class' => '',
                                'child' => array(
                                          'fraudinfo'=>array(
                                                        'name' => "Fraud Click Info",
                                                          'icon' => "fa-home",
                                                          'link' => 'fraud-click-info',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                                )
                                          ),                     
                  'Query' =>  array(
                                'name' => "Query DB",
                                'icon' => "fa-table",
                                'link' => '#',
                                'class' => '',
                                'child' => array(
                                          'query'=>array(
                                                        'name' => "Execute Query",
                                                          'icon' => "fa-home",
                                                          'link' => 'query',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'log'=>array(
                                                          'name' => "Query Access Log",
                                                          'icon' => "fa-home",
                                                          'link' => 'query-log',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        )
                                            )
                               ),
                     'Urls' =>  array(
                                'name' => "Ad Urls",
                                'icon' => "fa-globe",
                                'link' => '#',
                                'class' => '',
                                'child' => array(
                                          'urls'=>array(
                                                        'name' => "All Urls",
                                                          'icon' => "fa-home",
                                                          'link' => 'urls',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            
                                            
                                            'createCampaign'=>array(
                                                          'name' => "Create New Campaign",
                                                          'icon' => "fa-home",
                                                          'link' => 'create-new-campaign',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'urlcpa'=>array(
                                                          'name' => "CPA url Management",
                                                          'icon' => "fa-home",
                                                          'link' => 'urls-cpa',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'urlcpi'=>array(
                                                          'name' => "CPI urls Management",
                                                          'icon' => "fa-home",
                                                          'link' => 'urls-cpi',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'urlcps'=>array(
                                                          'name' => "CPS url Management",
                                                          'icon' => "fa-home",
                                                          'link' => 'urls-cps',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'urlcpicpa'=>array(
                                                          'name' => "CPICPA url Management",
                                                          'icon' => "fa-home",
                                                          'link' => 'urls-cpicpa',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'urlcollectads'=>array(
                                                          'name' => "Collectcent Ads Management",
                                                          'icon' => "fa-home",
                                                          'link' => 'ads',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        )
                                            )
                               ),
                  'delivery' =>  array(
                                'name' => "Delivery",
                                'icon' => "fa-bus",
                                'link' => '#',
                                'class' => '',
                                'child' => array(
                                          'delivery'=>array(
                                                        'name' => "Delivery Management",
                                                          'icon' => "fa-home",
                                                          'link' => 'delivery',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'deliverySale'=>array(
                                                        'name' => "Delivery Sale",
                                                          'icon' => "fa-home",
                                                          'link' => 'delivery-sale',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'deliveryAdd'=>array(
                                                          'name' => "Add delivery",
                                                          'icon' => "fa-home",
                                                          'link' => 'delivery/add',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'SmartDeliveryAdd'=>array(
                                                          'name' => "Smart Add delivery",
                                                          'icon' => "fa-home",
                                                          'link' => 'smart-delivery/add',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'deliverySaleAdd'=>array(
                                                          'name' => "Add Delivery sale",
                                                          'icon' => "fa-home",
                                                          'link' => 'delivery-sale/add',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'deliveryReport'=>array(
                                                          'name' => "Delivery report",
                                                          'icon' => "fa-home",
                                                          'link' => 'delivery-report',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'deactivationReport'=>array(
                                                          'name' => "Deactivation report",
                                                          'icon' => "fa-home",
                                                          'link' => 'deactivation-data',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        )
                                            )
                               ),
                        'Ip Pool' =>  array(
                                'name' => "Ip Pool",
                                'icon' => "fa-bus",
                                'link' => '#',
                                'class' => '',
                                'child' => array(
                                          'campaign ip-pool'=>array(
                                                        'name' => "Campaign Ip Pool",
                                                          'icon' => "fa-home",
                                                          'link' => 'campaign-ip-pool',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'Add campaign ip Pool'=>array(
                                                        'name' => "Add campaign ip Pool",
                                                          'icon' => "fa-home",
                                                          'link' => 'add-campaign-ip-pool',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'Ip pool'=>array(
                                                          'name' => "Ip Pool",
                                                          'icon' => "fa-home",
                                                          'link' => 'ip-pools',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'Add Ip Pool'=>array(
                                                          'name' => "Add Ip Pool",
                                                          'icon' => "fa-home",
                                                          'link' => 'add-ip-pool',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            )
                               ),
                      'users' =>  array(
                                'name' => "Users",
                                'icon' => "fa-user",
                                'link' => '#',
                                'class' => '',
                                'child' => array(
                                          'userlist'=>array(
                                                        'name' => "User List",
                                                          'icon' => "fa-home",
                                                          'link' => 'users',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'userRegister'=>array(
                                                          'name' => "Add User",
                                                          'icon' => "fa-home",
                                                          'link' => 'users/register',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'rolelist'=>array(
                                                          'name' => "All Roles",
                                                          'icon' => "fa-home",
                                                          'link' => 'users/roles',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'role-add'=>array(
                                                          'name' => "Add Roles",
                                                          'icon' => "fa-home",
                                                          'link' => 'users/roles/register',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        )
                                            )
                               ),
                      'resources' =>  array(
                                'name' => "Resources",
                                'icon' => "linea-icon linea-software fa-fw",
                                'link' => '#',
                                'class' => '',
                                'child' => array(
                                          'showaddnetwork'=>array(
                                                        'name' => "Add Network Resources",
                                                          'icon' => "fa-home",
                                                          'link' => 'Resources/add-network',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'showAdv'=>array(
                                                          'name' => "Add Advertiser Resources",
                                                          'icon' => "fa-home",
                                                          'link' => 'Resources/add-advertiser',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'showAddOptview'=>array(
                                                          'name' => "Add Operator Resources",
                                                          'icon' => "fa-home",
                                                          'link' => 'Resources/add-operator',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            // 'addip'=>array(
                                            //               'name' => "Add Operator IP",
                                            //               'icon' => "fa-home",
                                            //               'link' => 'Resources/add-ip',
                                            //               'child' =>  []
                                            //             ),
                                            'getnetworklist'=>array(
                                                          'name' => "List Network Resources",
                                                          'icon' => "fa-home",
                                                          'link' => 'Resources/list-network',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'getAdvlist'=>array(
                                                          'name' => "List Advertiser Resources",
                                                          'icon' => "fa-home",
                                                          'link' => 'Resources/list-advertiser',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'getOptlist'=>array(
                                                          'name' => "List Operator Resources",
                                                          'icon' => "fa-home",
                                                          'link' => 'Resources/list-operator',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        )
                                            )
                               ),
             
                              'other' =>  array(
                                'name' => "Others",
                                'icon' => "fa-question",
                                'link' => '#',
                                'class' => '',
                                'child' => array(
                                          'cron'=>array(
                                                        'name' => "Cron Management",
                                                          'icon' => "fa-home",
                                                          'link' => 'cron',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                          'manual-cron'=>array(
                                                        'name' => "Manual Cron",
                                                          'icon' => "fa-home",
                                                          'link' => 'manual-cron',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                           'autoCampaignIndex'=>array(
                                                        'name' => "Auto Campaign Changer",
                                                          'icon' => "fa-home",
                                                          'link' => 'cca/auto-campaign',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                           'autocampaignadd'=>array(
                                                        'name' => "Add New Auto Campaign ",
                                                          'icon' => "fa-home",
                                                          'link' => 'cca/auto-campaign-add',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'traffic'=>array(
                                                        'name' => "Traffic Diversion",
                                                          'icon' => "fa-home",
                                                          'link' => 'traffic-diversion',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            
                                           'ccalist'=>array(
                                                          'name' => "Campaign List",
                                                          'icon' => "fa-home",
                                                          'link' => "cca/list",
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'ConvStatusRep'=>array(
                                                          'name' => "Conversion Status Report",
                                                          'icon' => "fa-home",
                                                          'link' => "cca/conversion-status-report",
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'AddnewAdvRev'=>array(
                                                          'name' => "Add New Advertiser Reverse",
                                                          'icon' => "fa-home",
                                                          'link' => "advertiser-reverse",
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'reverseAdvertiser'=>array(
                                                          'name' => "Advertiser Reverse",
                                                          'icon' => "fa-home",
                                                          'link' => 'advertiser-reverse-view',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                          /*  'adsManagement'=>array(
                                                          'name' => "Advertiser Ads Management",
                                                          'icon' => "fa-home",
                                                          'link' => "ads-management",
                                                          'target' => "false",
                                                          'child' =>  []
                                              ),

             'updateCamp'=>array(
                                                          'name' => "advertiser ad Compaign new",
                                                          'icon' => "fa-home",
                                                          'link' => "cca/update-campaigns",
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                          */      
               )

                               ),
                      'report' =>  array(
                                'name' => "Reports",
                                'icon' => "fa-file-text-o",
                                'link' => '#',
                                'class' => '',
                                'child' => array(
                                          'conversioncountreport'=>array(
                                                        'name' => "Conversion Count Report",
                                                          'icon' => "fa-home",
                                                          'link' => 'conversion-count-report',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                          'indexCountry'=>array(
                                                        'name' => "Country Wise CRC Records",
                                                          'icon' => "fa-home",
                                                          'link' => 'country-wise-records',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                          'appwise-server-details'=>array(
                                                        'name' => "Appwise Server Details",
                                                          'icon' => "fa-home",
                                                          'link' => 'appwise-server-details',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                          
                                          'crchouly'=>array(
                                                        'name' => "CRC Hourly Records",
                                                          'icon' => "fa-home",
                                                          'link' => 'crc-hourly-records',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            'country-redirection'=>array(
                                                        'name' => "Country Redirection",
                                                          'icon' => "fa-home",
                                                          'link' => 'country-redirection',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                           'preview-list'=>array(
                                                        'name' => "Preview List",
                                                          'icon' => "fa-home",
                                                          'link' => 'http://admin.cccontrol.in/preview_list',
                                                          'target' => "true",
                                                          'child' =>  []
                                                        ),
                                            'operator-property-interface'=>array(
                                                        'name' => "Operator Property Interface",
                                                          'icon' => "fa-home",
                                                          'link' => 'http://162.243.39.72/PropertiesInterfaces/specialProperties.jsp',
                                                          'target' => "true",
                                                          'child' =>  []
                                                        ),
                                            'deactivation-report'=>array(
                                                        'name' => "Advertiser deactivation report",
                                                          'icon' => "fa-home",
                                                          'link' => 'deactivation-report',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),

                                            )

                               )




        )
    
];
