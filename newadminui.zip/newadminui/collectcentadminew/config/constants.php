<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Stripe, Mailgun, Mandrill, and others. This file provides a sane
    | default location for this type of information, allowing packages
    | to have a conventional place to find your various credentials.
    |
    */

    'GROUP_BY_OPTION' => [
        [
        'key'=>'date',
        'val'=>'Group By Date'
        ], 
        [
        'key'=>'hour',
        'val'=>'Group By Hour'
        ], 
        [
        'key'=>'op_id',
        'val'=>'Group By Operator'
        ],
        [
        'key'=>'id_channel',
        'val'=>'Group By Network'
        ],
        [
        'key'=>'id_advertiser',
        'val'=>'Group By Advertiser'
        ],
        [
        'key'=>'id_advertiser_campaign',
        'val'=>'Group By Advertiser Campaign',
        ],
        [
        'key'=>'id_ad',
        'val'=>'Group By Id Ad',
        ],    
        [
        'key'=>'parent_cca',
        'val'=>'Group By Parent CCA'
        ],
        [
        'key'=>'traffic_type',
        'val'=>'Group By Traffic Type'
        ],
        [
        'key'=>'report_type',
        'val'=>'Group By Report Type'
        ],
        [
        'key'=>'country',
        'val'=>'Group By country'
        ]
     ],

'GROUP_BY_OPTION_CPICPA' => [
        [
        'key'=>'date',
        'val'=>'Group By Date'
        ], 
        [
        'key'=>'hour',
        'val'=>'Group By Hour'
        ], 
        [
        'key'=>'op_id',
        'val'=>'Group By Operator'
        ],
         [
        'key'=>'os',
        'val'=>'Group By OS'
        ],
        [
        'key'=>'networkid',
        'val'=>'Group By Network'
        ],
        [
        'key'=>'adid',
        'val'=>'Group By Advertiser'
        ],
        [
        'key'=>'campaignid',
        'val'=>'Group By Advertiser Campaign',
        ],
        [
        'key'=>'adid',
        'val'=>'Group By Id Ad',
        ],    
        [
        'key'=>'parentcca',
        'val'=>'Group By Parent CCA'
        ],
        [
        'key'=>'traffic_type',
        'val'=>'Group By Traffic Type'
        ],
        [
        'key'=>'report_type',
        'val'=>'Group By Report Type'
        ],
        [
        'key'=>'country',
        'val'=>'Group By country'
        ],
         [
        'key'=>'siteid',
        'val'=>'Group By siteid'
        ],
         [
        'key'=>'pubid',
        'val'=>'Group By pubid'
        ]
     ],

     'TRAFFIC_TYPE'=>[
         'A',
         'B',
         'C',
         'D',
         'I',
         'IG',
         'WG',
         'WM',
         'SM',
         'SG',
	 'OM',
	 'OG'
     ],
     
     'RESULT_TYPE'=>[
          'IG',
          'CPA',
          'CPC',
          'CMB',
          'CPI',
          'CPICPA', 
          '[campaign Type]', 
          '0'
     ],

     'COUNTRIES'=>[
            storage_path() . "/json/country.json"
     ],

    'VERTICALS'=>[
                   'APK',
                   'Binary',
                   'CPA',
                   'CPI',
                   'CPL',
                   'CPR',
                   'CPS',
                   'CPV',
                   'Dating',
                   'Desktop',
                   'Forex',
                   'Nutra',
                   'PinSubmit',
                   'Sweepstakes',
                   'casino',
                   'Browser Extension',
                   'Astrology',
                   'Mail'
                ],


];
