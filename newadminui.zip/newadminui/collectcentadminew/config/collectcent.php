 <?php                              
        return [
                               'operator' => array(
                                      1 => "Airtel", 
                                      2 => "vodafone", 
                                      3 => "aircel", 
                                      4 => "idea",
                                      5 => "reliance",
                                      6 => "tata",
                                      7 => "BSNL",
                                      8 => "MTS",
                                      9 => "Uninor",
                                      17 => "DU UAE",
                                      18 => "Celcom",
                                      20 => "AIS",
                                      22 => "Digi Malaysia",
                                      24 => "Etisalat UAE",
                                      26 => "VodafoneEgypt",
                                      27 => "Thailand DTAC",
                                      29 => "Claro",
                                      30 => "Videocon",
                                      31 => "Ooredoo",
                                      32 => "Etisalat Nigeria",
                                      39 => "Airtel Kenya",
                                      40 => "Safaricom Kenya",
                                      41 => "Airtel Uganda",
                                      42 => "Airtel Ghana",
                                      43 => "Airtel Nigeria",
                                      44 => "Grameenphone",
                                      45 => "Banglalink",
                                      46 => "XL Indonesia",
                                      47 => "Indosat Indonesia"),

                                   'NetPostSource'=>array(
                                      "162.243.32.94" => 'Imageperfect',
                                      "192.241.246.123" => 'MVN',
                                      "162.243.27.201" => 'Net4',
                                      "162.243.3.184" => 'New Image Perfact IP 5B' 
                                      ),

                                    'NetPostSourceurl'=>array(
                                        "162.243.3.184" => "Imageperfect", 
                                        "162.243.1.46" => "Vacastudios",
                                        "162.243.7.210" => "Moiads",
                                        "162.243.9.35" => "SF",
                                        "192.241.245.208" => "Adsjoy",
                                        "192.241.184.246" => "6T Seconds",
                                        "162.243.18.13" => "MVN"
                                      ),


                                'campaignType' => array(
                                      "CPA" => "CPA",
                                      "CPC" => "CPC",
                                      "CPI" => "CPI",
                                      "CPICPA" =>"CPICPA",
                                      "CMB" =>"CMB"
                                      ),


                                'operatingSystem'=>array(

                                      "ios" => "ios",
                                      "android" => "android"),
                                 

                                'category' =>  array(
                                       "A" => "A",
                                      "B" => "B",
                                      "C" => "C",
                                      "I" => "I",
                                      "IG" => "IG",
                                      "D" => "D",
                                      "W" => "W",
                                      "WM"=> "WM",
                                      "WG"=> "WG",
                                      "SG" => "SG",
                                      "SM" => "SM"
                                      ),

                                'wifiStatus'=>array(

                                      "0" => "OFF",
                                      "1" => "ON"),

                                'payCur'=>array(

                                      "INR"    => "INR",
                                      "DOLLAR" => "DOLLAR",
                                      "EURO"   => "EURO"),

                                'incentype'=>array(

                                  "non_incent" => "non_incent",
                                  "incent"     => "incent"),

                                'url' =>array(
                                'App1' => 'http://162.243.217.139/dlv/c.php?',
                                'App2' => 'http://107.170.154.51/dlv/c.php?',
                                'App3' => 'http://162.243.254.216/dlv/c.php?',
                                'App6' => 'http://107.170.173.141/dlv/c.php?',
                                'App8' => 'http://162.243.221.193/dlv/c.php?',
                                'App12' =>'http://162.243.73.231/dlv/c.php?',
                                'App10' => 'http://162.243.80.250/dlv/c.php?',
                                'App13' => 'http://162.243.74.32/dlv/c.php?',
                                'App15' =>'http://192.241.191.139/dlv/c.php?',
                                'App16' => 'http://192.241.188.214/dlv/c.php?',
                                'App17' => 'http://162.243.199.134/dlv/c.php?',
                                'App18' => 'http://162.243.200.63/dlv/c.php?',
                                'App20' => 'http://162.243.83.66/dlv/c.php?',
                                'App21' => 'http://162.243.112.118/dlv/c.php?',
                                'App22' => 'http://192.241.166.247/dlv/c.php?',
                                'App25' => 'http://192.241.242.242/dlv/c.php?',
                                'App26' => 'http://192.241.242.234/dlv/c.php?',
                                'App27' => 'http://192.241.174.146/dlv/c.php?',
                                'App28' => 'http://192.241.180.55/dlv/c.php?',
                                'App38' => 'http://192.241.249.228/dlv/c.php?',
                                'App39' => 'http://192.241.251.97/dlv/c.php?"',
                                'App40' => 'http://192.241.251.97/dlv/c.php?"',
                                'App41' => 'http://192.241.251.97/dlv/c.php?"',
                                'App44' => 'http://192.241.251.97/dlv/c.php?"',
                                'App45' => 'http://192.241.251.97/dlv/c.php?"',
                                'App48' => 'http://192.241.251.97/dlv/c.php?"', 
                                ),

                              'app_server' => array(
                                  "01"=>"AppServer1",
                                  "02"=>"AppServer2", 
                                  "03"=>"AppServer3", 
                                  "04"=>"AppServer4", 
                                  "05"=>"AppServer5", 
                                  "06"=>"AppServer6", 
                                  "07"=>"AppServer7", 
                                  "08"=>"AppServer8",
                                  "09"=>"AppServer9", 
                                   "10"=>"AppServer10", 
                                   "11"=>"AppServer11",
                                   "12"=>"AppServer12", 
                                   "13"=>"AppServer13", 
                                   "14"=>"AppServer14", 
                                   "15"=>"AppServer15", 
                                   "16"=>"AppServer16",
                                   "17"=>"AppServer17", 
                                   "18"=>"AppServer18",
                                   "19"=>"AppServer19",
                                   "20"=>"AppServer20",
                                   "21"=>"AppServer21",
                                   "22"=>"AppServer22",
                                   "25"=>"AppServer25",
                                   "26"=>"AppServer26",
                                   "27"=>"AppServer27",
                                   "28"=>"AppServer28",
                                   "31"=>"AppServer5c",
                                   "33"=>"AppServer7a",
                                   "34"=>"AppServer34",
                                   "40"=>"AppServer40",
                                   "41"=>"AppServer41",
                                   "44"=>"AppServer44",
                                   "45"=>"AppServer45",
                                   "48"=>"AppServer48",
                            ),

                              'vertical' =>array(
                                          "APK"=>"APK",
                                          "Binary"=>"Binary",
                                          "CPA"=>"CPA",
                                          "CPI"=>"CPI",
                                          "CPL"=>"CPL",
                                          "CPR"=>"CPR",
                                          "CPS"=>"CPS",
                                          "CPV"=>"CPV",
                                          "Dating"=>"Dating",
                                          "Desktop"=>"Desktop",
                                          "Forex"=>"Forex",
                                          "Nutra"=>"Nutra",
                                          "PinSubmit"=>"PinSubmit",
                                          "Sweepstakes"=>"Sweepstakes"
                              ),    
                                
                                'default_server' =>array(


                                ),


                                'hour_format' => array(

                                  "0" => "00", 
                                  "1" => "01",
                                  "2" => "02", 
                                  "3" => "03", 
                                  "4" => "04", 
                                  "5" => "05", 
                                  "6" => "06", 
                                  "7" => "07", 
                                  "8" => "08",
                                  "9" => "09", 
                                  "10" => "10", 
                                  "11" => "11",
                                  "12" => "12", 
                                  "13" => "13", 
                                  "14" => "14", 
                                  "15" => "15", 
                                  "16" => "16",
                                  "17" => "17", 
                                  "18" => "18", 
                                  "19" => "19", 
                                  "20" => "20", 
                                  "21" => "21", 
                                  "22" => "22", 
                                  "23" => "23"),

                                'hidden_url' =>  array(
                                  'login',
                                  'api/user',
                                  'logout','/',
                                  'password/email',
                                  'password/reset/{token}',
                                  'password/reset',
                                  'setect2/fetch' 
                                )





                ];

?>
