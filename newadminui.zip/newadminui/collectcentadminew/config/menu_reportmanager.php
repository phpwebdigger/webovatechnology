 <?php                              
return [
    'all' => array(
               'dashboard' =>  array(
                                'name' => "Dashboard",
                                'icon' => "fa-home",
                                'link' => '',
                                'class' => '',
                                'child' => []
                                ),
                   
                    'network-data' =>  array(
                                'name' => "Network-Data",
                                'icon' => "fa-users",
                                'link' => '#',
                                'class' => '',
                                'child' => array(
                                           

                                           'offernetworkwise'=>array(
                                                        'name' => "Offer Networkwise",
                                                          'icon' => "fa-home",
                                                          'link' => 'offer-networkwise',
                                                          'target' => "true",
                                                          'child' =>  []
                                                        ),


                                                      )
                                
                                                    ), 
                         
                       'Advertiser-Data' =>  array(
                                'name' => "Advertiser-Data",
                                'icon' => "fa-users",
                                'link' => '#',
                                'class' => '',
                                'child' => array(
                                           'home'=>array(
                                                         'name' => "Offer Advertiser Wise",
                                                          'icon' => "fa-home",
                                                          'link' => 'offer-advertiserwise',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            )
                              ),
                        'Publisher' =>  array(
                                'name' => "Publisher",
                                'icon' => "fa-users",
                                'link' => 'publisherlist',
                                'class' => ''
                              ),
                       'Advertiser' =>  array(
                                'name' => "Advertiser",
                                'icon' => "fa-users",
                                'link' => 'adv_list',
                                'class' => ''
                              ),

        )
    
];
