 <?php                              
return [
    'all' => array(
               'dashboard' =>  array(
                                'name' => "Dashboard",
                                'icon' => "fa-home",
                                'link' => '',
                                'class' => '',
                                'child' => []
                                ),
                   
                 'Network-Data' =>  array(
                                'name' => "Network-Data",
                                'icon' => "fa-users",
                                'link' => '#',
                                'class' => '',
                                'child' => array(
                                           

                                           'offernetworkwise'=>array(
                                                        'name' => "Offer Networkwise",
                                                          'icon' => "fa-home",
                                                          'link' => 'offer-networkwise',
                                                          'target' => "true",
                                                          'child' =>  []
                                                        ),


                                                      )
                                
                                                    ), 
                         
                       'Advertiser-Data' =>  array(
                                'name' => "Advertiser-Data",
                                'icon' => "fa-users",
                                'link' => '#',
                                'class' => '',
                                'child' => array(
                                           'home'=>array(
                                                         'name' => "Offer Advertiser Wise",
                                                          'icon' => "fa-home",
                                                          'link' => 'offer-advertiserwise',
                                                          'target' => "false",
                                                          'child' =>  []
                                                        ),
                                            )
                              ),
//                        'resources' =>  array(
//                                'name' => "Resources",
//                                'icon' => "linea-icon linea-software fa-fw",
//                                'link' => '#',
//                                'class' => '',
//                                'child' => array(
//                                          'showaddnetwork'=>array(
//                                                        'name' => "Add Network Resources",
//                                                          'icon' => "fa-home",
//                                                          'link' => 'Resources/add-network',
//                                                          'target' => "false",
//                                                          'child' =>  []
//                                                        ),
//                                            'showAdv'=>array(
//                                                          'name' => "Add Advertiser Resources",
//                                                          'icon' => "fa-home",
//                                                          'link' => 'Resources/add-advertiser',
//                                                          'target' => "false",
//                                                          'child' =>  []
//                                                        ),
//                                           
//                                            'getnetworklist'=>array(
//                                                          'name' => "List Network Resources",
//                                                          'icon' => "fa-home",
//                                                          'link' => 'Resources/list-network',
//                                                          'target' => "false",
//                                                          'child' =>  []
//                                                        ),
//                                            'getAdvlist'=>array(
//                                                          'name' => "List Advertiser Resources",
//                                                          'icon' => "fa-home",
//                                                          'link' => 'Resources/list-advertiser',
//                                                          'target' => "false",
//                                                          'child' =>  []
//                                                        ),
//                                           
//                                            )
//                               ),
        'Publisher' =>  array(
                                'name' => "Publisher",
                                'icon' => "fa-users",
                                'link' => 'publisherlist',
                                'class' => ''
                              ),
                       'Advertiser' =>  array(
                                'name' => "Advertiser",
                                'icon' => "fa-users",
                                'link' => 'adv_list',
                                'class' => ''
                              ),
             
        )
    
];
