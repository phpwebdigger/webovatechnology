<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


Route::get('/forbidden', function () {
    return view('errors.forbidden');
});
Route::get('/abc', function () {
    return \App\User::all();
});
Route::get('/ads-management', 'AdsController@adsmanagement')->name('adsManagement');


Route::get('/internationalrotatormgnt_list', 'InternationRotator@index')->name('internationalrotatormgnt_list');
Route::post('/internationalcountryname', 'InternationRotator@internationalrotatormgnt_operator');
Route::post('/internationalrotatormgnt_list2', 'InternationRotator@getDataForTable');
Route::post('/trfc_status_update', 'InternationRotator@update_status');


Route::get('/internationalrotatormgntadd', 'InternationRotator@internationalrotatormgnt_country')->name('addInternational');
Route::post('/internationalccadata', 'InternationRotator@internationalrotatormgnt_cca');
Route::post('/internationaldatanew', 'InternationRotator@internationalrotator_addnew');




Route::get('/network-cr-update', 'NetworkControllerTest@index')->name('NetworkCrUpdate');
Route::get('/smart-network-cr-update', 'NetworkControllerTest@smart_index')->name('SmartNetworkCrUpdate');
Route::get('/smart-network-cr-update-parent', 'NetworkControllerTest@index_parent_new')->name('SmartNetworkCrUpdateParent');
Route::get('/filter-network-cr-update', 'NetworkControllerTest@filterNetworkCrData')->name('filterNetworkCrUpdate');
Route::get('/filter-network-cr-update-parent', 'NetworkControllerTest@filterNetworkCrDataParent')->name('filterNetworkCrUpdateParent');

Route::get('/smartlink', 'SmartLinkController@index')->name('smartlink');
Route::post('/smartlink', 'SmartLinkController@index')->name('smartNetworkfilter');
Route::get('/test', 'NetworkControllerTest@index')->name('homeTest');

Route::post('/network-cr-update', 'NetworkControllerTest@index')->name('networkfilter');

Route::post('/test', 'NetworkController@index')->name('networkfilterTest');

Route::get('/network-back-campaign', 'NetworkControllerRedis@index_back_campaign')->name('backCampaign');
Route::post('/network-back-campaign', 'NetworkControllerRedis@index_back_campaign')->name('backCompaignFilter');
Route::get('/publisher-cr-update', 'NetworkControllerTest@publisher_cr_index')->name('publisherCr');
Route::post('/publisher-cr-update', 'NetworkControllerTest@publisher_cr_index')->name('publisherCrFilter');
Route::get('/network-cr-update-single-network/{ad_id}', 'NetworkControllerTest@index_single')->name('network-wise-record');
Route::post('/network-cr-update-single-network/{ad_id}', 'NetworkControllerTest@index_single')->name('network-wise-record-filter');

Route::get('/network-cr-update-single-chanel', 'NetworkSingleController@index_single')->name('network-wise-record-chanel');

Route::get('/network-cpa-cr-update', 'NetworkControllerTest@cpa_cr_update')->name('homeCPA');
Route::post('/network-cpa-cr-update', 'NetworkControllerTest@cpa_cr_update')->name('networkfilterCPA');

Route::get('/network-cps-cr-update', 'NetworkControllerTest@cps_cr_update')->name('homeCPS');
Route::post('/network-cps-cr-update', 'NetworkControllerTest@cps_cr_update')->name('networkfilterCPS');
Route::get('/network-cpi-cr-update', 'NetworkControllerTest@cpi_cr_update')->name('homeCPI');
Route::post('/network-cpi-cr-update', 'NetworkControllerTest@cpi_cr_update')->name('networkfilterCPI');
Route::get('/network-cpicpa-cr-update', 'NetworkControllerTest@cpicpa_cr_update')->name('homeCPICPA');
Route::post('/network-cpicpa-cr-update', 'NetworkControllerTest@cpicpa_cr_update')->name('networkfilterCPICPA');
Route::get('/organizr-cr-update', 'NetworkControllerTest@organizr_cr_update')->name('homeOrganizr');
Route::post('/organizr-cr-update', 'NetworkControllerTest@organizr_cr_update')->name('networkfilterOrganizr');
Route::get('/carrier-specific-default-a', 'NetworkControllerTest@CarrierIndexA')->name('homeCariar');
Route::get('/filteration-carrier-specific-default', 'NetworkControllerTest@FilterationCarrierIndex')->name('FilterCarrierSpecificDefault');
Route::get('/carrier-specific-default-a-single-network/{ad_id}', 'NetworkControllerTest@CarrierIndexA_single')->name('carrier-specific-network-wise-record');
Route::post('/carrier-specific-default-a-single-network/{ad_id}', 'NetworkControllerTest@CarrierIndexA_single')->name('carrier-specific-network-wise-record-filter');
Route::post('/carrier-specific-default-a', 'NetworkControllerTest@CarrierIndexA')->name('homeCariarFilter');
Route::get('/carrier-specific-default-c', 'NetworkControllerTest@CarrierIndexC')->name('homeCariarC');
Route::post('/carrier-specific-default-c', 'NetworkControllerTest@CarrierIndexC')->name('homeCariarFilterC');
Route::get('/network-cr-update-rotator', 'NetworkControllerRedis@CarrierIndexRotator')->name('homeCariarRotator');
Route::post('/network-cr-update-rotator', 'NetworkControllerRedis@CarrierIndexRotator')->name('homeCariarFilterRotator');
Route::get('/wifi-specific-default-a', 'NetworkControllerTest@CarrierIndexWIFIA')->name('homeCariarWIFIA');
Route::post('/wifi-specific-default-a', 'NetworkControllerTest@CarrierIndexWIFIA')->name('homeCariarFilterWIFIA');
Route::get('/wifi-specific-default-c', 'NetworkControllerTest@CarrierIndexWIFIC')->name('homeCariarWIFIC');
Route::post('/wifi-specific-default-c', 'NetworkControllerTest@CarrierIndexWIFIC')->name('homeCariarFilterWIFIC');
Route::get('/advertiser-cr-update', 'AdvertiserController@index')->name('advertiserList');
Route::get('/smart-advertiser-cr-update', 'AdvertiserController@index')->name('SmartadvertiserList');
Route::post('/filter-advertiser-cr-update', 'AdvertiserController@filterAdvertiserCrData')->name('filterAdvertiserCrUpdate');

Route::get('/advertiser-cpa-cr-update', 'AdvertiserController@cpa_cr_update')->name('AdhomeCPA');
Route::post('/advertiser-cpa-cr-update', 'AdvertiserController@cpa_cr_update')->name('advertiserfilterCPA');
Route::get('/advertiser-cps-cr-update', 'AdvertiserController@cps_cr_update')->name('AdhomeCPS');
Route::post('/advertiser-cps-cr-update', 'AdvertiserController@cps_cr_update')->name('advertiserfilterCPS');
Route::get('/advertiser-cpi-cr-update', 'AdvertiserController@cpi_cr_update')->name('AdhomeCPI');
Route::post('/advertiser-cpi-cr-update', 'AdvertiserController@cpi_cr_update')->name('advertiserfilterCPI');
Route::get('/advertiser-cpicpa-cr-update', 'AdvertiserController@cpicpa_cr_update')->name('AdhomeCPICPA');
Route::post('/advertiser-cpicpa-cr-update', 'AdvertiserController@cpicpa_cr_update')->name('advertiserfilterCPICPA');


//Route::get('/admin', 'HomeController@index')->name('home');
//Auth::routes();
Route::get('/home', 'HomeController@index')->name('homeMain');
Auth::routes();
Route::get('/users', 'UserController@index')->name('userList');
Route::get('/users/register', 'UserController@getUserForm')->name('userRegister');
Route::get('/users/delete/{id}', 'UserController@destroy')->name('userDelete');
Route::post('/users/register', 'UserController@addUser')->name('userAdd');
Route::get('/users/edit/{id}', 'UserController@edit')->name('userEdit');
Route::post('/users/edit', 'UserController@update' )->name('userUpdate');
Route::get('/users/profile','UserController@profile')->name('profile');
/*Route::get('/users/delete/{id}', 'UserController@destroy');*/
//roles
Route::get('/users/roles', 'UserController@index_role')->name('rolelist');
Route::get('/users/roles/register/{id?}', 'UserController@roleget')->name('roleaddform');
Route::post('/users/roles/register', 'UserController@rolepost')->name('role-add');
Route::get('/role/delete/{id?}', 'UserController@roledelete')->name('roledelete');

Route::get('/', 'HomeController@index')->name('dashboard');
Route::get('/delivery', 'DeliveryController@index')->name('delivery');
Route::post('/delivery', 'DeliveryController@index')->name('deliverypost');
Route::get('/delivery/add', 'DeliveryController@add')->name('deliveryAdd');
Route::post('/delivery/add', 'DeliveryController@store')->name('deliverypostAddPost');
Route::get('/delivery/get-adsbynetwork/','DeliveryController@getAdsByNetwork')->name('deliveryAdsByNetwork');
Route::get('/delivery/get-eventadsbynetwork/','DeliveryController@getEventAdsByNetwork')->name('deliveryAdsByNetwork');
Route::get('/delivery_event/edit/{id_adv}/{zone}', 'DeliveryController@edit_event')->name('DeliveryEdit');
Route::post('/delivery/event_edit', 'DeliveryController@update_event' )->name('DeliveryUpdateEvent');
Route::get('/delivery/edit/{id}/{zone}', 'DeliveryController@edit')->name('DeliveryEdit');
Route::post('/delivery/edit', 'DeliveryController@update' )->name('DeliveryUpdate');

Route::get('/delivery-sale', 'ConfigDeliverySaleController@index')->name('deliverySale');
Route::get('/delivery-sale/add', 'ConfigDeliverySaleController@add')->name('deliverySaleAdd');
Route::post('/delivery-sale/add', 'ConfigDeliverySaleController@store')->name('deliverySalepostAddPost');
Route::get('/delivery-sale/edit/{id}', 'ConfigDeliverySaleController@edit')->name('DeliverySaleEdit');
Route::post('/delivery-sale/edit', 'ConfigDeliverySaleController@update' )->name('DeliverySaleUpdate');



Route::get('/delivery-report', 'DeliveryController@deliveryreport')->name('deliveryreport');
Route::post('/delivery-filter', 'DeliveryController@filterData')->name('deliveryFilter');

Route::get('/traffic-diversion', 'TrafficController@index')->name('traffic');
Route::get('/traffic-diversion/update', 'TrafficController@partialTrafficUpdate')->name('partialtrafficUpdate');
Route::post('/traffic-diversion', 'TrafficController@index')->name('trafficFilter');


Route::get('/smart-traffic-diversion', 'SmarttrafficconfigController@index')->name('smartTrafficConfig');
Route::get('/smart-traffic-diversion/updatesmarttrfc', 'SmarttrafficconfigController@partialSmartTrafficUpdate')->name('smarttrafficupdate');
Route::any('/smart-traffic/ccas','SmarttrafficconfigController@getCcaByCcz');
Route::post('/smart-traffic/getPercentageOnCampaignsByCca', 'SmarttrafficconfigController@getPercentageOnCampaignsByCca')->name('getPercentageOnCampaignsByCca');
Route::post('/smart-traffic/updateTrafficPercentage', 'SmarttrafficconfigController@updateTrafficPercentage')->name('updateTrafficPercentage');
Route::post('/smart-traffic/filterSmartTrfcData','SmarttrafficconfigController@filterSmartTrfcData')->name('filterSmarttraffic');

//Route::post('smart-traffic/filterSmartTrfcData','SmarttrafficconfigController@filterSmartTrfcData')->name('filterSmarttraffic');
Route::any('/getCampaign','SmarttrafficconfigController@getCampaign');
Route::any('/campaign_name_parent_cca','SmarttrafficconfigController@campaign_name_parent');
Route::any('/smart-traffic/create','SmarttrafficconfigController@create')->name('smartTrfcCreate');
Route::get('/smart-traffic/UpdateCampaign', 'SmarttrafficconfigController@UpdateCampaign');
Route::any('/smart-traffic/createSmartCampaign','SmarttrafficconfigController@createSmartCampaign');


/** New Smart -intetrfac start**/
Route::get('/smart-interface-new', 'SmartInterfacenewController@index')->name('smartInternewfaceView');
Route::post('/smart-interface-new/filterSmartinterfaceData', 'SmartInterfacenewController@filterSmartinterfacenewcData')->name('smartInternewfaceViewFilter');

Route::get('/smart-interface-add-new/{id}', 'SmartInterfacenewController@get_camp')->name('smartInternewfaceViewadd_more');

Route::get('/smart-interface-add-new-store', 'SmartInterfacenewController@store')->name('smartCampaignStoreadd');
Route::post('/smart-interface-add-new-store', 'SmartInterfacenewController@store')->name('smartCampaignStoreadd');
Route::get('/smart-interface-new-smartstatus_update', 'SmartInterfacenewController@smartStatus_update')->name('smartInterfaceWaitageUpdate');
Route::get('/smart-interface-new/getOps', 'SmartInterfacenewController@select_country_ops')->name('smartInterfaceselect_country');


 /** New Smart -intetrfac start**/

Route::get('/cron-old/{auth}','CronController@oldindex')->name('cron');
Route::get('/cron','CronController@index')->name('cron');
Route::post('/cron-old','CronController@oldindex')->name('oldcronPost');
Route::post('/cron','CronController@index')->name('cronPost');
Route::any('/edit_cron_new/{id}','CronController@edit_cron_new')->name('edit_cron_new');
Route::get('/add-cron','CronController@add')->name('add-cron');
Route::get('/add-cron-new/get-adsbynetwork/','CronController@getAdsByNetwork')->name('CronAdsByNetwork');
Route::any('/edit_cron/{id}','CronController@edit_cron')->name('edit_cron');

Route::post('/add-cron','CronController@add')->name('add-cron-post');
Route::get('/add-manual-cron','CronController@add_manual_cron')->name('add-manual-cron-post');

Route::get('/add-cron-new','CronController@add_new')->name('add-cron-new');
Route::post('/add-cron-new','CronController@add_new')->name('add-cron-post-new');

Route::get('/manual-cron','CronController@manual')->name('manual-cron');

Route::get('/rahul-cpa-list ','HomeController@rahulcpalist')->name('rahulcpalist');
Route::get('/reverce-calc ','HomeController@reverce_calc')->name('reverceCalc');

Route::get('/cca/list', 'CampaignController@createCampaignList')->name('ccalist');
Route::get('/create-new-campaign', 'CampaignController@index')->name('createCampaign');
Route::post('/cca/list', 'CampaignController@add')->name('addCampaign');
Route::post('/cca/listadd', 'CampaignController@addCamp')->name('addCampaignPost');

Route::post('/cca/addUrls', 'CampaignController@addUrls')->name('addCampaignPostUrl');

Route::get('/cca/filter-cca-list', 'CampaignController@findCampaignList')->name('filetrCampaignPostUrl');

Route::get('/cca/edit-cca-list/{id_ad}', 'CampaignController@edit_cca_list')->name('editCampaignPostUrl');
Route::post('/cca/edit-cca-list', 'CampaignController@edit_cca_list')->name('editCampaignPostUrl');

Route::post('/cca/update-cca-list', 'CampaignController@update_cca_list')->name('updateCampaignPostUrl');


Route::get('/cca/auto-campaign-add', 'CampaignController@getautoadd')->name('autocampaignadd');
Route::post('/cca/auto-campaign-add', 'CampaignController@autocampaignadd')->name('autocampaignaddPost');
Route::get('/cca/auto-campaign/edit/{id}', 'CampaignController@edit')->name('autoCampaignEdit');
Route::post('/cca/auto-campaign/edit', 'CampaignController@update')->name('autoCampaignUpdate');
Route::get('/cca/ajaxopt',"CampaignController@ajaxdataopt")->name('ajaxopt');
Route::post('/cca/ajaxopt',"CampaignController@ajaxdataopt")->name('ajaxopt');

Route::get('/cca/auto-campaign', 'CampaignController@getcampaign')->name('autoCampaignIndex');
Route::post('/cca/auto-campaign', 'CampaignController@getcampaign')->name('autoCampaignIndexPost');


Route::get('/cca/update-campaigns', 'CampaignController@UpdateCampaigns')->name('updateCamp');
Route::post('/cca/update-campaigns', 'CampaignController@UpdateCampaigns')->name('updateCampPost');

Route::get('/cca/update-campaigns-edit/{id}', 'CampaignController@UpdateCampaignsSingle')->name('EditupdateCamp');
Route::post('/cca/update-campaigns-edit/{id}', 'CampaignController@UpdateCampaignsSingle')->name('EditupdateCampPost');

Route::get('/cca/conversion-status-report', 'UserController@ConversionStatusReport')->name('ConvStatusRep');
Route::get('/cca/ajax', 'UserController@ajax')->name('ConvStatusRepajax');

Route::get('/cca/add-new-rahul-cpa-config', 'UserController@AddNewRahulCPAConfig')->name('AddnewRahulCPAconfig');
Route::get('/cca/edit-new-rahul-cpa-config', 'UserController@EditNewRahulCPAConfig')->name('EditnewRahulCPAconfig');
Route::get('/cca/change-ads-urls', 'UserController@ChangeAdsURLS')->name('changeAdsUrl');
//urls
Route::get('urls', 'AdsController@index')->name('urls');
Route::get('url-test', 'AdsControllerTest@index')->name('urls');
Route::post('urls', 'AdsController@index')->name('urlFilter');
Route::post('urls/filter-ads', 'AdsController@filterAds')->name('filterAds');
Route::get('urls/getUrlData', 'AdsController@getUrlData');
Route::get('urls/getUrlDataSmart', 'AdsController@getUrlDataSmart');
Route::get('urls/getCpiCpa', 'AdsController@getCpiCpa');
Route::get('urls/getUpdateUrl', 'AdsController@UpdateUrl');
Route::get('urls/edit-url', 'AdsController@editUrl');
Route::get('urls/edit-smarturl', 'AdsController@editsmartUrl');
Route::get('url/getcampaign','AdsController@getCampaign');
Route::post('urls/edit', 'AdsController@manageUrlPage' )->name('manageUrlPage');
Route::get('urls/edit', 'AdsController@update' );
Route::get('change-ads-urls/ajax' ,'AdsController@ajaxOperator')->name('adsAjax');
Route::post('change-ads-urls/ajax' ,'AdsController@ajaxOperator')->name('adsAjaxPost');
Route::post('updateSmartUrls' ,'AdsController@updateSmartUrls')->name('updateSmartUrls');
// Route::get('/change-ads-urls/ajax-submit' ,'AdsController@ajaxsubmit')->name('adsAjaxsubmitGet');

//url manaegemt 
Route::get('urls/manage/{id_ad}/{id_advertiser?}', 'AdsController@urlEditAll' )->name('editUrl');
Route::post('urls/manage/{id_ad}/{id_advertiser?}', 'AdsController@urlEditAll' )->name('editUrlPost');


Route::get('/smart-interface-remove', 'SmartInterfaceRemoveController@index')->name('smartInternewfaceView');

Route::get('/smart-interface-new-smartstatus_update_remove', 'SmartInterfaceRemoveController@smartStatus_update')->name('smartInterfaceWaitageUpdate');


Route::get('/urls/manage-cpa/{id_ad}/{id_advertiser?}', 'AdsController@urlEditAllCPA' )->name('editUrlCPA');
Route::post('/urls/manage-cpa/{id_ad}/{id_advertiser?}', 'AdsController@urlEditAllCPA' )->name('editUrlCPAPost');

Route::get('/urls/manage-cps/{id_ad}/{id_advertiser?}', 'AdsController@urlEditAllCPS' )->name('editUrlCPS');
Route::post('/urls/manage-cps/{id_ad}/{id_advertiser?}', 'AdsController@urlEditAllCPS' )->name('editUrlCPSPost');
Route::get('/urls/manage-cpi/{id_ad}/{id_advertiser?}', 'AdsController@urlEditAllCPI' )->name('editUrlCPI');
Route::post('/urls/manage-cpi/{id_ad}/{id_advertiser?}', 'AdsController@urlEditAllCPI' )->name('editUrlCPIPost');
Route::get('/urls/manage-cpicpa/{id_ad}/{id_advertiser?}', 'AdsController@urlEditAllCPICPA' )->name('editUrlCPICPA');
Route::post('/urls/manage-cpicpa/{id_ad}/{id_advertiser?}', 'AdsController@urlEditAllCPICPA' )->name('editUrlCPICPAPost');


Route::post('/change-ads-urls/ajax-submit' ,'AdsController@ajaxsubmit')->name('adsAjaxsubmitPost');

Route::get('/urls-cpa', 'AdsController@index_cpa')->name('urlcpa');
Route::post('/urls-cpa', 'AdsController@index_cpa')->name('urlcpaFilter');
Route::get('/urls-cpi', 'AdsController@index_cpi')->name('urlcpi');
Route::post('/urls-cpi', 'AdsController@index_cpi')->name('urlcpiFilter');
Route::get('/urls-cps', 'AdsController@index_cps')->name('urlcps');
Route::post('/urls-cps', 'AdsController@index_cps')->name('urlcpsFilter');
Route::get('/urls-cpicpa', 'AdsController@index_cpicpa')->name('urlcpicpa');
Route::post('/urls-cpicpa', 'AdsController@index_cpicpa')->name('urlcpicpaFilter');

Route::get('/urls-collect-ads', 'AdsController@adsmanagement')->name('urlcollectads');
Route::post('/urls-collect-ads', 'AdsController@adsmanagement')->name('urlcollectadsFilter');
Route::get('/cca/add-new-advertiser-reverse/{id?}', 'AdvertiserController@advertiser')->name('AddnewAdvRev');
//ad
Route::post('/setect2/fetch', 'Controller@getTableDataForSelect')->name('tabledataselect');
//query table 
Route::get('/query', 'QueryController@index')->name("query");
Route::post('/query', 'QueryController@execute')->name("postQuery");
Route::get('/query-log', 'QueryController@getAccess')->name("log");


Route::get('/tech_query', 'QueryTechController@index')->name("tech_query");
Route::post('/tech_query', 'QueryTechController@execute')->name("postQuerytech_query");
Route::get('/tech_query-log', 'QueryTechController@getAccess')->name("log");




Route::get('/Resources/add-network', 'NetworkController@showaddnetworkview')->name('showaddnetwork');
Route::post('/Resources/add-network', 'NetworkController@AddNetwork')->name('addnetwork');
Route::get('/Resources/list-network', 'NetworkController@getNetworkList')->name('getnetworklist');
Route::post('/Resources/list-network', 'NetworkController@getNetworkList')->name('getNetwork');
Route::get('/network/edit/{id}', 'NetworkController@editNetwork')->name('editNetwork');
Route::post('/network/edit', 'NetworkController@update')->name('updateNetwork');
Route::get('/Resources/add-operator', 'OperatorController@showaddoperatorview')->name('showAddOptview');
Route::post('/Resources/add-operator', 'OperatorController@AddOperator')->name('AddOptview');
Route::get('/Resources/list-operator', 'OperatorController@getOperatorList')->name('getOptlist');
Route::post('/Resources/list-operator', 'OperatorController@getOperatorList')->name('getOptlist');
Route::get('/operator/edit/{id}', 'OperatorController@editOperator')->name('editOperator');
Route::post('/operator/edit', 'OperatorController@update')->name('updateOptview');
Route::get('/Resources/add-advertiser', 'AdvertiserController@showaddadvertiserview')->name('showAdv');
Route::post('/Resources/add-advertiser', 'AdvertiserController@AddAdvertiser')->name('adAdv');
Route::get('/Resources/list-advertiser', 'AdvertiserController@getAdvertiserList')->name('getAdvlist');
Route::post('/Resources/list-advertiser', 'AdvertiserController@getAdvertiserList')->name('getAdv');
Route::get('/advertiser/edit/{id}', 'AdvertiserController@editAdvertiser')->name('editAdv');
Route::post('/advertiser/edit', 'AdvertiserController@update')->name('advUpdate');
Route::get('/add-ip', 'ResourcesIpController@showview')->name('showIP');
Route::post('/add-ip', 'ResourcesIpController@AddIp')->name('addip');
Route::get('/advertiser/edit/{id}', 'AdvertiserController@editAdvertiser');
Route::post('/advertiser/edit', 'AdvertiserController@update');
Route::get('/advertiser-reverse' ,'AdvertiserController@reverse')->name('reverseAdvertiser');
Route::post('/advertiser-reverse' ,'AdvertiserController@reverse')->name('reverseAdvertiserPost');
Route::post('/advertiser/ajax' ,'AdvertiserController@ajaxOperatordata')->name('reverseAdvertiserAjax');
Route::post('/advertiser-reverse-view/save' ,'AdvertiserController@savelist')->name('reverseAdvertiserSave');
Route::get('/advertiser-reverse-view' ,'AdvertiserController@Reverselist')->name('reverseAdvertiserShowGet');
Route::post('/advertiser-reverse-view' ,'AdvertiserController@Reverselist')->name('reverseAdvertiserShowPost');
Route::get('/advertiser-reverse/edit/{reverse_id}', 'AdvertiserController@editReverse');
Route::post('/advertiser-reverse-view/edit', 'AdvertiserController@updateReverse' )->name('updateReversePost');
Route::get('/advertiser-reverse-view/edit', 'AdvertiserController@updateReverse' );
//report
Route::get('/conversion-count-report', 'ReportController@conversioncount')->name('conversioncountreport');
Route::get('/country-wise-records', 'ReportController@indexCountry')->name('indexCountry');
Route::post('/country-wise-records', 'ReportController@indexCountry')->name('indexCountryFilter');
Route::get('/crc-hourly-records', 'ReportController@crchouly')->name('crchouly');
Route::post('/crc-hourly-records', 'ReportController@crchouly')->name('crchoulyFilter');

Route::get('/appwise-server-details', 'ReportController@appwise')->name('appwise-server-details');
Route::post('/appwise-server-details', 'ReportController@appwise')->name('appwise-server-details-post');

Route::get('/deactivation-report', 'ReportController@deactivationReport')->name('deactivation-report');
Route::post('/deactivation-report', 'ReportController@deactivationReport')->name('deactivation-report-post');


/* new Routes for Advertisernew moudle*/

Route::get('/advertisernew-cr-update', 'AdvertisernewController@index')->name('advertisernewList');
Route::post('/advertisernew-cr-update', 'AdvertisernewController@index')->name('advertisernewFilter');
Route::get('/advertisernew-cpa-cr-update', 'AdvertisernewController@cpa_cr_update')->name('AdnewhomeCPA');
Route::post('/advertisernew-cpa-cr-update', 'AdvertisernewController@cpa_cr_update')->name('advertisernewfilterCPA');
Route::get('/advertisernew-cps-cr-update', 'AdvertisernewController@cps_cr_update')->name('AdnewhomeCPS');
Route::post('/advertisernew-cps-cr-update', 'AdvertisernewController@cps_cr_update')->name('advertisernewfilterCPS');
Route::get('/advertisernew-cpi-cr-update', 'AdvertisernewController@cpi_cr_update')->name('AdnewhomeCPI');
Route::post('/advertisernew-cpi-cr-update', 'AdvertisernewController@cpi_cr_update')->name('advertisernewfilterCPI');
Route::get('/advertisernew-cpicpa-cr-update', 'AdvertisernewController@cpicpa_cr_update')->name('AdnewhomeCPICPA');
Route::post('/advertisernew-cpicpa-cr-update', 'AdvertisernewController@cpicpa_cr_update')->name('advertisernewfilterCPICPA');

/* Network Redis Routes */
Route::get('/network-cr-update-single-redis/{ad_id}', 'NetworkControllerRedis@index_single')->name('network-wise-record-redis');
Route::post('/network-cr-update-single-redis/{ad_id}', 'NetworkControllerRedis@index_single')->name('network-wise-record-filter-redis');
Route::get('/network-cr-update-redis', 'NetworkControllerRedis@index')->name('homeredis');
Route::get('/network-campaigns', 'NetworkControllerRedis@networkCampaign')->name('NetworkCampaign');
Route::post('/network-cr-update-redis', 'NetworkControllerRedis@index')->name('networkfilterredis');
Route::get('/network-cpa-cr-update-redis', 'NetworkControllerRedis@cpa_cr_update')->name('homeCPARedis');
Route::post('/network-cpa-cr-update-redis', 'NetworkControllerRedis@cpa_cr_update')->name('networkfilterCPARedis');
Route::get('/network-cpi-cr-update-redis', 'NetworkControllerRedis@cpi_cr_update')->name('homeCPIRedis');
Route::post('/network-cpi-cr-update-redis', 'NetworkControllerRedis@cpi_cr_update')->name('networkfilterCPIRedis');
Route::get('/network-cps-cr-update-redis', 'NetworkControllerRedis@cps_cr_update')->name('homeCPSRedis');
Route::post('/network-cps-cr-update-redis', 'NetworkControllerRedis@cps_cr_update')->name('networkfilterCPSRedis');
Route::get('/network-cpicpa-cr-update-redis', 'NetworkControllerRedis@cpicpa_cr_update')->name('homeCPICPARedis');
Route::post('/network-cpicpa-cr-update-redis', 'NetworkControllerRedis@cpicpa_cr_update')->name('networkfilterCPICPARedis');
Route::get('/network-international', 'NetworkControllerRedis@international')->name('international');
Route::post('/network-international', 'NetworkControllerRedis@international')->name('internationalfilters');


//Smart Link routes
Route::post('/smart-link-wifi-wm', 'SmartLinkController@smartLinkWMWifi_index')->name('smartLinkWifiWMFilter');
Route::get('/smart-link-wifi-wm', 'SmartLinkController@smartLinkWMWifi_index')->name('smartLinkWifiWM');

/* For both wifi internal pages */    
Route::post('/smart-link-wifi-single/{ad_id}', 'SmartLinkController@smartLinkWIFI_single')->name('smartLinkWifiSingleFilter');
Route::get('/smart-link-wifi-single/{ad_id}', 'SmartLinkController@smartLinkWIFI_single')->name('smartLinkWifiSingle');

Route::post('/smart-link-wifi-wg', 'SmartLinkController@smartLinkWGWifi_index')->name('smartLinkWifiWGFilter');
Route::get('/smart-link-wifi-wg', 'SmartLinkController@smartLinkWGWifi_index')->name('smartLinkWifiWG');
Route::get('/smart-link-wg', 'SmartLinkController@smartLinkWG_index')->name('smartLinkWG');
Route::post('/smart-link-wg', 'SmartLinkController@smartLinkWG_index')->name('smartLinkWGFilter');

Route::get('/smart-link-wg-single/{ad_id}', 'SmartLinkController@smartLinkWG_single')->name('smartLinkWGSingle');
Route::post('/smart-link-wg-single/{ad_id}', 'SmartLinkController@smartLinkWG_single')->name('smartLinkWGSingleFilter');

Route::get('/smart-link-single-parent/{ad_id}', 'SmartLinkController@smartLinkWG_single_parent')->name('smartLinkSingleFilterParent');
Route::post('/smart-link-single-parent/{ad_id}', 'SmartLinkController@smartLinkWG_single_parent')->name('smartLinkSingleFilters');
Route::post('/smart-link-wm', 'SmartLinkController@smartLinkWM_index')->name('smartLinkWM');
Route::get('/smart-link-wm', 'SmartLinkController@smartLinkWM_index')->name('smartLinkWMFilter');
Route::get('/smart-link-wm-single/{ad_id}', 'SmartLinkController@smartLinkWM_single')->name('smartLinkWMSingle');
Route::post('/smart-link-wm-single/{ad_id}', 'SmartLinkController@smartLinkWM_single')->name('smartLinkWMSingleFilter');

// Delivery Update Smart Url Status Routes
Route::get('/delivery-smtUrlStatus', 'DeliveryController@updateSmtUrlSt')->name('deliverySmtUrlStUpdate');
Route::get('/delivery-limitupdate', 'DeliveryController@lowerLimitUpdate')->name('deliverylowerLimitUpdate');

//Smart Interface Routes    
Route::get('/smart-interface-advertiser', 'SmartInterfaceController@index_adv')->name('smartAdvertiserView');
Route::get('/offer-advertiserwise', 'SmartInterfaceController@offer_advertiser')->name('OfferAdvertiserWise');
Route::post('/offer-advertiserwise', 'SmartInterfaceController@offer_advertiser')->name('OfferAdvertiserWisepost');
Route::get('/offer-networkwise', 'SmartInterfaceController@offer_networkwise')->name('offerNetworkwise');
Route::get('/offer-networkwise-details', 'SmartInterfaceController@offer_networkwisedtls')->name('offerNetworkwiseDetails');
 
Route::get('/smart-cca-by-advertiser/{advertiser_id}/{operator_id}','SmartInterfaceController@getccabyadvertiser')->name('smartCcaByAdvertiser');
Route::get('/offer-cca-by-advertiser/{advertiser_id}/{operator_id}','SmartInterfaceController@getofferccabyadvertiser')->name('smartOfferCcaByAdvertiser');
Route::get('/offer-by-parentcca/{parent_cca}/{zone}/','SmartInterfaceController@getOfferAdveriserbyParentcca')->name('OfferByParentCca');
Route::any('/publisherOfferList', 'SmartInterfaceController@publisherOfferList')->name('publisherlist');
Route::any('/change_pause_status', 'SmartInterfaceController@change_pause_status')->name('updateCpa');
Route::any('/change_active_status', 'SmartInterfaceController@change_active_status')->name('updateCpa');
Route::any('/update_active_status', 'SmartInterfaceController@update_active_status')->name('updateCpa');
Route::any('/update_cpa', 'SmartInterfaceController@updateCpa')->name('updateCpa');
Route::any('/update_cap', 'SmartInterfaceController@updateCap')->name('updateCap');

 Route::any('/update_click_count_cap', 'SmartInterfaceController@updateclickcountCap')->name('updateclickcountCap');


Route::any('/update_install_count_cap', 'SmartInterfaceController@updateinsatllcountCap')->name('updateinsatllcountCap');
Route::any('/update_sale_count_cap', 'SmartInterfaceController@updateSaleCountCap')->name('updateSaleCountCap');

Route::any('/update_kpi', 'SmartInterfaceController@updateKPI')->name('updateCap');
Route::any('/update_filter', 'SmartInterfaceController@changeFilter')->name('changeFilter');
Route::any('/update_filter_st', 'SmartInterfaceController@changeFilterSt')->name('changeFilterSt');
Route::any('/update_post_st', 'SmartInterfaceController@changePostSt')->name('changePostSt');
Route::any('/display_offer', 'SmartInterfaceController@displayOffer')->name('displayOffer');
Route::any('/getTrfcCampaign', 'SmartInterfaceController@getTrfcCampaigns')->name('getTrfcCampaigns');
Route::any('/addMoreRaw', 'SmartInterfaceController@addMoreRow')->name('addMoreRow');
Route::any('/addTrfcCampaign', 'SmartInterfaceController@addTrfcCampaign')->name('addTrfcCampaigns');
Route::any('/delete_trfc', 'SmartInterfaceController@deleteTrfc')->name('deleteTrfc');

Route::any('/display_popups', 'SmartInterfaceController@display_pops')->name('display_pops');

Route::any('/editofferwallTrfc', 'SmartInterfaceController@editofferwallTrfc')->name('editofferwallTrfc');

Route::any('/editofferwallTrfcis_offer_direct', 'SmartInterfaceController@editofferwallTrfcis_offer_direct')->name('editofferwallTrfc');

Route::any('/editofferwallTrfcisofferlist', 'SmartInterfaceController@editofferwallTrfcisofferlist')->name('editofferwallTrfcisofferlist');


Route::get('/smart-interface', 'SmartInterfaceController@index')->name('smartInterfaceView');
 /** New Smart -intetrfac start**/
 /** New Smart -intetrfac start**/
Route::get('/smart-interface-new', 'SmartInterfacenewController@index')->name('smartInternewfaceView');
Route::post('/smart-interface-new', 'SmartInterfacenewController@index')->name('smartInternewfaceViewFilter');

Route::get('/smart-interface-add-new/{id}', 'SmartInterfacenewController@get_camp')->name('smartInternewfaceViewadd_more');

Route::get('/smart-interface-add-new-store', 'SmartInterfacenewController@store')->name('smartCampaignStoreadd');

Route::post('/smart-interface-add-new-store', 'SmartInterfacenewController@store')->name('smartCampaignStoreadd');

Route::post('/smart-interface-edit-campaign-url', 'SmartInterfacenewController@edit_cmapiagn_url')->name('edit_cmapiagn_url_page');

Route::get('/smart-interface/getUrlDataSmart', 'SmartInterfacenewController@geturlSmart');

Route::get('/smart-interface-new/UpdateCampaignurl/', 'SmartInterfacenewController@editurlSmart');
Route::post('/smart-interface-new/UpdateCampaignurl/', 'SmartInterfacenewController@editurlSmart')->name('editurlSmart');
Route::get('/smart-interface-new-advertiser', 'SmartInterfacenewController@Smartcamapignlist');
 /** New Smart -intetrfac End**/
 /** New Smart -intetrfac start**/

Route::get('/smart-campaigns', 'SmartInterfaceController@campaigns')->name('smart-campaigns');

Route::get('/smart-campaigns-paginate', 'SmartInterfaceController@campaignsPaginate')->name('smart-campaigns-p');

Route::get('/smart-interface-add', 'SmartInterfaceController@get_camp')->name('smartInterfaceGet');
//Route::post('/smart-interface-getcamp', 'SmartInterfaceController@get_camp')->name('smartInterfaceGetCmp');
Route::get('/smart-interface/store', 'SmartInterfaceController@store')->name('smartCampaignStore');
Route::get('/smart-interface/edit/{id}', 'SmartInterfaceController@edit')->name('smartInterfaceEdit');
Route::get('/smart-interface-update', 'SmartInterfaceController@update')->name('smartInterfaceUpdate');
Route::get('/smart-interface-percent_update', 'SmartInterfaceController@percent_update')->name('smartInterfacePercentUpdate');
Route::get('/smart-interface-WaitageTypeUpdate', 'SmartInterfaceController@waitagetype_update')->name('smartInterfaceWaitageUpdate');
Route::get('/smart-interface-click_update', 'SmartInterfaceController@click_update')->name('smartInterfaceWaitageUpdate');
Route::get('/smart-interface-conversion_update', 'SmartInterfaceController@conversion_update')->name('smartInterfaceWaitageUpdate');
Route::get('/smart-interface-livestatus_update', 'SmartInterfaceController@livestatus_update')->name('smartInterfaceWaitageUpdate');
Route::get('/smart-interface-edit-fraud_update', 'SmartInterfaceController@fraud_update')->name('smartInterfaceWaitageUpdate');
Route::get('/smart-interface-smartstatus_update', 'SmartInterfaceController@smartStatus_update')->name('smartInterfaceWaitageUpdate');
Route::get('/smart-interface-desktop_update', 'SmartInterfaceController@smartDesktop_update')->name('smartInterfaceDesktopUpdate');
Route::get('/smart-interface-get-operator', 'SmartInterfaceController@get_oprator')->name('smartInterfaceGetOPR');
Route::get('/smart-interface-get-list', 'SmartInterfaceController@get_campaign')->name('smartInterfaceGetCampaign');

//Country Redirection
Route::get('/country-redirection', 'CountryRedirectionController@index')->name('countryRedirectionView');
Route::get('/country-redirection-add', 'CountryRedirectionController@add')->name('countryRedirectionAdd');
Route::get('/country-redirection-add-details', 'CountryRedirectionController@add_details')->name('countryRedirectionAddDetails');
Route::get('/country-redirection/edit/{id}', 'CountryRedirectionController@edit')->name('countryRedirectionEdit');
Route::get('/country-redirection-edit-details', 'CountryRedirectionController@edit_details')->name('countryRedirectionEditDetails');
Route::get('/country-redirection-status-update', 'CountryRedirectionController@status_update')->name('countryRedirectionStatus');

//Smart Engine Interface 
Route::get('/smart-hourly', 'SmartEngineController@index')->name('SmartEngineView');
Route::get('/smart-alldays', 'SmartEngineController@alldays')->name('SmartAllDays');
Route::get('/smart-engine-crc-hourly-get', 'SmartEngineController@index')->name('SmartEngineViewGet');
Route::get('/get-smart-filter', 'SmartEngineController@getSmartFilter')->name('GetSmartFilter');
Route::get('/get-smart-filter-hourly', 'SmartEngineController@getSmartFilterHourly')->name('GetSmartFilterHourly');
Route::get('/get-smartengine-details/{id}', 'SmartEngineController@getSmartDetails')->name('GetSmartDetails');
Route::get('/get-cca-by-smartcampaign/{id}','SmartEngineController@ccaBySmartCampaign')->name('ccaBySmartCampaign');
Route::get('/get-smart-filter-bycca', 'SmartEngineController@getSmartFilterByCca')->name('GetSmartFilter');
Route::get('/networks-updated','SmartEngineController@network_data')->name('network-updated');
Route::get('/smart-countrywise','SmartEngineController@countrywise')->name('smart-countrywise');
Route::get('/smart-getcountrywise','SmartEngineController@getcountrywise')->name('smart-getcountrywise');
Route::get('/getnetwork', 'AdsController@get_network')->name('GetNetwork');

Route::get('/ads', 'AdsController@index_ads')->name('ads');
#Route::post('/ads', 'AdsController@index_ads')->name('adsFilter');
Route::get('/ads/edit/{id_ad}', 'AdsController@edit_ads')->name('editAds');
Route::post('/ads/update', 'AdsController@update_ads')->name('updateAds');
Route::get('/ads/partialUpdate', 'AdsController@partialUpdate')->name('partialUpdateAds');
Route::get('/crcbacklogic/','NetworkControllerRedis@crcbacklogic')->name('crcbacklogic');


Route::get('/browser-history', 'BrowserController@index')->name('BrowserHistory');
Route::post('/browser-history', 'BrowserController@index')->name('BrowserHistoryFilter');

Route::get('/blockcca', 'BlockController@addblockcca')->name('addblockcca');
Route::get('/block/getXByY/','BlockController@getXByY')->name('advertiserbyoperator');
Route::post('/block/saveblockcca/','BlockController@saveblockcca')->name('save-block-cca');

Route::get('/listblockcca', 'BlockController@listblockcca')->name('listblockcca');
Route::get('deleteblockcca','BlockController@deleteblockcca')->name('deleteblockcca');

Route::get('/network', 'CrcController@index');
Route::get('network/getdata/', 'CrcController@getdata');
Route::get('network/getpublisher/', 'CrcController@getPublisher');

Route::get('/smart-analytics-reports', 'SmartAnalyticslistController@index')->name('smartanalyticsreports');
Route::post('/smart-analytics-reports', 'SmartAnalyticslistController@index')->name('smartanalyticsreportsfilters');
Route::get('/smart-analytics/{parent_cca}/{start}/{end}', 'SmartAnalyticslistController@report_details')->name('SmartAnalyticsdetails');
Route::post('/smart-analytics', 'SmartAnalyticslistController@report_details')->name('SmartAnalyticsdetails');

Route::get('/smart-analytics-new', 'SmartAnalyticsnewController@index')->name('SmartAnalyticsdetailsnew');
Route::post('/smart-analytics-new', 'SmartAnalyticsnewController@index')->name('SmartAnalyticsdetailsnew');
/*Smart analytics routes end*/


/* OfferUrl Management Start*/
Route::get('/offer-url-management-report', 'OfferurlmanagementController@getOfferurlreport')->name('offerurlmanagementreport');
Route::post('/offer-url-management-report', 'OfferurlmanagementController@getOfferurlreport')->name('offerurlmanagementreportpost');
Route::any('/offer-url-management-report_edit/{id}', 'OfferurlmanagementController@editgetOfferurlreport')->name('editofferurlmanagementreport');
Route::post('/offer-url-management-report_update', 'OfferurlmanagementController@updateOfferurlreport')->name('updateofferurlmanagementreport');
Route::get('/offer-url-management', 'OfferurlmanagementController@getOfferurlList')->name('offerurlmanagement');
#Route::post('/offer-url-management-filtes', 'SmartAnalyticsController@index')->name('offerurlmanagementfilters');
#Route::post('/offer-url-management-redirect-operator-config','SmartAnalyticsController@redirect_operator_config')->name('SmartAnalyticsController');
Route::post('/updateOfferurl_redirect_operator_config','OfferurlmanagementController@updateOfferurl_redirect_operator_config')->name('SmartAnalyticsController');
/* OfferUrl Management End*/

/*Offerwal management url new pages start*/
Route::get('/offerwalurllistdata','NewofferurlmanagementController@index_list')->name('Offerurllistdata');
// Route::get('/offerurlmgntdiversion','NewofferurlmanagementController@diversion_list')->name('OfferwallDiversion');
Route::post('/offerurlmgntdiversion','NewofferurlmanagementController@diversion_list')->name('OfferwallDiversion');
Route::post('/offerurlmgntdiversion_remove','NewofferurlmanagementController@diversion_remove')->name('OfferwallDiversion-remove');
Route::post('/offerurlmgntopratordiversion/','NewofferurlmanagementController@opratordiversion_list')->name('OperatorDiversion');

Route::post('/offerurlmgntopratordiversion_update/','NewofferurlmanagementController@opratordiversion_update')->name('OperatorDiversionUpdate');
Route::post('/offerurlmgntcountrydiversion_update/','NewofferurlmanagementController@countrydiversion_update')->name('CountryDiversionUpdate');
Route::post('/offer-url-management-report_update','NewofferurlmanagementController@updateOfferurlreport');
Route::post('/campaigns_list_operatorwaise','NewofferurlmanagementController@campaigns_list_operatorwaise');
Route::get('/country_list_append','NewofferurlmanagementController@country_list');
Route::post('/campaigns_list_countrywaise','NewofferurlmanagementController@campaigns_list_countrywaise');
Route::post('/udpatediversion','NewofferurlmanagementController@updatenew_diversion');
Route::post('/diversionliststatus','NewofferurlmanagementController@diversion_list_status');
Route::post('/country_list_status','NewofferurlmanagementController@country_list_status');
Route::post('/country_list_remove','NewofferurlmanagementController@country_list_remove');
Route::post('/operator_list_status','NewofferurlmanagementController@operator_list_status');
Route::post('/operator_list_remove','NewofferurlmanagementController@operator_list_remove');

/*Offerwal management url new pages end*/


Route::get('/fraud-click-info', 'FraudClickInfoController@index')->name('fraudinfo');
Route::post('/fraud-click-info', 'FraudClickInfoController@index')->name('fraudinfofiltered');


Route::get('/ip-pools', 'IpPoolsController@index')->name('ipPools');
Route::get('/add-ip-pool', 'IpPoolsController@add')->name('AddIpPool');
Route::post('/add-ip-pool', 'IpPoolsController@store')->name('AddIpPool');
Route::get('/ip-pools/edit/{id}','IpPoolsController@edit')->name('EditIppools');
Route::get('/ip-pools/delete/{id}','IpPoolsController@destroy')->name('DeleteIppool');
Route::post('/update-ip-pools', 'IpPoolsController@update')->name('IpPoolUpdatePost');

Route::get('/campaign-ip-pool', 'CampaignIpPoolsController@index')->name('CampaignIppools');
Route::get('/add-campaign-ip-pool', 'CampaignIpPoolsController@add')->name('CampaignAddIpPool');
Route::post('/add-campaign-ip-pool', 'CampaignIpPoolsController@store')->name('CampaignAddIpPoolPost');
Route::get('/getCampaigns', 'CampaignIpPoolsController@getCampaigns')->name('GetCampaigns');
Route::get('/campaign-ip-pool/edit/{id}','CampaignIpPoolsController@edit')->name('EditCampaigns');
Route::post('/update-campaign-ip-pool', 'CampaignIpPoolsController@update')->name('CampaignIpPoolUpdatePost');
//Conversion Resports
Route::get('/conversionsreport','ConversionreportController@index')->name('convesionreports');
Route::post('/conversionsreport','ConversionreportController@index')->name('convesionreportsfilter');


Route::get('/offerwall', 'SmartInterfaceController@offerwall')->name('Offerwall');
Route::get('/offer-delivery', 'DeliveryController@offerdelivery')->name('Offerdelivery');
Route::post('/offer-delivery', 'DeliveryController@offerdelivery')->name('Offerdeliverypost');


Route::get('/crc-hourly', 'CrcRecordsSmartController@index')->name('CrcHourly');
Route::get('/crc-filter-hourly', 'CrcRecordsSmartController@CrcFilterHourly')->name('CrcFilterHourly');

/*  New Campain Url start date ('2018-04-06') Create by Sonu  using same controller AdsController  */
Route::get('/new_campain_url','AdsController@new_campain_index')->name('NewCampainIndex');
Route::post('/new_campain_url','AdsController@new_campain_index')->name('NewCampainIndexfilter');
Route::get('/advertiser_log','ConversionreportController@Advertiser_log_reports')->name('Advertiserlogreports');
Route::post('/advertiser_log','ConversionreportController@Advertiser_log_reports')->name('Advertiserlogreportsfilter');
// Route::post('/advertiserlogreports_filter','ConversionreportController@new_campain_index_filter')->name('Advertiserlogreports_filter');
Route::get('/advertiser_operator','ConversionreportController@advertiser_operator_list')->name('Advertiseroperators');
Route::get('/advertiser_log_campagin','ConversionreportController@advertiser_log_campagin')->name('Advertiseroperators');
Route::get('/get_key','MacController@get_key')->name('MACKEY');
Route::post('/post-mac','MacController@post_mac')->name('MACKEY');

/*   New Campain Url start date ('2018-04-06') Create by Sonu   */
/* Smart Manual Controller*/
Route::get('/add-smart-manual-cron','CronController@add_smart_manual_cron')->name('add-manual-cron-post');
Route::get('/smart-manual-cron','CronController@smart_manual')->name('manual-cron');
Route::get('/filter-smart-manual-cron','CronController@filterSmartManualCron')->name('filter-smart-manual-cron');
Route::get('/new-smart-manual-cron','CronController@new_smart_manual')->name('manual-cron');
Route::get('/smart-manual-campaign','CronController@cca_campaign_list')->name('manual-cron-campaign');
Route::get('/smart-manual-cron-details','CronController@responsce_list_details')->name('manual-cron-campaign');
/* Smart Controller End*/



Route::get('/smart-carrier-specific-default-a', 'NetworkControllerTest@CarrierIndexA')->name('smarthomeCariar');
Route::get('/smart-carrier-specific-default-c', 'NetworkControllerTest@CarrierIndexC')->name('smarthomeCariarC');
Route::get('/smart-wifi-specific-default-a', 'NetworkControllerTest@CarrierIndexWIFIA')->name('smarthomeCariarWIFIA');
Route::get('/smart-wifi-specific-default-c', 'NetworkControllerTest@CarrierIndexWIFIC')->name('smarthomeCariarWIFIC');
Route::get('/smart-network-cr-update-single-network/{ad_id}', 'NetworkControllerTest@smart_single')->name('smart-network-wise-record');
Route::post('/smart-network-cr-update-single-network/{ad_id}', 'NetworkControllerTest@smart_single')->name('smart-network-wise-record-filter');
Route::get('/smart-delivery', 'DeliveryController@smart_index')->name('smart-delivery');
Route::get('/smart-delivery-old/{auth}', 'DeliveryController@smart_index2')->name('smart-delivery');
Route::post('/smart-delivery2', 'DeliveryController@smart_index2')->name('smartdeliverypost2');
Route::post('/smart-delivery', 'DeliveryController@smart_index')->name('smartdeliverypost');
Route::get('/smart-delivery/add', 'DeliveryController@smartadd')->name('SmartDeliveryAdd');
Route::get('/smart-delivery/event_add', 'DeliveryController@smart_event_add')->name('SmartDeliveryEventAdd');
Route::any('/smart-delivery-event', 'DeliveryController@smart_index_event')->name('smart-delivery-event');
Route::post('/add-delivery-event', 'DeliveryController@add_delivery_event')->name('delivery-event-post');


Route::get('hourly/','CrchourlyController@index');
Route::get('hourly/gethourdata/','CrchourlyController@gethourdata');
Route::get('hourly/getoperators/','CrchourlyController@getoperators');
Route::get('hourly/getadvertisers/','CrchourlyController@getAdvertisers');
Route::get('hourly/getnetworks/','CrchourlyController@getNetworks');
Route::get('hourly/getcampaigns/','CrchourlyController@getcampaigns');
Route::get('hourly/filterresult/','CrchourlyController@filterData');


Route::get('crc/', 'CrcRecordsNewController@index');
Route::get('getdata/', 'CrcRecordsNewController@getdata');
Route::get('getcountry/', 'CrcRecordsNewController@getCountry');
Route::get('advertiser/', 'CrcRecordsNewController@advertiser');
Route::get('getcampaigns/', 'CrcRecordsNewController@getcampaigns');

Route::get('conversion/','ConversionController@index');
Route::get('conversion/filterresult','ConversionController@filterData');

/*Created By Md Saddam Hussain*/

Route::get('edit-deativation/{id}','DeactivationController@edit');
Route::get('deactivation/','DeactivationController@index');
Route::get('deactivation-data/','DeactivationController@data');
Route::get('add-deactivation/','DeactivationController@add_data');
Route::get('edit_deactivation/','DeactivationController@edit_deactivation');

Route::get('domain-info/','DomainInfoController@data');
Route::get('info-domain/','DomainInfoController@index');
Route::get('add-domaininfo/','DomainInfoController@add_data');
Route::get('edit-domaininfo/{domainId}','DomainInfoController@edit');
Route::get('edit_domaininfo/','DomainInfoController@edit_domaininfo');
Route::get('redirect-info/','UrlRedirectionInfoController@data');
Route::get('view-redirectinfo-details/{id_advertiser}','UrlRedirectionHistoryController@data');
Route::post('redirect-info/','UrlRedirectionInfoController@data');
Route::get('view-redirectinfo-details/{id_advertiser}','UrlRedirectionHistoryController@data');
Route::post('view-redirectinfo-details/{id_advertiser}','UrlRedirectionHistoryController@data');
Route::post('/smart-delivery-old/{auth}', 'DeliveryController@smart_index2')->name('smart-delivery-post');

Route::get('/smart-interface-new/edit/{id}', 'SmartInterfacenewController@edit')->name('smartInterfaceNewEdit'); 




/*Ads new controller of smartulr chanages AdssmarturlController*/

Route::get('/smarturls/edit-smarturlnew', 'AdssmarturlController@editsmartnewUrl');

Route::post('/smarturls/updateSmartnewUrls' ,'AdssmarturlController@updateSmartnewUrls')->name('updateSmartnewUrls');

Route::get('/smarturls/getcampaign','AdssmarturlController@getsmartCampaign');
Route::get('/filter-cron','CronController@filterCron')->name('cron_filter');



Route::get('/smarturls/getPercentageOnCampaignsByCca', 'AdssmarturlController@getPercentageOnCampaignsByCca')->name('getPercentageOnCampaignsByCca');
Route::get('/smarturls/getCpiCpa_smarturl', 'AdssmarturlController@getCpiCpa_smarturl')->name('getCpiCpa_smarturl');







/*Ads new chanages controller of Smart link smartulr chanages AdssmarturlController*/

Route::get('/smarturls/edit-smart-link-urlnew', 'AdssmarturlController@editsmartlinknewUrl');

Route::post('/smarturls/updateSmartlinknewUrls' ,'AdssmarturlController@updateSmartlinknewUrls')->name('updateSmartlinknewUrls');

Route::get('/smarturls/getcampaign','AdssmarturlController@getsmartCampaign');

Route::get('/smarturls/getPercentageOnCampaignsByCca', 'AdssmarturlController@getPercentageOnCampaignsByCca')->name('getPercentageOnCampaignsByCca');
Route::get('/smarturls/getCpiCpa_smarturl', 'AdssmarturlController@getCpiCpa_smarturl')->name('getCpiCpa_smarturl');


Route::get('/url-redirection-check', 'UrlRedirectionCheckController@index')->name('urlRedirectionCheck');
Route::post('/url-redirection-check/getUrlData','UrlRedirectionCheckController@filterUrlData')->name('filterUrlSearch');




Route::get('/conversion-report','ConversionreportsController@index')->name('convesionreports');
Route::post('/conversion-report','ConversionreportsController@index')->name('convesionreportsfilter');
Route::get('/special-delivery','SpecialDeliveryController@index')->name('specialDelivery');
Route::get('/special-delivery-add','SpecialDeliveryController@add')->name('specialDeliveryADD');
Route::get('/special_delivery_add','SpecialDeliveryController@add_details')->name('specialDeliveryADDDT');
Route::get('/update_special_url','SpecialDeliveryController@update_url')->name('specialDeliveryUpdateUrl');





//siteid and pubid wise interface 
Route::get('cpacpihourly/','SiteidwaisehourlyController@index');
Route::get('cpacpihourly/gethourdata/','SiteidwaisehourlyController@gethourdata');
Route::get('cpacpihourly/getoperators/','SiteidwaisehourlyController@getoperators');
Route::get('cpacpihourly/getadvertisers/','SiteidwaisehourlyController@getAdvertisers');
Route::get('cpacpihourly/getnetworks/','SiteidwaisehourlyController@getNetworks');
Route::get('cpacpihourly/getcampaigns/','SiteidwaisehourlyController@getcampaigns');
Route::get('cpacpihourly/filterresult/','SiteidwaisehourlyController@filterData');

Route::get('siteidwsiediversion/','SiteidwaisediversionController@index');
Route::get('deleteSiteidwiserow','SiteidwaisediversionController@deleteSiteidwiserow');


//new logic interface details
Route::get('maskinginterface/','MaskinginterfaceController@index');

Route::get('change_advt_name/','MaskinginterfaceController@changeadvertisername');

Route::get('changeadvertisernametables/','MaskinginterfaceController@changeadvertisernametables');

Route::get('changeadvertisernameafterweek/','MaskinginterfaceController@changeadvertisernameafterweek');

Route::get('publisher_changes','MaskinginterfaceController@publisher_changes')->name('publisher_changes');






//Siteidwise diversion list

 
Route::get('siteidwsiediversion/','SiteidwaisediversionController@index');
Route::post('Siteidwisefileter/','SiteidwaisediversionController@Siteidwisefileter');
Route::get('Siteidwiseparentccadetails/','SiteidwaisediversionController@Siteidwiseparentccadetails');

Route::get('Siteidwiseadd_insert/','SiteidwaisediversionController@Siteidwiseadd_newinsert');

Route::get('Siteidwiseaddmorerow/','SiteidwaisediversionController@Siteidwiseaddmorerow');

Route::get('Siteidwiseeditdetails/','SiteidwaisediversionController@Siteidwisediverisoneditdeatils');

Route::get('Siteidwiseeditsave/','SiteidwaisediversionController@Siteidwisediverisoneditsave');
Route::get('selectcampaignofferlist/','SiteidwaisediversionController@selectcampaignofferlist');
Route::get('updateSiteidwisestatus/','SiteidwaisediversionController@updateSiteidwise');
//(CTIIT Interface)

Route::get('cttiitwsieconversion/','CTIITController@index');
Route::get('cttiitwsieconversion/filterresult','CTIITController@filterData');







//CPA Interface  create josn

 Route::get('cpadefineinterface','CpadefineController@index');

Route::get('getnetwrok_details','CpadefineController@getnetwrok_details');

Route::get('getnetwrok_details_config','CpadefineController@getnetwrok_details_config');

Route::get('savecpadetailsconfig','CpadefineController@savecpadetailsconfig');

Route::get('getcpapreviewconfig','CpadefineController@getcpapreviewconfig');

Route::get('getcpadefinecampain','CpadefineController@getcpadefinecampain');



Route::get('crchourlycamapaire','CrchourlycomparisonController@index')->name('crchourlycompaireindex');
Route::get('crchourlycamapaire/gethourdata/','CrchourlycomparisonController@gethourdata');
Route::get('crchourlycamapaire/getoperators/','CrchourlycomparisonController@getoperators');
Route::get('crchourlycamapaire/getadvertisers/','CrchourlycomparisonController@getAdvertisers');
Route::get('crchourlycamapaire/getnetworks/','CrchourlycomparisonController@getNetworks');
Route::get('crchourlycamapaire/getcampaigns/','CrchourlycomparisonController@getcampaigns');
Route::get('crchourlycamapaire/filterresult/','CrchourlycomparisonController@filterData');
//Date wise daily compare hourly

Route::get('crcdailycamapaire','CrcdailycomparisonController@index')->name('crcdailycompaireindex');
Route::get('crcdailycamapaire/getdailydata/','CrcdailycomparisonController@getdailydata');
Route::get('crcdailycamapaire/getoperators/','CrcdailycomparisonController@getoperators');
Route::get('crcdailycamapaire/getadvertisers/','CrcdailycomparisonController@getAdvertisers');
Route::get('crcdailycamapaire/getnetworks/','CrcdailycomparisonController@getNetworks');
Route::get('crcdailycamapaire/getcampaigns/','CrcdailycomparisonController@getcampaigns');
Route::get('crcdailycamapaire/dailyfilterresult/','CrcdailycomparisonController@filterData');



//CITY MAPPING INTERFACE 20191018
Route::get('citymapping','CitymappingController@index')->name('citymapping');

Route::get('addcitymapping','CitymappingController@add_city_mapping')->name('addcitymapping');

Route::post('savecitywisediversion','CitymappingController@save_city_mapping')->name('savecitywisediversion');

Route::get('dependdata','CitymappingController@getdependdata')->name('depanddata');

Route::get('autocomplete','CitymappingController@search')->name('autosearch');

Route::get('getdependdatacity','CitymappingController@getdependdatacity')->name('getdependdatacity');

Route::get('city-redirection/edit/{id}','CitymappingController@editcitymapping')->name('geteditcitymapping');
Route::post('updatecitywisediversion','CitymappingController@update_city_mapping')->name('updatecitywisediversion');

Route::get('city-redirection/delete/{id}','CitymappingController@deletecitymapping')->name('geteditcitymapping');
Route::get('city-redirection-status-update','CitymappingController@status_update')->name('cityRedirectionStatus');


//impression count 

Route::get('impression_count','ImpressionController@index')->name('impression_count');
Route::post('/impression_count', 'ImpressionController@index')->name('impression_countreportpost');

Route::any('/publisherlist', 'NetworkController@publisherlist')->name('publisherlist');
Route::any('/addpublisher', 'NetworkController@addpublisher');
//Route::any('/doaddpublisher', 'NetworkController@doaddpublisher');
Route::any('/adv_list', 'NetworkController@advertiser_list')->name('adv_list');
Route::any('/addadvertiser', 'NetworkController@addadvertiser');
Route::any('/edit-publisher/{ccz}', 'NetworkController@editpublisher');
Route::any('/dopublisheredit/{pub_id}', 'NetworkController@dopublisheredit');



Route::get('/offer-networkwise-newpage', 'SmartInterfaceController@offer_networkwise_newpages')->name('offer_networkwise_newpages');

Route::post('/offer-networkwise-newpage', 'SmartInterfaceController@offer_networkwise_newpages')->name('offer_networkwise_newpages');



Route::get('/user_wise_reports','UserwisereportController@index')->name('user_wise_reports');
Route::post('/user_wiser_reports','UserwisereportController@index_filter')->name('user_wise_reports');


Route::any('/publisherOfferListnewpage', 'PublisherInterfaceredisController@publisherOfferList')->name('publisherlist');
Route::any('/publisherOfferListnewpage2', 'PublisherInterfaceredis2Controller@publisherOfferList')->name('publisherlist');
Route::any('/change_domain_url', 'PublisherInterfaceredisController@update_domain_url')->name('updateDomain');
Route::any('/cpi-smart-delivery', 'DeliveryController@smart_index_new')->name('smartdeliverypost_new');

/*  
 *             event-delivery URL     
 * 
 *  */

Route::get('/event-delivery','EventDeliveryController@index')->name('event_delivery');
Route::post('/event-delivery', 'EventDeliveryController@index')->name('eventpost');
Route::get('/event-smtUrlStatus', 'EventDeliveryController@updateSmtUrlSt')->name('eventSmtUrlStUpdate');
Route::get('/event/add', 'EventDeliveryController@add')->name('eventAdd');
Route::post('/event/add', 'EventDeliveryController@store')->name('eventpostAddPost');
Route::get('/event/get-adsbynetwork/','EventDeliveryController@getAdsByNetwork')->name('deliveryAdsByNetwork');
Route::get('/event/edit/{id}/{zone}', 'EventDeliveryController@edit')->name('EventEdit');
Route::post('/event/edit', 'EventDeliveryController@update' )->name('EventUpdate');



Route::get('/advertiser-report-timezonewise', 'TimeZoneReportController@time_zone_offer_advertiser')->name('AdvertiserOfferTimeZoneWise');
Route::post('/advertiser-report-timezonewise', 'TimeZoneReportController@time_zone_offer_advertiser')->name('AdvertiserOfferTimeZoneWisepost');