<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RoleUser extends Model
{
    //

    /**
     * The database table used by the model.
     * @var string
     */
    protected $table = 'role_user1';
    protected $primaryKey = 'id';
    protected $fillable = ['id', 'role_id', 'user_id',];
    public $timestamps = false;
    protected $auditEnabled = true;



}
