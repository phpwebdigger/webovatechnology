<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdvertiserCampaigns extends Model
{
    //

     protected $table = 'advertiser_campaigns';
     public $timestamps = false;

    public function Advertiser()
    {
        return $this->belongsTo('App\Advertiser','id_advertiser','id');
    }

    public function Operator()
    {
        return $this->belongsTo('App\Operator','id_op','id');
    }

    public function CountryOperators(){
    	return $this->hasMany('App\Operator','country_code','country_code');
    }

}
