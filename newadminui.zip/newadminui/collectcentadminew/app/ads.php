<?php
namespace App;

use Illuminate\Database\Eloquent\Model;

class ads extends Model
{
  protected $table = 'ads';
  public $timestamps = false;

  public function Operator(){
	return $this->belongsTo('App\Operator','cco','id');
  }

  public function AdvertiserCampaign(){
        return $this->belongsTo('App\AdvertiserCampaigns','id_advertiser','id');
  }

  public function Networks(){
        return $this->belongsTo('App\AdNetwork','id_zone','ccz');
  }


}