<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Siteidwisediversion extends Model
{
	//protected $connection = 'mysql2';
	protected $table = 'siteid_campaign_routing';
	public $timestamps = false;
	protected $primaryKey = "id";
}
