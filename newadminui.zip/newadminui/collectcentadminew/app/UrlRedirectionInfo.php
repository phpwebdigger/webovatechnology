<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UrlRedirectionInfo extends Model
{
    //
     protected $table = 'urlRedirectionInfo';
     protected $fillable = ["id_advertiser","src_url",'dest_url','statusCode','isLoopBackUrl','errorRetryCount'];
     public $timestamps = true;	
    
}
