<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Operator extends Model
{
    protected $table = 'operator';
	protected $primaryKey = 'id';
	protected $fillable = ['name','country','country_code','language','rahul_cpa'];
   	public $timestamps = false;
}
