<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FraudClickInfo extends BaseModel
{
    //
    	public $timestamps = false;
    	protected $table = 'fraud_click_info';

}
