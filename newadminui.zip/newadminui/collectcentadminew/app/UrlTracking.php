<?php
namespace App;

use Illuminate\Database\Eloquent\Model;

class UrlTracking extends Model
{
    public $timestamps = false;
    protected $table = 'url_tracking';
    protected $fillable = ["id","user_name",'id_ad','id_advertiser','click_url','mac_address'];
      

}