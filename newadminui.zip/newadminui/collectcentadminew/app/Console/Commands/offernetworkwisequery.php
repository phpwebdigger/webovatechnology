<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Redis;
use Illuminate\Support\Facades\DB;

class offernetworkwisequery extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'offernetworkwisequery:offernetworkquery';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Fetch The OfferNetwrok Query';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $redis = Redis::connection();
        $date  = date('Y-m-d');
        $key   = "networkwisenewpageredis_$date";
      try {
          if(!$redis->exists($key)){
             $items = $this->index_adv_networkwisenewpageredis(); 
             $networkwisenewpageredis = Redis::set($key, $items);
             $redis->expire($key,5);
            }else{
            $items = Redis::get($key);
         }
      } catch (\Exception $e) {
            // echo $e->getMessage();
          $items = $this->index_adv_networkwisenewpageredis();  
      }

     
      return $items; 
    }

    public function index_adv_networkwisenewpageredis(){
    
            $dtvalue = date('Y-m-d');
                $enddate = date('Y-m-d',strtotime("+1 days"));
        array_push($condtion,['crc_records_new.create_time','>=',$dtvalue] );
        array_push($condtion,['crc_records_new.create_time','<=',$enddate] );

                $select =  
                        "select smart_rotator_campaigns_operators.campaign_id,
                        ad_network.account_manager,  
                        smart_rotator_campaigns_operators.redirect_diversion_config,
                        smart_rotator_campaigns_operators.id_zone as zone,
                        smart_rotator_campaigns_operators.smart_live as active,
                        ad_network.name as network_name,
                        smart_rotator_campaigns_operators.publisher_cpa as cpa,
                        smart_rotator_campaigns_operators.ads_cat as traffic_type,
                        crc_records_new.id_advertiser_campaign,
                        advertiser_campaigns.name,
                        advertiser_campaigns.offername,
                        advertiser_campaigns.id,
                        advertiser_campaigns.id_op as op_id,
                        smart_rotator_campaigns_operators.is_offer_direct as trfc,
                        advertiser_campaigns.vertical,
                        smart_rotator_campaigns_operators.status as cap_status,
                        smart_rotator_campaigns_operators.country_code as country_code,
                        advertiser_campaigns.os_type,
                        advertiser_campaigns.incent_type,
                        crc_records_new.parent_cca as parent_cca,
                        crc_records_new.id_channel as id_channel,
                        crc_records_new.clickcount_fraud as fraud,
                        crc_records_new.create_time as datetime,
                        CONCAT(crc_records_new.cr_received,'%') AS cr_received,
                        CONCAT(crc_records_new.cr_given,'%') AS cr_given,
                        sum(crc_records_new.clickcount) as clickcount,
                        sum(crc_records_new.conversion_count_unique) as conversion_count_unique,
                        sum(crc_records_new.conversion_count) as conversion_count,
                        sum(crc_records_new.clicks_active_count) as clicks_active_count,
                        sum(crc_records_new.sale_count) as sale_count,
                        sum(crc_records_new.total_cost) as cost_dollar,
                        sum(crc_records_new.revenue_dollar) as revenue_dollar
                    from crc_records_new as crc_records_new 
                    join smart_rotator_campaigns_operators as smart_rotator_campaigns_operators on smart_rotator_campaigns_operators.campaign_id = crc_records_new.parent_cca 
                    join advertiser_campaigns as advertiser_campaigns on advertiser_campaigns.id = smart_rotator_campaigns_operators.campaign_id 
                    join ad_network as ad_network on smart_rotator_campaigns_operators.id_zone = ad_network.ccz 
                    and smart_rotator_campaigns_operators.id_zone = crc_records_new.id_channel
                    where smart_rotator_campaigns_operators.ads_cat in ('OM', 'OG') 
                    and (crc_records_new.create_time >= '$dtvalue' and crc_records_new.create_time <= '$enddate') 
                    group by smart_rotator_campaigns_operators.campaign_id,smart_rotator_campaigns_operators.id_zone";
               
                 $data =  DB::select(DB::raw($select));

                 return $data;
                
                }



}
