<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Advertisermasking extends Model
{
	protected $primaryKey = 'id'; // or null
	protected $table = 'advertiser_maskings';
	protected $fillable = ['advertiser_name','display_name','description','created_date','status'];
   	public $timestamps = false;
   	
   
}
