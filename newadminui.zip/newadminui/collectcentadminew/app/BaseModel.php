<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class BaseModel extends Model
{
     public function getTableData($condition){
    	return DB::table('users')->get();
    }
}
