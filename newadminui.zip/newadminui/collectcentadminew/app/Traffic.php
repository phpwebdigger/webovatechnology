<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Traffic extends Model
{
    protected $table = 'trfc_config';
	protected $fillable = ['id'];
   	public $timestamps = false;
}
