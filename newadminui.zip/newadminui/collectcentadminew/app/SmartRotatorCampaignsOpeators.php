<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmartRotatorCampaignsOpeators extends Model
{
	protected $table = 'smart_rotator_campaigns_operators';
	public $timestamps = false;
   	
   	 public function AdvertiserCampaign()
     {
        return $this->belongsTo('App\AdvertiserCampaigns','campaign_id','id');
     }

     public function Operator()
     {
        return $this->belongsTo('App\Operator','op_id','id');
     }

     public function Network()
     {
        return $this->belongsTo('App\AdNetwork','id_zone','ccz');
     }
   	
}
