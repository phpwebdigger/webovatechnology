<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;
use App\QueryAccess;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Auth;
// use App\SmartTrafficConfig;
use App\SmartTrafficConfig;
use App\AdvertiserCampaigns;
use App\ads;      
use Response;
use Session;
use Validator;
use Illuminate\Support\Facades\Cookie;
use App\UrlTracking;

class SmarttrafficconfigController extends Controller
{
    //
   public function  __construct()
    {
       $this->middleware('auth');
    }


    public function index(Request $request){
        $Smarttraffic_data= new \App\Smarttrfcconfig();
        $condtion = $data1 = [];
        $total = 30;
        $select = [ 'smart_trfc_config.id',
                    'smart_trfc_config.cca',
                    'smart_trfc_config.campaign_id',
                    'smart_trfc_config.hold_percentage',
                    'smart_trfc_config.status',
                    'smart_trfc_config.is_primary_campaign',
                    'ads.id_ad',
                    'ads.id_zone',
                    'ads.country_code',
                    'ads.network_name',
                    'ads.operator_name',
                    'ads.cco',
                    'advertiser_campaigns.permanent_status as permanent_status',
                    'advertiser_campaigns.name as campaign_name',
                    'advertiser_campaigns.id_advertiser as id_advertiser',
                    'advertiser.name as advertiser',
                    // 'country.name as country_name'
                    // 'advertiser_campaigns.country_code',
                    'advertiser_campaigns.id_op',
                    // 'operator.name as operator_name'
                    'advertiser_campaigns.status as campaign_status',

                     
                ];        
                // array_push($condtion,['ads.is_smart_cca','=','1']);
                $smrttrfc_result = $Smarttraffic_data->select($select)->where($condtion)
                            ->leftJoin("ads","ads.id_ad","=","smart_trfc_config.cca")
                            ->leftJoin("advertiser_campaigns","advertiser_campaigns.id","=","smart_trfc_config.campaign_id")
                            ->leftJoin("advertiser","advertiser.id","=","advertiser_campaigns.id_advertiser")
                            // ->leftJoin("operator","operator.id","=","ads.cco")
                            ->orderBy('smart_trfc_config.cca','desc')
                            ->orderBy('smart_trfc_config.is_primary_campaign','desc')
                            ->limit($total)
                            ->get();
                foreach($smrttrfc_result as $fetch_url) {
                $array = [];
                $add_more = [];
                $is_check = $fetch_url->status == 1 ? "checked": "";
                $active =  $fetch_url->status == 1 ? "Active": "Inactive";
                $campaign_status= ($fetch_url->campaign_status==0 ? 'Paused': ($fetch_url->campaign_status==5 ? 'Cap Reached':'Active'));

                $is_active = '<span class=""><input type="checkbox" id='.$fetch_url->id.'  name="is_smarttrfc_active[]" '.$is_check.'></span><label for="checkbox8" id="status-'.$fetch_url->id.'">'.$active.'</label>';
                if($fetch_url->is_primary_campaign == 1){
                $add_more = "<a href='javascript:void()' class='add-more' data-id='".$fetch_url->cca."' data-cco='".$fetch_url->cco."'>Add More<a>";
                }
                array_push($array,
                          $fetch_url->network_name.'('.$fetch_url->id_zone.')',
                          $fetch_url->operator_name .' ('.$fetch_url->country_code.')',

                          $fetch_url->cca."<span id='id_ad-".$fetch_url->id_ad."' class='change-campaign' data-value=".$fetch_url->id_ad." data-smart_id=".$fetch_url->campaign_id.">&nbsp;<i class='fa fa-edit'></i></span>",

                          "<span id='".$fetch_url->id_advertiser."'>".$fetch_url->advertiser."(".$fetch_url->id_advertiser.")"."</span>",
                          "<span id='cca_".$fetch_url->id."'>".$fetch_url->campaign_name."(".$fetch_url->campaign_id.")"."</span>",
                          
                          // "<span id='percentage-container_".$fetch_url->id."' style='font-size:24px'>".$fetch_url->hold_percentage."</span><span id='percentage-".$fetch_url->id."' class='edit-percentage' data-id='".$fetch_url->cca."' data-cco='".$fetch_url->id_op."'>&nbsp;<i class='fa fa-edit'></i></span>",
                          "<span class='outer-container' id='outer-percent-container_".$fetch_url->id."'><span class='percentage-container' id='percentage-container_".$fetch_url->id."' style='font-size:24px'>".$fetch_url->hold_percentage."</span><span id='percentage-".$fetch_url->id."' class='percentage-edit' data-cca=".$fetch_url->cca." data-value=".$fetch_url->hold_percentage.">&nbsp;<i class='fa fa-edit'></i></span></span>",
                           $fetch_url->is_primary_campaign == '1' ? "Primary Campaign": "Diverted",                                               
                           $is_active,
                           $add_more,
                          "<span id='".$fetch_url->permanent_status."'>".$fetch_url->permanent_status."</span>",
                          "<span id='".$fetch_url->campaign_status."'>".$campaign_status."</span>"

                          );
                      array_push($data1, $array);
                }
                $operators =  DB::table("operator")
                                  ->leftJoin("country","operator.country_code","=","country.iso")
                                  ->selectRaw(DB::raw("operator.id as id, operator.name as operator,country.iso as country"))
                                  ->orderby("operator.name","ASC")->get(); 
                $advertiser =  DB::table("advertiser_campaigns")
                                  ->leftJoin("advertiser","advertiser_campaigns.id_advertiser","=","advertiser.id")
                                  ->selectRaw(DB::raw("distinct advertiser_campaigns.id_advertiser as id_advertiser, advertiser.name as campaign_advertiser"))
                                  ->orderby("advertiser.name","ASC")->get(); 
               
                $networks =  DB::table("ad_network")->selectRaw(DB::raw("distinct ccz,name"))->orderby("name","ASC")->get();
//              $advertiser =  DB::table("advertiser_campaigns")->selectRaw(DB::raw("distinct id_advertiser,campaign_advertiser"))->orderby("campaign_advertiser","ASC")->get();
                $page_name="Smart Trfc Config";
                $routename = "smarttraffic";
                return view('Smarttraffic.index',compact('networks','data1','total','page_name','opdata','advertiser','operators','routename'));
        }
   
      

     /* to Update Status of traffic confg */ 
      public function partialSmartTrafficUpdate(Request $request){
        $action = $request->action;
        $data = '';
        $status = array('status'=>0,'data'=>$data);
         $trfc_table = new \App\Smarttrfcconfig();
        if($action == 'status'){
            $status = $request->status;
            $id = $request->id;
            $update = array('status' => $request->status);
            $upt1 = $trfc_table::where('id','=',$id)->update($update);
            if($request->status == 1){
                $data = 'Active';
            }else{
                $data = 'InActive';  
            } 
            $status = array('status'=>'1','data'=>$data);
            
        }else if($action == 'percent'){
            $id = $request->id;
            $update = array('hold_percentage' => $request->percent);
            $upt1 = $trfc_table::where('id','=',$id)->update($update);
            $status = array('status'=>'1','data'=>$request->percent);
        }
        $status = Response::json($status);
        return $status;
    }

    /* to get all the campaign with percentage*/
    public function getPercentageOnCampaignsByCca(Request $request){
        $condition = [];
        $alreadyExistedCampaigns = [];
        $advertiser_campaigns = '';
        if($request->cca){
            array_push($condition,['smart_trfc_config.cca','=',$request->cca]);
        }
        $select = [ 
                    'smart_trfc_config.id', 
                    'smart_trfc_config.cca',
                    'smart_trfc_config.campaign_id',
                    'smart_trfc_config.hold_percentage',
                    'smart_trfc_config.status',
                    'ads.id_zone',
                    'ads.network_name',
                    'ads.operator_name',
                    'advertiser_campaigns.name as campaign_name'
                  ];
        try{
            $data = SmartTrafficConfig::where($condition)
                     ->leftJoin("ads","ads.id_ad","=","smart_trfc_config.cca")
                     ->leftJoin("advertiser_campaigns","smart_trfc_config.campaign_id","=","advertiser_campaigns.id")
                     ->select($select)->orderBy('smart_trfc_config.cca','desc')
                      ->orderBy('smart_trfc_config.is_primary_campaign')->get();
            foreach($data as $smartTrfc){
              array_push($alreadyExistedCampaigns,$smartTrfc->campaign_id);
            }         
            if($request->cco || ($request->cco==0)){
                $ad_condition = [];
                array_push($ad_condition,['id_op','=',$request->cco]);
                array_push($ad_condition,['status','=','1']);
                $ad_select = ['name','id'];
                $advertiser_campaigns = AdvertiserCampaigns::where($ad_condition)
                                        ->whereNotIn('id',$alreadyExistedCampaigns)
                                        ->select($ad_select)->orderby('name')->get();
            }
            $status = array('status'=>1,'data'=>$data,'advertiser_campaigns'=>$advertiser_campaigns);    
         }catch(\Illuminate\Database\QueryException $ex){ 
          $status = array('status'=>2,'data'=>'','message'=>$ex->getMessage(),'advertiser_campaigns'=>''); 
        }
        $data = Response::json($status);
        return $data;
    }

    public function updateTrafficPercentage(Request $request){
         $ids = $request->id;
         $cca = $request->cca;
         $hold_percentages = $request->hold_percentage;
         $percentage = 0;
         $condition = [];
         try{
          if($request->cca){
                array_push($condition,['cca','=',$request->cca]);
          }
          for($i=0;$i<count($hold_percentages);$i++){
             $result = DB::statement("update smart_trfc_config set hold_percentage =".$hold_percentages[$i]." where id = ".$ids[$i]);
          }
           $select = ['id','cca','campaign_id','hold_percentage'];
          if($result){
              $data = SmartTrafficConfig::where($condition)->select($select)->limit(10)->get();
              $status = array('status'=>1,'hold_percentage'=>$data);
          }
        }catch(\Illuminate\Database\QueryException $ex){
          $status = array('status'=>2,'hold_percentage'=>$data);
        }
      return json_encode($status); 

    }
    
    /*filteration of smart trfc config 
     * Dev : sumit M
     * Date : 22 may 2018
     */ 
    
    function filterSmartTrfcData(Request $request){
      $data = $condition = []; 
      $network = $request->network;  
      $status = $request->status;
      $operator = $request->operator;
      $parent_cca = $request->parent_cca;
      $id_ad = $request->id_ad;
      $advertiser = $request->advertiser;
      $stat_perma = $request->permanentStatus;
      $add_more = '';
      if($network != 'null' && $network != ''){
         array_push($condition,['ads.id_zone','=',$network]);  
      }
      if($operator != 'null' && $operator != ''){
        array_push($condition,['ads.cco','=',$operator]);
      }
      if($status != 'null' && $status != ''){
         array_push($condition,['smart_trfc_config.status','=',$status]);           
      }
      if($parent_cca != 'null' && $parent_cca != ''){
         array_push($condition,['smart_trfc_config.cca','=',$parent_cca]);
      } 
    if($id_ad != 'null' && $id_ad != ''){
         array_push($condition,['smart_trfc_config.campaign_id','=',$id_ad]);
      }
    if($advertiser != 'null' && $advertiser != ''){
         array_push($condition,['advertiser_campaigns.id_advertiser','=',$advertiser]);
      }
    if($stat_perma != 'null' && $stat_perma != ''){
         array_push($condition,['advertiser_campaigns.permanent_status','=',$stat_perma]);
      }
      
       // array_push($condition,['ads.is_smart_cca','=','1']);
       $select = [ 
                    'smart_trfc_config.id',
                    'smart_trfc_config.cca',
                    'smart_trfc_config.campaign_id',
                    'smart_trfc_config.hold_percentage',
                    'smart_trfc_config.status',
                    'smart_trfc_config.is_primary_campaign',
                    'ads.id_ad',
                    'ads.id_zone',
                    'ads.network_name',
                    'ads.operator_name',
                    'ads.cco',
                    'advertiser_campaigns.permanent_status as permanent_status',
                    'advertiser_campaigns.name as campaign_name',
                    'advertiser_campaigns.id_advertiser as id_advertiser',
                    'advertiser.name as advertiser',
                    // 'country.name as country_name'
                    'ads.country_code', 'advertiser_campaigns.status as campaign_status'
            ];
    // print_r($condition);        
    $smrttrfc_result = SmartTrafficConfig::where($condition)
                            ->select($select)
                            ->leftJoin("ads","ads.id_ad","=","smart_trfc_config.cca")
                            ->leftJoin("advertiser_campaigns","advertiser_campaigns.id","=","smart_trfc_config.campaign_id")
                            ->leftJoin("advertiser","advertiser.id","=","advertiser_campaigns.id_advertiser")
                            ->orderBy('smart_trfc_config.cca','desc')
                            ->orderBy('smart_trfc_config.is_primary_campaign','desc')
                            ->get();                   
        if(count($smrttrfc_result) > 0){
          foreach($smrttrfc_result as $fetch_url){
                $array = [];
                $add_more = [];
                $is_check = $fetch_url->status == 1 ? "checked": "";
                $active =  $fetch_url->status == 1 ? "Active": "Inactive";

                    $campaign_status= ($fetch_url->campaign_status==0 ? 'Paused': ($fetch_url->campaign_status==5 ? 'Cap Reached':'Active'));


                $is_active = '<span class=""><input type="checkbox" id='.$fetch_url->id.'  name="is_smarttrfc_active[]" '.$is_check.'></span><label for="checkbox8" id="status-'.$fetch_url->id.'">'.$active.'</label>';
                if($fetch_url->is_primary_campaign == 1){
                $add_more = "<a href='javascript:void()' class='add-more' data-id='".$fetch_url->cca."' data-cco='".$fetch_url->cco."'>Add More<a>";
                }else{
                  $add_more='';
                }
                array_push($array,
                          $fetch_url->network_name.'('.$fetch_url->id_zone.')',
                          $fetch_url->operator_name .' ('.$fetch_url->country_code.')',
                          $fetch_url->cca."<span id='id_ad-".$fetch_url->id_ad."' class='change-campaign' data-value=".$fetch_url->cca." data-smart_id=".$fetch_url->campaign_id.">&nbsp;<i class='fa fa-edit'></i></span>",
                          "<span id='".$fetch_url->id_advertiser."'>".$fetch_url->advertiser."(".$fetch_url->id_advertiser.")"."</span>",
                          "<span id='cca_".$fetch_url->id."'>".$fetch_url->campaign_name."(".$fetch_url->campaign_id.")"."</span>",
                          // "<span id='percentage-container_".$fetch_url->id."' style='font-size:24px'>".$fetch_url->hold_percentage."</span><span id='percentage-".$fetch_url->id."' class='edit-percentage' data-id='".$fetch_url->cca."' data-cco='".$fetch_url->id_op."'>&nbsp;<i class='fa fa-edit'></i></span>",
                          "<span class='outer-container' id='outer-percent-container_".$fetch_url->id."'><span class='percentage-container' id='percentage-container_".$fetch_url->id."' style='font-size:24px'>".$fetch_url->hold_percentage."</span><span id='percentage-".$fetch_url->id."' class='percentage-edit' data-cca=".$fetch_url->cca." data-value=".$fetch_url->hold_percentage.">&nbsp;<i class='fa fa-edit'></i></span></span>",
                           $fetch_url->is_primary_campaign == '1' ? "Primary Campaign": "Diverted",
                           $is_active,
                           $add_more,
                          "<span id='".$fetch_url->permanent_status."'>".$fetch_url->permanent_status."</span>",
                          "<span id='".$fetch_url->campaign_status."'>".$campaign_status."</span>"
                          );
                array_push($data, $array);
          }
      if($data){
          $Rstatus = array('status'=>'1','data'=>$data);
        }
      }else{
          $Rstatus = array('status'=>'2','data'=>$data);
      }
      echo json_encode($Rstatus);
      exit;
  }


    function getCcaByCcz(Request $request){
        $operator_id = $request->operator_id;
        $condition = $alreadyExisting = $ccas = [];
        $ccz = $request->ccz;
        $smmodal = ads::selectRaw("concat(id_ad,'(',title,')') as cca , id_ad , title,id_advertiser,cco")->where('id_zone','=',$ccz)->where('cco','=',$operator_id)->orderby('cca','asc')->get();
        $allCcas = array();
        $select = ['cca'];
            $all_ccas = ads::selectRaw("group_concat(id_ad) as all_ccas")->where('id_zone','=',$ccz)->where('cco','=',$operator_id)->get()->toArray();
            if($all_ccas[0]['all_ccas']){
              $all_cca = $all_ccas[0]['all_ccas'];
              $att = explode(",",$all_cca);
              $alreadyExisting = SmartTrafficConfig::whereIn('cca',$att)->select($select)->get();
            }
            if(count($alreadyExisting)){
              foreach($alreadyExisting  as $cca){
                array_push($ccas,$cca->cca);
              }
            }
        $advertiser_campaigns = [];    
        foreach($smmodal as $key=>$fetch_dt){
            if(!in_array($fetch_dt->cca, $ccas)){
              $allCcas[$key]['cca'] = mb_convert_encoding($fetch_dt->cca, 'UTF-8', 'UTF-8');
              $allCcas[$key]['id_ad'] = $fetch_dt->id_ad;
              $allCcas[$key]['campaign_id'] = $fetch_dt->id_advertiser;
              $allCcas[$key]['title'] = mb_convert_encoding($fetch_dt->title, 'UTF-8', 'UTF-8');
              $allCcas[$key]['cco'] = $fetch_dt->cco;
            }
        }
        $status = array('status'=>1,'data'=>$allCcas);
        return $status;
    }

    function getCampaign(Request $request){
        $id_ad = $request->id_ad;
        $smmodal = ads::selectRaw("concat(id_ad,'(',title,')') as cca , id_ad , title")->where('id_ad','=',$id_ad)->limit(1)->get();
        $aprentcca_campagin_name=array();
        foreach($smmodal as $fetch_dt){ 
            $aprentcca_campagin_name[$fetch_dt->id_ad] = $fetch_dt->cca;
        }
        return $aprentcca_campagin_name;
    }


    function campaign_name_parent(Request $request){
        $ccz = $request->ccz;
        $operator_id = $request->operator_id;
        $smmodal = ads::selectRaw("concat(id_ad,'(',title,')') as cca , id_ad , title")->where('id_zone','=',$ccz)->where('cco','=',$operator_id)->orderby('cca','desc')->get();
        $aprentcca_campagin_name=array();
        foreach($smmodal as $fetch_dt){ 
            $aprentcca_campagin_name[$fetch_dt->id_ad] = $fetch_dt->cca;
        }
        return $aprentcca_campagin_name;
    }


    function create(Request $request){
        $status = array('status'=>2,'message'=>'There is something went wrong');
        $allRequest = $request->input();
        $cca = $campaign = '';
        $hold_percentage = $request->hold_percentage; 
        $campaign_id = $request->campaign_id;
        $data = []; 
        if($request->ccz && $request->cca){
            $cca_campaign = explode("_",$request->cca);
            if(count($cca_campaign) > 1){
               $cca = $cca_campaign[0];
               $campaign = $cca_campaign[1]; 
            }
           if($campaign){  
           try{
             $smartTrafficConfig = SmartTrafficConfig::create([
                'cca' => $cca,
                'campaign_id' => $campaign,
                'start_date' => date('Y-m-d h:i:s'),
                'end_date' => date('Y-m-d h:i:s',strtotime('+1 years')),
                'hold_percentage' => $request->hold_percentage_first,
                'is_primary_campaign' => '1',
                'status'=> $request->status,
              ]);
              if(count($hold_percentage)){
                 for($i=0;$i<count($hold_percentage);$i++){
                        array_push($data,
                              array(
                                  'cca' => $cca,
                                  'campaign_id' => $campaign_id[$i],
                                  'start_date' => date('Y-m-d h:i:s'),
                                  'end_date' => date('Y-m-d h:i:s',strtotime('+1 years')),
                                  'hold_percentage' => $hold_percentage[$i],
                                  'status' => 1
                                 )
                        );
                  }
              }
              if(count($data) > 0){
                  SmartTrafficConfig::insert($data);
              }
              $status = array('status'=>1,'message'=>'a record is added');
           }catch(\Illuminate\Database\QueryException $ex){ 
              $status = array('status'=>2,'message'=>$ex->errorInfo); 
           }
        }else{
            $status = array('status'=>2,'message'=>'There is no campaign');
          }  
            $Rstatus = Response::json($status);
            return $Rstatus;
        } 
    }


           /* Update URL in 
        function UpdateCampaign(Request $request){
		      $data = $request->session()->all();
            $user_name = $data['roles']['name']; 
            $smart_trfc_id= $request->trfc_id;
            $id_ad = $request->id_ad;
            $id_advertiser = $request->id_advertiser;
            $url = $request->url;
            $advertiser_name = '';
            $value = 1;//Cookie::get('LARAVELMAC');
            if(!empty($value))
            {
                if($id_ad && $id_advertiser)
                {

                  $select = [
                    'id', 
                    'is_primary_campaign'
                  ];
                  $condition = [];
                  array_push($condition,['id','=',$smart_trfc_id]);
                  $smartdata = SmartTrafficConfig::where($condition)->select($select)->limit(1)->get();
		
                  if($smartdata &&  $smartdata[0]->is_primary_campaign){   
                      $adsQuery = DB::statement("UPDATE 
                                 ads,advertiser_campaigns as advertiser 
                                 SET ads.title = advertiser.name,
                                 ads.id_advertiser = advertiser.id,
                                 ads.click_url ='".$url."'
                                 where ads.id_ad=".$id_ad." and advertiser.id=".$id_advertiser);
                  }
                  try { 
                  $SmartUpdate = DB::statement("UPDATE 
                             smart_trfc_config as smarttraffic
                             SET smarttraffic.campaign_id =".$id_advertiser."
                             where smarttraffic.id=".$smart_trfc_id);
                  

                  $advertiser_campaigns = DB::select("select `name`,id from advertiser_campaigns where id ='".$id_advertiser."'");
                  if($advertiser_campaigns){
                     $advertiser_name = $advertiser_campaigns[0]->name." (".$advertiser_campaigns[0]->id.")";
                  }
                  if(isset($SmartUpdate) && !empty($SmartUpdate))
                    {
                        $url_tracking = new UrlTracking();
                        $url_tracking->user_name = $user_name;
                        $url_tracking->id_ad = $id_ad;
                        $url_tracking->id_advertiser = $id_advertiser;
                        $url_tracking->click_url = $url;
                        $url_tracking->mac_address = $value;
                        $url_tracking->save();
                        if($url_tracking)
                        {
                            $data = array('status'=>1,'message'=>'Successful','data'=>$advertiser_name,'parent_cca'=>$advertiser_campaigns[0]->id);
                            
                        }else{
                            $data = array('status'=>2,'message'=>'No Successful','data'=>'');
                        }    
                    }
                    else
                    {
                       $data = array('status'=>0,'message'=>'No Successful','data'=>'');  
                    }
                    } catch(\Illuminate\Database\QueryException $ex){ 
                       $data = array('status'=>0,'message'=>"Campaign ID $id_advertiser entry is already exist for this parent_cca $id_ad",'data'=>'');  
                    }
                }
               
            }else{
                $data = array('status'=>3,'message'=>'There is something wend wrong','data'=>'');
            }
            
            $data = Response::json($data);
            return $data;
        }

	*/

			  /* Update URL in */
        function UpdateCampaign(Request $request){
            
		      $data = $request->session()->all();
            $user_name = $data['roles']['name']; 
            $smart_trfc_id= $request->trfc_id;
            $id_ad = $request->id_ad;
            $id_advertiser = $request->id_advertiser;
            $url = $request->url;
            $advertiser_name = '';
            $value = 1;//Cookie::get('LARAVELMAC');
            if(!empty($value))
            {
                if($id_ad && $id_advertiser)
                {
                   $condition = [];
                   
                   $select = ['id', 'is_primary_campaign','campaign_id','cca'];
                   array_push($condition,['cca','=',$id_ad]);
                   array_push($condition,['campaign_id','=',$id_advertiser]);
                   $smartdata = SmartTrafficConfig::where($condition)->select($select)->limit(1)->get();
              if(isset($smartdata[0]['id']) && isset($smartdata[0]['campaign_id']) && isset($smartdata[0]['cca']) && $smartdata[0]['campaign_id']==$id_advertiser)
              {
                 $data = array('status'=>0,'message'=>"Campaign ID $id_advertiser entry is already exist for this parent_cca $id_ad",'data'=>'');  
              }
             else{

                  $select = ['id', 'is_primary_campaign'];
                  $condition = [];
                  array_push($condition,['id','=',$smart_trfc_id]);
                  $smartdata = SmartTrafficConfig::where($condition)->select($select)->limit(1)->get();
		
                  if($smartdata &&  $smartdata[0]->is_primary_campaign){   
                      $adsQuery = DB::statement("UPDATE 
                                 ads,advertiser_campaigns as advertiser 
                                 SET ads.title = advertiser.name,
                                 ads.id_advertiser = advertiser.id,
                                 ads.click_url ='".$url."'
                                 where ads.id_ad=".$id_ad." and advertiser.id=".$id_advertiser);
                  }
                  try { 
                  $SmartUpdate = DB::statement("UPDATE  smart_trfc_config as smarttraffic   SET smarttraffic.campaign_id =".$id_advertiser."
                             where smarttraffic.id=".$smart_trfc_id);
                  

                  $advertiser_campaigns = DB::select("select `name`,id from advertiser_campaigns where id ='".$id_advertiser."'");
                  if($advertiser_campaigns){
                     $advertiser_name = $advertiser_campaigns[0]->name." (".$advertiser_campaigns[0]->id.")";
                  }
                  if(isset($SmartUpdate) && !empty($SmartUpdate))
                    {
                        $url_tracking = new UrlTracking();
                        $url_tracking->user_name = $user_name;
                        $url_tracking->id_ad = $id_ad;
                        $url_tracking->id_advertiser = $id_advertiser;
                        $url_tracking->click_url = $url;
                        $url_tracking->mac_address = $value;
                        $url_tracking->save();
                        if($url_tracking)
                        {
                            $data = array('status'=>1,'message'=>'Successful','data'=>$advertiser_name,'parent_cca'=>$advertiser_campaigns[0]->id);
                            
                        }else{
                            $data = array('status'=>2,'message'=>'No Successful','data'=>'');
                        }    
                    }
                    else
                    {
                       $data = array('status'=>0,'message'=>'No Successful','data'=>'');  
                    }
                    } catch(\Illuminate\Database\QueryException $ex){ 
                      $data = array('status'=>0,'message'=>'No Successful Some Exception','data'=>'');  
                    }
                  }
                }
               
            }else{
                $data = array('status'=>3,'message'=>'There is something wend wrong','data'=>'');
            }
            
            $data = Response::json($data);
            return $data;
        }


      function createSmartCampaign(Request $request){
        // print"<pre>";print_r($request->input());die;
        $status = array('status'=>2,'message'=>'There is something went wrong');
        $cca = $request->cca; 
        $ids = $request->id; 
        $campaign = '';
        $data = [];
        $hold_percentage = $request->hold_percentage; 
        $campaign_id = $request->campaign_id;
        $status = $request->status;
        $campaign_id_exist = $request->campaign_id_exist;
        $hold_percentage_exist = $request->hold_percentage_exist;
        $status_exist = $request->status_exist;
        if($request->cca){
           try{
               for($i=0;$i<count($hold_percentage_exist);$i++){
                    $SmartTrafficConfig = SmartTrafficConfig::find($ids[$i]);
                    $SmartTrafficConfig->cca = $request->cca;
                    $SmartTrafficConfig->hold_percentage = $hold_percentage_exist[$i];
                    $SmartTrafficConfig->campaign_id = $campaign_id_exist[$i];
                    $SmartTrafficConfig->status = $status_exist[$i];
                    $SmartTrafficConfig->save();
                }
              if(count($hold_percentage)){
                 for($i=0;$i<count($hold_percentage);$i++){
                        array_push($data,
                              array(
                                  'cca' => $cca,
                                  'campaign_id' => $campaign_id[$i],
                                  'start_date' => date('Y-m-d h:i:s'),
                                  'end_date' => date('Y-m-d h:i:s',strtotime('+1 years')),
                                  'hold_percentage' => $hold_percentage[$i],
                                  'status' => $status[$i]
                                  // 'statusssss' => 1
                                 )
                        );
                  }
              }
              SmartTrafficConfig::insert($data);
              $status = array('status'=>1 , 'message'=>'a record is added');
           }catch(\Illuminate\Database\QueryException $ex){ 
              $status = array('status'=>2,'message'=>$ex->errorInfo); 
           }
        }else{
            $status = array('status'=>2,'message'=>'There is no campaign');
        }  
        $Rstatus = Response::json($status);
        return $Rstatus;
         
    }

  

  }

