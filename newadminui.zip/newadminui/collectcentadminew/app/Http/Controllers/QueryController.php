<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\QueryAccess;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Auth;

class QueryController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('query',['results'=>[],'prefix'=>'','query'=>'','errors'=>'']);
    }


    public function execute(Request $req)
    {
     $query = trim($req->querycheck);
     $query = str_ireplace('  ', ' ', $query);
     $queryexecuted = false;
    $query_error = false;
    $error = false;

      if (stripos($query, 'delete from') !== false) {
        $error = true;
        $error_message = "Delete query is not allowed.";

    }elseif (stripos($query, 'from users') !== false) {
        $error = true;
        $error_message = "Table not exists";
    }
  elseif(stripos($query, 'update ads') !== false) {
        $error = true;
        $error_message = "Update not allow at ads !";
    }
    elseif(stripos($query, 'insert into ads') !== false) {
        $error = true;
        $error_message = "Insert not allow at ads !";
    }
    elseif(stripos($query, 'delete from ads') !== false) {
        $error = true;
        $error_message = "delete not allow at ads !";
    }
    elseif (stripos($query, 'from advertiser_campaigns') === false && stripos($query, 'from ads') === false && stripos($query, 'from delivery') === false && stripos($query, 'from conversions') === false && stripos($query, 'from config_delivery') === false && stripos($query, 'insert into config_delivery') === false && stripos($query, 'update config_delivery') === false && stripos($query, 'from cron_config') === false && stripos($query, 'insert into cron_config') === false && stripos($query, 'update cron_config') === false  && stripos($query, 'from trfc_config') === false && stripos($query, 'insert into trfc_config') === false && stripos($query, 'update trfc_config') === false && stripos($query, 'from smart_trfc_config') === false) {
        $error = true;
        $error_message = "Table not exists";
    }
    elseif (stripos($query, 'insert into ads') !== false && stripos($query, 'insert into advertiser_campaigns') !== false && stripos($query, 'insert into delivery') !== false && stripos($query, 'insert into conversions') !== false ) {
        $error = true;
        $error_message = "Insert Query Not allowed";
    }
    elseif (stripos($query, 'delete from ads') !== false && stripos($query, 'delete from advertiser_campaigns') !== false && stripos($query, 'delete from delivery') !== false && stripos($query, 'delete from conversions') !== false && stripos($query, 'delete from config_delivery') !== false) {
        $error = true;
        $error_message = "Delete Query Not allowed";
    }
    elseif (stripos($query, 'update ads') !== false && stripos($query, 'update advertiser_campaigns') !== false && stripos($query, 'update delivery') !== false && stripos($query, 'update conversions') !== false ) {
        $error = true;
        $error_message = "Update Query Not allowed";
    }
  
    elseif(stripos($query, 'drop ') !== false) {
        $error = true;
        $error_message = "Drop Command Not Allowed";
    }
    elseif(stripos($query, ' database') !== false) {
        $error = true;
        $error_message = "Database Not Allowed";
    }
 elseif(stripos($query,'limit') !== false) {
        $error = false;
        }
    elseif(stripos($query,'insert') !== false) {
        $error = false;
        $error_message = "Insert Query Not allowed";
        }    
    elseif(stripos($query,'show table') !== false) {
        $error = false;
        $error_message = "This command Not allowed";
        }    
  
    else{
      $error = true;
      $error_message = 'Query Not contains Limit.Please use limit in Query' ;
    }
    	try{
          if ($error == false && $query != '') {
            $queryprefixArr  = explode(" ",$query);
            $queryprefix = $queryprefixArr[0];
            if($queryprefix =="select")
            {
    		    $data =  DB::select(DB::raw($query));
          }elseif($queryprefix =="update") {
             $data =  DB::update(DB::raw($query));
          } elseif($queryprefix =="insert") {
           $data =  DB::insert(DB::raw($query));
          }
          $queryexecuted = true;
          if ($data === false) {
            $query_error = true;
            $query_message = $dbObj->lastError;
           } else {
            $queryprefixArr  = explode(" ",$query);
            $queryprefix = $queryprefixArr[0];
          }
           	return view('query',['results'=>$data, 'prefix'=>$queryprefix, 'errors'=>"", 'query'=>$query]);
    	    	}
        return view('query',['results'=>[], 'prefix'=>'','errors'=>$error_message, 'query'=>$query]);
    	}
    	catch(\Illuminate\Database\QueryException $ex){ 
  					dd($ex->getMessage()); 
  				return view('query',['results'=>[],'errors'=>'query in not correct']);
 					 
		}


        
    }
    public function getAccess(Request $request)
    {
           $keyword = $request->get('search');
           $perPage = 10;

           if (!empty($keyword)) {
               $QueryAccess = QueryAccess::where('name', 'LIKE', "%$keyword%")
                ->with('User')->orderBy('id','DESC')->paginate($perPage);
           } else {

              $QueryAccess = QueryAccess::with('User')->orderBy('id','DESC')->paginate($perPage);
         
           }
      
           return view('queryaccess', compact('QueryAccess'));
    }
}
