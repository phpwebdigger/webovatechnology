<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Ad;
use App\ads;
use App\operator;
use Illuminate\Support\Facades\Input;
use Response;
use App\AdvertiserCampaigns;

class BrowserController extends Controller
{
   
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
  

    public function index(Request $request,$urlFilter = "BrowserHistoryFilter")
    {
       
        
    $opNameArr =   array();
    $camNameArr =   array();
    $statNameArr =   array();
    $opQuerySelect = AdvertiserCampaigns::select(["id","id_op","status","live","name"])->get();
    
    foreach($opQuerySelect as $opArr){
          $statNameArr[$opArr->id]=$opArr->live;
          $opNameArr[$opArr->id]=$opArr->id_op;
          $camNameArr[$opArr->id]=$opArr->name;
    }
    
    
   
    $id_adNameArr =   array();
    $id_QuerySelect = DB::table("ads")->select(["id_ad","title"])->get();
    
    
    foreach($id_QuerySelect as $id_Arr){
        
        $id_adNameArr[$id_Arr->id_ad]=$id_Arr->id_ad;
    }
    
    

        $opQr=  array();
       
        $dataOp = DB::table("operator")->select(["id","name"])->get();  
        
        foreach($dataOp as $Arr){
        
              $opQr[$Arr->id]=$Arr->name;
        
        }


      
       $queryResultOpArray =  DB::table("operator")
        ->leftJoin("country","operator.country_code","=","country.iso")
        ->select(["operator.id as id","operator.name as name","country.iso as cc"]) 
        ->where("operator.status","=","1")
        ->orderBy("operator.name","ASC")
        ->get();
    


    $opid = "";
    $whereInCond = false;
    if($request->opname != '')
    {
                          //echo $_POST['opname'];
      $opid = $request->opname; 
       $camQueryResult = AdvertiserCampaigns::select(["id"])->where("is_live","=",'1')
       ->where("id_op","=",$request->opname)->get();
     
      $cmpin = [];
      foreach($camQueryResult as $cmpdt)
      {
        array_push($cmpin, $cmpdt->id);
      }
      $whereInCond = true;
    }
       
        if($whereInCond){
            $data = DB::table("exclude_logic")->whereIn('campaign_id',$cmpin)
            ->select(["*"])
            ->get();
        }else{
          $data = DB::table("exclude_logic")
            ->select(["*"])
            ->get();
        }
        
          $data1 = [];
        foreach ($data as $fetch_records) {
                $array = [];
                if($id_adNameArr[$fetch_records['value']]){
                  $value = $id_adNameArr[$fetch_records->value];
                }else{
                  $value =  $fetch_records->value;
                }
                 if($fetch_records['phone_type'] == "") {
                    $phone_type = "";
                }elseif($fetch_records['phone_type'] == "false"){
                    $phone_type =  'Feature Phone' ;
                } 
                 else if($fetch_records['phone_type'] == "true") {
                      $phone_type =  'Smart Phone';
                 }
                 if($camNameArr[$fetch_records->route_value]){
                    $route_value =  $camNameArr[$fetch_records->route_value];
                }  else {
                    $route_value =  $fetch_records->route_value;
                }

                array_push($array,
                    $fetch_records->id,  
                $fetch_records->type,
               $value,
                $opQr[$fetch_records->operator_name],
                $fetch_records->browser,
                $fetch_records->operating_system,
                $phone_type,
                $route_value,
                 ($fetch_records->status == 1) ? 'Active' : 'De-Active',
               '<a href="exclude_browser1.php?uid='.$fetch_records->id.'&idopr='.$operator.'">Edit</a>',
                '<a id="'.$fetch_records->id.'" onclick="return checkDelete()" href="bdelete.php?delid='.$fetch_records->id.'">Delete</a>' 
          

                   );
                array_push($data1, $array);
          }



          return view('browser.main',compact(['data1','queryResultOpArray','urlFilter',"opid"]));


    }
    
        
          
}
