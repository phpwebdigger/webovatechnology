<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\SmartRotatorCampaignsOpeators;
use Response;
use Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Redis;
use App\AdNetwork;
class PublisherInterfaceredis2Controller extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */


 public function publisherOfferList(Request $request){
   
    if($request->start_date!="" || $request->end_date!="" || $request->network_name!="" || $request->campaign_name!="" || $request->diversion!="" || $request->only_status!="" || $request->country_code !="" || $request->campaign_id !="" || $request->publisherid!=""){
      $data=  $this->publisherOfferList_filetr($request);
    }else{

     $template_name = "offerlist.pubwiseofferredispages2";
        $cat = ['OM','OG'];
    
       $redis = Redis::connection();     

                $cache = $request->input('cache');
        $date  = date('Y-m-d');
        $min = date("i");
         
        if($min >= '00' && $min <= '04')
        {
            $key="publisherofferredis_wise_data_12";
        }
        else if($min >= '05' && $min <= '09')
        {
            $key   = "publisherofferredis_wise_data_1";
        }
        else if($min >= '10' && $min <= '14')
        {
            $key   = "publisherofferredis_wise_data_2";
        }
        else if($min >= '15' && $min <= '19')
        {
            $key   = "publisherofferredis_wise_data_3";
        }
        else if($min >= '20' && $min <= '24')
        {
            $key   = "publisherofferredis_wise_data_4";
        }
        else if($min >= '25' && $min <= '29')
        {
            $key   = "publisherofferredis_wise_data_5";
        }
        else if($min >= '30' && $min <= '34')
        {
            $key   = "publisherofferredis_wise_data_6";
        }
        else if($min >= '35' && $min <= '39')
        {
            $key   = "publisherofferredis_wise_data_7";
        }
        else if($min >= '40' && $min <= '44')
        {
            $key   = "publisherofferredis_wise_data_8";
        }
        else if($min >= '45' && $min <= '49')
        {
            $key   = "publisherofferredis_wise_data_9";
        }
        else if($min >= '50' && $min <= '54')
        {
            $key   = "publisherofferredis_wise_data_10";
        }
        else if($min >= '55' && $min <= '59')
        {
            $key   = "publisherofferredis_wise_data_11";
        }
          //  echo $key;
          // $allKeys = $redis->keys('*');
          $items = $redis->get($key);
          $datas =  unserialize($items);
//          echo "<pre>";
//		  print_r($datas);
//		  die;
         $data=  $this->index_publisher_display($datas); 
        } 
        return $data;
 }


        public function index_publisher_display($datas){

             $dtvalue = "";//date('Y-m-d');
             
             $enddate = "";//date('Y-m-d',strtotime("+1 days"));
		$country_code = $request->country_code;
        $campaign_id = $request->campaign_id;
        $publisherid = $request->publisherid;

             $condtion = $data1= [];
            foreach ($datas as $result) 
                    {

//                        echo "<pre>";
//						print_r($result);
//						die;

                        $active = $filter_st = $postback = '';
                        if($result['active'] == '1')
                        {
                            $active = 'Active';
                        }
                        else
                        {
                            $active = 'Pause';
                        }
                        
                        if($result['filter_status'] == '1')
                        {
                            $filter_st = 'Active';
                        }
                        else
                        {
                            $filter_st = 'Inactive';
                        }
                        
                        if($result['postback_status'] == '1')
                        {
                            $postback = 'Active';
                        }
                        else
                        {
                            $postback = 'Inactive';
                        }  
                           
                           if($result['status'] == '5')
                        {
                            $backcolor = 'style="background-color:#FE6BD7;color:000"';
                        }
                        else
                        {
                            $backcolor = 'style="background-color:#25F3EC;color:000"';
                        }  

                        
    
                        $array = $data = $rtotal = [];
                        $offer_url = "'".$result['offer_url']."'";
                        
                         $array[] =  $result['cca'];

                        $array[] =  '<a href="javascript:void(0);" onclick="changeActStatus('.$result['cca'].','.$result['zone'].','.$result['srco_id'].','.$result['active'].');"><i class="fa fa-pencil"></i><span id="active_status_'.$result['srco_id'].'">'.$active.'</span></a><span id="'.$result['srco_id'].'" class="new_status_change" ><input type="checkbox" name="new_active_status_'.$result->srco_id.'" id="new_active_status" onclick="getSelectedValue(this, value);" /><label style="display:none;">'.$result['srco_id'].'</label></span>';

                        $array[] =  $result['network_name']." {".$result['zone']."}"; 

                        $array[] =  '<a  href="javascript:void(0);" onclick="changeCpa('.$result['cca'].','.$result['zone'].','.$result['srco_id'].','.$result['cpa'].');"><i class="fa fa-pencil"></i><span id="cpa_'.$result['srco_id'].'">'.$result['cpa'].'</span></a>';
                        //Pub Install Cap
        $array[] =  '<a '.$backcolor.' href="javascript:void(0);" onclick="changeCap('.$result['cca'].','.$result['zone'].','.$result['srco_id'].','.$result['cap_count_conversions'].');"><i class="fa fa-pencil"></i><span id="cap_conversion_'.$result['srco_id'].'">'.$result['cap_count_conversions'].'</span></a>';

                        //cap_count_click

        $array[] =  '<a '.$backcolor.' href="javascript:void(0);" onclick="changeCapClick('.$result['cca'].','.$result['zone'].','.$result['srco_id'].','.$result['cap_count_click'].');"><i class="fa fa-pencil"></i><span id="cap_countclick_'.$result['srco_id'].'">'.$result['cap_count_click'].'</span></a>';

                        //cap_count_install     
    $array[] =  '<a '.$backcolor.' href="javascript:void(0);" onclick="changeCapinstall('.$result['cca'].','.$result['zone'].','.$result['srco_id'].','.$result['cap_count_install'].');"><i class="fa fa-pencil"></i><span id="cap_countinstall_'.$result['srco_id'].'">'.$result['cap_count_install'].'</span></a>';
	//sale count 
	$array[] =  '<a '.$backcolor.' href="javascript:void(0);" onclick="changeCapSale('.$result['cca'].','.$result['zone'].','.$result['srco_id'].','.$result['cap_count_sale'].');"><i class="fa fa-pencil"></i><span id="cap_countsale_'.$result['srco_id'].'">'.$result['cap_count_sale'].'</span></a>';

                        $array[] =  $result['traffic_type'];
			if(!isset($result['name'])) {
			$array[]="";
			}else{                                
                        $array[] = '<span title="'.htmlspecialchars(htmlentities($result['name']),ENT_QUOTES,'UTF-8',TRUE).'">'.htmlspecialchars(htmlentities($result['name']),ENT_QUOTES,'UTF-8',TRUE).'('.$result['id'].')</span>';}
			if(!isset($result['name'])){
			$array[]="";
			}else{			
                        $array[] ='<span>'.htmlspecialchars(htmlentities($result['offername']),ENT_QUOTES,'UTF-8',TRUE).'('.$result['id'].')</span>';
}
                        //code emplemet edit functionaly

                        // $array[] =  $result->trfc;
                          $array[] =  '<a href="javascript:void(0);" onclick="changeTrfc('.$result['cca'].',
                          '.$result['zone'].','.$result['id'].');"><i class="fa fa-pencil"></i><span id="trfc_'.$result['srco_id'].'">'.$result['trfc'].'</span></a>
    <span href="javascript:void(0);" id="trigger" onmouseover="display_pop('.$result['cca'].','.$result['zone'].','.$result['id'].');"> Details </span> ';                      

                        //code emplement end here
                        
                        $array[] =   $result['country_code'];
                        $array[] =  $result['os_type'];
                        $array[] =   '<a href="javascript:void(0);"  onclick="changeFilter('.$result['cca'].'
                        ,'.$result['zone'].','.$result['srco_id'].','.$result['filter'].');"><i class="fa fa-pencil"></i><span id="filter_'.$result['srco_id'].'">'.$result['filter'].'</span></a>';
                        $array[] =   '<a href="javascript:void(0);" onclick="changeFilterSt('.$result['cca'].',
                        '.$result['zone'].','.$result['srco_id'].','.$result['filter_status'].');"><i class="fa fa-pencil"></i><span id="filter_st_'.$result['srco_id'].'">'.$filter_st.'</span></a>';
                        $array[] =   '<a href="javascript:void(0);" onclick="changePostbackSt('.$result['cca'].',
                        '.$result['zone'].','.$result['srco_id'].','.$result['postback_status'].');"><i class="fa fa-pencil"></i><span id="postback_st_'.$result['srco_id'].'">'.htmlspecialchars(htmlentities($postback),ENT_QUOTES,'UTF-8',TRUE).'</span></a>';
                        $array[] =   '<a title="Copy Url" href="javascript:void(0);" onclick="CopyUrl('.$result['srco_id'].');"><i class="fa fa-clipboard" aria-hidden="true"></i><span id="copy_'.$result['srco_id'].'" style="display:none;">'.$result['offer_url'].'</span></a>';
$array[] =   '<a title="Copy Preview" href="javascript:void(0);" onclick="CopyPreview('.$result['srco_id'].');"><i class="fa fa-clipboard" aria-hidden="true"></i><span id="copy_preview_'.$result['srco_id'].'" style="display:none;">'.htmlspecialchars(htmlentities($result['offer_url']),ENT_QUOTES,'UTF-8',TRUE).'</span></a>';
			//if(isset($result['publisher_kpi'])){
			 //}
                        $KPI_DATA =""; //htmlspecialchars(addslashes($result['publisher_kpi']),ENT_QUOTES,'UTF-8',TRUE);
                        $array[] =   '<a title="View Details" href="javascript:void(0);"
                        onclick="viewDetails('.$result['cca'].','.$result['zone'].','.$result['id'].');"><i class="fa fa-eye" aria-hidden="true"></i></a> | <a title="Edit KPI" href="javascript:void(0);" onclick="editKPI('.$result['cca'].','.$result['zone'].','.$result['srco_id'].',\''.$KPI_DATA.'\')"><i class="fa fa-pencil" aria-hidden="true"></i></a>';
                        $array[] =  '<span title="'.$result['approve_date'].'">'.date('d-m-Y',strtotime($result['approve_date'])).'</span>';
			$array[] =  '<span>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <select name="change_domain_name_'.$result['srco_id'].'" id="change_domain_name_'.$result['srco_id'].'" class="form-control" required style="width:100%">
                                                    <option value="Select">Select</option>
                                                    <option value="topapp.link">topapp.link</option>
                                                    <option value="fineapp.live">fineapp.live</option>
                                                    <option value="ofapp.live">ofapp.live</option>
                                                    <option value="forapp.live">forapp.live</option>
                                                    <option value="easyapp.live">easyapp.live</option>
                                                </select>    
                                            </div>
                                        </div>
                                        <input type="button" name="submit_domain_'.$result->srco_id.'" id="new_active_status" onclick="getSelectedId(this, value);" value="submit" /><label style="display:none;">'.$result['srco_id'].'</label></span>
                                </span>';
                        ?>
                            
                    <?php
                        array_push($data1, $array);
                    }

                  
        $networksResult = DB::select("select distinct(adn.ccz), adn.id, adn.name from ad_network as adn INNER JOIN smart_rotator_campaigns_operators as smt ON adn.ccz = smt.id_zone WHERE smt.smart_status = '1' AND smt.ads_cat in ('OM','OG') and adn.ccz!=0 order by adn.name ASC");
        
        $CampaignsResult = DB::select("select distinct(ac.id), ac.name from advertiser_campaigns as ac INNER JOIN smart_rotator_campaigns_operators as crd ON ac.id = crd.campaign_id WHERE crd.smart_status = '1' AND crd.ads_cat in ('OM','OG') ORDER BY ac.name ASC");
		 $countries = \App\Country::all();                    
                      $result  = array('data1' => $data1,
                          'network'=>$networksResult,
                          'campaigns_list'=>$CampaignsResult,
                          'div'=>$diversion,
                          'filter_st'=>$only_status,
                          'dtvalue'=>$dtvalue,
                          'dtvalue2'=>$enddate,
			 'countries'=>$countries,
                          'countries_name'=>$country_code,
                          'publisherid'=>$publisherid,
                          'campaign_id'=>$campaign_id
                          );

                    $dataN =  view('offerlist.pubwiseofferredispages2')->with($result);
                    return $dataN;

        }

    public function update_domain_url(Request $request)
    {
//        echo "<pre>";
//        print_r($request->all());
//        echo "</pre>";        
        $id = $request->rotator_id;
        
        $data =  $offers = \App\SmartRotatorCampaignsOpeators::where('id', '=', $id)
                         ->take(1)->get();
        
//        echo "<pre>";
//        print_r($data);
//        echo "</pre>";   
        
        $ads_cat = $data[0]['ads_cat'];
        $offer_url = $data[0]['offer_url'];
        
        if($ads_cat == 'OM')
        {
            $cat = 'SM';
        }
        else
        {
            $cat = 'SG';
        }
        
        
//        echo "Ads Category = ".$ads_cat."<br>";
//        echo "URL = ".$offer_url."<br>";
        
        $exp_url = explode("?",$offer_url);
        
//        echo "<pre>";
//        print_r($exp_url);
//        echo "</pre>"; 
        
        
        $domain = $request->domain;
        
        if($domain === 'topapp.link')
        {
            $new_url = 'https://topapp.link/dlv/'.$cat.'?'.$exp_url[1];
        }
        else if($domain === 'fineapp.live')
        {
            $new_url = 'https://fineapp.live/dlv/'.$cat.'?'.$exp_url[1];
        }
        else if($domain === 'ofapp.live')
        {
            $new_url = 'https://ofapp.live/ReqRouter/'.$cat.'?'.$exp_url[1];
        }
        else if($domain === 'forapp.live')
        {
            $new_url = 'https://forapp.live/ReqRouter/'.$cat.'?'.$exp_url[1];
        }
        else if($domain === 'easyapp.live')
        {
            $new_url = 'https://www.easyapp.live/ReqRouter/'.$cat.'?'.$exp_url[1];
        }
        
        
//        echo "<br>";
//        echo "NEW URL - ".$new_url;
//        
//        die();
        
        
        $sql = "update smart_rotator_campaigns_operators set offer_url ='".$new_url."' where id = '".$id."' LIMIT 1";
        $result = DB::update($sql);

        if($result)
        {
            $status = ['status'=>'1','message'=>'Successfully server url updated ...'];
            echo json_encode($status);
            exit;
        }
        else
        {
              $status = ['status'=>'2','message'=>'Problem while updating server url ....'];
            echo json_encode($status);
            exit;
        }
        
    }
    public function publisherOfferList_filetr(Request $request){
                

        $condtion = $data1= [];
        $cat = ['OM','OG'];
        
        $dtvalue = $request->start_date;
        $enddate= $request->end_date;
        $nwtwork = $request->network_name;
        $campaign = $request->campaign_name;
        $diversion = $request->diversion;
        $only_status = $request->only_status;
  	    $country_code = $request->country_code;
        $campaign_id = $request->campaign_id;
        $publisherid = $request->publisherid;

        /*  if(is_null($dtvalue)){
            $dtvalue = date('Y-m-d');
        }
        if(is_null($dtvalue2)){
                $dtvalue2 = date('Y-m-d');
                $enddate = date('Y-m-d',strtotime("+1 days"));
        }else{
           if($dtvalue == $dtvalue2){ 
              $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));
           }else{
            $enddate = date('Y-m-d',strtotime($dtvalue2));
           }
        }*/


        $condi = '';
        if(!empty($nwtwork))
        {
            $zone = "'" . implode ( "', '", $nwtwork ) . "'";
            $condi .=' AND smart_rotator_campaigns_operators.id_zone IN ('.$zone.')';
        }
        
        if(!empty($campaign))
        {
            $campaign_id = "'" . implode ( "', '", $campaign ) . "'";
            $condi .=' AND smart_rotator_campaigns_operators.campaign_id IN ('.$campaign_id.')';
        }
        if($only_status != '')
        {
            $condi .=" AND smart_rotator_campaigns_operators.smart_live = "."'$only_status'";
        }
        if($diversion != '')
        {
            $condi .=" AND smart_rotator_campaigns_operators.is_offer_direct = "."'$diversion'";
        }
		
	 if($country_code != ''){
            $country_codes = "'" . implode ( "', '", $country_code ) . "'";
            $condi .=' AND advertiser_campaigns.country_code IN ('.$country_codes.')';
        }
        if($campaign_id != '')
        {
            $condi .=" AND smart_rotator_campaigns_operators.campaign_id = "."'$campaign_id'";
        }
         if($publisherid != '')
        {
            $condi .=" AND ad_network.ccz = "."'$publisherid'";
        }

        if($dtvalue != '' && $enddate != '')
        {
            $condi .=" AND date(smart_rotator_campaigns_operators.start_date) >= "."'$dtvalue'".
                     " AND date(smart_rotator_campaigns_operators.start_date) <= "."'$enddate'";
        }
 
        
        $select =  
            "select smart_rotator_campaigns_operators.campaign_id as cca,
            smart_rotator_campaigns_operators.id as srco_id,
            smart_rotator_campaigns_operators.id_zone as zone,
            smart_rotator_campaigns_operators.smart_live as active,
            smart_rotator_campaigns_operators.offer_url as offer_url,
            smart_rotator_campaigns_operators.cap_count_conversions as cap_count_conversions,
            smart_rotator_campaigns_operators.cap_count_click as cap_count_click,
            smart_rotator_campaigns_operators.cap_count_install as cap_count_install,
            ad_network.name as network_name,
            smart_rotator_campaigns_operators.publisher_cpa as cpa,
            smart_rotator_campaigns_operators.publisher_kpi as publisher_kpi,
            smart_rotator_campaigns_operators.ads_cat as traffic_type,
            advertiser_campaigns.name,
            advertiser_campaigns.offername,
            advertiser_campaigns.advtrackinglink,
            advertiser_campaigns.id,
            smart_rotator_campaigns_operators.is_offer_direct as trfc,
            smart_rotator_campaigns_operators.status as status,
            smart_rotator_campaigns_operators.start_date as approve_date,
            advertiser_campaigns.os_type,
            advertiser_campaigns.country_code as country_code,
            config_delivery.lower_limit as filter,
            config_delivery.filter_status as filter_status,
            config_delivery.postback_status as postback_status 
            from smart_rotator_campaigns_operators as smart_rotator_campaigns_operators            
            LEFT JOIN advertiser_campaigns as advertiser_campaigns ON advertiser_campaigns.id = smart_rotator_campaigns_operators.campaign_id
            LEFT JOIN ad_network as ad_network ON ad_network.ccz = smart_rotator_campaigns_operators.id_zone
            LEFT JOIN config_delivery as config_delivery ON config_delivery.id_zone = smart_rotator_campaigns_operators.id_zone AND
                config_delivery.id_ad = smart_rotator_campaigns_operators.campaign_id WHERE smart_rotator_campaigns_operators.ads_cat IN ('OM','OG')
                $condi
            ORDER BY smart_rotator_campaigns_operators.id DESC
            ";
        
          
                $data=  DB::select(DB::raw($select));
          

                    foreach ($data as $result) 
                    {
                        $active = $filter_st = $postback = '';
                        if($result->active == '1')
                        {
                            $active = 'Active';
                        }
                        else
                        {
                            $active = 'Pause';
                        }
                        
                        if($result->filter_status == '1')
                        {
                            $filter_st = 'Active';
                        }
                        else
                        {
                            $filter_st = 'Inactive';
                        }
                        
                        if($result->postback_status == '1')
                        {
                            $postback = 'Active';
                        }
                        else
                        {
                            $postback = 'Inactive';
                        }  
                           
                           if($result->status == '5')
                        {
                            $backcolor = 'style="background-color:#FE6BD7;color:000"';
                        }
                        else
                        {
                            $backcolor = 'style="background-color:#25F3EC;color:000"';
                        }  

                        
    
                        $array = $data = $rtotal = [];
                        $offer_url = "'".$result->offer_url."'";
                        
                        $array[] =  $result->cca;

                        $array[] =  '<a href="javascript:void(0);" onclick="changeActStatus('.$result->cca.','.$result->zone.','.$result->srco_id.','.$result->active.');"><i class="fa fa-pencil"></i><span id="active_status_'.$result->srco_id.'">'.$active.'</span></a><span id="'.$result->srco_id.'" class="new_status_change" ><input type="checkbox" name="new_active_status_'.$result->srco_id.'" id="new_active_status" onclick="getSelectedValue(this, value);" /><label style="display:none;">'.$result->srco_id.'</label></span>';

                        $array[] =  $result->network_name." {".$result->zone."}"; 

                        $array[] =  '<a  href="javascript:void(0);" onclick="changeCpa('.$result->cca.','.$result->zone.','.$result->srco_id.','.$result->cpa.');"><i class="fa fa-pencil"></i><span id="cpa_'.$result->srco_id.'">'.$result->cpa.'</span></a>';
                        //Pub Install Cap
                        $array[] =  '<a '.$backcolor.' href="javascript:void(0);" onclick="changeCap('.$result->cca.','.$result->zone.','.$result->srco_id.','.$result->cap_count_conversions.');"><i class="fa fa-pencil"></i><span id="cap_conversion_'.$result->srco_id.'">'.$result->cap_count_conversions.'</span></a>';

                        //cap_count_click

                             $array[] =  '<a '.$backcolor.' href="javascript:void(0);" onclick="changeCapClick('.$result->cca.','.$result->zone.','.$result->srco_id.','.$result->cap_count_click.');"><i class="fa fa-pencil"></i><span id="cap_countclick_'.$result->srco_id.'">'.$result->cap_count_click.'</span></a>';

                        //cap_count_install     
                                $array[] =  '<a '.$backcolor.' href="javascript:void(0);" onclick="changeCapinstall('.$result->cca.','.$result->zone.','.$result->srco_id.','.$result->cap_count_install.');"><i class="fa fa-pencil"></i><span id="cap_countinstall_'.$result->srco_id.'">'.$result->cap_count_install.'</span></a>';

                        $array[] =  $result->traffic_type;                                 
                        $array[] =  '<span title="'.$result->name.'">'.$result->name.'('.$result->id.')</span>';
                        $array[] =  '<span title="'.$result->offername.'">'.$result->offername.'('.$result->id.')</span>';
                        //code emplemet edit functionaly

                        // $array[] =  $result->trfc;
                          $array[] =  '<a href="javascript:void(0);" onclick="changeTrfc('.$result->cca.','.$result->zone.','.$result->id.');"><i class="fa fa-pencil"></i><span id="trfc_'.$result->srco_id.'">'.$result->trfc.'</span></a>
    <span href="javascript:void(0);" id="trigger" onmouseover="display_pop('.$result->cca.','.$result->zone.','.$result->id.');"> Details </span> ';                      

                        //code emplement end here
                        
                        $array[] =   $result->country_code;
                        $array[] =   $result->os_type;
                        $array[] =   '<a href="javascript:void(0);"  onclick="changeFilter('.$result->cca.','.$result->zone.','.$result->srco_id.','.$result->filter.');"><i class="fa fa-pencil"></i><span id="filter_'.$result->srco_id.'">'.$result->filter.'</span></a>';
                        $array[] =   '<a href="javascript:void(0);" onclick="changeFilterSt('.$result->cca.','.$result->zone.','.$result->srco_id.','.$result->filter_status.');"><i class="fa fa-pencil"></i><span id="filter_st_'.$result->srco_id.'">'.$filter_st.'</span></a>';
                        $array[] =   '<a href="javascript:void(0);" onclick="changePostbackSt('.$result->cca.','.$result->zone.','.$result->srco_id.','.$result->postback_status.');"><i class="fa fa-pencil"></i><span id="postback_st_'.$result->srco_id.'">'.$postback.'</span></a>';
                        $array[] =   '<a title="Copy Url" href="javascript:void(0);" onclick="CopyUrl('.$result->srco_id.');"><i class="fa fa-clipboard" aria-hidden="true"></i><span id="copy_'.$result->srco_id.'" style="display:none;">'.$result->offer_url.'</span></a>';
                        $array[] =   '<a title="Copy Preview" href="javascript:void(0);" onclick="CopyPreview('.$result->srco_id.');"><i class="fa fa-clipboard" aria-hidden="true"></i><span id="copy_preview_'.$result->srco_id.'" style="display:none;">'.$result->advtrackinglink.'</span></a>';
//                        $array[] =   '<a title="View Details" href="javascript:void(0);" onclick="viewDetails('.$result->cca.','.$result->zone.','.$result->id.','.$result->offername.','.$result->cap_count_conversions.','.$result->country_code.','.$result->os_type.');"><i class="fa fa-eye" aria-hidden="true"></i></a>';
//                        $array[] =   '<a title="View Details" href="javascript:void(0);" onclick="viewDetails('.$result->cca.','.$result->zone.','.$result->id.');"><i class="fa fa-eye" aria-hidden="true"></i></a> | <a title="Edit KPI" href="javascript:void(0);" onclick="editKPI('.$result->cca.','.$result->zone.','.$result->srco_id.','.str_replace(array("(", ")", "/", ":","'",","), " ", $result->publisher_kpi).'"><i class="fa fa-pencil" aria-hidden="true"></i></a>';
                        $KPI_DATA = htmlspecialchars(addslashes($result->publisher_kpi),ENT_QUOTES,'UTF-8',TRUE);
                        $array[] =   '<a title="View Details" href="javascript:void(0);" onclick="viewDetails('.$result->cca.','.$result->zone.','.$result->id.');"><i class="fa fa-eye" aria-hidden="true"></i></a> | <a title="Edit KPI" href="javascript:void(0);" onclick="editKPI('.$result->cca.','.$result->zone.','.$result->srco_id.',\''.$KPI_DATA.'\')"><i class="fa fa-pencil" aria-hidden="true"></i></a>';
                        $array[] =  '<span title="'.$result->approve_date.'">'.date('d-m-Y',strtotime($result->approve_date)).'</span>';
                        ?>
                            
                    <?php
                        array_push($data1, $array);
                    }

        $networksResult = DB::select("select distinct(adn.ccz), adn.id, adn.name from ad_network as adn INNER JOIN smart_rotator_campaigns_operators as smt ON adn.ccz = smt.id_zone WHERE smt.smart_status = '1' AND smt.ads_cat in ('OM','OG') and adn.ccz!=0 order by adn.name ASC");
        
        $CampaignsResult = DB::select("select distinct(ac.id), ac.name from advertiser_campaigns as ac INNER JOIN smart_rotator_campaigns_operators as crd ON ac.id = crd.campaign_id WHERE crd.smart_status = '1' AND crd.ads_cat in ('OM','OG') ORDER BY ac.name ASC");
                    
	$countries = \App\Country::all();
                      $result  = array('data1' => $data1,
                          'network'=>$networksResult,
                          'campaigns_list'=>$CampaignsResult,
                          'div'=>$diversion,
                          'filter_st'=>$only_status,
                          'dtvalue'=>$dtvalue,
                          'dtvalue2'=>$enddate,
			  'nwtwork' =>$nwtwork,
                          'campaign' => $campaign,
                          'only_status'=>$only_status,
			'countries'=>$countries,
                          'countries_name'=>$country_code,
                          'publisherid'=>$publisherid,
                          'campaign_id'=>$campaign_id
                          );

                    $dataN =  view('offerlist.pubwiseofferredispages')->with($result);
                    return $dataN;
    }
    
  
    
  

	   /* To show network wise smart record */
    public function offer_networkwise_newpages(Request $request){
        $advertiser_id = $operator_id = $parent_cca = "";
        $type = "network";
        $template_name = "smart.networkwisenewpageredis";
        $cat = ['OM','OG'];
   	
	   $redis = Redis::connection();	

        $cache = $request->input('cache');
        $date  = date('Y-m-d');
        $min = date("i");
         
        if($min >= '00' && $min <= '04')
        {
            $key="network_wise_data_12";
        }
        else if($min >= '05' && $min <= '09')
        {
            $key   = "network_wise_data_1";
        }
        else if($min >= '10' && $min <= '14')
        {
            $key   = "network_wise_data_2";
        }
        else if($min >= '15' && $min <= '19')
        {
            $key   = "network_wise_data_3";
        }
        else if($min >= '20' && $min <= '24')
        {
            $key   = "network_wise_data_4";
        }
        else if($min >= '25' && $min <= '29')
        {
            $key   = "network_wise_data_5";
        }
        else if($min >= '30' && $min <= '34')
        {
            $key   = "network_wise_data_6";
        }
        else if($min >= '35' && $min <= '39')
        {
            $key   = "network_wise_data_7";
        }
        else if($min >= '40' && $min <= '44')
        {
            $key   = "network_wise_data_8";
        }
        else if($min >= '45' && $min <= '49')
        {
            $key   = "network_wise_data_9";
        }
        else if($min >= '50' && $min <= '54')
        {
            $key   = "network_wise_data_10";
        }
        else if($min >= '55' && $min <= '59')
        {
            $key   = "network_wise_data_11";
        }
            
        $items = $redis->get($key);
   		 $datas =  unserialize($items);
       return $this->index_adv_networ($datas); 
    }

     public function index_adv_networ($datas){

         

                       $type = "network";

           if(is_null($dtvalue)){
            $dtvalue = date('Y-m-d');
        }
        if(is_null($dtvalue2)){
                $dtvalue2 = date('Y-m-d');
                $enddate = date('Y-m-d',strtotime("+1 days"));
        }else{
           if($dtvalue == $dtvalue2){ 
              $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));
           }else{
            $enddate = date('Y-m-d',strtotime($dtvalue2));
           }
        }

             
        $condtion = $data221= [];
        $total_sale_count = $count = $totalClick = $actualcount = $totalconversion = $clicks_active_count = $unique_conversion = $totalCostDollar = $totalRevenueDollar = $totalprofit = $finalprofit_ECPM =  0;
         $sum_revenue_doller = $sum_revenue_inr = $sum_totalprofit_inr =  $sum_cost_inr = $sum_act_Click = 0;

             $role_id = Auth::user()->email;

                   foreach ($datas as $result) {
                       

                          $array = $data = $rtotal = [];
                        $count++;
                        $cap_status=0;
                        $totalCostDollar = round($totalCostDollar + ($result['cost_dollar']),2);  
                        $profit_dollar = $result['revenue_dollar'] - $result['cost_dollar'];
                        $profit_both = "<span class=dollar>".round($profit_dollar,2)."</span>";

                        $actualClick = $result['clickcount'] - $result['fraud'];
                        $cost_dollar = round($result['cost_dollar'],2);
                        
                        $totalRevenueDollar = round($totalRevenueDollar + ($result['revenue_dollar']),2);
                        
                        $totalprofitdoller = $result['revenue_dollar'] - $result['cost_dollar'] ;

                        $cr_in = '';
                        if($actualClick != 0)
                        {
                            $ecpm_doller = ($result['revenue_dollar']/$actualClick)*1000;
                            $cr_in = (($result['conversion_count_unique']/$actualClick)*100);
                            $cr_out = (($result['clicks_active_count']/$actualClick)*100);
                        }
                        else
                        {
                            $ecpm_doller = 0.000;
                        }
                        
                        if($result['conversion_count_unique'] == 0)
                        {
                            $cr_in = 0.00;
                        }
                        
                        if($result['clicks_active_count'] == 0)
                        {
                            $cr_out = 0.00;
                        }
                        if($result['active'] == 0)
                        {
                            $active = 'Pause';
                        }
                        else 
                        {
                            $active = 'Active';
                        }
                        

                        if($result['cap_status']==1){
                            $cap_status='<p  class="label label-success">Active</p>';
                        }else if($result['cap_status']==0){ 
                            $cap_status="<p  class='label label-warning'> Inactive </p>";
                        }else if($result['cap_status']==5){ 
                            $cap_status="<p class='label label-danger'>Pause</p>";
                        }
                        
                        $first_field = $result['id'];
                    
                        if($advertiser_id){
                            $first_field = $result['id'];
                        }else if($type == 'network'){
                           $first_field = $result['id_channel'];
                        } else if ($type == 'advertiser'){
                        $first_field = $result['id'];
                        }

                        if($type == 'advertiserByParentcca'){
                          $array[] =  $result['id'];
                          $first_field = $result['id'];
                        }
                        if($type == 'network'){
                            $array[] = $result['id'];
                            // $array[] = "$result->id";
                        }
                        
                       
                      $array[] =    $this->getNetwork($result['id_channel']);
                        $array[] =  $result['cpa'];  
                        $array[] =  $result['traffic_type']; 
                        // $array[] = "";                           
                        $array[] =  isset($result['name'])?htmlentities($result['name']):'';

                         $array[] =  isset($result['offername'])?htmlentities($result['offername']):'';

                       
                             $array[] = '<a href="javascript:void(0);" onclick="changeTrfc('.$result['parent_cca'].','.$result['zone'].','.$result['campaign_id'].');"><i class="fa fa-pencil"></i><span id="trfc_'.$result['campaign_id'].'">'.$result['trfc'].'</span></a>
    <span href="javascript:void(0);" id="trigger" onmouseover="display_pop('.$result['parent_cca'].','.$result['zone'].','.$result['campaign_id'].');"> Details </span>';

            
                        $array[] =   $active;
                        $array[] =   $cap_status;
                        $array[] =   $result['vertical'];
                        $array[] =   $result['country_code'];
                        $array[] =   $result['os_type'];
                        $array[] =   $result['clickcount'];
                        $array[] =   $actualClick; 
                        $array[] =   $result['conversion_count'];
                        
                       
                            $array[] =   $result['conversion_count_unique'];
                        
                        
                        $array[] =   $result['clicks_active_count'];                                
                        $array[] =   $result['sale_count'];
                        
                      
                             $array[] =  round($cr_in,2)."%";
                        $array[] =  round($cr_out,2)."%";    
                      
                        $array[] =   '$'."<span class=dollar>".$cost_dollar."</span>";
                        $array[] =   '$'."<span class=dollar>".round($result['revenue_dollar'],2);
                        $array[] =   '$'.$profit_both;
                        $array[] =   '$'.round($ecpm_doller,3);

                        array_push($data221, $array);
                        $total_sale_count = $total_sale_count + $result['sale_count']; 
                        $totalClick = $totalClick + $result['clickcount'];
                        $sum_act_Click = $sum_act_Click + $actualClick;
                        
                      
                        $unique_conversion = $unique_conversion + $result['conversion_count_unique'];
                        
                        
                        $actualcount = $actualcount + $actualClick;
                        $totalconversion = $totalconversion + $result['conversion_count'];
                        $clicks_active_count = $clicks_active_count + $result['clicks_active_count'];
                        
                        
                        $sum_revenue_doller = $sum_revenue_doller + $result['revenue_dollar'];
                        
                        $totalprofit = $totalprofit + $profit_dollar;
                        
                    }
                      


                        $lastRow =[$totalClick,$sum_act_Click,$totalconversion,$unique_conversion,$clicks_active_count,$total_sale_count,$totalCostDollar,round($sum_revenue_doller,2),round($totalprofit,2)];
//                        $lastRow =[$totalClick,$sum_act_Click,$totalconversion,$total_sale_count,$totalCostDollar,$totalRevenueDollar];


                      $result  = array('data1' => $data221,            
                        'dtvalue' => $dtvalue,
                        'dtvalue2' => $dtvalue2,
                        'role' => $role_id,
                        'lastRow'=>$lastRow
                      );
                    $dataN =  view('smart.networkwisenewpageredis')->with($result);
                    return $dataN;

                  
     }

  
       


}
