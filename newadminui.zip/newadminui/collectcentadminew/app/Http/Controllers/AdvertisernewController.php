<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\QueryAccess;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Validation\ValidatesRequests;
use App\Advertiser;
use App\User;
use App\AdNetwork;
use\App\reverse_setting;

use Auth;
use Illuminate\Support\Facades\Redis;
use Cache;

class AdvertisernewController extends Controller
{
    //
    public function __construct()
    {
         $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request,$pagename="main",$routename = "advertiserFilter",$header="Advertiser CR Update")
    {
            
            $redis = Redis::connection();
            $keys = $redis->keys("*");
            $advertiserkey = 'CrcCampaignCrcAdvertiserCampaignNew-'.date('Ymd');
            $adsData = $redis->sMembers($advertiserkey);
            $single_array = $redisData = []; 
            // print"<pre>";print_r($adsData);die;
            if(in_array($advertiserkey,$keys)){
              $i=0;
              foreach($adsData as $key=>$ads){
                $single_array[$key] = json_decode($ads,true);
                $redisData[$single_array[$key]['id_advertiser_campaign']] = $single_array[$key]; 
                // if($i>1){break;}
                $i++; 
              }
            }
            // dd($redisData);
            
            $condtion = [];
            $ddCondition = [];
            $dtvalue = $request->start;
            $dtvalue2 = $request->end;

            
            
            
            if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                    $dtvalue2 = date('Y-m-d');
                    $enddate = date('Y-m-d',strtotime("+1 days"));
            }else{
                //$dtvalue2 = date('Y-m-d',strtotime("+1 days"));
               $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));

            }
            
            $request->total = $request->total ? $request->total:50;
            $condtion1 = [];

            array_push($condtion,['crc_advertiser_campaign_new.create_time','>=',$dtvalue] );
            array_push($condtion,['crc_advertiser_campaign_new.create_time','<=',$enddate] );
             array_push($condtion1,['crc_advertiser_campaign_new.create_time','>=',$dtvalue] );
            array_push($condtion1,['crc_advertiser_campaign_new.create_time','<=',$enddate] );
             array_push($condtion1,['crc_records_new.create_time','>=',$dtvalue] );
            array_push($condtion1,['crc_records_new.create_time','<=',$enddate] );
            array_push($ddCondition,['crc_advertiser_campaign_new.create_time','>=',$dtvalue] );
            array_push($ddCondition,['crc_advertiser_campaign_new.create_time','<=',$enddate] );

            if($request->type && $request->type!= "CPS"){
                array_push($condtion,['advertiser_campaigns.type','=',strtoupper($request->type)] );
            }
  
            $adData = [];
            $adDataArray = "";
            if($request->type == "CPS"){
              
              $adDataArray = Advertiser::where("account_manager","=","anshul.tyagi@collectcent.com")->get(["id"]);
              
              foreach($adDataArray as $value){
                  if($value->id && (!in_array($value->id, $adData))){
                      array_push($adData, $value->id);
                  }
              }
            }


            if($request->id_channel){
                array_push($condtion,['advertiser_campaigns.id_advertiser','=',$request->id_channel] );
            }
            if($request->operator_id){
                array_push($condtion,['crc_advertiser_campaign_new.op_id','=',$request->operator_id] );
                //dd($condtion);
            }
            if($request->traffic_type){
                array_push($condtion,['advertiser_campaigns.ads_cat','=',$request->traffic_type] );

            }
            if ($request->country) {
               array_push($condtion,["advertiser_campaigns.country_code",'=',$request->country] );

            }
            $ddData = $this->createDD($ddCondition);
            
           
           $select = "advertiser.name  as adv_name"
                    .",advertiser_campaigns.id_advertiser"
                    .",advertiser_campaigns.name"
                    .",advertiser_campaigns.country_code"
                    .",country.name as cntry"
                    .",advertiser_campaigns.cpa as ac_cpa"
                    .",sum(crc_advertiser_campaign_new.conversion_count_unique) AS distinct_conversion"
                    .",crc_advertiser_campaign_new.op_name"
                    .",crc_advertiser_campaign_new.op_id"
                    .",crc_advertiser_campaign_new.id_advertiser_campaign"
                    .",crc_advertiser_campaign_new.total_cost"
                    .",sum(crc_advertiser_campaign_new.clickcount) AS clickcount"
                    .",sum(crc_advertiser_campaign_new.conversion_count) AS conversion_count"
                    .",sum(crc_advertiser_campaign_new.clicks_active_count) as clicks_active_count"
                    .",crc_advertiser_campaign_new.cr_goal AS cr_goal"
                    .",crc_advertiser_campaign_new.cr_received AS cr_received"
                    .",crc_advertiser_campaign_new.cr_given AS cr_given"
                    .",crc_advertiser_campaign_new.create_time"
                    .",manage_crc_advertiser.remark"
                    .",advertiser_campaigns.ads_cat"
                    .",advertiser_campaigns.type";

          $data =  DB::table("crc_advertiser_campaign_new")
              ->where($condtion) 
             ->selectRaw(DB::raw($select))
             ->leftJoin("advertiser_campaigns","crc_advertiser_campaign_new.id_advertiser_campaign","=","advertiser_campaigns.id")
              ->leftJoin("country","advertiser_campaigns.country_code","=","country.iso")
             ->leftJoin("advertiser","advertiser.id","=","advertiser_campaigns.id_advertiser")
             ->leftJoin("manage_crc_advertiser","manage_crc_advertiser.adv_id","=","advertiser_campaigns.id")
             ->groupby("crc_advertiser_campaign_new.id_advertiser_campaign");
             
        
          $selectCost = "advertiser_campaigns.id,sum(crc_records_new.total_cost) as rctotalcost,crc_advertiser_campaign_new.report_type";
           array_push($condtion1,['crc_advertiser_campaign_new.report_type','=',"CPA" ]);
            $dataCost =  DB::table("crc_advertiser_campaign_new")
              ->where($condtion1) 
             ->selectRaw(DB::raw($selectCost))
             ->leftJoin("advertiser_campaigns","crc_advertiser_campaign_new.id_advertiser_campaign","=","advertiser_campaigns.id")
             ->leftJoin("advertiser","advertiser.id","=","advertiser_campaigns.id_advertiser")
              ->leftJoin("crc_records_new","crc_records_new.id_advertiser_campaign","=","advertiser_campaigns.id")
              ->leftJoin("manage_crc_advertiser","manage_crc_advertiser.adv_id","=","advertiser_campaigns.id")
             ->groupby("crc_advertiser_campaign_new.id_advertiser_campaign")->get();
             
             $rtotal=array();
              foreach ($dataCost as $cost) {
               # code...
               $rtotal[$cost->id]=$cost->rctotalcost;
             }
          

        if($request->colorder){
           $data = $data->orderby($request->colorder,$request->order);
           $appends["colorder"]=$request->colorder;
           $appends["order"]=$request->order;
         }else{
            $data = $data->orderby("advertiser_campaigns.name","ASC");
            
         }
         if(sizeof($adData)>0){
          $data =  $data->whereIn('advertiser_campaigns.id_advertiser', $adData);
         }
        $appends['id_channel']=$request->id_channel;
        $appends['operator_id']=$request->operator_id;
        $appends['traffic_type']= $request->traffic_type;
        $appends['total']=$request->total;
       
                
         $data =  $data->get();
          if(sizeof($data) !== 0)
                {
                    $update_time =  $data[sizeof($data)-1]->create_time;
                }else{
                    $update_time = "";
                }
           
        
               
                $data1 = [];
                $clickcount = 0;
                $conversion_count = 0;
                $clicks_active_count = 0;
                $distinct_conversion = 0;
                $sourcost = 0;
                $convCount = 0;
                $profit = 0;
                $revenue_dollar = 0;
          foreach ($data as $fetch_records){
                $array = [];
                $totalCost  =   array_key_exists($fetch_records->id_advertiser_campaign,$rtotal)?$rtotal[$fetch_records->id_advertiser_campaign]:0;
                $campaign = $fetch_records->id_advertiser_campaign;
                
                if(array_key_exists($fetch_records->id_advertiser_campaign,$redisData))
                {
                  $revenue = $fetch_records->ac_cpa * $redisData[$campaign]['conversion_count']; 
                  $profit_field = $revenue - round($totalCost * 65, 2);
                  array_push($array,
                            $redisData[$campaign]['id_advertiser_campaign'],
                            $fetch_records->adv_name,
                            $redisData[$campaign]['op_name'],
                            $fetch_records->ads_cat,
                            '<a href="/network-cr-update-single-redis/0?id_advertiser_campaign='.$fetch_records->id_advertiser_campaign.'&start='.$dtvalue.'&end='.$dtvalue2.'" title="'.$fetch_records->name.'">'.$fetch_records->name.'</a>',
                            $fetch_records->country_code.'('.$fetch_records->cntry.')',
                            $fetch_records->type,
                            $redisData[$campaign]['clickcount'],
                            $redisData[$campaign]['conversion_count'],
                            $redisData[$campaign]['clicks_active_count'],
                            $redisData[$campaign]['cr_received'].'%',
                            $redisData[$campaign]['cr_given'].'%',
                            $redisData[$campaign]['conversion_count_unique'],
                            $redisData[$campaign]['cr_goal'],
                            round($totalCost,2).'/'.round($totalCost * 65, 2),
                            $revenue,
                            $revenue/1000,
                            $profit_field,
                            '<input class="form-control" type="text" value="'.$fetch_records->remark.'" id="example-text-input">',
                            '<i class="fa fa-edit"></i>');
                          array_push($data1, $array);
                          $clickcount += $redisData[$campaign]['clickcount'];
                          $conversion_count += $redisData[$campaign]['conversion_count'];
                          $clicks_active_count += $redisData[$campaign]['clicks_active_count'];
                          $distinct_conversion += $redisData[$campaign]['conversion_count_unique'];
                          $revenue_dollar += $revenue; 
                          $sourcost += $totalCost;
                          $convCount += $fetch_records->ac_cpa * $redisData[$campaign]['conversion_count'];
                          $profit = $profit  + $profit_field;
                          

                      }
                    } 

                         $lastRow =[
                         $clickcount,
                         $conversion_count,
                         $clicks_active_count,
                         $distinct_conversion,
                         $convCount,
                         $convCount."/".$convCount*65,
                         $sourcost."/".$sourcost*65,
                         $revenue_dollar,
                         $profit
                         ];
         
             
           
         $result  = array('data1' => $data1,
            "routename"=>$routename,
            'header'=>$header,
            'dtvalue' => $dtvalue,
            'dtvalue2' => $dtvalue2,
            'ddData' => $ddData,
            'id_channel'=>$request->id_channel,
            'operator_id'=>$request->operator_id,
            'type'=>$request->type,
            'traffic_type' => $request->traffic_type,
            'pagename' => $pagename,
            'total' => $request->total,
            'country'=> $request->country,
            'lastRow' => $lastRow,
            'update_time' =>$update_time
          );
          if(sizeof($adData)>0){
              $viewPage = "advertisernew.advertiser_cr_update_cps";
         }else{
               $viewPage = "advertisernew.advertiser_cr_update";
         }
         return view($viewPage)->with($result);
       }

     public function cpa_cr_update(Request $request){
        $request->type = "CPA";
        return $this->index($request,"cpa","advertiserfilterCPA","Advertiser CPA Cr Update");

     }
     public function cps_cr_update(Request $request){
        $request->type = "CPS";
        return $this->index($request,"cpa","advertiserfilterCPS","Advertiser CPS Cr Update");

     }
      public function cpi_cr_update(Request $request){
        $request->type = "CPI";
        return $this->index($request,"cpa","advertiserfilterCPI","Advertiser CPI Cr Update");

     }
    public function cpicpa_cr_update(Request $request){
        $request->type = "CPICPA";
        return $this->index($request,"cpa","advertiserfilterCPICPA","Advertiser CPICPA Cr Update");

     }
    function getAdvertiserList(Request $request) 
        {
            $select =  ["advertiser.name as advertiser_name",
                    "advertiser.country as country",
                    "advertiser.advertiser_key as advertiser_key",
                    "advertiser.language as language",
                    "advertiser.account_manager as account_manager",
                    "advertiser.create_time as create_time",
                    "advertiser.status as status",
                    "advertiser.id"];
            $data =  Advertiser::with('User')
            ->select($select)   
            ->orderBy('advertiser.id', 'DESC')
            ->get();
            // dd($data->all());
            return view('Resources.AdvertiserList',['adver' => $data]);
    
        }
    function showaddadvertiserview()
        {
            return view ('/Resources.addadvertiser');
        }
    function AddAdvertiser(Request $request)
        {   

            $data  = array(
                'name' => $request->adname,
                'account_manager'=>$request->account_manager);  
            Advertiser::create($data);
            return redirect('/Resources/list-advertiser');
        }
    function editAdvertiser($id)
    {
        $adver=Advertiser::find($id);

        // $users=User::all(['id', 'name']);
        // return view ('Resources.editadvertiser',compact('adver','users'));
        return view ('Resources.editadvertiser',compact('adver'));
    }

      //Database updation

    public function update(Request $request)
     {
       
        $adver=Advertiser::find($request->id);
        $adver->name = $request->adname;
        $adver->country = $request->country;
        $adver->account_manager = $request->account_manager;
        $adver->status = $request->status;
        $adver->save();
        
        return redirect('/Resources/list-advertiser');
     }

  public function createDD($condtion){
      $select = "advertiser.name  as adv_name"
      .",country.name as cntry"
      .",advertiser_campaigns.id_advertiser"
      .",advertiser_campaigns.country_code"
      .",advertiser_campaigns.name"
      .", crc_advertiser_campaign_new.op_name"
      .",crc_advertiser_campaign_new.op_id"
      .",crc_advertiser_campaign_new.id_advertiser_campaign"
      .",crc_advertiser_campaign_new.total_cost";

 array_push($condtion,['report_type','=',"CPA"] );

  $data = DB::table("crc_advertiser_campaign_new")
  ->where($condtion)
  ->selectRaw(DB::raw($select))
  ->leftJoin("advertiser_campaigns","crc_advertiser_campaign_new.id_advertiser_campaign","=","advertiser_campaigns.id")
  ->leftJoin("country","advertiser_campaigns.country_code","=","country.iso")
  ->leftJoin("advertiser","advertiser_campaigns.id_advertiser","=","advertiser.id")
  ->groupby("crc_advertiser_campaign_new.id_advertiser_campaign")
  ->orderby("advertiser_campaigns.name")->get();

   $ddDataResult  = array(
                'network_dropdown' => [],
                'country_dropdown' => [],
                'operator_dropdown' => [],
                'idad_dropdown' => [],
                'traffictype_dropdown' => []
            );
    foreach ($data as $dropdown) {

            if ($dropdown->id_advertiser){
                $ddDataResult['network_dropdown'][$dropdown->id_advertiser] = $dropdown->adv_name;
            }
            if ($dropdown->country_code){
                 $ddDataResult['country_dropdown'][$dropdown->country_code] = $dropdown->country_code."(".$dropdown->cntry.")";
             }
            if ($dropdown->op_id && $dropdown->op_name){
                  $ddDataResult['operator_dropdown'][$dropdown->op_id] = $dropdown->op_name."(".$dropdown->country_code.")";
            }
            if ($dropdown->id_advertiser_campaign){
                   $ddDataResult['idad_dropdown'][$dropdown->id_advertiser_campaign] = $dropdown->id_advertiser_campaign;
            }
            // if($dropdown->traffic_type){
            //    $ddDataResult['traffictype_dropdown'][$dropdown->traffic_type] = $dropdown->traffic_type;
            // }
          }
return $ddDataResult;
  }
            public function ajaxOperatordata(Request $Request){
             $value=$Request->vals;
              $res1 = "";
             $select = "distinct (advertiser_campaigns.id_op) as ops,operator.name as op_name,operator.country_code as cc";
                  
            $data =  DB::table('advertiser_campaigns')
             ->selectRaw(DB::raw($select))
              ->leftJoin("operator","advertiser_campaigns.id_op","=", "operator.id")
              ->where([["advertiser_campaigns.id_advertiser","=",$value]])
              ->get()
              ->toArray();

              
             
               foreach ($data as $key => $val) {
               $res1 = "<option value ='".$val->ops."'>".$val->op_name."</option>";
             }

              return $res1;

               
         }
         public function reverse(Request $request)
         {
            
          return view('advertiser.advertiser_reverse');
         }

         public function  savelist(Request $request)
         { 
               $value = new reverse_setting;
               $advertiser = $request->advertiser;
              $operator = $request->operator;
              $revrse_cca = $request->reverse_cca;
              $value->advetiser_id = $advertiser;
              $value->operator_id = $operator; 
              $value->reverse_cca_id = $revrse_cca;
               $value->save();
               return redirect()->route('reverseAdvertiserShowGet');
            }
            public function reverselist(Request $request)
            {

            $select = "reverse_setting.reverse_id, reverse_setting.advetiser_id, reverse_setting.operator_id, reverse_setting.reverse_cca_id as reverse, advertiser.name as advertiser_name, operator.name as operator_name"; 
                $data =  DB::table('reverse_setting')
                ->selectRaw(DB::raw($select))
                ->leftJoin("advertiser","advertiser.id", "=", "reverse_setting.advetiser_id")
                ->leftJoin("operator","operator.id" ,"=", "reverse_setting.operator_id")
                ->orderBy('reverse_setting.reverse_id','DECS')
                ->paginate(10);
                return view('advertiser.advertiser-reverse-view')->with('data',$data);

         }
          public function editReverse($reverse_id)
          {
            $select = "reverse_setting.reverse_id, reverse_setting.advetiser_id, reverse_setting.operator_id, reverse_setting.reverse_cca_id as reverse, advertiser.name as advertiser_name, operator.name as operator_name"; 
                
                
            $users = reverse_setting::where('reverse_id',$reverse_id)
            ->selectRaw(DB::raw($select))
            ->leftJoin("advertiser","advertiser.id", "=", "reverse_setting.advetiser_id")
            ->leftJoin("operator","operator.id" ,"=", "reverse_setting.operator_id")        
            ->get()
            ->first();
            
            return view('advertiser.update-reverse',compact('users'));
          }
          public function updateReverse(Request $request)
           {

            
            $select = "reverse_setting.reverse_id, reverse_setting.advetiser_id, reverse_setting.operator_id, reverse_setting.reverse_cca_id as reverse, advertiser.name as advertiser_name, operator.name as operator_name"; 
                $data =  DB::table('reverse_setting')
                ->selectRaw(DB::raw($select))
                ->leftJoin("advertiser","advertiser.id", "=", "reverse_setting.advetiser_id")
                ->leftJoin("operator","operator.id" ,"=", "reverse_setting.operator_id")
                ->orderBy('reverse_setting.reverse_id','DECS')
                ->get()
                ->first();
            $update = array('advetiser_id' => $request->advertiser,'operator_id' => $request->operator,'reverse_cca_id' => $request->reverse_cca);
            
           $advertiser = reverse_setting::where(['reverse_id' =>  $request->ereverse])->update($update);
      
            /*$users->reverse_id = $request->ereverse;
            $users->advetiser_id = $request->eadvertiser_drop;
            $users->operator_id = $request->eoperator_drop;
            $users->reverse_cca_id = $request->ereverseId;
            $users->save();*/
            return redirect()->route('reverseAdvertiserShowGet');
           }




    }
