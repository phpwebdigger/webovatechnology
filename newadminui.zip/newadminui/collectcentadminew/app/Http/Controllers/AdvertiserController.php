<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\QueryAccess;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Validation\ValidatesRequests;
use App\Advertiser;
use App\User;
use App\AdNetwork;
use\App\reverse_setting;
use Illuminate\Support\Facades\Redis;
use SimpleHelper;

use Auth;

class AdvertiserController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function redisConnection(){
      $redis; 
        try{
            $redis = Redis::connection();
            return $redis; 
        }catch(\Exception $e){
           return false;
        }
        
    }
      /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request,$pagename="main",$routename = "advertiserFilter",$header="Advertiser CR Update")
    {
          $ddCondition = $adData = $rtotal = $lastRow = [];
          $update_time = '';
          $dtvalue = $request->start;
          $dtvalue2 = $request->end;
          if(is_null($dtvalue)){
              $dtvalue = date('Y-m-d');
          }
          if(is_null($dtvalue2)){
              $dtvalue2 = date('Y-m-d');
              $dtvalue2 = $enddate = date('Y-m-d',strtotime("+1 days"));
          }else{
              $dtvalue2 = $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));
          }
          array_push($ddCondition,['crc_advertiser_campaign_new.create_time','>=',$dtvalue] );
          array_push($ddCondition,['crc_advertiser_campaign_new.create_time','<=',$enddate] );
          $redis = $this->redisConnection();
          $key = "advertiser_cr_dropdowns".$request->type;
            try{
                if($request->cache == 1){
                    $redis->delete($key);
                } 
                if(!$redis->exists($key)){
                  $ddData = $this->createDD($ddCondition);
                  Redis::set($key, json_encode($ddData));
                  $redis->expire($key,900);
                }else{
                    $ddData = json_decode(Redis::get($key),true);
                }
            }catch(\Exception $e){
                $ddData = $this->createDD($ddCondition);
            }
            $advertiser_key = "advertisers_campaignwise_data";
            try{
                if($request->cache == 1){
                    $redis->delete($advertiser_key);
                } 
                if(!$redis->exists($advertiser_key)){
                  $data = $this->getAdvertiserCrUpdate($request);
                  Redis::set($advertiser_key, json_encode($data));
                  $redis->expire($advertiser_key,300);
                }else{
                  $data = json_decode(Redis::get($advertiser_key),true);
                }
            }catch(\Exception $e){
                $data = $this->getAdvertiserCrUpdate($request);
            }
          if(isset($data['status']) &&  $data['status'] == 1){  
                $update_time = $data['update_time']; 
                $lastRow = $data['lastRow'];
                $data =  $data['data'];
          }else{
             $data = '';
          }
          if(sizeof($adData)>0){
                    $viewPage = "advertiser.advertiser_cr_update_cps";
                }else{
                     $viewPage = "advertiser.advertiser_cr_update";
                }      
          
          $result  = array(
            'data1' => $data,
            "routename"=>$routename,
            'header'=>$header,
            'dtvalue' => $dtvalue,
            'dtvalue2' => $dtvalue2,
            'ddData' => $ddData,
            'id_channel'=>$request->id_channel,
            'operator_id'=>$request->operator_id,
            'type'=>$request->type,
            'traffic_type' => $request->traffic_type,
            'pagename' => $pagename,
            'country'=> $request->country,
            'lastRow' => $lastRow,
            'update_time' =>$update_time
          );
          return view($viewPage)->with($result);
    }


     function getAdvertiserCrUpdate(Request $request){
        //  try{    
            $condtion = $condtion1 = [];
            $ddCondition = $adData = $rtotal = $types = $id_advertiser_arr = $operator_id_arr = $traffic_type_arr = $country_arr = [];
            $dtvalue = $request->start;
            $dtvalue2 = $request->end;
            $adDataArray = "";
            if(is_null($dtvalue)){
              $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                $dtvalue2 = $enddate = date('Y-m-d',strtotime("+1 days"));
            }else{
                $dtvalue2 = $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));
            }
            array_push($condtion,['crc_records_new.create_time','>=',$dtvalue]);
            array_push($condtion,['crc_records_new.create_time','<=',$enddate]);
            if($request->type && $request->type!= "CPS"){
             if(is_array($request->type) && count($request->type) > 1 ){
                  $types = $request->type;
              }else if(is_array($request->type)){
                  array_push($condtion,['advertiser_campaigns.type','=',$request->type[0]]);   
              }else{
                array_push($condtion,['advertiser_campaigns.type','=',$request->type]);
              }     
            }
            if($request->id_advertiser && $request->id_advertiser != 0){
              if(count($request->id_advertiser) > 1 ){
                  $id_advertiser_arr = $request->id_advertiser;
              }else{
                  array_push($condtion,['advertiser_campaigns.id_advertiser','=',$request->id_advertiser[0]]);   
              }              
            }
            if($request->operator_id){
                if(count($request->operator_id) > 1 ){
                $operator_id_arr = $request->operator_id;
                }else{
                array_push($condtion,['crc_advertiser_campaign_new.op_id','=',$request->operator_id[0]]);
                }
            }
            if($request->traffic_type){
              $flag = 1;
              if(count($request->traffic_type) > 1){
               $traffic_type_arr = $request->traffic_type;
              }else{ 
                array_push($condtion,['advertiser_campaigns.ads_cat','=',$request->traffic_type[0]] );
              } 
            }
            if($request->country && $request->country !== 0){
              $flag = 1;
              if(count($request->country) > 1 ){
                $country_arr = $request->country;
              }else{
                array_push($condtion,['advertiser_campaigns.country_code','=',$request->country[0]] );
              }
            }
            $adv_name='';

            $array_pub_name=[];

            // $array_pub_name =array('3S Studio'=>'AAB','Actwebmedia'=>'AAC');

            $select = "advertiser.name  as adv_name"
                    .",advertiser_campaigns.id_advertiser"
                    .",advertiser_campaigns.name"
                    .",advertiser_campaigns.country_code"
                    .",advertiser_campaigns.cpa as ac_cpa"
                    .",advertiser_campaigns.id_op" 
                    .",sum(crc_records_new.conversion_count_unique) AS distinct_conersion"
                    // .",crc_records_new.op_name"
                    .",crc_records_new.op_id"
                    .",crc_records_new.id_advertiser_campaign"
                    .",crc_records_new.parent_cca"  
                    .",sum( IF(crc_records_new.traffic_type = 'WG' OR crc_records_new.traffic_type = 'WM',crc_records_new.cost_dollar, crc_records_new.total_cost)) as total_cost"
                    .",sum(crc_records_new.clickcount) AS clickcount"
                    .",sum(crc_records_new.conversion_count) AS conversion_count"
                    .",sum(crc_records_new.clicks_active_count) as clicks_active_count"
                    .",crc_records_new.cr_goal AS cr_goal"
                    .",sum(crc_records_new.revenue_dollar) as revenue_dollar" 
                    .",sum(crc_records_new.cr_received) AS cr_received"
                    .",sum(crc_records_new.cr_given) AS cr_given"
                    .",crc_records_new.create_time"
                    // .",manage_crc_advertiser.remark"
                    .",advertiser_campaigns.ads_cat"
                    .",operator.name as op_name"
                    .",advertiser_campaigns.type";
                  $data =  DB::table("crc_records_new")->where($condtion);
                  if($types){
                    $data =   $data->whereIn('advertiser_campaigns.type',$types);
                  }
                  if($id_advertiser_arr){
                    $data =   $data->whereIn('advertiser_campaigns.id_advertiser',$id_advertiser_arr);
                  }
                  if($operator_id_arr){
                     $data =   $data->whereIn('advertiser_campaigns.id_op',$operator_id_arr);
                  }
                  if($traffic_type_arr){
                    $data =   $data->whereIn('advertiser_campaigns.ads_cat',$traffic_type_arr);
                  }
                  if($country_arr){
                    $data =   $data->whereIn('advertiser_campaigns.country_code',$country_arr);
                  }

                  $data =   $data->selectRaw(DB::raw($select))
                  ->leftJoin("advertiser_campaigns","crc_records_new.id_advertiser_campaign","=","advertiser_campaigns.id")
                  ->leftJoin("advertiser","advertiser.id","=","advertiser_campaigns.id_advertiser")
                  ->leftJoin("operator","advertiser_campaigns.id_op","=","operator.id")
                  ->groupby("crc_records_new.id_advertiser_campaign")->orderby('advertiser_campaigns.name');
                  if(sizeof($adData)>0){
                    $data =  $data->whereIn('advertiser_campaigns.id_advertiser', $adData);
                  }
                  $data =  $data->get();
                  if(sizeof($data) !== 0){
                      $update_time =  $data[sizeof($data)-1]->create_time;
                  }else{
                      $update_time = "";
                  }
                  $data1 = [];
                  $clickcount = $conversion_count = $clicks_active_count = 0;
                  $distinct_conersion = $sourcost = $convCount = $AllRevenueCost = $finalprofit = $ecpm_total = 0;
                  foreach($data as $fetch_records){
                      $array = [];
                      $totalCost  = $fetch_records->total_cost;
                         $finalprofitval = round(($fetch_records->revenue_dollar- $totalCost)* 65,2);
              //          $totalsourcecostval=round($totalSourceCost * 65, 2);
              // $totalrevenueval=($fetch_records->conversion_count)*($fetch_records->ac_cpa);
              // $finalprofitval=$totalrevenueval - $totalsourcecostval;
              // $finalprofit = $finalprofit + $finalprofitval;
              // echo $finalprofitval; 
                      $crIn = $this->getPercentage($fetch_records->conversion_count,$fetch_records->clickcount);
                      $crOut = $this->getPercentage($fetch_records->clicks_active_count,$fetch_records->clickcount);
                      $ecpm = 0;
                      if($fetch_records->clickcount){
                          $ecpm = round($fetch_records->revenue_dollar/$fetch_records->clickcount*1000,4);
                      }

                        if(count($array_pub_name)>0 && array_key_exists($fetch_records->adv_name, $array_pub_name))
                            {
                              $adv_name= $array_pub_name[$fetch_records->adv_name];
                            }else{
                             $adv_name= $fetch_records->adv_name;
                            }

                      array_push($array,
                            $fetch_records->id_advertiser_campaign,
                            
                            $adv_name,
                          
                            $fetch_records->op_name,
                            $fetch_records->ads_cat,
                            '<a href="/smart-network-cr-update-single-network/0?id_advertiser_campaign='.$fetch_records->id_advertiser_campaign.'&start='.$dtvalue.'&end='.$dtvalue2.'">'.$fetch_records->name.'('.$fetch_records->id_advertiser_campaign.')</a>',
                            $fetch_records->country_code,
                            $fetch_records->type,
                            $fetch_records->clickcount,
                            $fetch_records->conversion_count,
                            $fetch_records->clicks_active_count,
                            round($crIn,2).'%',
                            round($crOut,2).'%',
                            round($fetch_records->distinct_conersion,2),
                            round($totalCost,2).'/'.SimpleHelper::intoRupees($totalCost,0),
                            // round($fetch_records->revenue_dollar * 65,2),
                            round($fetch_records->revenue_dollar,2).'/'.SimpleHelper::intoRupees($fetch_records->revenue_dollar,0),
                            round($ecpm,2),
                            round($finalprofitval,2).'/'.SimpleHelper::intoRupees($finalprofitval,0)
                            );
                    array_push($data1, $array);
                    $clickcount += $fetch_records->clickcount;
                    $conversion_count += $fetch_records->conversion_count;
                    $clicks_active_count += $fetch_records->clicks_active_count;
                    $distinct_conersion += $fetch_records->distinct_conersion;
                    $sourcost += $totalCost;
                    $AllRevenueCost += round(SimpleHelper::intoRupees($fetch_records->revenue_dollar,0));
                    $finalprofit = $finalprofit + round($finalprofitval);  
                    $ecpm_total +=round($ecpm,2);
                    // $profit += ($fetch_records->ac_cpa * $fetch_records->conversion_count - $totalCost);
                  }
            $lastRow = [ 
                        "Total",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        $clickcount,
                        $conversion_count,
                        $clicks_active_count,
                        "",
                        "",
                        $distinct_conersion,
                        "",
                        $AllRevenueCost,
                        $ecpm_total,
                        round($finalprofit,2),
                      ];

            if(count($data1) > 0){
                $status = array('status'=>1,'data'=>$data1,'lastRow'=>$lastRow,'update_time'=>$update_time);
            }else{
                $status = array('status'=>2,'message'=>'Please search again there is not result available');
            }
       /* }catch(\Exception $e){
            $status = array('status'=>2,'message'=>'Please search again there is not result available');  
        }
      */
         
            return $status; 
      }


      function getPercentage($param1,$param2){
        if($param2 == 0 ){return 0;}  
        $percent =  $param1/$param2 *100;
        return round($percent,3);
       }


    /* function getAdvertiserCrUpdate(Request $request){
         try{    
            $condtion = $condtion1 = [];
            $ddCondition = $adData = $rtotal = $types = $id_advertiser_arr = $operator_id_arr = $traffic_type_arr = $country_arr = [];
            $dtvalue = $request->start;
            $dtvalue2 = $request->end;
            $adDataArray = "";
            if(is_null($dtvalue)){
              $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                $dtvalue2 = date('Y-m-d');
                $dtvalue2 = $enddate = date('Y-m-d',strtotime("+1 days"));
            }else{
                $dtvalue2 = $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));
            }
            array_push($condtion,['crc_advertiser_campaign_new.create_time','>=',$dtvalue] );
            array_push($condtion,['crc_advertiser_campaign_new.create_time','<=',$enddate] );
            array_push($condtion1,['crc_advertiser_campaign_new.create_time','>=',$dtvalue] );
            array_push($condtion1,['crc_advertiser_campaign_new.create_time','<=',$enddate] );
            array_push($condtion1,['crc_records_new.create_time','>=',$dtvalue] );
            array_push($condtion1,['crc_records_new.create_time','<=',$enddate] );
            array_push($condtion1,['crc_advertiser_campaign_new.report_type','=',"CPA" ]);
            if($request->type && $request->type!= "CPS"){
             if(is_array($request->type) && count($request->type) > 1 ){
                  $types = $request->type;
              }else if(is_array($request->type)){
                  array_push($condtion,['advertiser_campaigns.type','=',$request->type[0]]);   
              }else{
                array_push($condtion,['advertiser_campaigns.type','=',$request->type]);
              }     
            }
            if($request->id_advertiser && $request->id_advertiser != 0){
              if(count($request->id_advertiser) > 1 ){
                  $id_advertiser_arr = $request->id_advertiser;
              }else{
                  array_push($condtion,['advertiser_campaigns.id_advertiser','=',$request->id_advertiser[0]]);   
              }              
            }
            if($request->operator_id){
                if(count($request->operator_id) > 1 ){
                $operator_id_arr = $request->operator_id;
                }else{
                array_push($condtion,['crc_advertiser_campaign_new.op_id','=',$request->operator_id[0]]);
                }
            }
            if($request->traffic_type){
              $flag = 1;
              if(count($request->traffic_type) > 1){
               $traffic_type_arr = $request->traffic_type;
              }else{ 
                array_push($condtion,['advertiser_campaigns.ads_cat','=',$request->traffic_type[0]] );
              } 
            }
            if($request->country && $request->country !== 0){
              $flag = 1;
              if(count($request->country) > 1 ){
                $country_arr = $request->country;
              }else{
                array_push($condtion,['advertiser_campaigns.country_code','=',$request->country[0]] );
              }
            }
            $select = "advertiser.name  as adv_name"
                    .",advertiser_campaigns.id_advertiser"
                    .",advertiser_campaigns.name"
                    .",advertiser_campaigns.country_code"
                    .",advertiser_campaigns.cpa as ac_cpa"
                    .",sum(crc_advertiser_campaign_new.conversion_count_unique) AS distinct_conersion"
                    .",crc_advertiser_campaign_new.op_name"
                    .",crc_advertiser_campaign_new.op_id"
                    .",crc_advertiser_campaign_new.id_advertiser_campaign"
                    .",crc_advertiser_campaign_new.total_cost"
                    .",sum(crc_advertiser_campaign_new.clickcount) AS clickcount"
                    .",sum(crc_advertiser_campaign_new.conversion_count) AS conversion_count"
                    .",sum(crc_advertiser_campaign_new.clicks_active_count) as clicks_active_count"
                    .",crc_advertiser_campaign_new.cr_goal AS cr_goal"
                    .",crc_advertiser_campaign_new.cr_received AS cr_received"
                    .",crc_advertiser_campaign_new.cr_given AS cr_given"
                    .",crc_advertiser_campaign_new.create_time"
                    // .",manage_crc_advertiser.remark"
                    .",advertiser_campaigns.ads_cat"
                    .",advertiser_campaigns.type";
                  $selectCost = "crc_records_new.id_advertiser_campaign as id,crc_records_new.id_ad,sum(crc_records_new.total_cost) as rctotalcost,crc_advertiser_campaign_new.report_type";
                  $data =  DB::table("crc_advertiser_campaign_new")->where($condtion);
                  if($types){
                    $data =   $data->whereIn('advertiser_campaigns.type',$types);
                  }
                  if($id_advertiser_arr){
                    $data =   $data->whereIn('advertiser_campaigns.id_advertiser',$id_advertiser_arr);
                  }
                  if($operator_id_arr){
                     $data =   $data->whereIn('crc_advertiser_campaign_new.op_id',$operator_id_arr);
                  }
                  if($traffic_type_arr){
                    $data =   $data->whereIn('advertiser_campaigns.ads_cat',$traffic_type_arr);
                  }
                  if($country_arr){
                    $data =   $data->whereIn('advertiser_campaigns.country_code',$country_arr);
                  }
                  $data =   $data->selectRaw(DB::raw($select))
                  ->leftJoin("advertiser_campaigns","crc_advertiser_campaign_new.id_advertiser_campaign","=","advertiser_campaigns.id")
                  ->leftJoin("advertiser","advertiser.id","=","advertiser_campaigns.id_advertiser")
                  ->groupby("crc_advertiser_campaign_new.id_advertiser_campaign")->orderby('advertiser_campaigns.name');
              
                  $dataCost =  DB::table("crc_advertiser_campaign_new")->where($condtion1)->selectRaw(DB::raw($selectCost))
                              ->leftJoin("crc_records_new","crc_records_new.id_advertiser_campaign","=","crc_advertiser_campaign_new.id_advertiser_campaign")
                              ->groupby("crc_advertiser_campaign_new.id_advertiser_campaign")->get();
                  foreach($dataCost as $cost) {
                      $rtotal[$cost->id] = $cost->rctotalcost;
                  }
                  if(sizeof($adData)>0){
                    $data =  $data->whereIn('advertiser_campaigns.id_advertiser', $adData);
                  }
                  $data =  $data->get();
                  if(sizeof($data) !== 0){
                      $update_time =  $data[sizeof($data)-1]->create_time;
                  }else{
                      $update_time = "";
                  }
                  $data1 = [];
                  $clickcount = $conversion_count = $clicks_active_count = 0;
                  $distinct_conersion = $sourcost = $convCount = $AllRevenueCost = $finalprofit = 0;
                  foreach ($data as $fetch_records){
                  $array = [];
                  $totalCost  =   array_key_exists($fetch_records->id_advertiser_campaign,$rtotal)?$rtotal[$fetch_records->id_advertiser_campaign]:0;
                  array_push($array,
                            $fetch_records->id_advertiser_campaign,
                            $fetch_records->adv_name,
                            $fetch_records->op_name,
                            $fetch_records->ads_cat,
                            '<a href="/network-cr-update-single-network/"'.$fetch_records->id_advertiser_campaign.'"?id_advertiser_campaign='.$fetch_records->id_advertiser_campaign.'&start='.$dtvalue.'&end='.$dtvalue2.'">'.$fetch_records->name.'('.$fetch_records->id_advertiser_campaign.'</a>',
                            $fetch_records->country_code,
                            $fetch_records->type,
                            $fetch_records->clickcount,
                            $fetch_records->conversion_count,
                            $fetch_records->clicks_active_count,
                            $fetch_records->cr_received.'%',
                            $fetch_records->cr_given.'%',
                            $fetch_records->distinct_conersion,
                            round($totalCost,2).'/'.round($totalCost * 65, 2),
                            $fetch_records->ac_cpa * $fetch_records->conversion_count,
                            $fetch_records->ac_cpa * $fetch_records->conversion_count/1000,
                            $fetch_records->ac_cpa * $fetch_records->conversion_count - round($fetch_records->total_cost * 65, 2)
                            );
                    array_push($data1, $array);
                    $clickcount += $fetch_records->clickcount;
                    $conversion_count += $fetch_records->conversion_count;
                    $clicks_active_count += $fetch_records->clicks_active_count;
                    $distinct_conersion += $fetch_records->distinct_conersion;
                    $sourcost += ($totalCost);
                    $AllRevenueCost += $fetch_records->ac_cpa * $fetch_records->conversion_count;
                    $totalrevenueval = ($fetch_records->conversion_count)*($fetch_records->ac_cpa);
                    $finalprofitval = $totalrevenueval - ($totalCost*65);
                    $finalprofit = $finalprofit + $finalprofitval;  
                    // $profit += ($fetch_records->ac_cpa * $fetch_records->conversion_count - $totalCost);
                  }
            $lastRow = [ 
                        "Total",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        $clickcount,
                        $conversion_count,
                        $clicks_active_count,
                        "",
                        "",
                        $distinct_conersion,
                        "",
                        "",
                        "",
                        $finalprofit,
                      ];

            if(count($data1) > 0){
                $status = array('status'=>1,'data'=>$data1,'lastRow'=>$lastRow,'update_time'=>$update_time);
            }else{
                $status = array('status'=>2,'message'=>'Please search again there is not result available');
            }
        }catch(\Exception $e){
            $status = array('status'=>2,'message'=>'Please search again there is not result available');  
        }
         
            return $status; 
      } */

      public function filterAdvertiserCrData(Request $request){
        $type = $id_advertiser = $operator_id = $traffic_type = $country = '';
        $dtvalue = $request->start;
        $dtvalue2 = $request->end;
        if($request->type){
            $type = $request->type;
        }    
        if($request->id_advertiser){
            $id_advertiser = implode("-",$request->id_advertiser);
        }
        if($request->$operator_id){
          $operator_id = implode("-",$request->operator_id);
        }
        if($request->$traffic_type){
          $traffic_type = implode("-",$request->traffic_type);
        }
        if($request->$country){
          $country = implode("-",$request->country);
        }
        $filter_key = "advertiser_key?start=$dtvalue&end=$dtvalue2&id_advertiser=$id_advertiser&operator=$operator_id&traffic_type=$traffic_type&country=$country";
        $redis = $this->redisConnection();
        try{
                if($request->cache == 1){
                    $redis->delete($filter_key);
                } 
                if(!$redis->exists($filter_key)){
                  $data = $this->getAdvertiserCrUpdate($request);
                  Redis::set($advertiser_key, json_encode($data));
                  $redis->expire($filter_key,900);
                }else{
                  $data = json_decode(Redis::get($filter_key),true);
                }
            }catch(\Exception $e){
               $data = $this->getAdvertiserCrUpdate($request);
        }
        if($data['status']){
          $data = json_encode($data);
        }
        return $data;  
      }

     public function cpa_cr_update(Request $request){
        $request->type = "CPA";
        return $this->index($request,"cpa","advertiserfilterCPA","Advertiser CPA Cr Update");

     }
     public function cps_cr_update(Request $request){
        $request->type = "CPS";
        return $this->index($request,"cpa","advertiserfilterCPS","Advertiser CPS Cr Update");

     }
      public function cpi_cr_update(Request $request){
        $request->type = "CPI";
        return $this->index($request,"cpa","advertiserfilterCPI","Advertiser CPI Cr Update");

     }
    public function cpicpa_cr_update(Request $request){
        $request->type = "CPICPA";
        return $this->index($request,"cpa","advertiserfilterCPICPA","Advertiser CPICPA Cr Update");

     }
    function getAdvertiserList(Request $request) 
        {
          $user = Auth::user();

            $select = ["advertiser.name as advertiser_name",
                    "advertiser.country as country",
                    "advertiser.advertiser_key as advertiser_key",
                    "advertiser.language as language",
                    "advertiser.account_manager as account_manager",
                    "advertiser.create_time as create_time",
                    "advertiser.status as status",
                    "advertiser.id"];
            $data =  Advertiser::with('User')
            ->select($select) ;
          if(!empty($user->role_id) && $user->role_id=='12'){
          $data->where('advertiser.account_manager',$user->email);
          }  
            $data=$data->orderBy('advertiser.id', 'ASC')
            ->get();
            
            $data1 = [];
        $stat = '';
        $i=0;
        foreach ($data as $fetch_records)
        {
            $i++;

            $array = [];
            if($fetch_records->status==1)
            {
                $stat = 'Active';
            }
            else
            {
                $stat = 'Inactive';
            }

            array_push($array,
                    $i,
                $fetch_records->id,
                
                $fetch_records->advertiser_name,
                $fetch_records->country,
                $fetch_records->language,
                $fetch_records->account_manager,
                $fetch_records->advertiser_key,
                $fetch_records->create_time,
                $stat,
                '<a href="/advertiser/edit/'.$fetch_records->id.'"><button type="button" class="btn btn-danger btn-circle "><i class="fa fa-edit"></i></button></a>'
                );
            array_push($data1, $array);

        }
        
        $result  = array('data1' => $data1);
            
            // dd($data->all());
        return view('Resources.AdvertiserList')->with($result);
//            return view('Resources.AdvertiserList',['adver' => $data]);
    
        }
    function showaddadvertiserview()
        {
           $user = Auth::user();
           $role_id = $user->role_id;
           $user_email = $user->email;
            return view ('/Resources.addadvertiser',['role_id' =>$role_id,'user_email'=>$user_email]);
        }
    function AddAdvertiser(Request $request)
        {   

            $data  = array(
                'name' => $request->adname,
                'account_manager'=>$request->account_manager);  
            Advertiser::create($data);
            return redirect('/Resources/list-advertiser');
        }
    function editAdvertiser($id)
    {
        $adver=Advertiser::find($id);

        $user = Auth::user();
           $role_id = $user->role_id;
           $user_email = $user->email;

        // $users=User::all(['id', 'name']);
        // return view ('Resources.editadvertiser',compact('adver','users'));
        return view ('Resources.editadvertiser',compact('adver','role_id'));
    }

      //Database updation

    public function update(Request $request)
     {       
    
       
       
        $manager =is_array($request->account_manager) ? implode(',', $request->account_manager): $request->account_manager;        

        $adver=Advertiser::find($request->id);
        $adver->name = $request->adname;
        $adver->country = $request->country;
        $adver->account_manager = $manager;
        $adver->status = $request->status;
        $adver->save();
        
        return redirect('/Resources/list-advertiser');
     }

  public function createDD($condtion){
      $select = "advertiser.name  as adv_name"
      .",country.name as cntry"
      .",advertiser_campaigns.id_advertiser"
      .",advertiser_campaigns.country_code"
      .",advertiser_campaigns.name"
      .", crc_advertiser_campaign_new.op_name"
      .",crc_advertiser_campaign_new.op_id"
      .",crc_advertiser_campaign_new.id_advertiser_campaign"
      .",crc_advertiser_campaign_new.total_cost";

 array_push($condtion,['report_type','=',"CPA"] );

  $data = DB::table("crc_advertiser_campaign_new")
  ->where($condtion)
  ->selectRaw(DB::raw($select))
  ->leftJoin("advertiser_campaigns","crc_advertiser_campaign_new.id_advertiser_campaign","=","advertiser_campaigns.id")
  ->leftJoin("country","advertiser_campaigns.country_code","=","country.iso")
  ->leftJoin("advertiser","advertiser_campaigns.id_advertiser","=","advertiser.id")
  ->groupby("crc_advertiser_campaign_new.id_advertiser_campaign")
  ->orderby("advertiser_campaigns.name")->get();

   $ddDataResult  = array(
                'network_dropdown' => [],
                'country_dropdown' => [],
                'operator_dropdown' => [],
                'idad_dropdown' => [],
                'traffictype_dropdown' => []
            );
    foreach ($data as $dropdown) {

            if ($dropdown->id_advertiser){
                $ddDataResult['network_dropdown'][$dropdown->id_advertiser] = $dropdown->adv_name;
            }
            if ($dropdown->country_code){
                 $ddDataResult['country_dropdown'][$dropdown->country_code] = $dropdown->country_code."(".$dropdown->cntry.")";
             }
            if ($dropdown->op_id && $dropdown->op_name){
                  $ddDataResult['operator_dropdown'][$dropdown->op_id] = $dropdown->op_name."(".$dropdown->country_code.")";
            }
            if ($dropdown->id_advertiser_campaign){
                   $ddDataResult['idad_dropdown'][$dropdown->id_advertiser_campaign] = $dropdown->id_advertiser_campaign;
            }
          }
        return $ddDataResult;
  }
            public function ajaxOperatordata(Request $Request){
              $value=$Request->vals;
              $res1 = "";
              $select = "distinct (advertiser_campaigns.id_op) as ops,operator.name as op_name,operator.country_code as cc";
                  
              $data =  DB::table('advertiser_campaigns')
              ->selectRaw(DB::raw($select))
              ->leftJoin("operator","advertiser_campaigns.id_op","=", "operator.id")
              ->where([["advertiser_campaigns.id_advertiser","=",$value]])
              ->get()
              ->toArray();
               foreach ($data as $key => $val) {
               $res1 .= "<option value ='".$val->ops."'>".$val->op_name."</option>";
              }

              return $res1;

               
         }
         public function reverse(Request $request)
         {
            
          return view('advertiser.advertiser_reverse');
         }

         public function  savelist(Request $request)
         { 
               $value = new reverse_setting;
               $advertiser = $request->advertiser;
              $operator = $request->operator;
              $revrse_cca = $request->reverse_cca;
              $value->advetiser_id = $advertiser;
              $value->operator_id = $operator; 
              $value->reverse_cca_id = $revrse_cca;
               $value->save();
               return redirect()->route('reverseAdvertiserShowGet');
            }
            public function reverselist(Request $request)
            {

            $select = "reverse_setting.reverse_id, reverse_setting.advetiser_id, reverse_setting.operator_id, reverse_setting.reverse_cca_id as reverse, advertiser.name as advertiser_name, operator.name as operator_name"; 
                $data =  DB::table('reverse_setting')
                ->selectRaw(DB::raw($select))
                ->leftJoin("advertiser","advertiser.id", "=", "reverse_setting.advetiser_id")
                ->leftJoin("operator","operator.id" ,"=", "reverse_setting.operator_id")
                ->orderBy('reverse_setting.reverse_id','DECS')
                ->paginate(10);
                return view('advertiser.advertiser-reverse-view')->with('data',$data);

         }
          public function editReverse($reverse_id)
          {
            $select = "reverse_setting.reverse_id, reverse_setting.advetiser_id, reverse_setting.operator_id, reverse_setting.reverse_cca_id as reverse, advertiser.name as advertiser_name, operator.name as operator_name"; 
                
                
            $users = reverse_setting::where('reverse_id',$reverse_id)
            ->selectRaw(DB::raw($select))
            ->leftJoin("advertiser","advertiser.id", "=", "reverse_setting.advetiser_id")
            ->leftJoin("operator","operator.id" ,"=", "reverse_setting.operator_id")        
            ->get()
            ->first();
            
            return view('advertiser.update-reverse',compact('users'));
          }
          public function updateReverse(Request $request)
           {

            $select = "reverse_setting.reverse_id, reverse_setting.advetiser_id, reverse_setting.operator_id, reverse_setting.reverse_cca_id as reverse, advertiser.name as advertiser_name, operator.name as operator_name"; 
                $data =  DB::table('reverse_setting')
                ->selectRaw(DB::raw($select))
                ->leftJoin("advertiser","advertiser.id", "=", "reverse_setting.advetiser_id")
                ->leftJoin("operator","operator.id" ,"=", "reverse_setting.operator_id")
                ->orderBy('reverse_setting.reverse_id','DECS')
                ->get()
                ->first();
            $update = array('advetiser_id' => $request->advertiser,'operator_id' => $request->operator,'reverse_cca_id' => $request->reverse_cca);
            
           $advertiser = reverse_setting::where(['reverse_id' =>  $request->ereverse])->update($update);
      
            /*$users->reverse_id = $request->ereverse;
            $users->advetiser_id = $request->eadvertiser_drop;
            $users->operator_id = $request->eoperator_drop;
            $users->reverse_cca_id = $request->ereverseId;
            $users->save();*/
            return redirect()->route('reverseAdvertiserShowGet');
           }




    }
