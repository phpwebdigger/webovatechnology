<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\SmartRotatorCampaignsOpeators;
use Response;
use Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Redis;
use App\AdNetwork;
use DateTime;
use Config;
class TimeZoneReportController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    

    
    public function getCampaignName($id)
    {
        $dataMain= DB::table("advertiser_campaigns")
               ->select('advertiser_campaigns.name as offer_url','advertiser_campaigns.id as campaign_id')
               ->where('advertiser_campaigns.id',$id)
            ->get();
        return $dataMain=$dataMain->toArray();
    }
    
   
    public function getCampaignNameofferlist($country_code,$id_op,$os_type,$except){

               $dataMain= DB::table("advertiser_campaigns")
               ->select('advertiser_campaigns.name as offer_url','advertiser_campaigns.id as campaign_id')
               ->where('advertiser_campaigns.status','=','1')
               ->where('advertiser_campaigns.country_code','=',$country_code)
               ->where('advertiser_campaigns.id_op','=',$id_op)
               ->where('advertiser_campaigns.os_type','=',$os_type)
              ->whereNotIn('advertiser_campaigns.id',$except)->orderby('advertiser_campaigns.name')
        ->get();
        $dataMain=$dataMain->toArray();
        return $dataMain;
    }


    
    



    public function index_adv_reports(Request $request,$advertiser_id=null,$operator_id=null,$parent_cca=null,$viewPage = "zone.smart_advertiser_view",$type=null,$cat = array('SM','SG')){

            $role_id='';
        $condtion = $data1= $select_opertings=$campaigndata= [];
        $total_sale_count = $count = $totalClick = $actualcount = $totalconversion = $clicks_active_count = $unique_conversion = $totalCostDollar = $totalRevenueDollar = $totalprofit = $finalprofit_ECPM = $total_cap= $total_cap_remain= $totalconversionuniquew=  0;
//        $dtvalue = $request->start;
//        $dtvalue2 = $request->end;
        $id_channel =  $request->id_channel;

        $advertiser_id_offer_cca = $advertiser_id;
        $op_id_offer_cca = $operator_id;


//        if(is_null($dtvalue)){
//            $dtvalue = date('Y-m-d');
//        }
//        if(is_null($dtvalue2)){
//                $dtvalue2 = date('Y-m-d');
//                $enddate = date('Y-m-d',strtotime("+1 days"));
//        }else{
//           if($dtvalue == $dtvalue2){ 
//              $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));
//           }else{
//            $enddate = date('Y-m-d',strtotime($dtvalue2));
//           }
//        }
        
        $dtvalue = date('Y-m-d');
        
//        array_push($condtion,['crdt.create_time','<=',$enddate] );
        $role_id = Auth::user()->email;
        
        if($request->time_zone && $request->time_zone != '')
        {
            if(count($request->time_zone) > 0 )
            {
                $time_zone = $request->time_zone;
            }
        }
        else
        {
            $date = explode(" - ",$request->date);
            if(count($date) > 1){
             $startDate = date('Ymd',strtotime($date[0]));
             $endDate = date('Ymd',strtotime($date[1]));
            }
        }
         
         
         

        $select_country =[];  $select_verticaltype=[]; $select_vertical =[];$select_os='';
        $country_arr = $operator_id_arr= $operating_id_array=[];

        $advertiser_id= $request->id_advertiser;


        if($request->operating_id){
            $select_opertings=$request->operating_id;
            if(count($request->operating_id) > 1 )
            {
                $operating_id_array = $request->operating_id;
            }
            else
            {
                array_push($condtion,['advertiser_campaigns.os_type','=',$request->operating_id[0]]);
            }
        }


        if($request->vertical){
            $select_vertical=$request->vertical;
            if(count($request->vertical) > 1 )
            {
                $select_verticaltype = $request->vertical;
            }
            else
            {
                array_push($condtion,['advertiser_campaigns.vertical','=',$request->vertical]);
            }
        }

        if($request->country && $request->country !== 0)
        {
            $flag = 1;
            $select_country = $request->country;
            if (count($request->country) > 1) {
                $country_arr = $request->country;
                $data = $data->Where(function ($query) use($country_arr) {
                    for ($i = 0; $i < count($country_arr); $i++) { //$country_arr[$i]
                        $query->orwhereRaw("find_in_set('" . $country_arr[$i] . "',advertiser_campaigns.country_code)");
                    }
                });
            } else {
                $data = $data->whereRaw("find_in_set('" . $request->country[0] . "',advertiser_campaigns.country_code)");
            }
        }
                
        if($time_zone)
        {
//            echo "Date value".$dtvalue;
//            echo "<br>";
//            print_r($time_zone);
//            echo "<br>";
//            echo "Zone = ".$time_zone; 
            
            array_push($condtion,['advertiser_campaigns.timezone','=',$time_zone]);
            
            
            $select_time_zone =  "id,timezone as timezone_data";
            $time_zone_data =  DB::table("advertiser_campaigns")
                            ->selectRaw(DB::raw($select_time_zone))
                            ->where('type','CPICPA')
                            ->where('timezone',$time_zone)
//                            ->orderby('id','desc')
                            ->limit(5020)
                            ->get();
//            echo "<pre>";
//            print_r($time_zone_data);
//            echo "</pre>";
            
            
            
            
            $current_hour = date("H");
//            echo "<br>";
//            echo "CURRENT HOUR = ".$current_hour;
//            echo "Date value".$dtvalue; 
//            print_r($time_zone);
//            $result=$this->time_zone_rt($dtvalue,$timezone='true',$time_zone[0]);
            $result=$this->time_zone_rt($dtvalue,$timezone='true',$time_zone);
//                echo "RESULT = ".$result;
//                echo "<br>";
            $explode_date = explode(" ",$result);
            $exp_dt = $explode_date[0];
            
//                echo "<br>";
//                echo "<pre>";
//                print_r($explode_date);
//                echo "</pre>";
                
            $explode_hour = explode(":",$explode_date[1]);
                
//                echo "<pre>";
//                print_r($explode_hour);
//                echo "</pre>";
//                  $data = $data->where(DB::raw('date(con1.datetime)'),'>=',$result);
                
                
//            array_push($condtion,['crdt.date','=',$exp_dt]);
            
            $yesterday = date('Y-m-d', strtotime($exp_dt . " - 1 day"));
            
//            echo "<br>";
//            echo "YESTER DAY = ".$yesterday;
//            echo "<br>";
            $act_exp_hr = $explode_hour[0];
//            echo "ACTUAL EXPLODED HOUR = ".$act_exp_hr;
//            echo "<br>";
            
            if($act_exp_hr > $current_hour)
            {
                array_push($condtion,['crdt.date','>=',$yesterday] );
            }
            else
            {
                array_push($condtion,['crdt.date','=',date('Y-m-d')] );
                array_push($condtion,['crdt.hour','>=',$explode_hour[0]]);
            }
            
            
        }
        else
        {
            array_push($condtion,['advertiser_campaigns.timezone','=','Asia/Kolkata']);
        }
        


        
        
        
        
        
        
        
        
        
        
        
        
        
//        foreach ($time_zone_data as $time_zone) 
//        {
//            $camp_id[$time_zone->id] = $time_zone->id;
//            
//            $data_value[$time_zone->id] = $this->time_zone_rt($dtvalue,$timezone='true',$time_zone->timezone_data);
//            
//            $explode_date[$time_zone->id] = explode(" ",$data_value[$time_zone->id]);
//            
//            $exp_dt[$time_zone->id] = $explode_date[$time_zone->id][1];
//            
//            $explode_hour[$time_zone->id] = explode(":",$exp_dt[$time_zone->id]);
//            
//            $actual_hour[$time_zone->id] = $explode_hour[$time_zone->id][0];
//            
//            
////            array_push($condtion,['crdt.hour','=',$actual_hour[$time_zone->id]]);
//        }
         
         
//        echo "<pre>";
//        print_r($camp_id);
//        echo "</pre>";
//        echo "<pre>";
//        print_r($exp_dt);
//        echo "</pre>";
//        echo "<pre>";
//        print_r($actual_hour);
//        echo "</pre>";
//        echo "<pre>";
//        print_r($time_zone_data);
//        echo "</pre>";
        
//            array_push($condtion,['crdt.hour','=',$explode_hour[0]]);
            
        
        
//         die();
         
         
         
         
         
        $select =  "crdt.id_advertiser as id,"
                    ."crdt.advertiser_campain_name as name,"
                    ."advertiser_campaigns.url,"
                    ."advertiser_campaigns.payout_type,"
                    ."crdt.report_type as type,"
                    ."advertiser_campaigns.vertical,"
                    ."advertiser_campaigns.os_type,"
                    ."advertiser_campaigns.country_code,"
                    ."advertiser_campaigns.cpa as ac_cpa,"
                    ."advertiser_campaigns.id_op as id_op,"
                    ."crdt.id_channel,"
                    ."crdt.id_advertiser_campaign,"
                    ."crdt.clickcount_fraud as fraud,"
                    ."crdt.id_ad as id_ad,"
                    ."sum(crdt.clickcount) AS clickcount,"
                    ."sum(crdt.conversion_count) AS conversion_count,"
                    ."sum(crdt.clicks_active_count) as clicks_active_count,"
                    ."sum(crdt.conversion_count_unique) as conversion_count_unique,"
                    ."sum(crdt.revenue_dollar) as revenue_dollar,"
                    ."sum(crdt.total_cost) as cost_dollars,"
                    ."CONCAT(crdt.cr_received,'%') AS cr_received,"
                    ."CONCAT(crdt.cr_given,'%') AS cr_given,"
                    ."crdt.date as create_time,"
                    ."crdt.hour as hour,"
                    ."crdt.traffic_type,"
                    ."sum(crdt.sale_count) as sale_count,"
                    ."advertiser_campaigns.cap_count_conversions as total_cap,"
                    ."advertiser_campaigns.timezone as timezone,"
                    ."crdt.parent_cca,"
                    ."advertiser_campaigns.id_op as operator_name,"
                    ."crdt.id_advertiser as advtr_id,"
                    ."crdt.advertiser_name  as adv_name";
                
                        $data =  DB::table("crc_records_details as crdt")
                            ->selectRaw(DB::raw($select))
                            ->where('crdt.report_type','CPICPA')
                            ->where($condtion)
                            ->leftJoin("advertiser_campaigns","advertiser_campaigns.id","=","crdt.id_advertiser_campaign")
                            ->leftJoin("advertiser","advertiser.id","=","advertiser_campaigns.id_advertiser")
                            ->groupby("crdt.id_advertiser_campaign")
                            ->orderby("crdt.revenue_dollar",'desc')
//                            ->limit("20")
                            ->get();
         
         
                    foreach ($data as $result) 
                    {
                            $array = $data = $rtotal = [];
                            $count++;
                          
                            $profit_dollar = $result->revenue_dollar - $result->cost_dollars;
                            $profit = round($profit_dollar * 70,2);                            
                            $profit_both = "<span class=dollar>$profit_dollar</span>";                            
                            $totalprofit = $totalprofit + $profit_dollar;
                            
                            $actualClick = $result->clickcount - $result->fraud;
                            $cost_dollar = round($result->cost_dollars,2);
                            $cost_dollar_ruppes = round($result->cost_dollars*70);
                            $revenue_dollar = round($result->revenue_dollar,2);
                            $revenue_dollar_ruppes = round($result->revenue_dollar * 70);
                            $remain_cpa =$result->total_cap-$result->conversion_count_unique;                            
                            
                            
                            $array[] =  $result->id_advertiser_campaign;                            
                            $array[] =  $result->adv_name."(".$result->id_advertiser.")";                            
                            $array[] =  '<span title="'.$result->name.'">'.$result->name.'('.$result->id_advertiser_campaign.')</span>';
                            $array[] =   $result->timezone;
                            $array[] =   $result->country_code;
                            $array[] =   $result->vertical;
                            $array[] =   $result->os_type;
                            $array[] =   $result->total_cap;
                            $array[] =   $remain_cpa;
                            $array[] =   $actualClick;
                            $array[] =   $result->conversion_count_unique;                            
                            $array[] =   $result->sale_count;                            
                            $array[] =   $result->clicks_active_count;
                            if($result->conversion_count > 0 && $result->clickcount>0)
                            {
                                $cr_ins=round(($result->conversion_count / $result->clickcount)*100,2);
                                $array[] = $cr_ins == 0 ? '0.00 %' : $cr_ins;
                            }
                            else
                            {
                                $array[] =  '0.00';    
                            }

                            if($result->conversion_count > 0 && $actualClick > 0)
                            {
                                $cr_nisns  = round(($result->clicks_active_count / $actualClick)*100,2);
                                $array[]   =  $cr_nisns == 0 ? '0.00 %' : $cr_nisns;
                            }
                            else
                            {
                                $array[] =  '0.00';    
                            }                           

                            $array[] =   "<span class=dollar>".$cost_dollar."</span>";
                            $array[] =   round($result->revenue_dollar,2);
                            $array[] =   $profit_both;
                              
                        
                            array_push($data1, $array);
                                $total_sale_count = $total_sale_count + $result->sale_count; 
                                $total_cap = $total_cap+$result->total_cap;
                                $total_cap_remain = $total_cap_remain + $remain_cpa;
                                $totalClick = $totalClick + $result->clickcount;
                                $actualcount = $actualcount + $actualClick;
                                $totalconversion = $totalconversion + $result->conversion_count;
                                $totalconversionuniquew = $totalconversionuniquew +$result->conversion_count_unique;
                                
                                $clicks_active_count = $clicks_active_count + $result->clicks_active_count;                                
                                $unique_conversion = $unique_conversion + $result->conversion_count_unique;                                
                                $totalCostDollar = $totalCostDollar + round($result->cost_dollars,2);
                                $totalRevenueDollar = $totalRevenueDollar + round($result->revenue_dollar,2);
                                
                        }   

                    $lastRow =[$actualcount, $totalconversionuniquew,$total_sale_count,$clicks_active_count,$totalCostDollar,'$'.$totalRevenueDollar,$totalprofit];
         
                    
                    $countrydata =  DB::table("country");
                    $countrydata = $countrydata->selectRaw("distinct(country.iso),country.name")
                        ->orderby("country.name")
                            ->get();


                    $osdata =  DB::table("crc_records_new");
                    $osdata = $osdata->selectRaw("distinct operator.name,operator.id")
                        ->leftJoin("operator","operator.id","=","crc_records_new.op_id")
                        ->where("crc_records_new.op_id","!=","")
                        ->get();
                    
                    
                    
                    
                      $result  = array('data1' => $data1,            
                        'dtvalue' => $dtvalue,
                        'dtvalue2' => $dtvalue2,
                        'lastRow'=>$lastRow,
                          'countryarray' => $countrydata,
                          'oslist' =>$osdata,
                           'role' => $role_id,
                          'select_id_advertiser'=>$advertiser_id,
                          'select_country'=>$select_country,
                          'select_opertings'=>$select_opertings,
                           'selected_vertical'=>$select_vertical,
                           'time_zone'=>$time_zone
                      );
                    
                    $dataN =  view($viewPage)->with($result);
                    return $dataN;
                }

    public function time_zone_rt($tdate,$timezone='false' , $timezone_value){
      if($timezone){
      $datetime1 = new \DateTime();
          $datetime1->setTimezone(new \DateTimeZone('Asia/Calcutta'));
          $local_time=$datetime1->format('Y-m-d H:i:s');


           $datetime = new \DateTime();
           $datetime->setTimezone(new \DateTimeZone($timezone_value));
           $new_date=$datetime->format('Y-m-d');

           

            $MNTTZ = new \DateTimeZone($timezone_value);
            $ESTTZ = new \DateTimeZone('Asia/Calcutta');
              
            $dt = new \DateTime($tdate.' 00:00:00', $MNTTZ);
            $dt->format('Y-m-d H:i:s');
            $dt->setTimezone($ESTTZ);
            $result =$dt->format('Y-m-d H:i:s');
          }

          return $result;
    }
    
    

    /* To show network wise smart record */
    public function offer_networkwise(Request $request){
        $advertiser_id = $operator_id = $parent_cca = "";
        $type = "network";
        $template_name = "smart.networkwise";
        $cat = ['OM','OG'];
        return $this->index_adv($request,$advertiser_id,$operator_id,$parent_cca,$template_name,$type,$cat);   
    }
    
    
    
    

    /* To show advertiser wise data for OM OG category */
    public function time_zone_offer_advertiser(Request $request){
        $advertiser_id = $operator_id = $parent_cca = "";
        $type = "advertiser";
        $template_name = "zone.smart_advertiser_view";
        $cat = ['OM','OG'];
        return $this->index_adv_reports($request,$advertiser_id,$operator_id,$parent_cca,$template_name,$type,$cat);   
    }

         /* show cca by advertiser*/
    public function getofferccabyadvertiser(Request $request,$advertiser_id,$operator_id){
           $advertiser_id=$request->advertiser_id;
           $operator_id=$request->operator_id;

        $template_name =  'smart.offerccaByAdvertiser';
        $type = 'offerccabyadvertiser';
        $cat = ['OM','OG'];
        $parent_cca = ""; 
        return $this->index_adv_reports($request,$advertiser_id,$operator_id,$parent_cca,$template_name,$type,$cat);
    }



    public function get_camp(Request $request){
        $condtion = [];
        $select_adv =  ["id","name"];
        $advertier_data =  DB::table("advertiser")->select($select_adv)->get();
		    $select_opr =  ["opr.id","opr.name","opr.country_code as iso"];
        $oprdata =  DB::table("operator as opr")->select($select_opr)->leftjoin('country as count', 'count.iso', '=', 'opr.country_code')->get();
        $select_country =  ["id","iso","name"];
        $country_data =  DB::table("country")->select($select_country)->get();
		    $result  = array(
            'operator' => $oprdata,
            'country' => $country_data,
            'advertiser'=> $advertier_data
        );
        $viewPage = "smart.smart_interface_add";
        $dataN =  view($viewPage)->with($result);
        return $dataN;
    }

    public function get_oprator(Request $request){
        $condtion = [];
        $country=$request->country;
//        $select_opr =  ["id","name"];
//        $advertier_data =  DB::table("advertiser")->select($select_adv)->get();
		    $select_opr =  ["opr.id","opr.name","opr.country_code as iso"];
        $oprdata =  DB::table("operator as opr")->select($select_opr)->leftjoin('country as count', 'count.iso', '=', 'opr.country_code')
                ->where("opr.country_code","=",$country)->get();
        $data="";
        foreach($oprdata as $opr)
        {
            $data .= "<option value='".$opr->id."'>".$opr->name."(".$opr->iso.")</option>";
        }
        return $data;
    }
    
    
    public function percent_update(Request $request){
        $id = $request->id;
        $waitage_percent = $request->waitage_percent;
        if($id && ($waitage_percent || $request->exists('waitage_percent'))){
            $update = DB::table('smart_rotator_campaigns_operators')
                      ->where('id', $id)
                      ->limit(1)  // optional - to ensure only one record is updated.
                      ->update(array('waitage_percentage' => $waitage_percent)); 
            if($update){ 
                $status =  array('status'=>1);
            }else{
                $status =  array('status'=>2);
            }
        }else{
            $status =  array('status'=>3);
        }
        return json_encode($status);
    }

    /* To update waitage_type in advertiser_campaigns */
    public function waitagetype_update(Request $request){
        $id = $request->id;
        $waitage_type = $request->waitage_type;
        $waitage_time = $request->waitage_time;
        if(!empty($id) && !empty($waitage_type)){
        $update = DB::table('smart_rotator_campaigns_operators')
            ->where('id', $id)
             ->limit(1)  // optional - to ensure only one record is updated.
            ->update(array('waitage_type' => $waitage_type,'waitage_time' => $waitage_time)); 
            if($update){
               $status =  array('status'=>1,'message'=>'Successfully Fraud status updated!');
            }else{
               $status =  array('status'=>2,'message'=>'Sorry please try again!');
            }
        }else{
           $status =  array('status'=>3,'message'=>'Oops, something went wrong!');
        }
        return $status;
    }

    public function click_update(Request $request){
        $id = $request->id;
        $cap_count_click = $request->click_count;
        if(!empty($id) && !empty($cap_count_click)){
          $update = DB::table('smart_rotator_campaigns_operators')
            ->where('id', $id)
            ->limit(1)  // optional - to ensure only one record is updated.
            ->update(array('cap_count_click' => $cap_count_click)); 
            if($update){
               echo 1;
                exit();
            }else {
                echo 2;
                exit();
            }
        }else{
            echo 3;
            exit();
        }
    }

    public function conversion_update(Request $request){
        $id = $request->id;
        $conversion_count = $request->conversion_count;
        if(!empty($id) && !empty($conversion_count)){
            $update = DB::table('smart_rotator_campaigns_operators')
            ->where('id', $id)
            ->limit(1)  // optional - to ensure only one record is updated.
            ->update(array('cap_count_conversions' => $conversion_count)); 
            if($update){
               echo 1;
                exit();
            }else {
                echo 2;
                exit();
            }
        }else{
            echo 3;
            exit();
        }
    }

    public function fraud_update(Request $request){
        $id = $request->id;
        $status = $request->status;
        if(!empty($id) && $status != ''){
            if($status=='1'){
                $statuss = '0';
            }else{
                $statuss = '1';
            }
            $update = DB::table('advertiser_campaigns')
            ->where('id', $id)
            ->limit(1)  // optional - to ensure only one record is updated.
            ->update(array('is_fraud' => $statuss)); 
            if($update){
               $status =  array('status'=>1,'message'=>'Successfully Fraud status updated!');
            }else{
               $status =  array('status'=>2,'message'=>'Sorry please try again!');
            }
        }else{
           $status =  array('status'=>3,'message'=>'Oops, something went wrong!');
        }
        return $status;
    }
    
    /* To change the smart_live status of Campaign*/
    public function livestatus_update(Request $request){
       $smartoperator_id = $request->id; #smart_campaign_id
       $campaign_id = $request->campaign_id; #smart_campaign_id
       $is_live = $request->is_live;  #1 live,0 nt live 
       $update_smart = '';
       if($campaign_id){
         $checkCampaign = DB::Select("select status from advertiser_campaigns where id=$campaign_id");
         if($checkCampaign){ 
            if($checkCampaign[0]->status == 0 && $is_live == 1){
              $status =  array('status'=>2,'message'=>'Please activate the campaign  first!');
              return $status;
            }
         }     
         if($smartoperator_id){
              $update = DB::table('smart_rotator_campaigns_operators')->where('id',$smartoperator_id)->update(array('smart_live' => $is_live));
             if($update){
                 $status =  array('status'=>1,'message'=>'Successfully Status updated!');
              }else{
                 $status =  array('status'=>2,'message'=>'Sorry please try again!');
              }
          }else{
              $status =  array('status'=>3,'message'=>'Oops, something went wrong!');
          }
        }
        return $status;
    }

    /*  To remove the campaign from the smart_rotator_campaigns_operators table*/
    public function smartStatus_update(Request $request){
        $smartoperator_id = $request->smartoperator_id;
        if($smartoperator_id){
             $update = DB::table('smart_rotator_campaigns_operators')
            ->where('id', $smartoperator_id)
            ->limit(1)  // optional - to ensure only one record is updated.
            ->update(['smart_status' => '0']);
            if($update){
                $status = array('status'=>'1','message'=>'This campiagn is removed');
            }else{
                $status = array('status'=>'2','message'=>'This campiagn is not removed');
            }
        }else{
            $status = array('status'=>'3','message'=>'Oops something went wrong');
        }    
        return json_encode($status);
    }

    

    public function smartDesktop_update(Request $request){
       $id = $request->id;
       $option_type = $request->option_type;
       if(!empty($id) && $option_type != ''){
        $update = DB::table('smart_rotator_campaigns_operators')
            ->where('id', $id)
            ->limit(1)  // optional - to ensure only one record is updated.
            ->update(array('is_desktop' => $option_type)); 
            if($update){
            echo 1;exit();
            }else{
            echo 2;exit();
            }
        }else{
            echo 3;
            exit();
        }
    }
    
    /* TO save and update smart campaign */
    public function store(Request $request){
        $operator_country = $datawgwm = [];
        $adv_camp_id = $request->adv_camp_id;
        $adv_camp_ids = explode(',',$request->adv_camp_id); 
        $operator_id = explode(',',$request->opr_list);
        $country_iso = $request->country_id;
        $cat_list = "'".$request->cat_list."'";  
        $adv_list = explode(',', $request->adv_list);
        $operator_name = $request->operator_name;
        $operator_name_arr = explode(")",$operator_name);
        $cat_data = ['WM','WG'];
        $waitage_percentage = "'".$request->waitage_percentage."'";
        $waitage_type = "'".$request->waitage_type."'";
        $waitage_time = $request->waitage_time;
        $dataOP = DB::select("select `operator`.`country_code`,`operator`.`id` from `operator` where `operator`.`status` = 1 "
                 . "and `operator`.`id` in ($request->opr_list) order by `operator`.`name` asc");
        foreach($dataOP as $op_co_name){
            if($op_co_name->id == 33){
              $operator_country[] = $country_iso;  
            }else{
              $operator_country[] = $op_co_name->country_code;
            }
        }
       
        if($request->exists('opr_list') && $request->adv_camp_id){
           $sql_insertroute = "Insert into smart_rotator_campaigns_operators(`campaign_id`,`op_id`,`smart_status`,`country_code`,`ads_cat`,`waitage_percentage`,`waitage_type`,`waitage_time`) values ";
            $n = count($operator_id);
            $vals = array();
            for($i=0;$i<$n;$i++){
                $campaign_id = $adv_camp_id;
                $op_id = isset($operator_id[$i]) ? "'".$operator_id[$i]."'" : "NULL";
                $status = '1';
                $country_code = isset($operator_country[$i]) ? "'".$operator_country[$i]."'" : "NULL";
                $operator_name = isset($operator_name_arr[$i]) ? "'".$operator_name_arr[$i]."'" : "no operator";
                $campaign_exist = $this->checkCampaign($campaign_id,$cat_list,$op_id,$country_code);
                array_push($vals, "($campaign_id, $op_id,$status,$country_code,$cat_list,$waitage_percentage,$waitage_type,$waitage_time)");
                if($campaign_exist){ break;}
            }
            /* To check campaign exist in smart operator*/
            if($campaign_exist){
            $status =  array('status'=>3, 'message'=>"$campaign_exist exist for operator $operator_name)"); 
            }else{
                $sql_insertroute .= implode(', ', $vals);
                $sqlResult = DB::insert($sql_insertroute);
                if($sqlResult){
                $status =  array('status'=>1, 'message'=>"campaign inserted ");
                }else{
                $status =  array('status'=>2, 'message'=>"Not inserted");
                }
            }    
        }
        return json_encode($status);
      }

    

    /* To check Campaign */ 
    public function checkCampaign($campaign_id,$cat_list,$op_id,$country_code){
       if($campaign_id && $op_id){
         $country_condition = " AND 1=1"; 
         if($country_code){
          $country_condition = " AND country_code = $country_code";
         }         
         $sql = "Select count(1) as campaignCount from smart_rotator_campaigns_operators where campaign_id = $campaign_id AND ads_cat = $cat_list AND op_id = $op_id $country_condition limit 1";
         $result = DB::select($sql);
         if($result[0]->campaignCount > 0){
            return $campaign_id;
         }
       }
       return false;
    }    

    // AJAX call for get campign
    public function get_campaign(Request $request){   
        $data = $ddDataResult1  = [];
        $country = $request->country;
        $opr_list = $request->opr_list;
        $cat_list = $request->cat_list;
        $adv_list = $request->adv_list;
        $cc = $operator = "";
        $category_condition = ""; 
        $condition = "1=1";
        
        if($adv_list){
           $condition .= " AND id_advertiser = '".$adv_list."'";
           $category_condition .= " AND id_advertiser = '".$adv_list."'";
           $category_condition .= " AND status = '1'";
        }
        
        if(($cat_list != 'WM' || $cat_list != 'WG') && $cat_list){
            $condition .= " AND ads_cat = '".$cat_list."'";
        }

        if($opr_list !=""){
            $operator = "$opr_list";
            if(is_array($opr_list)){
                $opr = explode(",", $opr_list);
                $operator = "'" . implode("','", $opr) . "'";
            }
            $condition .= " AND id_op IN ($operator)";
        }
        if($country){
            $condition .= " AND country_code = '".$country."'";
        }
        $condition  .= " AND status = '1'";
        $data = DB::select("select id,name,ads_cat from advertiser_campaigns Where $condition UNION select id,name,ads_cat from advertiser_campaigns where ads_cat IN ('WG','WM') $category_condition");
        foreach ($data as $dropdown){            
            $ddDataResult1[$dropdown->id]['name'] = $dropdown->name." (".$dropdown->id.")(".$dropdown->ads_cat.")";
            $ddDataResult1[$dropdown->id]['cat_id'] = $dropdown->ads_cat;
        }
        if($ddDataResult1){
            $status = array('status'=>1,'data'=>$ddDataResult1);
        }else{
            $status = array('status'=>2,'data'=>$ddDataResult1);  
        }
        return json_encode($status);
    }

    /* Edit Smart Campaign data*/
    public function edit(Request $request,$id){
        $condition = $operator_condition = [];
        $is_offer  = $request->is_offer;
        if($id){
            array_push($condition,["SR.id","=",$id] );
        }
        $select_camp =  [
            "AC.name",
            "AC.id_advertiser",
            "AC.cpa",
            "AC.url",
            "SR.includes",
            "SR.excludes", 
            "SR.campaign_id",
            "SR.waitage_percentage",
            "SR.waitage_type",
            "SR.waitage_time",
            "SR.id",
            "SR.op_id",
            "SR.cap_count_click",
            "SR.cap_count_conversions",
            "SR.start_date",
            "SR.end_date",
            "SR.ads_cat",
            "SR.country_code",
            "SR.smart_live",
            "SR.smart_status",
            "SR.is_desktop"

          ];
        
        $camp_data =  DB::table("smart_rotator_campaigns_operators as SR")
         ->where($condition)
         ->leftJoin("advertiser_campaigns as AC","SR.campaign_id","=","AC.id")
         ->select($select_camp)
         ->limit(1)
         ->get();
        
        $decode_data = json_decode($camp_data, true);
        $includes =  json_decode($decode_data[0]['includes']);
        $excludes =  json_decode($decode_data[0]['excludes']);
        
        $select_country =  ["iso","name"];
        $country_data =  DB::table("country")->select($select_country)->get();
        $select_opr =  ["id","name","country_code"];

        array_push($operator_condition,["country_code","=",$decode_data[0]['country_code']]);
        
        $operator_data =  DB::table("operator")
         ->where($operator_condition) 
         ->select($select_opr)
         ->get();
        echo $is_offer;
        $result  = array(
            'data' => $decode_data[0],
            'country_data' => $country_data,
            'operator_data' => $operator_data,
            'includes' => $includes,
            'excludes' => $excludes,
            'is_offer' => $is_offer
          );
        $viewPage = "smart.smart_interface_edit";
        $dataN =  view($viewPage)->with($result);
        return $dataN;
    }

    
    /* Update smart campaign data*/ 
    public function update(Request $request){
        $smartOperator_id = $request->id;
        $campaign_id = $request->campaign_id;
        $country_code = $request->country;
        $operator_code = $request->operator;
        $category = $request->category;
        $waitage_percentage = $request->waitage_percentage;
        $waitage_type = $request->waitage_type;
        $waitage_time = $request->waitage_time;
        $conversion_count = $request->cap_count_conversions;
        $click_count = $request->cap_count_click;
        $start_datetime = $request->start_datetime;
        $end_datetime = $request->end_datetime;
        
        /* Includes */
       $includes['network'] = $include_network = $request->include_network;
       $includes['referrer'] = $include_referrer = $request->include_referrer;
       $includes['site_id'] = $include_siteid = $request->include_siteid;
       $includes['os'] = $include_os = $request->include_os;
       $includes['browser'] = $include_browser = $request->include_browser;
        
        /* Excludes */
       $excludes['network'] = $exclude_network = $request->exclude_network;
       $excludes['referrer'] = $exclude_referrer = $request->exclude_referrer;
       $excludes['site_id'] = $exclude_siteid = $request->exclude_siteid;
       $excludes['os'] = $exclude_os = $request->exclude_os;
       $excludes['browser'] = $exclude_browser = $request->exclude_browser;
       $includes_all = json_encode($includes);
       $excludes_all = json_encode($excludes);
       $smart_status = $request->smart_status;
       $is_offer = $request->is_offer;
       if($smartOperator_id && $country_code && $category){
            $SmartRotator = SmartRotatorCampaignsOpeators::find($smartOperator_id);
            $SmartRotator->country_code =  $country_code;
            $SmartRotator->op_id =  $operator_code;
            $SmartRotator->ads_cat =  $category;
            $SmartRotator->smart_status =  $smart_status;
            $SmartRotator->waitage_percentage =  $waitage_percentage;
            $SmartRotator->waitage_type = $waitage_type;
            $SmartRotator->waitage_time = $waitage_time;
            $SmartRotator->cap_count_conversions =  $conversion_count;
            $SmartRotator->cap_count_click =  $click_count;
            $SmartRotator->start_date = $start_datetime;
            $SmartRotator->end_date =  $end_datetime;
            $SmartRotator->includes =  $includes_all;
            $SmartRotator->excludes =  $excludes_all;
            $SmartRotator->is_desktop =  $request->is_desktop;
            $SmartRotator->save();
            if($SmartRotator){
                $status = array("status"=>1,'message'=>'Updated Successfully');   
            }else{
                $status = array("status"=>2,'message'=>'Not Updated Successfully');
            }
        }else{
             $status = array("status"=>3,'message'=>'Some thing went wrong');           
        }
        return json_encode($status);
    }
    
    public function publisherOfferList(Request $request){
                
//        echo "<pre>";
//        print_r($request->all());
//        echo "</pre>";
//        die();
//       
        $condtion = $data1= [];
        $cat = ['OM','OG'];
        
        $selected_date = $request->start_date;
        $end_date = $request->end_date;
        $nwtwork = $request->network_name;
        $campaign = $request->campaign_name;
        $diversion = $request->diversion;
        $only_status = $request->only_status;
        $condi = '';
        if(!empty($nwtwork))
        {
            $zone = "'" . implode ( "', '", $nwtwork ) . "'";
            $condi .=' AND smart_rotator_campaigns_operators.id_zone IN ('.$zone.')';
        }
        
        if(!empty($campaign))
        {
            $campaign_id = "'" . implode ( "', '", $campaign ) . "'";
            $condi .=' AND smart_rotator_campaigns_operators.campaign_id IN ('.$campaign_id.')';
        }
        if($only_status != '')
        {
            $condi .=" AND smart_rotator_campaigns_operators.smart_live = "."'$only_status'";
        }
        if($diversion != '')
        {
            $condi .=" AND smart_rotator_campaigns_operators.is_offer_direct = "."'$diversion'";
        }
        if($selected_date != '' && $end_date != '')
        {
            $condi .=" AND date(smart_rotator_campaigns_operators.start_date) >= "."'$selected_date'".
                     " AND date(smart_rotator_campaigns_operators.start_date) <= "."'$end_date'";
        }
 
        $networksResult = DB::select("select distinct(adn.ccz), adn.id, adn.name from ad_network as adn INNER JOIN smart_rotator_campaigns_operators as smt ON adn.ccz = smt.id_zone WHERE smt.smart_status = '1' AND smt.ads_cat in ('OM','OG') order by adn.name ASC");
        
        $CampaignsResult = DB::select("select distinct(ac.id), ac.name from advertiser_campaigns as ac INNER JOIN smart_rotator_campaigns_operators as crd ON ac.id = crd.campaign_id WHERE crd.smart_status = '1' AND crd.ads_cat in ('OM','OG') ORDER BY ac.name ASC");
        
        $select =  
            "select smart_rotator_campaigns_operators.campaign_id as cca,
            smart_rotator_campaigns_operators.id as srco_id,
            smart_rotator_campaigns_operators.id_zone as zone,
            smart_rotator_campaigns_operators.smart_live as active,
            smart_rotator_campaigns_operators.offer_url as offer_url,
            smart_rotator_campaigns_operators.cap_count_conversions as cap_count_conversions,
            smart_rotator_campaigns_operators.cap_count_click as cap_count_click,
            smart_rotator_campaigns_operators.cap_count_install as cap_count_install,
            smart_rotator_campaigns_operators.cap_count_sale as cap_count_sale,
            ad_network.name as network_name,
            smart_rotator_campaigns_operators.publisher_cpa as cpa,
            smart_rotator_campaigns_operators.publisher_kpi as publisher_kpi,
            smart_rotator_campaigns_operators.ads_cat as traffic_type,
            advertiser_campaigns.name,
            advertiser_campaigns.offername,
            advertiser_campaigns.advtrackinglink,
            advertiser_campaigns.id,
            smart_rotator_campaigns_operators.is_offer_direct as trfc,
            smart_rotator_campaigns_operators.status as status,
            smart_rotator_campaigns_operators.start_date as approve_date,
            advertiser_campaigns.os_type,
            advertiser_campaigns.country_code as country_code,
            config_delivery.lower_limit as filter,
            config_delivery.filter_status as filter_status,
            config_delivery.postback_status as postback_status 
            from smart_rotator_campaigns_operators as smart_rotator_campaigns_operators            
            LEFT JOIN advertiser_campaigns as advertiser_campaigns ON advertiser_campaigns.id = smart_rotator_campaigns_operators.campaign_id
            LEFT JOIN ad_network as ad_network ON ad_network.ccz = smart_rotator_campaigns_operators.id_zone
            LEFT JOIN config_delivery as config_delivery ON config_delivery.id_zone = smart_rotator_campaigns_operators.id_zone AND
                config_delivery.id_ad = smart_rotator_campaigns_operators.campaign_id WHERE smart_rotator_campaigns_operators.ads_cat IN ('OM','OG')
                $condi
            ORDER BY smart_rotator_campaigns_operators.id DESC 
            ";
        
            $data = Cache::remember('publisherOfferList',1, function () use ($select) {
                return   DB::select(DB::raw($select));
            });
       

                    foreach ($data as $result) 
                    {
                        $active = $filter_st = $postback = '';
                        if($result->active == '1')
                        {
                            $active = 'Active';
                        }
                        else
                        {
                            $active = 'Pause';
                        }
                        
                        if($result->filter_status == '1')
                        {
                            $filter_st = 'Active';
                        }
                        else
                        {
                            $filter_st = 'Inactive';
                        }
                        
                        if($result->postback_status == '1')
                        {
                            $postback = 'Active';
                        }
                        else
                        {
                            $postback = 'Inactive';
                        }  
                           
                           if($result->status == '5')
                        {
                            $backcolor = 'style="background-color:#FE6BD7;color:000"';
                        }
                        else
                        {
                            $backcolor = 'style="background-color:#25F3EC;color:000"';
                        }  

                        
    
                        $array = $data = $rtotal = [];
                        $offer_url = "'".$result->offer_url."'";
                        
                        $array[] =  $result->cca;

                        $array[] =  '<a href="javascript:void(0);" onclick="changeActStatus('.$result->cca.','.$result->zone.','.$result->srco_id.','.$result->active.');"><i class="fa fa-pencil"></i><span id="active_status_'.$result->srco_id.'">'.$active.'</span></a><span id="'.$result->srco_id.'" class="new_status_change" ><input type="checkbox" name="new_active_status_'.$result->srco_id.'" id="new_active_status" onclick="getSelectedValue(this, value);" /><label style="display:none;">'.$result->srco_id.'</label></span>';

                        $array[] =  $result->network_name." {".$result->zone."}"; 

                        $array[] =  '<a  href="javascript:void(0);" onclick="changeCpa('.$result->cca.','.$result->zone.','.$result->srco_id.','.$result->cpa.');"><i class="fa fa-pencil"></i><span id="cpa_'.$result->srco_id.'">'.$result->cpa.'</span></a>';
                        //Pub Install Cap
                        $array[] =  '<a '.$backcolor.' href="javascript:void(0);" onclick="changeCap('.$result->cca.','.$result->zone.','.$result->srco_id.','.$result->cap_count_conversions.');"><i class="fa fa-pencil"></i><span id="cap_conversion_'.$result->srco_id.'">'.$result->cap_count_conversions.'</span></a>';

                        //cap_count_click

                             $array[] =  '<a '.$backcolor.' href="javascript:void(0);" onclick="changeCapClick('.$result->cca.','.$result->zone.','.$result->srco_id.','.$result->cap_count_click.');"><i class="fa fa-pencil"></i><span id="cap_countclick_'.$result->srco_id.'">'.$result->cap_count_click.'</span></a>';

                        //cap_count_install     
                                $array[] =  '<a '.$backcolor.' href="javascript:void(0);" onclick="changeCapinstall('.$result->cca.','.$result->zone.','.$result->srco_id.','.$result->cap_count_install.');"><i class="fa fa-pencil"></i><span id="cap_countinstall_'.$result->srco_id.'">'.$result->cap_count_install.'</span></a>';
                                $array[] =  '<a '.$backcolor.' href="javascript:void(0);" onclick="changeCapSale('.$result->cca.','.$result->zone.','.$result->srco_id.','.$result->cap_count_sale.');"><i class="fa fa-pencil"></i><span id="cap_countsale_'.$result->srco_id.'">'.$result->cap_count_sale.'</span></a>';

                        $array[] =  $result->traffic_type;                                 
                        $array[] =  '<span title="'.$result->name.'">'.$result->name.'('.$result->id.')</span>';
                        $array[] =  '<span title="'.$result->offername.'">'.$result->offername.'('.$result->id.')</span>';
                        //code emplemet edit functionaly

                        // $array[] =  $result->trfc;
                          $array[] =  '<a href="javascript:void(0);" onclick="changeTrfc('.$result->cca.','.$result->zone.','.$result->id.');"><i class="fa fa-pencil"></i><span id="trfc_'.$result->srco_id.'">'.$result->trfc.'</span></a>
    <span href="javascript:void(0);" id="trigger" onmouseover="display_pop('.$result->cca.','.$result->zone.','.$result->id.');"> Details </span> ';                      

                        //code emplement end here
                        
                        $array[] =   $result->country_code;
                        $array[] =   $result->os_type;
                        $array[] =   '<a href="javascript:void(0);"  onclick="changeFilter('.$result->cca.','.$result->zone.','.$result->srco_id.','.$result->filter.');"><i class="fa fa-pencil"></i><span id="filter_'.$result->srco_id.'">'.$result->filter.'</span></a>';
                        $array[] =   '<a href="javascript:void(0);" onclick="changeFilterSt('.$result->cca.','.$result->zone.','.$result->srco_id.','.$result->filter_status.');"><i class="fa fa-pencil"></i><span id="filter_st_'.$result->srco_id.'">'.$filter_st.'</span></a>';
                        $array[] =   '<a href="javascript:void(0);" onclick="changePostbackSt('.$result->cca.','.$result->zone.','.$result->srco_id.','.$result->postback_status.');"><i class="fa fa-pencil"></i><span id="postback_st_'.$result->srco_id.'">'.$postback.'</span></a>';
                        $array[] =   '<a title="Copy Url" href="javascript:void(0);" onclick="CopyUrl('.$result->srco_id.');"><i class="fa fa-clipboard" aria-hidden="true"></i><span id="copy_'.$result->srco_id.'" style="display:none;">'.$result->offer_url.'</span></a>';
                        $array[] =   '<a title="Copy Preview" href="javascript:void(0);" onclick="CopyPreview('.$result->srco_id.');"><i class="fa fa-clipboard" aria-hidden="true"></i><span id="copy_preview_'.$result->srco_id.'" style="display:none;">'.$result->advtrackinglink.'</span></a>';
//                        $array[] =   '<a title="View Details" href="javascript:void(0);" onclick="viewDetails('.$result->cca.','.$result->zone.','.$result->id.','.$result->offername.','.$result->cap_count_conversions.','.$result->country_code.','.$result->os_type.');"><i class="fa fa-eye" aria-hidden="true"></i></a>';
//                        $array[] =   '<a title="View Details" href="javascript:void(0);" onclick="viewDetails('.$result->cca.','.$result->zone.','.$result->id.');"><i class="fa fa-eye" aria-hidden="true"></i></a> | <a title="Edit KPI" href="javascript:void(0);" onclick="editKPI('.$result->cca.','.$result->zone.','.$result->srco_id.','.str_replace(array("(", ")", "/", ":","'",","), " ", $result->publisher_kpi).'"><i class="fa fa-pencil" aria-hidden="true"></i></a>';
                        $KPI_DATA = htmlspecialchars(addslashes($result->publisher_kpi),ENT_QUOTES,'UTF-8',TRUE);
                        $array[] =   '<a title="View Details" href="javascript:void(0);" onclick="viewDetails('.$result->cca.','.$result->zone.','.$result->id.');"><i class="fa fa-eye" aria-hidden="true"></i></a> | <a title="Edit KPI" href="javascript:void(0);" onclick="editKPI('.$result->cca.','.$result->zone.','.$result->srco_id.',\''.$KPI_DATA.'\')"><i class="fa fa-pencil" aria-hidden="true"></i></a>';
                        $array[] =  '<span title="'.$result->approve_date.'">'.date('d-m-Y',strtotime($result->approve_date)).'</span>';
                        
                        array_push($data1, $array);
                    }

                    
                      $result  = array('data1' => $data1,
                          'network'=>$networksResult,
                          'campaigns_list'=>$CampaignsResult,
                          'div'=>$diversion,
                          'filter_st'=>$only_status,
                          'dtvalue'=>$selected_date,
                          'dtvalue2'=>$end_date
                          );

                    $dataN =  view('offerlist.pubwiseoffer')->with($result);
                    return $dataN;
    }
    
    public function updateCpa(Request $request)
    {
        $id = $request->id;
        $cca = $request->cca;
        $ccz = $request->ccz;
        $cpa = $request->cpa;

        if($id != '' && $cca != '' && $ccz != '')
        {
            $sql = "update smart_rotator_campaigns_operators set publisher_cpa ='".$cpa."' where id = '".$id."' AND campaign_id = '".$cca."' AND id_zone = '".$ccz."' LIMIT 1";
            $result = DB::update($sql);
            
            if($result)
            {
                $status = ['status'=>'1','message'=>'Successfully cpa changed'];
                echo json_encode($status);
                exit;
            }
        }
        else
        {
            $status = ['status'=>'0','message'=>'Oops, some problem occure !!'];
            echo json_encode($status);
            exit;
        }
    }
    
    public function change_active_status(Request $request)
    {
        $id = $request->id;
        $rotator_id = implode( "','", $id );

        if($rotator_id)
        {
            $sql = "update smart_rotator_campaigns_operators set smart_live ='0' where id IN ('".$rotator_id."')";
            $result = DB::update($sql);
            
            if($result)
            {
                $status = ['status'=>'1','message'=>'Successfully Live Status changed'];
                echo json_encode($status);
                exit;
            }
            else
            {
                $status = ['status'=>'2','message'=>'Not updated !!!'];
                echo json_encode($status);
                exit;
            }
        }
        else
        {
            $status = ['status'=>'0','message'=>'Oops, some problem occure !!'];
            echo json_encode($status);
            exit;
        }
    }
    public function change_pause_status(Request $request)
    {
        $id = $request->id;
        $rotator_id = implode( "','", $id );

        if($rotator_id)
        {
            $sql = "update smart_rotator_campaigns_operators set smart_live ='1' where id IN ('".$rotator_id."')";
            $result = DB::update($sql);
            
            if($result)
            {
                $status = ['status'=>'1','message'=>'Successfully Live Status changed'];
                echo json_encode($status);
                exit;
            }
            else
            {
                $status = ['status'=>'2','message'=>'Not updated !!!'];
                echo json_encode($status);
                exit;
            }
        }
        else
        {
            $status = ['status'=>'0','message'=>'Oops, some problem occure !!'];
            echo json_encode($status);
            exit;
        }
    }
    
    public function update_active_status(Request $request)
    {
//        echo "<pre>";
//        print_r($request->all());
//        echo "</pre>";die();
        
        $id = $request->id;
        $cca = $request->cca;
        $ccz = $request->ccz;
        $st = $request->status;
        
        if($id != '' && $cca != '' && $ccz != '')
        {
            $sql = "update smart_rotator_campaigns_operators set smart_live ='".$st."' where id = '".$id."' AND campaign_id = '".$cca."' AND id_zone = '".$ccz."' LIMIT 1";
            $result = DB::update($sql);
            
            if($result)
            {
                $status = ['status'=>'1','message'=>'Successfully Live Status changed'];
                echo json_encode($status);
                exit;
            }
        }
        else
        {
            $status = ['status'=>'0','message'=>'Oops, some problem occure !!'];
            echo json_encode($status);
            exit;
        }
    }
    
    public function updateCap(Request $request)
    {
       

        $id = $request->id;
        $cca = $request->cca;
        $ccz = $request->ccz;
        $cap = $request->cap;

       $previuos_data= $this->getcurrent_cap($id,$cca,$ccz);

       

       $previuos_cpa_value = trim($previuos_data[0]['cpa_count_value']);

       $previuos_cpa_status = trim($previuos_data[0]['status']);       
      
       
        if($id != '' && $cca != '' && $ccz != '')
        {
            if($cap < $previuos_cpa_value){

             $sql = "update smart_rotator_campaigns_operators set cap_count_conversions ='".$cap."' where id = '".$id."' AND campaign_id = '".$cca."'  AND id_zone = '".$ccz."' LIMIT 1";
            
            }else if( $cap > $previuos_cpa_value){
            $sql = "update smart_rotator_campaigns_operators set cap_count_conversions ='".$cap."' ,status='1' where id = '".$id."' AND campaign_id = '".$cca."' AND id_zone = '".$ccz."' LIMIT 1";
             }
              $result = DB::update($sql);

            if($result)
            {
                $status = ['status'=>'1','message'=>'Successfully Cap changed'];
                echo json_encode($status);
                exit;
            }
        }
        else
        {
            $status = ['status'=>'0','message'=>'Oops, some problem occure !!'];
            echo json_encode($status);
            exit;
        }
    }
    
 public function updateclickcountCap(Request $request)
    {
       

        $id = $request->id;
        $cca = $request->cca;
        $ccz = $request->ccz;
        $cap = $request->cap;

       $previuos_data= $this->getcurrent_cap_count_click($id,$cca,$ccz);

       

       $previuos_cpa_value = trim($previuos_data[0]['cap_count_click']);

       $previuos_cpa_status = trim($previuos_data[0]['status']);       
      
       
        if($id != '' && $cca != '' && $ccz != '')
        {
            if($cap < $previuos_cpa_value){

             $sql = "update smart_rotator_campaigns_operators set cap_count_click ='".$cap."' where id = '".$id."' AND campaign_id = '".$cca."'  AND id_zone = '".$ccz."' LIMIT 1";
            
            }else if( $cap > $previuos_cpa_value){
            $sql = "update smart_rotator_campaigns_operators set cap_count_click ='".$cap."' ,status='1' where id = '".$id."' AND campaign_id = '".$cca."' AND id_zone = '".$ccz."' LIMIT 1";
             }
              $result = DB::update($sql);

            if($result)
            {
                $status = ['status'=>'1','message'=>'Successfully Cap changed'];
                echo json_encode($status);
                exit;
            }
        }
        else
        {
            $status = ['status'=>'0','message'=>'Oops, some problem occure !!'];
            echo json_encode($status);
            exit;
        }
    }


    public function updateinsatllcountCap(Request $request)
    {
       

        $id = $request->id;
        $cca = $request->cca;
        $ccz = $request->ccz;
        $cap = $request->cap;

       $previuos_data= $this->getcurrent_cap_count_install($id,$cca,$ccz);


       

       $previuos_cpa_value = trim($previuos_data[0]['cap_count_install']);

       $previuos_cpa_status = trim($previuos_data[0]['status']);       
      
       
        if($id != '' && $cca != '' && $ccz != '')
        {
            $sql= $result='';
            if($cap < $previuos_cpa_value){

             $sql = "update smart_rotator_campaigns_operators set cap_count_install ='".$cap."' where id = '".$id."' AND campaign_id = '".$cca."'  AND id_zone = '".$ccz."' LIMIT 1";
               $result = DB::update($sql);
            
            }else if( $cap > $previuos_cpa_value){
            $sql = "update smart_rotator_campaigns_operators set cap_count_install ='".$cap."' ,status='1' where id = '".$id."' AND campaign_id = '".$cca."' AND id_zone = '".$ccz."' LIMIT 1";
              $result = DB::update($sql);
             }

            if($result)
            {
                $status = ['status'=>'1','message'=>'Successfully Cap changed'];
                echo json_encode($status);
                exit;
            }
            else{
                $status = ['status'=>'3','message'=>'Something worng in  Cap changed'];
                echo json_encode($status);
                exit;   
            }
        }
        else
        {
            $status = ['status'=>'0','message'=>'Oops, some problem occure !!'];
            echo json_encode($status);
            exit;
        }
    }
    public function updateSaleCountCap(Request $request)
    {
       
        
//        echo "<pre>";
//        print_r($request->all());
//        echo "</pre>";
//        die();
        

        $id = $request->id;
        $cca = $request->cca;
        $ccz = $request->ccz;
        $cap = $request->cap;

       $previuos_data= $this->getcurrent_cap_count_sale($id,$cca,$ccz);

//       echo "INSIDE SALE";
//       echo "<pre>";
//       print_r($previuos_data);
//       echo "</pre>";
//       die();

       $previuos_cpa_value = trim($previuos_data[0]['cap_count_install']);

       $previuos_cpa_status = trim($previuos_data[0]['status']);       
      
       
        if($id != '' && $cca != '' && $ccz != '')
        {
            $sql= $result='';
            if($cap < $previuos_cpa_value)
            {

                $sql = "update smart_rotator_campaigns_operators set cap_count_sale ='".$cap."' where id = '".$id."' AND campaign_id = '".$cca."'  AND id_zone = '".$ccz."' LIMIT 1";
                $result = DB::update($sql);            
            }
            else if( $cap > $previuos_cpa_value)
            {
                $sql = "update smart_rotator_campaigns_operators set cap_count_sale ='".$cap."' ,status='1' where id = '".$id."' AND campaign_id = '".$cca."' AND id_zone = '".$ccz."' LIMIT 1";
                $result = DB::update($sql);
            }

            if($result)
            {
                $status = ['status'=>'1','message'=>'Successfully Sale count changed'];
                echo json_encode($status);
                exit;
            }
            else{
                $status = ['status'=>'3','message'=>'Something worng in  Cap changed'];
                echo json_encode($status);
                exit;   
            }
        }
        else
        {
            $status = ['status'=>'0','message'=>'Oops, some problem occure !!'];
            echo json_encode($status);
            exit;
        }
    }

    public function getcurrent_cap($id,$cca,$ccz){
            $sql="select cap_count_conversions,status from smart_rotator_campaigns_operators where id = '".$id."' AND campaign_id = '".$cca."' AND id_zone = '".$ccz."' LIMIT 1";

             $result = DB::select($sql);
                $data1 =[];
             foreach ($result as $key => $value) {
                $array=[];
                 $array['cpa_count_value'] = $value->cap_count_conversions;

                 $array['status'] = $value->status;

                  array_push($data1,$array);
                    }

                    
                      // $result  = array($data1);

                      return $data1;

    }


       public function getcurrent_cap_count_click($id,$cca,$ccz){
            $sql="select cap_count_click,status from smart_rotator_campaigns_operators where id = '".$id."' AND campaign_id = '".$cca."' AND id_zone = '".$ccz."' LIMIT 1";

             $result = DB::select($sql);
                $data1 =[];
             foreach ($result as $key => $value) {
                $array=[];
                 $array['cap_count_click'] = $value->cap_count_click;

                 $array['status'] = $value->status;

                  array_push($data1,$array);
                    }

                  
                      return $data1;

    }

       public function getcurrent_cap_count_install($id,$cca,$ccz){

            $sql="select cap_count_install,status from smart_rotator_campaigns_operators where id = '".$id."' AND campaign_id = '".$cca."' AND id_zone = '".$ccz."' LIMIT 1";

             $result = DB::select($sql);
                $data1 =[];
             foreach ($result as $key => $value) {
                $array=[];
                 $array['cap_count_install'] = $value->cap_count_install;

                 $array['status'] = $value->status;

                  array_push($data1,$array);
                    }

                  
                      return $data1;

    }
       public function getcurrent_cap_count_sale($id,$cca,$ccz){

            $sql="select cap_count_sale,status from smart_rotator_campaigns_operators where id = '".$id."' AND campaign_id = '".$cca."' AND id_zone = '".$ccz."' LIMIT 1";

            $result = DB::select($sql);
            
//            echo "<pre>";
//            print_r($result);
//            echo "</pre>";
//            die();
            
            
                $data1 =[];
                
                $array=[];
                 $array['cap_count_sale'] = $result[0]->cap_count_sale;

                 $array['status'] = $result[0]->status;

                  array_push($data1,$array);
                
                
//             foreach ($result as $key => $value) {
//                
//            }

                  
                      return $data1;

    }

    public function updateKPI(Request $request)
    {
//        echo "<pre>";
//        print_r($request->all());
//        echo "</pre>";
//        die();
        
        $id = $request->id;
        $cca = $request->cca;
        $ccz = $request->ccz;
        $kpi = str_replace("'", "", $request->kpi);

        if($id != '' && $cca != '' && $ccz != '')
        {
            $sql = "update smart_rotator_campaigns_operators set publisher_kpi ='".$kpi."' where id = '".$id."' AND campaign_id = '".$cca."' AND id_zone = '".$ccz."' LIMIT 1";
            $result = DB::update($sql);
            
            if($result)
            {
                $status = ['status'=>'1','message'=>'Successfully KPI updated'];
                echo json_encode($status);
                exit;
            }
            else 
            {
                $status = ['status'=>'2','message'=>'Problem while updating...'];
                echo json_encode($status);
                exit;
            }
        }
        else
        {
            $status = ['status'=>'0','message'=>'Oops, some problem occure !!'];
            echo json_encode($status);
            exit;
        }
    }
    
    public function changeFilter(Request $request)
    {
//        echo "<pre>";
//        print_r($request->all());
//        echo "</pre>";die();
        
        $id = $request->id;
        $cca = $request->cca;
        $ccz = $request->ccz;
        $filter = $request->filter;

        if($filter != '' && $cca != '' && $ccz != '')
        {
            $sql = "update config_delivery set lower_limit ='".$filter."' where id_zone = '".$ccz."' AND id_ad = '".$cca."' AND is_offer = '1' LIMIT 1";
            $result = DB::update($sql);
            
            if($result)
            {
                $status = ['status'=>'1','message'=>'Successfully Filer changed'];
                echo json_encode($status);
                exit;
            }else{
                  $status = ['status'=>'2','message'=>'No Filer changed because data not match in table'];
                echo json_encode($status);
                exit;
            }
        }
        else
        {
            $status = ['status'=>'0','message'=>'Oops, some problem occure !!'];
            echo json_encode($status);
            exit;
        }
    }
    
    public function changeFilterSt(Request $request)
    {
//        echo "<pre>";
//        print_r($request->all());
//        echo "</pre>";die();
        
        $id = $request->id;
        $cca = $request->cca;
        $ccz = $request->ccz;
        $filterst = $request->filterst;

        if($filterst != '' && $cca != '' && $ccz != '')
        {
            $sql = "update config_delivery set filter_status ='".$filterst."' where id_zone = '".$ccz."' AND id_ad = '".$cca."' AND is_offer = '1' LIMIT 1";
            $result = DB::update($sql);
            
            if($result)
            {
                $status = ['status'=>'1','message'=>'Successfully Filter status changed'];
                echo json_encode($status);
                exit;
            }
        }
        else
        {
            $status = ['status'=>'0','message'=>'Oops, some problem occure !!'];
            echo json_encode($status);
            exit;
        }
    }
    
    public function changePostSt(Request $request)
    {
//        echo "<pre>";
//        print_r($request->all());
//        echo "</pre>";die();
        
        $id = $request->id;
        $cca = $request->cca;
        $ccz = $request->ccz;
        $postst = $request->postst;

        if($postst != '' && $cca != '' && $ccz != '')
        {
            $sql = "update config_delivery set postback_status ='".$postst."' where id_zone = '".$ccz."' AND id_ad = '".$cca."' AND is_offer = '1' LIMIT 1";
            $result = DB::update($sql);
            
            if($result)
            {
                $status = ['status'=>'1','message'=>'Successfully Postback status changed'];
                echo json_encode($status);
                exit;
            }
        }
        else
        {
            $status = ['status'=>'0','message'=>'Oops, some problem occure !!'];
            echo json_encode($status);
            exit;
        }
    }
    public function displayOffer(Request $request)
    {
//        echo "<pre>";
//        print_r($request->all());
//        echo "</pre>";
        
//        die();
        
        $id = $request->id;
        $cca = $request->cca;
        $ccz = $request->ccz;
//        $offer_name = $request->offer_name;
//        $cap_count = $request->cap_count;
//        $country = $request->country;
//        $os = $request->os;

        if($id != '' && $cca != '' && $ccz != '')
        {
            $condtion = [];
            
            array_push($condtion,["smart_rotator_campaigns_operators.campaign_id","=",$cca]);
            array_push($condtion,["smart_rotator_campaigns_operators.id_zone","=",$ccz]);
            array_push($condtion,["advertiser_campaigns.id","=",$id]);
            
            $select=['advertiser_campaigns.id',
                        'advertiser_campaigns.offername',
                        'advertiser_campaigns.country_code as country_code',                        
                        'smart_rotator_campaigns_operators.publisher_cpa',
                        'smart_rotator_campaigns_operators.cap_count_conversions',
                        'advertiser_campaigns.os_type',
                        'smart_rotator_campaigns_operators.offer_url',
                        'advertiser_campaigns.advtrackinglink as preview',
                        'smart_rotator_campaigns_operators.publisher_kpi'];
            $dat_data=DB::table('advertiser_campaigns')->select($select)
                    ->leftJoin("smart_rotator_campaigns_operators","advertiser_campaigns.id","=","smart_rotator_campaigns_operators.campaign_id")

//                ->where('advertiser_campaigns.id',$id)->first();
                ->where($condtion)->first();

            
//            echo "<pre>";
//            print_r($dat_data);
//            echo "</pre>";
//            die();
            
            $offer_id = $dat_data->id;
            
            
            $result = '';
            $result .= '<div class="form-group col-sm-12">';
                $result .= '<div class="row">';
                    $result .= '<label class="col-sm-2 control-label">Offer Id</label>';
                        $result .= '<div class="col-sm-10">';
                            $result .= '<label class="control-label">'.$offer_id.'</label>';
                        $result .= '</div>';
                $result .= '</div>';
                
                $result .= '<div class="row">';
                    $result .= '<label class="col-sm-2 control-label">Offer Name</label>';
                        $result .= '<div class="col-sm-10">';
                            $result .= '<label class="control-label">'.$dat_data->offername.'</label>';
                        $result .= '</div>';
                $result .= '</div>';
                
                $result .= '<div class="row">';
                    $result .= '<label class="col-sm-2 control-label">GEO</label>';
                        $result .= '<div class="col-sm-10">';
                            $result .= '<label class="control-label">'.$dat_data->country_code.'</label>';
                        $result .= '</div>';
                $result .= '</div>';
                
                $result .= '<div class="row">';
                    $result .= '<label class="col-sm-2 control-label">CAP</label>';
                        $result .= '<div class="col-sm-10">';
                            $result .= '<label class="control-label">'.$dat_data->cap_count_conversions.'</label>';
                        $result .= '</div>';
                $result .= '</div>';
                
                $result .= '<div class="row">';
                    $result .= '<label class="col-sm-2 control-label">Os</label>';
                        $result .= '<div class="col-sm-10">';
                            $result .= '<label class="control-label">'.$dat_data->os_type.'</label>';
                        $result .= '</div>';
                $result .= '</div>';
                
                $result .= '<div class="row">';
                    $result .= '<label class="col-sm-2 control-label">Payout</label>';
                        $result .= '<div class="col-sm-10">';
                            $result .= '<label class="control-label"> $ '.$dat_data->publisher_cpa.'</label>';
                        $result .= '</div>';
                $result .= '</div>';
                
                $result .= '<div class="row">';
                    $result .= '<label class="col-sm-2 control-label">Tracking Url</label>';
                        $result .= '<div class="col-sm-10">';
                            $result .= '<label class="control-label">'.$dat_data->offer_url.'</label>';
                        $result .= '</div>';
                $result .= '</div>';
                
                $result .= '<div class="row">';
                    $result .= '<label class="col-sm-2 control-label">Preview Url</label>';
                        $result .= '<div class="col-sm-10">';
                            $result .= '<label class="control-label">'.$dat_data->preview.'</label>';
                        $result .= '</div>';
                $result .= '</div>';
//                $kpi = strlen($dat_data->publisher_kpi) > 250 ? substr($dat_data->publisher_kpi,0,250)."..." : $dat_data->publisher_kpi;
                $kpi = $dat_data->publisher_kpi;
                $result .= '<div class="row">';
                    $result .= '<label class="col-sm-2 control-label">KPI</label>';
                        $result .= '<div class="col-sm-10">';
                            $result .= '<p style="font-size:12px; color:#000;" title="'.$dat_data->publisher_kpi.'" >'.$kpi.'</p>';
                        $result .= '</div>';
                $result .= '</div>';
                
            $result .= '</div>';
            
            $status = ['status'=>'1','message'=>'Successfully','array_data'=>$result];
            echo json_encode($status);
            exit;
        }
        else
        {
            $status = ['status'=>'0','message'=>'Oops, some problem occure !!'];
            echo json_encode($status);
            exit;
        }
    }


      function display_pop($cmp_id , $zone){
         $result_data = "";
         $result_data.="<div id='pop-up'>";
             $result_data.=$cmp_id;
              $result_data.=$zone;
          $result_data .= "</div>";
          return $result_data;
      }



    function display_pops(Request $request){
        //$cmp_id , $zone


        $cmp_id =$request->campaign_id;

        $zone =$request->id_zone;

        $select=['redirect_diversion_config','is_offer_direct','op_id','country_code'];
         $dat_data=DB::table('smart_rotator_campaigns_operators')->select($select)
                ->where('id_zone',$zone)
                ->where('campaign_id',$cmp_id)->first();

        $array = json_decode(json_encode($dat_data), true);

        $array_data = explode(",",substr($array['redirect_diversion_config'], 1, -1));

       

        $result_data = "";
            $ids = [];
            foreach ($array_data as $key => $value) 
                {

                    $id = explode(":",$value);
                    $ids[] =substr($id[0],1,-1);
                }

                $result_data.='<div id="row">';

        if(!empty($array_data[0]))
        {
            $result_data .= '<table class="table table-bordered">';

                $result_data .= '<tr>';
                $result_data .= '<th>Campaign Name</th><th>Percentage</th>';
                $result_data .= '</tr>';

                foreach ($array_data as $key => $value) 
                {
                    $id = explode(":",$value);
                    $result_data .= '<tr>';
                        $result_data .= '<td>';
                        $result_data .= $this->getCampaignName(substr($id[0],1,-1))[0]->offer_url."{ ".substr($id[0],1,-1)." }";
                        $result_data .= '</td>';
                        $result_data .= '<td>';
                        $result_data.= substr($id[1],1,-1);
                        $result_data .= '</td>';
                       
                    $result_data .= '</tr>';
                }

            $result_data .= '</table>';
        }
        else
        {
            $result_data .= '<table class="table table-bordered">';
                $result_data .= 'No Data Found';
            $result_data .= '</table>';
        }
                 $result_data .= '</div>';

         echo $result_data;

    }


    function getcampaignQuery($id){


    }
    

		      public function getNetwork($id_channel){
               
if (Cache::has('network_name_'.$id_channel)) { 
$categories  =Cache::get('network_name_'.$id_channel);
}else{        
$categories = Cache::remember('network_name_'.$id_channel, 3360, function() use($id_channel)
{
    $adDataArray = AdNetwork::where("ccz","=",$id_channel)->get();
              foreach($adDataArray as $value){
                    $name_rts= $value->name.'('.$value->ccz.')';
              }
              return $name_rts;
});

    }
        return $categories;
        }


	   /* To show network wise smart record */
    public function offer_networkwise_newpages(Request $request){
        $advertiser_id = $operator_id = $parent_cca = "";
        $type = "network";
        $template_name = "smart.networkwisenewpageredis";
        $cat = ['OM','OG'];
   	
	   $redis = Redis::connection();	

	
		//echo "<pre>";
		//print_r($redis);
		//echo "</pre>";
//	die();	
        $cache = $request->input('cache');
        $date  = date('Y-m-d');
        //$key   = "networkwisenewpageredis1_".$date;


        $min = date("i");
         
        if($min >= '00' && $min <= '04')
        {
            $key="network_wise_data_12";
        }
        else if($min >= '05' && $min <= '09')
        {
            $key   = "network_wise_data_1";
        }
        else if($min >= '10' && $min <= '14')
        {
            $key   = "network_wise_data_2";
        }
        else if($min >= '15' && $min <= '19')
        {
            $key   = "network_wise_data_3";
        }
        else if($min >= '20' && $min <= '24')
        {
            $key   = "network_wise_data_4";
        }
        else if($min >= '25' && $min <= '29')
        {
            $key   = "network_wise_data_5";
        }
        else if($min >= '30' && $min <= '34')
        {
            $key   = "network_wise_data_6";
        }
        else if($min >= '35' && $min <= '39')
        {
            $key   = "network_wise_data_7";
        }
        else if($min >= '40' && $min <= '44')
        {
            $key   = "network_wise_data_8";
        }
        else if($min >= '45' && $min <= '49')
        {
            $key   = "network_wise_data_9";
        }
        else if($min >= '50' && $min <= '54')
        {
            $key   = "network_wise_data_10";
        }
        else if($min >= '55' && $min <= '59')
        {
            $key   = "network_wise_data_11";
        }
            

//        switch ($min)
//    {
////        case 0:
////
////            $key="network_wise_data_12";
////            // echo "KEY = ".$key;
////            break;
//
////        case 5:
////
////            $key   = "network_wise_data_1";
////            // echo "KEY = ".$key;
////            break;
//
//        case 10:
//
//            $key   = "network_wise_data_2";
//            // echo "KEY = ".$key;
//            break;                                    
//    
//
//    case 15:
//
//            $key   = "network_wise_data_3";
//            // echo "KEY = ".$key;
//            break;
//
//        case 20:
//
//            $key   = "network_wise_data_4";
//            // echo "KEY = ".$key;
//            break;
//
//        case 25:
//
//            $key   = "network_wise_data_5";
//            // echo "KEY = ".$key;
//            break;
//             case 30:
//
//            $key   = "network_wise_data_6";
//            // echo "KEY = ".$key;
//            break;
//        case 35:
//
//            $key   = "network_wise_data_7";
//            // echo "KEY = ".$key;
//            break;
//
//        case 40:
//
//            $key   = "network_wise_data_8";
//            // echo "KEY = ".$key;
//            break;
//
//
//
//        case 45:
//
//            $key   = "network_wise_data_9";
//            // echo "KEY = ".$key;
//            break;
//
//        case 50:
//
//            $key   = "network_wise_data_10";
//            // echo "KEY = ".$key;
//            break;
//
//        case 55:
//
//            $key   = "network_wise_data_11";
//            // echo "KEY = ".$key;
//            break;
//	default:
//            $key   = "network_wise_data_".$min;
//       //     echo "KEY = ".$key;
//            break; 
//    }


        // echo "KEY =====".$key;
       // $key='network_wise_data_7';

        $allKeys = $redis->keys('*');
      
//echo "<pre>";
//print_r($allKeys);
//echo "</pre>";
     $items = $redis->get($key);
  // 		echo '<pre>';
//		print_r($items);
//		echo '</pre>';		 
   		 //$datas =  unserialize($items);
		

        $datas="";

         $toda=date('Y-m-d', strtotime($request->start));
         $enda=date('Y-m-d', strtotime($request->end));

        
        if($toda==date('Y-m-d', strtotime(' - 1 day')) &&  $enda=date('Y-m-d', strtotime(' - 1 day'))){
         $datas = $this->offer_previous_days_networkwise_newpages($request);
        }else{
            $datas =  unserialize($items);   
        }
          
        
       return $this->index_adv_networ($request,$datas); 
    }

	 public function offer_previous_days_networkwise_newpages(Request $request){

      
        $redis = Redis::connection();    

        $cache = $request->input('cache');
        $date  = date('Y-m-d');

        $min = date("i");
         
        if($min >= '00' && $min <= '04')
        {
            $key="prevoiusday_network_wise_data_12";
        }
        else if($min >= '05' && $min <= '09')
        {
            $key   = "prevoiusday_network_wise_data_1";
        }
        else if($min >= '10' && $min <= '14')
        {
            $key   = "prevoiusday_network_wise_data_2";
        }
        else if($min >= '15' && $min <= '19')
        {
            $key   = "prevoiusday_network_wise_data_3";
        }
        else if($min >= '20' && $min <= '24')
        {
            $key   = "prevoiusday_network_wise_data_4";
        }
        else if($min >= '25' && $min <= '29')
        {
            $key   = "prevoiusday_network_wise_data_5";
        }
        else if($min >= '30' && $min <= '34')
        {
            $key   = "prevoiusday_network_wise_data_6";
        }
        else if($min >= '35' && $min <= '39')
        {
            $key   = "prevoiusday_network_wise_data_7";
        }
        else if($min >= '40' && $min <= '44')
        {
            $key   = "prevoiusday_network_wise_data_8";
        }
        else if($min >= '45' && $min <= '49')
        {
            $key   = "prevoiusday_network_wise_data_9";
        }
        else if($min >= '50' && $min <= '54')
        {
            $key   = "prevoiusday_network_wise_data_10";
        }
        else if($min >= '55' && $min <= '59')
        {
            $key   = "prevoiusday_network_wise_data_11";
        }
     
        $items = $redis->get($key);


        return $datas =  unserialize($items);   

     
     
    }

     public function index_adv_networ(Request $request,$datas){

                       $type = "network";

           if(is_null($dtvalue)){
            $dtvalue = date('Y-m-d');
        }
        if(is_null($dtvalue2)){
                $dtvalue2 = date('Y-m-d');
                $enddate = date('Y-m-d',strtotime("+1 days"));
        }else{
           if($dtvalue == $dtvalue2){ 
              $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));
           }else{
            $enddate = date('Y-m-d',strtotime($dtvalue2));
           }
        }

             
        $condtion = $data221= [];
        $total_sale_count = $count = $totalClick = $actualcount = $totalconversion = $clicks_active_count = $unique_conversion = $totalCostDollar = $totalRevenueDollar = $totalprofit = $finalprofit_ECPM =  0;
         $sum_revenue_doller = $sum_revenue_inr = $sum_totalprofit_inr =  $sum_cost_inr = $sum_act_Click = 0;

             $role_id = Auth::user()->email;
	      
		   if($role_id=="sanjeev@collectcent.com"){
        $rtss =[];
         }else{
            $rtss = $this->account_managerilist($role_id);    
         } 

                                  
                       
                     // $array[] =$this->getNetwork($result['id_channel']);
                
                      

			 if($role_id=="sanjeev@collectcent.com"){
        $rtss =[];
         }else{
            $rtss = $this->account_managerilist($role_id);    
         }   

                       if($role_id=="sanjeev@collectcent.com"){
                           foreach ($datas as $result) {
                            $array = $data = $rtotal = [];
                        $count++;
                        $cap_status=0;
                        $totalCostDollar = round($totalCostDollar + ($result['cost_dollar']),2);  
                        $profit_dollar = $result['revenue_dollar'] - $result['cost_dollar'];
                        $profit_both = "<span class=dollar>".round($profit_dollar,2)."</span>";

                        $actualClick = $result['clickcount'] - $result['fraud'];
                        $cost_dollar = round($result['cost_dollar'],2);
                        
                        $totalRevenueDollar = round($totalRevenueDollar + ($result['revenue_dollar']),2);
                        
                        $totalprofitdoller = $result['revenue_dollar'] - $result['cost_dollar'] ;

                        $cr_in = '';
                        if($actualClick != 0)
                        {
                            $ecpm_doller = ($result['revenue_dollar']/$actualClick)*1000;
                            $cr_in = (($result['conversion_count_unique']/$actualClick)*100);
                            $cr_out = (($result['clicks_active_count']/$actualClick)*100);
                        }
                        else
                        {
                            $ecpm_doller = 0.000;
                        }
                        
                        if($result['conversion_count_unique'] == 0)
                        {
                            $cr_in = 0.00;
                        }
                        
                        if($result['clicks_active_count'] == 0)
                        {
                            $cr_out = 0.00;
                        }
                        if($result['active'] == 0)
                        {
                            $active = 'Pause';
                        }
                        else 
                        {
                            $active = 'Active';
                        }
                        

                        if($result['cap_status']==1){
                            $cap_status='<p  class="label label-success">Active</p>';
                        }else if($result['cap_status']==0){ 
                            $cap_status="<p  class='label label-warning'> Inactive </p>";
                        }else if($result['cap_status']==5){ 
                            $cap_status="<p class='label label-danger'>Pause</p>";
                        }
                        
                        $first_field = $result['id'];
                    
                        if($advertiser_id){
                            $first_field = $result['id'];
                        }else if($type == 'network'){
                           $first_field = $result['id_channel'];
                        } else if ($type == 'advertiser'){
                        $first_field = $result['id'];
                        }

                        if($type == 'advertiserByParentcca'){
                          $array[] =  $result['id'];
                          $first_field = $result['id'];
                        }
                        if($type == 'network'){
                            $array[] = $result['id'];
                            // $array[] = "$result->id";
                        }
                        
                       if($result['clickcount'] < 300){
                      $array[] ="<div class='change_color'><a href=/offer-by-parentcca/".$result['parent_cca']."/".$result['id_channel']."/?start=$dtvalue&end=$enddate>".$this->getNetwork($result['id_channel'])."</a></div>";
			}else{

		//	$array[] =$this->getNetwork($result['id_channel']);
				$array[] = "<a href=/offer-by-parentcca/".$result['parent_cca']."/".$result['id_channel']."/?start=$dtvalue&end=$enddate>".$this->getNetwork($result['id_channel']). "</a>";
		}
                        $array[] =  $result['cpa'];  
                        $array[] =  $result['traffic_type']; 
                        // $array[] = "";                           
                        $array[] = isset($result['name'])?htmlentities($result['name']):'';

                         $array[] =  isset($result['offername'])?htmlentities($result['offername']):'';

                       
                            $array[] = '<a href="javascript:void(0);" onclick="changeTrfc('.$result['parent_cca'].','.$result['zone'].','.$result['campaign_id'].');"><i class="fa fa-pencil"></i><span id="trfc_'.$result['campaign_id'].'">'.$result['trfc'].'</span></a>
    <span href="javascript:void(0);" id="trigger" onmouseover="display_pop('.$result['parent_cca'].','.$result['zone'].','.$result['campaign_id'].');"> Details </span>';

            
                        $array[] =   $active;
                        $array[] =   $cap_status;
                        $array[] =   $result['vertical'];
                        $array[] =   $result['country_code'];
                        $array[] =   $result['os_type'];
                        $array[] =   $result['clickcount'];
                        $array[] =   $actualClick; 
                        $array[] =   $result['conversion_count'];
                        
                       
                            $array[] =   $result['conversion_count_unique'];
                        
                        
                        $array[] =   $result['clicks_active_count'];                                
                        $array[] =   $result['sale_count'];
                        
                      
                             $array[] =  round($cr_in,2)."%";
                        $array[] =  round($cr_out,2)."%";    
                      
                        $array[] =   '$'."<span class=dollar>".$cost_dollar."</span>";
                        $array[] =   '$'."<span class=dollar>".round($result['revenue_dollar'],2);
                        $array[] =   '$'.$profit_both;
                        $array[] =   '$'.round($ecpm_doller,3);

                        array_push($data221, $array);
                        $total_sale_count = $total_sale_count + $result['sale_count']; 
                        $totalClick = $totalClick + $result['clickcount'];
                        $sum_act_Click = $sum_act_Click + $actualClick;
                        
                      
                        $unique_conversion = $unique_conversion + $result['conversion_count_unique'];
                        
                        
                        $actualcount = $actualcount + $actualClick;
                        $totalconversion = $totalconversion + $result['conversion_count'];
                        $clicks_active_count = $clicks_active_count + $result['clicks_active_count'];
                        
                        
                        $sum_revenue_doller = $sum_revenue_doller + $result['revenue_dollar'];
                        
                        $totalprofit = $totalprofit + $profit_dollar;
                           }
                       }else{
                   foreach ($datas as $result) {
                    
                       if(in_array($result['id_channel'],$rtss)){ 
                       
                            $array = $data = $rtotal = [];
                        $count++;
                        $cap_status=0;
                        $totalCostDollar = round($totalCostDollar + ($result['cost_dollar']),2);  
                        $profit_dollar = $result['revenue_dollar'] - $result['cost_dollar'];
                        $profit_both = "<span class=dollar>".round($profit_dollar,2)."</span>";

                        $actualClick = $result['clickcount'] - $result['fraud'];
                        $cost_dollar = round($result['cost_dollar'],2);
                        
                        $totalRevenueDollar = round($totalRevenueDollar + ($result['revenue_dollar']),2);
                        
                        $totalprofitdoller = $result['revenue_dollar'] - $result['cost_dollar'] ;

                        $cr_in = '';
                        if($actualClick != 0)
                        {
                            $ecpm_doller = ($result['revenue_dollar']/$actualClick)*1000;
                            $cr_in = (($result['conversion_count_unique']/$actualClick)*100);
                            $cr_out = (($result['clicks_active_count']/$actualClick)*100);
                        }
                        else
                        {
                            $ecpm_doller = 0.000;
                        }
                        
                        if($result['conversion_count_unique'] == 0)
                        {
                            $cr_in = 0.00;
                        }
                        
                        if($result['clicks_active_count'] == 0)
                        {
                            $cr_out = 0.00;
                        }
                        if($result['active'] == 0)
                        {
                            $active = 'Pause';
                        }
                        else 
                        {
                            $active = 'Active';
                        }
                        

                        if($result['cap_status']==1){
                            $cap_status='<p  class="label label-success">Active</p>';
                        }else if($result['cap_status']==0){ 
                            $cap_status="<p  class='label label-warning'> Inactive </p>";
                        }else if($result['cap_status']==5){ 
                            $cap_status="<p class='label label-danger'>Pause</p>";
                        }
                        
                        $first_field = $result['id'];
                    
                        if($advertiser_id){
                            $first_field = $result['id'];
                        }else if($type == 'network'){
                           $first_field = $result['id_channel'];
                        } else if ($type == 'advertiser'){
                        $first_field = $result['id'];
                        }

                        if($type == 'advertiserByParentcca'){
                          $array[] =  $result['id'];
                          $first_field = $result['id'];
                        }
                        if($type == 'network'){
                            $array[] = $result['id'];
                            // $array[] = "$result->id";
                        }
                        
                       
                      $array[] =$this->getNetwork($result['id_channel']);
                        $array[] =  $result['cpa'];  
                        $array[] =  $result['traffic_type']; 
                        // $array[] = "";                           
                        $array[] =  isset($result['name'])?htmlentities($result['name']):'';

                         $array[] =  isset($result['offername'])?htmlentities($result['offername']):'';

                       
                     //       $array[] = '<a href="javascript:void(0);" onclick="changeTrfc('.$result['parent_cca'].','.$result['zone'].','.$result['campaign_id'].');"><i class="fa fa-pencil"></i><span id="trfc_'.$result['campaign_id'].'">'.$result['trfc'].'</span></a>
  //  <span href="javascript:void(0);" id="trigger" onmouseover="display_pop('.$result['parent_cca'].','.$result['zone'].','.$result['campaign_id'].');"> Details </span>';
			$array[] =  $result['trfc'];
            
                        $array[] =   $active;
                        $array[] =   $cap_status;
                        $array[] =   $result['vertical'];
                        $array[] =   $result['country_code'];
                        $array[] =   $result['os_type'];
                        $array[] =   $result['clickcount'];
                        $array[] =   $actualClick; 
                        $array[] =   $result['conversion_count'];
                        
                       
                        $array[] =   $result['clicks_active_count'];
                        
                        
                        
                        $array[] =   $result['sale_count'];
                        
                      
                       //      $array[] =  round($cr_in,2)."%";
                        $array[] =  round($cr_out,2)."%";    
                      
                        //$array[] =   '$'."<span class=dollar>".$cost_dollar."</span>";
                        $array[] =   '$'."<span class=dollar>".round($result['cost_dollar'],2);
                        //$array[] =   '$'.$profit_both;
                        //$array[] =   '$'.round($ecpm_doller,3);

                        array_push($data221, $array);
                       
				 $total_sale_count = $total_sale_count + $result['sale_count']; 
	                        
				$totalClick = $totalClick + $result['clickcount'];

                        $sum_act_Click = $sum_act_Click + $actualClick;
                        
                      
                       // $unique_conversion = $unique_conversion + $result['conversion_count_unique'];
                        
                        
                        $actualcount = $actualcount + $actualClick;
                        $totalconversion = $totalconversion + $result['conversion_count'];
                        $clicks_active_count = $clicks_active_count + $result['clicks_active_count'];
                        
                        
                        $sum_revenue_doller = $sum_revenue_doller + $result['cost_dollar'];///$result['revenue_dollar'];
                        
                        $totalprofit = $totalprofit + $profit_dollar;
                          
                       } 
                       
                    }
                }
                   


                        $lastRow =[$totalClick,$sum_act_Click,$totalconversion,$unique_conversion,$clicks_active_count,$total_sale_count,$totalCostDollar,round($sum_revenue_doller,2),round($totalprofit,2)];
//                        $lastRow =[$totalClick,$sum_act_Click,$totalconversion,$total_sale_count,$totalCostDollar,$totalRevenueDollar];


                      $result  = array('data1' => $data221,            
                        'dtvalue' => $dtvalue,
                        'dtvalue2' => $dtvalue2,
                        'role' => $role_id,
                        'lastRow'=>$lastRow
                      );
                    $dataN =  view('smart.networkwisenewpageredis')->with($result);
                    return $dataN;

     }

	  public function account_managerilist($email){
         $adDataArray = AdNetwork::where("account_manager","Like","%".$email."%")->get();
              foreach($adDataArray as $value){
                    $name_rts[]= $value->ccz;
              }
              return $name_rts;
     }

  



      /* To show network wise smart record 
    public function offer_networkwise_newpages(Request $request){
        $advertiser_id = $operator_id = $parent_cca = "";
        $type = "network";
        $template_name = "smart.networkwisenewpageredis";
        $cat = ['OM','OG'];
         $redis = Redis::connection();
        $cache = $request->input('cache');
        $date  = date('Y-m-d');
        $key   = "networkwisenewpageredis_$date";
	//$items = Redis::get($key);
		//echo '<pre>';print_r($redis);echo '</pre>';exit();
      try {
          if(!$redis->exists($key)){
             $items = $this->index_adv_networkwisenewpageredis($request,$advertiser_id,$operator_id,$parent_cca,$template_name,$type,$cat); 
             $networkwisenewpageredis = Redis::set($key, $items);
             $redis->expire($key,5);
//		echo "1";
            }else{
            $items = Redis::get($key);
//		echo "2";
         }
      } catch (\Exception $e) {
            // echo $e->getMessage();
          $items = $this->index_adv_networkwisenewpageredis($request,$advertiser_id,$operator_id,$parent_cca,$template_name,$type,$cat);  
      }
//	exit();
     
      return view('smart.networkwisenewpageredis')->with($items); 
    }



    public function index_adv_networkwisenewpageredis(Request $request,$advertiser_id=null,$operator_id=null,$parent_cca,$viewPage = null,$type=null,$cat = array('SM','SG')){
    

//        echo "Parent = ".$parent_cca;die();
            $role_ids='';
        $condtion = $data1= [];
        $total_sale_count = $count = $totalClick = $actualcount = $totalconversion = $clicks_active_count = $unique_conversion = $totalCostDollar = $totalRevenueDollar = $totalprofit = $finalprofit_ECPM =  0;
        $dtvalue = $request->start;
        $dtvalue2 = $request->end;
        $id_channel =  $request->id_channel;
       
        
       // echo "Id Channel = ".$id_channel;die();
        
        if(is_null($dtvalue)){
            $dtvalue = date('Y-m-d');
        }
        if(is_null($dtvalue2)){
                $dtvalue2 = date('Y-m-d');
                $enddate = date('Y-m-d',strtotime("+1 days"));
        }else{
           if($dtvalue == $dtvalue2){ 
              $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));
           }else{
            $enddate = date('Y-m-d',strtotime($dtvalue2));
           }
        }

        array_push($condtion,['crc_records_new.create_time','>=',$dtvalue] );
        array_push($condtion,['crc_records_new.create_time','<=',$enddate] );

             $role_id = Auth::user()->email;
        
        if(!empty($role_id) && $role_id=='sapna.verma@collectcent.com'){
            $role_ids='and (ad_network.account_manager = "'.$role_id.'") ';
        }

        if(!empty($role_id) && $role_id=='ben@collectcent.com'){
//        $role_ids='and (ad_network.account_manager = "'.$role_id.'") ';           
            $role_ids="and FIND_IN_SET('ben@collectcent.com',trim(ad_network.account_manager))";
        }

        if(!empty($role_id) && $role_id=='hadar@collectcent.com'){
        $role_ids="and FIND_IN_SET('hadar@collectcent.com',trim(ad_network.account_manager))";
//        $role_ids='and (ad_network.account_manager = "'.$role_id.'") ';           
        }

        if(!empty($role_id) && $role_id=='farzana.tanwar@collectcent.com'){
            $role_ids="and FIND_IN_SET('farzana.tanwar@collectcent.com',trim(ad_network.account_manager))";
        }
        
        if(!empty($role_id) && $role_id=='shashank.saxena@collectcent.com'){
            $role_ids="and FIND_IN_SET('shashank.saxena@collectcent.com',trim(ad_network.account_manager))";
        }
        
        if(!empty($role_id) && $role_id=='jason.wang@collectcent.com'){
            $role_ids="and FIND_IN_SET('jason.wang@collectcent.com',trim(ad_network.account_manager))";
        }


                $select =  
                        "select smart_rotator_campaigns_operators.campaign_id,
                        ad_network.account_manager,  
                        smart_rotator_campaigns_operators.redirect_diversion_config,
                        smart_rotator_campaigns_operators.id_zone as zone,
                        smart_rotator_campaigns_operators.smart_live as active,
                        ad_network.name as network_name,
                        smart_rotator_campaigns_operators.publisher_cpa as cpa,
                        smart_rotator_campaigns_operators.ads_cat as traffic_type,
                        crc_records_new.id_advertiser_campaign,
                        advertiser_campaigns.name,
                        advertiser_campaigns.offername,
                        advertiser_campaigns.id,
                        advertiser_campaigns.id_op as op_id,
                        smart_rotator_campaigns_operators.is_offer_direct as trfc,
                        advertiser_campaigns.vertical,
                        smart_rotator_campaigns_operators.status as cap_status,
                        smart_rotator_campaigns_operators.country_code as country_code,
                        advertiser_campaigns.os_type,
                        advertiser_campaigns.incent_type,
                        crc_records_new.parent_cca as parent_cca,
                        crc_records_new.id_channel as id_channel,
                        crc_records_new.clickcount_fraud as fraud,
                        crc_records_new.create_time as datetime,
                        CONCAT(crc_records_new.cr_received,'%') AS cr_received,
                        CONCAT(crc_records_new.cr_given,'%') AS cr_given,
                        sum(crc_records_new.clickcount) as clickcount,
                        sum(crc_records_new.conversion_count_unique) as conversion_count_unique,
                        sum(crc_records_new.conversion_count) as conversion_count,
                        sum(crc_records_new.clicks_active_count) as clicks_active_count,
                        sum(crc_records_new.sale_count) as sale_count,
                        sum(crc_records_new.total_cost) as cost_dollar,
                        sum(crc_records_new.revenue_dollar) as revenue_dollar
                    from crc_records_new as crc_records_new 
                    join smart_rotator_campaigns_operators as smart_rotator_campaigns_operators on smart_rotator_campaigns_operators.campaign_id = crc_records_new.parent_cca 
                    join advertiser_campaigns as advertiser_campaigns on advertiser_campaigns.id = smart_rotator_campaigns_operators.campaign_id 
                    join ad_network as ad_network on smart_rotator_campaigns_operators.id_zone = ad_network.ccz 
                    and smart_rotator_campaigns_operators.id_zone = crc_records_new.id_channel
                    where smart_rotator_campaigns_operators.ads_cat in ('OM', 'OG') 
                    and (crc_records_new.create_time >= '$dtvalue' and crc_records_new.create_time <= '$enddate') 
                    $role_ids 
                    group by smart_rotator_campaigns_operators.campaign_id,smart_rotator_campaigns_operators.id_zone";
               
                
//                echo $select;
                
                
                if($type == 'network')
                {
                 $data =  DB::select(DB::raw($select));
                
                }
           

                    $sum_revenue_doller = $sum_revenue_inr = $sum_totalprofit_inr =  $sum_cost_inr = $sum_act_Click = 0;
                    foreach ($data as $result) 
                    {
                        $array = $data = $rtotal = [];
                        $count++;
                        $cap_status=0;
                        $totalCostDollar = round($totalCostDollar + ($result->cost_dollar),2);  
                        $profit_dollar = $result->revenue_dollar - $result->cost_dollar;
                        $profit_both = "<span class=dollar>".round($profit_dollar,2)."</span>";

                        $actualClick = $result->clickcount - $result->fraud;
                        $cost_dollar = round($result->cost_dollar,2);
                        
                        $totalRevenueDollar = round($totalRevenueDollar + ($result->revenue_dollar),2);
                        
                        $totalprofitdoller = $result->revenue_dollar - $result->cost_dollar ;

                        $cr_in = '';
                        if($actualClick != 0)
                        {
                            $ecpm_doller = ($result->revenue_dollar/$actualClick)*1000;
                            $cr_in = (($result->conversion_count_unique/$actualClick)*100);
                            $cr_out = (($result->clicks_active_count/$actualClick)*100);
                        }
                        else
                        {
                            $ecpm_doller = 0.000;
                        }
                        
                        if($result->conversion_count_unique == 0)
                        {
                            $cr_in = 0.00;
                        }
                        
                        if($result->clicks_active_count == 0)
                        {
                            $cr_out = 0.00;
                        }
                        if($result->active == 0)
                        {
                            $active = 'Pause';
                        }
                        else 
                        {
                            $active = 'Active';
                        }
                        

                        if($result->cap_status==1){
                            $cap_status='<p  class="label label-success">Active</p>';
                        }else if($result->cap_status==0){ 
                            $cap_status="<p  class='label label-warning'> Inactive </p>";
                        }else if($result->cap_status==5){ 
                            $cap_status="<p class='label label-danger'>Pause</p>";
                        }
                        
                        $first_field = $result->id;
                    
                        if($advertiser_id){
                            $first_field = "$result->id";
                        }else if($type == 'network'){
                           $first_field = "$result->id_channel";
                        } else if ($type == 'advertiser'){
                        $first_field = $result->id;
                        }

                        if($type == 'advertiserByParentcca'){
                          $array[] =  $result->id;
                          $first_field = $result->id;
                        }
                        if($type == 'network'){
                            $array[] = $result->id;
                            // $array[] = "$result->id";
                        }
                        
//                        if($result->clickcount > 0 && $result->clickcount < 10)
                        if($result->clickcount < 300)
                        {

                             if(!empty($role_id) && $role_id=='sapna.verma@collectcent.com' ||  $role_id=='ben@collectcent.com' ||  $role_id=='jason.wang@collectcent.com' ){  
                            $array[] =  "<div class=''>$result->network_name ($result->id_channel)</div>";
                            }else{
                                $array[] =  "<div class='change_color'><a href=/offer-by-parentcca/$result->parent_cca/$result->id_channel/?start=$dtvalue&end=$enddate>$result->network_name ($result->id_channel)<a></div>";
                            }
                        }
                        else
                        {
                            if(!empty($role_id) && $role_id=='sapna.verma@collectcent.com' && $role_id=='jason.wang@collectcent.com'){  
                            $array[] =  "<div class=''>$result->network_name ($result->id_channel)</div>";
                            }else{

                            $array[] =  "<a href=/offer-by-parentcca/$result->parent_cca/$result->id_channel/?start=$dtvalue&end=$enddate>$result->network_name ($result->id_channel)<a>";
                         }
                        }
                        
                        $array[] =  $result->cpa;  
                        $array[] =  $result->traffic_type;                            
                        $array[] =  '<span title="'.$result->name.'">'.$result->name.'('.$result->id.')</span>';

                        $array[] =  '<span title="'.$result->offername.'">'.$result->offername.'('.$result->id.')</span>';

                        $dsrs='"'.$this->display_pop("'".$result->parent_cca."'","'".$result->zone."'").'"';
                     if(!empty($role_id) && $role_id=='sapna.verma@collectcent.com' || $role_id=='ben@collectcent.com' || $role_id=='hadar@collectcent.com' || $role_id=='jason.wang@collectcent.com'){ 
                           $array[] =  $result->trfc;
                     }else{ 
                        $array[] =  '<a href="javascript:void(0);" onclick="changeTrfc('.$result->parent_cca.','.$result->zone.','.$result->campaign_id.');"><i class="fa fa-pencil"></i><span id="trfc_'.$result->campaign_id.'">'.$result->trfc.'</span></a>
    <span href="javascript:void(0);" id="trigger" onmouseover="display_pop('.$result->parent_cca.','.$result->zone.','.$result->campaign_id.');"> Details </span>';
        }


//                        $array[] =  '<a href="javascript:void(0);" onclick='.'"changeTrfc('.$result->parent_cca.','.$result->zone.','.$result->campaign_id.',"'.$result->country_code.'","'.$result->os_type.'")"'.'><i class="fa fa-pencil"></i><span id="trfc_'.$result->campaign_id.'">'.$result->trfc.'</span></a>$this->display_pop($result->parent_cca,$result->zone)';
                        
                        $array[] =   $active;
                        $array[] =   $cap_status;
                        $array[] =   $result->vertical;
                        $array[] =   $result->country_code;
                        $array[] =   $result->os_type;
                        $array[] =   $result->clickcount;
                        $array[] =   $actualClick; 
                        $array[] =   $result->conversion_count;
                        
                        if($role_id == 'sapna.verma@collectcent.com' || $role_id =='ben@collectcent.com' || $role_id == 'hadar@collectcent.com' || $role_id=='jason.wang@collectcent.com'){  
                            // $array[] =   $actualClick;   
                        }else{
                            $array[] =   $result->conversion_count_unique;
                        }
                        
                        
                        $array[] =   $result->clicks_active_count;                                
                        $array[] =   $result->sale_count;
                        
                        if($role_id == 'sapna.verma@collectcent.com' || $role_id =='ben@collectcent.com' || $role_id == 'hadar@collectcent.com' || $role_id=='jason.wang@collectcent.com'){  
                            // $array[] =  "";// round($cr_out,2)."%....";    
                        }else{
                             $array[] =  round($cr_in,2)."%";
                        }
                        $array[] =  round($cr_out,2)."%";    
                      
                        $array[] =   '$'."<span class=dollar>".$cost_dollar."</span>";
                        $array[] =   '$'."<span class=dollar>".round($result->revenue_dollar,2);
                        $array[] =   '$'.$profit_both;
                        $array[] =   '$'.round($ecpm_doller,3);

                        array_push($data1, $array);
                        $total_sale_count = $total_sale_count + $result->sale_count; 
                        $totalClick = $totalClick + $result->clickcount;
                        $sum_act_Click = $sum_act_Click + $actualClick;
                        
                        if($role_id == 'sapna.verma@collectcent.com' || $role_id =='ben@collectcent.com' || $role_id == 'hadar@collectcent.com' || $role_id=='jason.wang@collectcent.com'){  
                            // $array[] =   $actualClick;   
                        }else{
                            $unique_conversion = $unique_conversion + $result->conversion_count_unique;
                        }
                        
                        
                        $actualcount = $actualcount + $actualClick;
                        $totalconversion = $totalconversion + $result->conversion_count;
                        $clicks_active_count = $clicks_active_count + $result->clicks_active_count;
                        
                        
                        $sum_revenue_doller = $sum_revenue_doller + $result->revenue_dollar;
                        
                        $totalprofit = $totalprofit + $profit_dollar;
                        
                    }

                        $lastRow =[$totalClick,$sum_act_Click,$totalconversion,$unique_conversion,$clicks_active_count,$total_sale_count,$totalCostDollar,round($sum_revenue_doller,2),round($totalprofit,2)];
//                        $lastRow =[$totalClick,$sum_act_Click,$totalconversion,$total_sale_count,$totalCostDollar,$totalRevenueDollar];


                   return   $result  = array('data1' => $data1,            
                        'dtvalue' => $dtvalue,
                        'dtvalue2' => $dtvalue2,
                        'role' => $role_id,
                        'lastRow'=>$lastRow
                      );
                    // $dataN =  view('smart.networkwisenewpageredis.blade')->with($result);
                    // return $dataN;
                }
*/
}
