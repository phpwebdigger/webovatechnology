<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;
use App\QueryAccess;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Auth;
use App\Traffic;
use App\ads;
use Response;
use Session;
use Validator;

class TrafficController extends Controller
{
    //
   public function  __construct()
    {
       $this->middleware('auth');
    }


    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
   
     public function index(Request $request,$type="",$page_name="TRFC Config"){
        $select = "ad_network.ccz,ad_network.name as network_name,ads.title as campaign_name,net.id_zone,net.id,net.is_child,net.parent_cca,net.id_ad,net.hold_percentage,net.status, ads.cco,ads.operator_name";
        $condtion = [];
        array_push($condtion, ["is_international","!=","'1'"]);
        $net_id="";
        $op_id ="";
        $parent_cca  = $request->parent_cca;

        if($request->parent_cca){
          array_push($condtion,['net.parent_cca','=',$request->parent_cca] );
        }
        
        if($request->net_id && $request->net_id != "" && $request->net_id != "-1"){
          array_push($condtion,['net.id_zone','=',$request->net_id] );
          $net_id = $request->net_id;
        }else{
             $net_id = "-1";
        }
        
        if($request->op_id && $request->op_id != "" && $request->op_id != "-1000"){
          array_push($condtion,['ads.cco','=',$request->op_id] );
          $op_id = $request->op_id;
        }else{
              $op_id = "-1000";
        }
        if($type != ""){
            array_push($condtion,['type','=',$type] );
        }
        
        $appends = [];
        
        $total = $request->total ?? 50;
        
        $appends['net_id']=$request->net_id;
        
        $appends['cco']=$request->cco;
        
        $appends['total']=$request->total;

        
         $data =  DB::table("trfc_config as net")
                            ->where($condtion)
                            ->leftJoin("ads","ads.id_ad","=","net.id_ad")
                            ->leftJoin("ad_network","ad_network.ccz","=","net.id_zone")
                            ->selectRaw(DB::raw($select));
        if($request->colorder){
             $data = $data->orderby($request->colorder,$request->order);
             $appends["colorder"]=$request->colorder;
             $appends["order"]=$request->order;
        }else{
        $data = $data->orderby("ad_network.name","ASC")->orderby("net.parent_cca","DESC")->orderby("net.id_ad","ASC");
        }
        $data = $data->limit(50)->get();

        //dropdoewn
        $netData1 =  DB::table("ad_network")
             ->selectRaw(DB::raw("distinct ccz,name"))
             ->orderby("name","ASC")->get();

        $netData=array();
        foreach($netData1 as $fetch_dt)
        { 
            $netData[$fetch_dt->ccz] = $fetch_dt->name;
            
        }
        
        $opdata =  DB::table("operator")
             ->leftJoin("country","operator.country_code","=","country.iso")
             ->selectRaw(DB::raw("operator.id as id, operator.name as name,country.iso as cc"))
             ->orderby("operator.name","ASC")->get(); 
        
        $data1 = [];
        foreach ($data as $fetch_url){
                $array = [];
                $is_check = $fetch_url->status == 1 ? "checked": "";
                $active = $fetch_url->status == 1 ? "Active": "Inactive";
                $is_active = '<span class=""><input type="checkbox" id='.$fetch_url->id.'  name="is_active[]" '.$is_check.'></span><label for="checkbox8" id="status-'.$fetch_url->id.'">'.$active.'</label>';
                array_push($array,
                    $fetch_url->id,
                    '<a href=""><button type="button" class="btn btn-success btn-circle "><i class="fa fa-edit"></i></button></a>',
                    $fetch_url->network_name,
                    $fetch_url->operator_name,
                    $fetch_url->id_zone,
                    $fetch_url->parent_cca,
                    $fetch_url->id_ad,
                    $fetch_url->campaign_name,
                    '<span id="editPercent-'.$fetch_url->id.'" style="display:none"> 
                    <input type="textbox" id="percentText-'.$fetch_url->id.'" class="small-text col-md-5">
                    <a href="javascript:void(0)" data-id="'.$fetch_url->id.'" class="btn-success pad10 savePercent">Go</a><a href="javascript:void(0)" data-id="'.$fetch_url->id.'" class="btn-danger pad10 cancel">cancel</a></span><div id="mainPercent-'.$fetch_url->id.'"><span id="percentVal-'.$fetch_url->id.'">'.$fetch_url->hold_percentage.'</span><button type="button" class="btn btn-success btn-circle"><a class="change-percent" data-val="'.$fetch_url->id.'" href="javascript:void(0);"><i class="fa fa-edit"></i></a></button></div>',
                    $fetch_url->is_child,
                    $is_active
                );
                array_push($data1, $array);
            }
            return view('traffic.trafficdiversion',compact(['data1','net_id','op_id','page_name','total','parent_cca']));
      }


      /* to Update Status of traffic confg */ 
    public function partialTrafficUpdate(Request $request){
        $action = $request->action;
        $data = '';
        $status = array('status'=>0,'data'=>$data);
        if($action == 'status'){
            $status = $request->status;
            $id = $request->id;
            $update = array('status' => $request->status);
            $upt1 = Traffic::where('id','=',$id)->update($update);
            if($request->status == 1){
                $data = 'Active';
            }else{
                $data = 'InActive';  
            } 
            $status = array('status'=>'1','data'=>$data);
            
        }else if($action == 'percent'){
            $id = $request->id;
            $update = array('hold_percentage' => $request->percent);
            $upt1 = Traffic::where('id','=',$id)->update($update);
            $status = array('status'=>'1','data'=>$request->percent);
            
            
        }
        $status = Response::json($status);
        return $status;

    }

}

