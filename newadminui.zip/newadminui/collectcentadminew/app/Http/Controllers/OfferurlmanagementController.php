<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Response;
use Cache;
use App\CrcRecordsSmart;
use App\Offerurl;
use Session;
class OfferurlmanagementController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }
   
   public function getOfferurlreport(Request $request, $routename="offerurlmanagementreportpost", $header_name="Offer Url Management"){
	  $condtion = [];
            $ddCondition = [];
            $dtvalue = $request->start;
            $dtvalue2 = $request->end;
            
            
            if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                    $dtvalue2 = date('Y-m-d');
                    $enddate = date('Y-m-d',strtotime("+1 days"));
            }else{
                //$dtvalue2 = date('Y-m-d',strtotime("+1 days"));
               $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));

            }
            
            array_push($condtion,['crc_records_new.create_time','>=',$dtvalue] );
            array_push($condtion,['crc_records_new.create_time','<=',$enddate] );
           // array_push($condtion,['smart_rotator_campaigns_operators.id_zone','!=','0'] );
           // array_push($ddCondition,['smart_rotator_campaigns_operators.id_zone','!=','0'] );
           
            if($request->id_channel){
             //   array_push($condtion,['smart_rotator_campaigns_operators.id_zone','=',$request->id_channel] );
            }
            if($request->operator_id){
              //  array_push($condtion,['smart_rotator_campaigns_operators.op_id','=',$request->operator_id] );
               
            }
            if($request->traffic_type){
              //  array_push($condtion,['smart_rotator_campaigns_operators.ads_cat','=',$request->traffic_type] );

            }
          $request->total = $request->total ? $request->total : 50;
            
            $select = "advertiser_campaigns.id,"
                      ."advertiser_campaigns.id_advertiser,"
                      ."advertiser_campaigns.name,"
                      ."advertiser_campaigns.url,"
                      ."advertiser_campaigns.payout_type,"
                      ."advertiser_campaigns.type,"
                      ."operator.country_code,"
                      ."advertiser_campaigns.cpa as ac_cpa,"
                      ."advertiser_campaigns.id_op as smart_rotator_id,"
                      ."crc_records_new.op_id,"
                      ."crc_records_new.id_channel,"
                      ."crc_records_new.id_advertiser_campaign as smart_rotator_id,"
                      ."crc_records_new.total_cost,"
                      ."crc_records_new.clickcount_fraud as fraud,"
                      ."crc_records_new.id_ad as id_ad,"
                      ."sum(crc_records_new.clickcount) AS clickcount,"
                      ."sum(crc_records_new.conversion_count) AS conversion_count,"
                      ."sum(crc_records_new.clicks_active_count) as clicks_active_count,"
                      ."sum(crc_records_new.conversion_count_unique) as conversion_count_unique,"
                      ."CONCAT(crc_records_new.cr_goal,'%') AS cr_goal,"
                      ."CONCAT(crc_records_new.cr_received,'%') AS cr_received,"
                      ."CONCAT(crc_records_new.cr_given,'%') AS cr_given,"
                      ."crc_records_new.create_time,"
                      ."crc_records_new.traffic_type,"
                      ."crc_records_new.parent_cca,"
                      ."crc_records_new.network_name as network_names,"
		                  ."ad_network.name as network_name,"
                      ."operator.name as operator_name,"
                      ."advertiser.id as advtr_id,"
                      ."advertiser.name  as advertiser_campain_name";
                       
        $appends = [];
	   
		 $data =  DB::table("crc_records_new as crc_records_new")
                    ->selectRaw(DB::raw($select))
                    ->whereIn('crc_records_new.traffic_type',['OM','OG'])
                     ->where($condtion)
                     //->leftJoin("smart_rotator_campaigns_operators as SR","SR.campaign_id","=","crc_records_new.id_advertiser_campaign")
                     ->leftJoin("advertiser_campaigns","advertiser_campaigns.id","=","crc_records_new.id_advertiser_campaign")
                     // ->leftJoin("ads","ads.id_ad","=","crc_records_new.id_ad")
                     ->leftJoin("ad_network","ad_network.ccz","=","crc_records_new.id_channel")
                     ->leftJoin("advertiser","advertiser.id","=","advertiser_campaigns.id_advertiser")
                     ->leftJoin("operator","operator.id","=","advertiser_campaigns.id_op")
                     ->groupby("crc_records_new.id_advertiser_campaign","advertiser_campaigns.id_op","crc_records_new.parent_cca")
                     ->get();
           $i=0;
            $data1 = [];
         
            if($data){
foreach ($data as $fetch_records)
{

  $i++;

            $array = [];
            array_push($array,
               '<a href="/offer-url-management-report_edit/'.$fetch_records->smart_rotator_id.'">'.$fetch_records->name.'</a>',
                $fetch_records->network_name,
                $fetch_records->operator_name,
                $fetch_records->clickcount,
                $fetch_records->clicks_active_count,
                $fetch_records->conversion_count,
                $fetch_records->conversion_count_unique
                
                );
            array_push($data1, $array);


}
 }else{
	 $data1='No data found';
	 }      
           
              $ddData = $this->createDDCareer($request,$ddCondition);
       
         $result  = array('data1' => $data1,
            "routename"=>$routename,
            'header'=>$header_name,
            'dtvalue' => $dtvalue,
            'dtvalue2' => $dtvalue2,
            'ddData' => $ddData,
            'id_channel'=>$request->id_channel,
            'operator_id'=>$request->operator_id,
            'traffic_type' => $request->traffic_type,
            'country'=> $request->country,
            'total'=>$request->total
          );
         return view('Offerurlmanagement.Offerurlmanagementreport')->with($result);
	   } 
	   
	   private function createDDCareer(Request $request,$condition){
		   
		   }
   
   
   
   
   
 public function editgetOfferurlreport($id,$header_name="Edit Offer") 
	{
		     $condtion = [];
		     array_push($condtion,['smart_rotator_campaigns_operators.id_zone','!=','0'] );
		     array_push($condtion,['smart_rotator_campaigns_operators.campaign_id','=',$id] );
		     $select =   "crc_records_new.advertiser_campain_name as advertiser_campain_name"
                        .",crc_records_new.network_name"
                        .",crc_records_new.op_name"
						.",smart_rotator_campaigns_operators.id"
						.",smart_rotator_campaigns_operators.campaign_id"
						.",smart_rotator_campaigns_operators.op_id"
						.",smart_rotator_campaigns_operators.id_zone"
						.",smart_rotator_campaigns_operators.country_code"
						.",smart_rotator_campaigns_operators.smart_live"
						.",smart_rotator_campaigns_operators.ads_cat"
						.",smart_rotator_campaigns_operators.smart_status"
						.",smart_rotator_campaigns_operators.is_offer_direct"
						.",smart_rotator_campaigns_operators.offer_url"
						.",smart_rotator_campaigns_operators.redirect_operator_config";
          $appends = [];
	   
		  $data =  DB::table("smart_rotator_campaigns_operators")
					->where($condtion) 
					->selectRaw(DB::raw($select))
					->leftJoin("crc_records_new","crc_records_new.id_advertiser_campaign","=","smart_rotator_campaigns_operators.campaign_id")
					->groupBy("smart_rotator_campaigns_operators.id_zone")->orderby("smart_rotator_campaigns_operators.campaign_id")->get();
		    $data1 = [];
        $stat = '';
        $i=0;
        $count_data=count($data);
        foreach ($data as $fetch_records)
        {
         
			$array = [];
            
			 if($fetch_records->is_offer_direct==1)
            {
               $is_offer_direct ='<input type="checkbox"  onclick = Editoffer('.$fetch_records->is_offer_direct.','.$fetch_records->id.'); id="is_offer_direct" name="toggleBtn" checked data-toggle="toggle" data-on="Active" data-off="Inactive" data-onstyle="success" data-offstyle="danger" data-size="mini" value="'.$fetch_records->id.'">On';
            }
            else
            {
                $is_offer_direct ='<input type="checkbox"  onclick = Editoffer('.$fetch_records->is_offer_direct.','.$fetch_records->id.'); id="is_offer_direct" name="toggleBtn" data-toggle="toggle" data-on="Active" data-off="Inactive" data-onstyle="success" data-offstyle="danger" data-size="mini" value="'.$fetch_records->id.'">Off';
            }
            array_push($array,
      
                $fetch_records->id_zone,
                $fetch_records->offer_url,
                $fetch_records->smart_status,
                $is_offer_direct
               
                );
            array_push($data1, $array);

        }
        
       
        return view('Offerurlmanagement.OfferurlmanagementList',compact(['data1','header_name','count_data']));

    }
    
    public function updateOfferurlreport(Request $request,$header_name="Update Offer") 
	{
			$status=$request->status;
			$id=$request->id;
			$action_step=$request->action_step;
		     $data1=$dataMain=[];
		     if($status=='false' && $action_step == 'smart_live'){
				 $update = array('smart_live' => '0');
			 }else{
				 $update = array('smart_live' => '1');
				 }
				  if($status=='false' && $action_step == 'is_offer_direct'){
				 $update = array('is_offer_direct' => '0');
			 }else{
				 $update = array('is_offer_direct' => '1');
				 }
		      if($request->id){
                $dataMain = Offerurl::where('id',$request->id)->update($update);
                if($dataMain){
					$dataCountry_name =Offerurl::where('id',$request->id)->get();
					
					$dataMain= DB::table("advertiser_campaigns")->select('advertiser_campaigns.name as offer_url','advertiser_campaigns.id as campaign_id')
					->where('advertiser_campaigns.country_code','=',$dataCountry_name[0]->country_code)
					->whereIN('operator.id',[-1,0])
					->leftJoin("operator","operator.id","=","advertiser_campaigns.id_op")->get();
					$status = array('success_status'=>$status,'action_step'=>$action_step,'data'=>$dataMain);
                }
             }
         
        Session::flash('message', 'Successfully updated ads!');
		  $status = Response::json($status);
              
             return $status; 

    }
    
    public function updateOfferurl_redirect_operator_config(Request $request,$header_name="Update Offer") 
	{

//{"ES":"20034","IN":"6789"}   {"1":"20034","2":"6789"}
		$id=$request->id;
    $percentage=$request->percentage;
		$campagin_name=explode(',',$request->campagin_name);

     
      $j_a=array();

    foreach ($campagin_name as $key => $value) {
      $j_a[$value]= $percentage;
    }
    $redirect_diversion_config=json_encode($j_a);
    $redirect_country_config=$request->redirect_country_config['json'];
    $redirect_operator_config=$request->redirect_operator_config['json'];
		if($id){
			 $update = array('redirect_diversion_config' => $redirect_diversion_config,
        'redirect_country_config'=>$redirect_country_config,
        'redirect_operator_config'=>$redirect_operator_config);
			 $dataMain =Offerurl::where('id',$request->id)->update($update);
     //  $dataMain=1;
			  if($dataMain){
				  $status = array('success_status'=>'success');
				  }else{
					    $status = array('success_status'=>'fail');
					  }
			}
		
			return $status;
	
    }
   
   
}
