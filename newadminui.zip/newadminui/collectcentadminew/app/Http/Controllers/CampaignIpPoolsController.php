<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\QueryAccess;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Auth;
use App\CampaignIpPools;
use App\IpPools;
use Illuminate\Support\Facades\Redis;
use Cache;
use Log;



class CampaignIpPoolsController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request){
        $select =  [
            "id",
            "campaign_id",
            "id_ad",
            "ip_pool_id",
            "status",
            "created", 
            "updated", 
         ];
        $condtion = [];
        $data =  CampaignIpPools::with(['IpPools','AdvertiserCampaign'])->get();
        // dd($data);
        $data1= [];
         $count = 0;
          foreach ($data as $result) {
                $array = [];
                $count++;
                array_push($array,
                            $result->id,
                            $result->AdvertiserCampaign->name."(".$result->campaign_id.")",
                            $result->id_ad,
                            isset($result->IpPools->name)?$result->IpPools->name:''."(".$result->ip_pool_id.")",
                            $result->status == 1 ? 'Active':'InActive',
                            $result->created,
                            $result->updated,
                            "<a href=/campaign-ip-pool/edit/$result->id>Edit</a>"
                          );
                  array_push($data1, $array);
          }
          return view('CampaignIpPools.index',compact('data1'));
      }
    
    public function add(Request $request){
        $ipPools =  IpPools::all();
        $select_adv =  ["id","name"];
        $advertier_data =  DB::table("advertiser")->select($select_adv)->get();
        $select_opr =  ["opr.id","opr.name","opr.country_code as iso"];
        $oprdata =  DB::table("operator as opr")->select($select_opr)->leftjoin('country as count', 'count.iso', '=', 'opr.country_code')->get();
        $select_country =  ["id","iso","name"];
        $country_data =  DB::table("country")->select($select_country)->get();
        $result  = array(
            'operator' => $oprdata,
            'country' => $country_data,
            'advertiser'=> $advertier_data,
            'ipPools' => $ipPools
        );
        $viewPage = "CampaignIpPools.add";
        $dataN =  view($viewPage)->with($result);
        return $dataN;
    }
    
    
    public function store(Request $request){
      $created = date('Y-m-d H:i:s');
      // $campaigns_arr = explode("_",$request->campaign);
       //  if(count($campaigns_arr) > 1){
            $campaign_id = $request->campaign;
            $id_ad = $request->id_ad;
       //  }else{
        //    return redirect('add-campaign-ip-pool'); 
        // }
        if($request->ip_pool_id){
              CampaignIpPools::create(
              [
                'campaign_id' => $campaign_id,
                'ip_pool_id' => $request->ip_pool_id,
                'id_ad' => $id_ad, 
                'status' => '1',
                'created' => $created
              ]
              );
        }else if($request->ip_pools){
           
           $validate = $this->validate($request,[
              'name' => 'required|unique:ip_pools|max:275',
              'ip_pools' => 'required',
           ]);
           
            if($validate->fails()) {
              return Redirect::back()->withErrors($validate);
            }

           $ip_pool_id = IpPools::create(
            [
              'ip_pools' => $request->ip_pools,
              'name' => $request->name,
              'created' => $created
            ]
            );
            
            CampaignIpPools::create(
            [
              'campaign_id' => $campaign_id,
              'ip_pool_id' => $ip_pool_id->id,
              'id_ad' => $id_ad, 
              'status' => '1',
              'created' => $created
            ]
            );
        }else{
            return redirect('add-campaign-ip-pool');     
        }
        return redirect('campaign-ip-pool');  
    }

    
    public function edit($id){
        // $campaignIpPools = CampaignIpPools::find($id);
        $campaignIpPools = CampaignIpPools::with(['AdvertiserCampaign','IpPools'])->find($id);
        // $campaignIpPools =  $campaignIpPools->toArray();
        $ipPools =  IpPools::all();
        $select_adv =  ["id","name"];
        $advertier_data =  DB::table("advertiser")->select($select_adv)->get();
        $select_opr =  ["opr.id","opr.name","opr.country_code as iso"];
        $oprdata =  DB::table("operator as opr")->select($select_opr)->leftjoin('country as count', 'count.iso', '=', 'opr.country_code')->get();
        $select_country =  ["id","iso","name"];
        $country_data =  DB::table("country")->select($select_country)->get();
        // print"<pre>";print_r($campaignIpPools);print"</pre>";die;
        // dd($campaignIpPools);
        $result  = array(
            'operator' => $oprdata,
            'country' => $country_data,
            'advertiser'=> $advertier_data,
            'ipPools' => $ipPools,
            'campaignIpPools' => $campaignIpPools
        );
        $viewPage = "CampaignIpPools.edit";
        $dataN =  view($viewPage)->with($result);
        return $dataN;
    }


    public function getCampaigns(Request $request){
        $operator = $request->operator;
        $country = $request->country;
        $advertiser = $request->advertiser;
        $advertiser_campaigns = [];
        if($operator && $country && $advertiser){
            $advertiser_campaigns = DB::select("select id,id_advertiser,name,url from advertiser_campaigns 
                    where id_op = '$operator' AND country_code = '$country' AND id_advertiser = '$advertiser' AND status = 1 order by name");
        } 
        $status = array('status'=>1,'advertiser_campaigns'=>$advertiser_campaigns); 
        $status = json_encode($status);
        return $status; 
    }



    public function update(Request $request){
       $created = date('Y-m-d H:i:s');
       // $campaigns_arr = explode("_",$request->campaign);
      // if(count($campaigns_arr) > 1){
            $campaign_id = $request->campaign;
            $id_ad = $request->id_ad;
       //  }else{
        //  return redirect('edit-campaign-ip-pool'); 
       //  }
        if($request->ip_pools){
           $ip_pool_id = IpPools::create(
            [
              'ip_pools' => $request->ip_pools,
              'name' => $request->name,
              'created' => $created
            ]
            );
        }
        if($request->id){
          $CampaignIpPools = CampaignIpPools::find($request->id);
          $CampaignIpPools->campaign_id = $campaign_id;
          $CampaignIpPools->id_ad = $id_ad;
          if($request->ip_pool_id){
            $CampaignIpPools->ip_pool_id = $request->ip_pool_id;
          }else{
            $CampaignIpPools->ip_pool_id = $ip_pool_id->id;
          }
          $CampaignIpPools->save();
        }else{
            return redirect('edit-campaign-ip-pool');     
        }
        return redirect('campaign-ip-pool');  
    }


    public function destroy($id)
    {
        CampaignIpPools::destroy($id);
        return redirect()->route('CampaignIpPools.index')
                        ->with('success','Member deleted successfully');
    }








    
     

    

    

  
    



}
