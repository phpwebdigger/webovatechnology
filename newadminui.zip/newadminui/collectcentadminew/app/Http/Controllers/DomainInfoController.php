<?php

namespace App\Http\Controllers;
use App\User;
use App\Role;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Cookie;
use App\DomainInfo;


class DomainInfoController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

    function index(Request $request){
        
//        $view = 'deactivation.index';
//        return view($view);
        return view('redirect.index',["errors"=>""]);
    }
    
    function add_data(Request $request){
        $time_stamp = date("Y-m-d H:i:s");
//        echo "<pre>";
//        print_r($request->all());
//        echo "</pre>";die();
        
        $company_name = $request->company_name;
        $server_name = $request->server_name;
        $ips = $request->ips;
        $domain_name = $request->domain_name;
        $status = $request->status;
        
        $dataS  = array(
            'companyName'=>$company_name,
            'serverName'=>$server_name,
            'ip'=>$ips,
            'domainName'=>$domain_name,
            'status'=>$status
          ); 
        
        
        if(DB::table('domainInfo')->insert($dataS))
        {
            $status = ['status'=>'1','message'=>'Successfully inserted '];
            echo json_encode($status);
            exit;
        }
        else
        {
            $status = ['status'=>'0','message'=>'Problem while insetion'];
            echo json_encode($status);
            exit;
        }

    }
    
    function edit_domaininfo(Request $request){
        
//        echo "<pre>";
//        print_r($request->all());
//        echo "</pre>";
//        die();
        
        
        $id = $request->id;
        $st = $request->status;
        $domain_name = $request->domain_name;
        
        $update = DB::table('domainInfo')
            ->where('domainId', $id)
            ->limit(1)
            ->update(['domainName' => $domain_name,'status'=>$st]);

        if($update)
        {
            $status = ['status'=>'1','message'=>'Successfully updated '];
            echo json_encode($status);
            exit;
        }
        else
        {
            $status = ['status'=>'0','message'=>'Problem while updation'];
            echo json_encode($status);
            exit;
        }

    }
    
    function data(Request $request){
        $select =  [
            "domainId",
            "companyName",
            "serverName",
            "ip",
            "domainName",
            "status"
        ];

        
        $data =  DB::table("domainInfo")
        ->select($select)
        ->orderBy('domainId', 'desc')
//        ->limit(100)
         ->get();
        $data1= [];
        $count = 0;
         
         
//        dd($data);die();
         
        foreach ($data as $result) {
               $array = [];

               $count++;
               array_push($array,
                           $result->companyName,
                           $result->serverName,
                           $result->ip,
                           $result->domainName,
                           $result->status,
                           '<a href="edit-domaininfo/'.$result->domainId.'"<i class="fa fa-edit"></i>'
                       
                       );
               array_push($data1, $array);

        }
          
        
        $view = 'redirect.redirectDomain-data';
        return view($view,compact('data1'));
    }
    
    function edit(Request $request){
        
        $data1 = DB::table('domainInfo')
                ->select('*')
                ->where('domainId', '=', $request->domainId)
                ->get();
//        dd($data1);
        
//        $data1=DomainInfo::find($request->domainId);
        return view('redirect.domaininfo_edit',compact('data1'));
    }
    

    


  
}
