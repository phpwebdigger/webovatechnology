<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Response;
use Illuminate\Support\Facades\Redis;
use Cache;
use App\Advertiser;
use App\Operator;
use App\AdvertiserCampaigns;
/**
* 
*/
class ConversionreportController extends Controller
{
	
	  public function __construct()
    {
        $this->middleware('auth');
    }


public function index(Request $request){

 $hour = date("H");
  if(!empty($request->start)){
    $current_date= date('Ymd', strtotime($request->start));//$request->start;
    }else{
   $current_date = date('Ymd');      
      }

    $dtvalue = date('Y-m-d');
      $enddate = date('Y-m-d',strtotime("+1 days"));
    
    $total_pages = $request->total ? $request->total:50;
    
    $advertiser_is=$request->advertiser;

        $condtion =[]; $condtion2=[];
            $ddCondition = [];
            $dtvalue = $request->start;
            
            if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            }
            
            
           

            $condtion1 = [];

           // array_push($condtion,['date(con.create_time)','>=',$dtvalue] );
            if($request->advertiser > 0){
              array_push($condtion,['advertiser_campaigns.id_advertiser','=',$request->advertiser]);
              // array_push($condtion2,['crc_records_new.id_advertis','=',$request->advertiser]);
              array_push($condtion2,['crc_records_new.create_time','=',$dtvalue]);
          
          }
           array_push($ddCondition,['advertiser_campaigns.id_advertiser','=',$request->advertiser]);
           array_push($ddCondition,['con.click_hour','=',$request->advertiser]);
            if($request->advertiser > 0){
           $data_det = DB::select( DB::raw("select crc_records_new.advertiser_name, crc_records_new.id_advertiser,sum(crc_records_new.conversion_count) as conversions, sum(crc_records_new.sale_count) as sale_count, (sum(crc_records_new.conversion_count)+sum(crc_records_new.sale_count)) as total_conversion, date(crc_records_new.create_time),sum(crc_records_new.conversion_count_unique * crc_records_new.advertiser_campain_cpa) as total_revenue_price,sum(crc_records_new.conversion_count_unique) as conversion_count_unique from `crc_records_new` where (date(`crc_records_new`.`create_time`) = '$dtvalue' and `crc_records_new`.`id_advertiser` = '$request->advertiser') group by `crc_records_new`.`id_advertiser` order by `crc_records_new`.`id_advertiser` desc;"));
         }else{
           $data_det = DB::select( DB::raw("select crc_records_new.advertiser_name, crc_records_new.id_advertiser,sum(crc_records_new.conversion_count) as conversions , sum(sale_count) as sale_count , (sum(crc_records_new.conversion_count)+sum(crc_records_new.sale_count)) as total_conversion, date(crc_records_new.create_time),sum(crc_records_new.conversion_count_unique * crc_records_new.advertiser_campain_cpa) as total_revenue_price,sum(crc_records_new.conversion_count_unique) as conversion_count_unique from `crc_records_new` where (date(`crc_records_new`.`create_time`) = '$dtvalue') group by `crc_records_new`.`id_advertiser` order by `crc_records_new`.`id_advertiser` desc;"));
         }
          $select = "sum(con.price) as dollar_price" 
                              .",advertiser_campaigns.id_advertiser" 
                              .",advertiser.id as id_advertiser"; 

          $data =  DB::table('conversions_'.$current_date.' as con')
              ->where($condtion) 
             ->selectRaw(DB::raw($select))
             ->leftJoin("advertiser_campaigns","advertiser_campaigns.id","=","con.id_advertiser")->leftJoin("advertiser","advertiser_campaigns.id_advertiser","=","advertiser.id")
               ->groupby("advertiser.id")
              ->orderby("advertiser_campaigns.name","DESC");
           
            if(!empty($request->groupby)){
              $data = $this->groupby_data($ddCondition,$current_date);
            }else{
            $data =  $data->get()->toArray();

          }
                
                $longArray=array();
                foreach ($data as $key => $value) {
                  $longArray[$value->id_advertiser]=(array) $value;
                }

                foreach ($data_det as $key => $value) {
               
                  if(isset($longArray[$value->id_advertiser])){
                    $data_det[$key]->dollar_price =  $longArray[$value->id_advertiser]['dollar_price'];

                  } else {
                    $data_det[$key]->dollar_price =  "0.0";

                  }
                  
                }




                     
$data1=[];
  $total_revenue = $total_revenue_prices= 0;
                  foreach ($data_det as $result) {
                    if($result->conversions>0){
                                 $array = [];
                         array_push($array,
                                  $result->advertiser_name,
                                  $result->conversion_count_unique,
                                  $result->conversions,
                                  $result->sale_count,
                                  $result->total_conversion,
                                  $result->dollar_price,
                                  $result->total_revenue_price
                                 );

                    array_push($data1, $array);

                      $total_revenue += $result->dollar_price;
                      $total_revenue_prices +=  $result->total_revenue_price;
                      }
                }


                // echo '<pre>';
                // print_r($data1);
                // echo '</pre>';  exit();

                   $lastRow =[
                        $total_revenue ,
                        $total_revenue_prices
                         ];


               $advertiser_dropdown= $this->advertiser_list();
                  $result  = array(
                'dtvalue' => $dtvalue,
                'data1' => $data1,
                'total'=>$total_pages,
                'hour' => $hour,
                'header'=>'Conversions Report',
                'routename'=>'convesionreports',
               'lastRow' => $lastRow,
                'advertiser_list'=>$advertiser_dropdown,
              );
                   $viewPage = "Conversionreports.conversion_index";

             $dataN =  view($viewPage)->with($result);
             return $dataN;



}




public function groupby_data($condtion,$table_name){

    $select = "sum(con.price) as dollar_price" 
                              .",advertiser_campaigns.id_advertiser" 
                              .",advertiser.id as id_advertiser"; 

          $data =  DB::table('conversions_'.$table_name.' as con')
              ->where($condtion) 
             ->selectRaw(DB::raw($select))
             ->leftJoin("advertiser_campaigns","advertiser_campaigns.id","=","con.id_advertiser")
             ->leftJoin("advertiser","advertiser_campaigns.id_advertiser","=","advertiser.id")
             // ->groupby("con.id_advertiser")
               ->groupby("advertiser.id")
             ->groupby("advertiser_campaigns.id")
             ->orderby("advertiser_campaigns.name","DESC");
             
              $data =  $data->get();

              return $data;

}






function objectToArray($d) 
{
    if (is_object($d)) {
        // Gets the properties of the given object
        // with get_object_vars function
        $d = get_object_vars($d);
    }

    if (is_array($d)) {
        /*
        * Return array converted to object
        * Using __FUNCTION__ (Magic constant)
        * for recursive call
        */
        return array_map(__FUNCTION__, $d);
    } else {
        // Return array
        return $d;
    }
}



	 public function advertiser_list(){
       $select = "advertiser.name  as adv_name"
      .",advertiser_campaigns.id_advertiser"
      .",advertiser_campaigns.name";
	  $data = DB::table("advertiser_campaigns")
  ->selectRaw(DB::raw($select))
  ->leftJoin("advertiser","advertiser_campaigns.id_advertiser","=","advertiser.id")
  ->orderby("advertiser_campaigns.name")->get();

   $ddDataResult  = array(
                'advertiser_dropdown' => [],
               
            );
    foreach ($data as $dropdown) {

            if ($dropdown->id_advertiser){
                $ddDataResult['advertiser_dropdown'][$dropdown->id_advertiser] = $dropdown->adv_name .' ['.$dropdown->id_advertiser.']';
            }
         
          }
return $ddDataResult;
  }


public function groupby_data_old($condtion,$table_name){

/*
				$select = "advertiser.name  as name"
					.",advertiser.id as id_advertiser "
          .",advertiser_campaigns.name as advt_name"
					 .",advertiser_campaigns.cpa as cpa "
					.",con.id_conversion"
           .",count(1) as conversions"
              // .",(count(1) * advertiser_campaigns.cpa) as revenue_price"
                   .",con.id_ad"
                   .",con.id_zone"
                   .",con.cc_token" 
                   .",date(con.click_date_time)"
                   .",date(con.datetime)"
                   .",con.id_advertiser as id_ad"
                   .",con.parent_cca"
                   .",con.siteid"
                   .",con.network_token"
                   .",con.status" 
                   .",con.country"
                   .",con.price"
                   .",con.click_hour"
                   .",con.activation_mode"
                   .",con.client_ip"
                   .",con.pubid"
                   .",con.subid"
                   .",con.subid1"
                   .",con.subid2"
                   .",sum(con.dollar_price)  as dollar_price ";
*/                    

                    $select = "sum(con.price) as dollar_price" 
                              .",advertiser_campaigns.id_advertiser" 
                              .",advertiser.id as id_advertiser"; 

          $data =  DB::table('conversions_'.$table_name.' as con')
              ->where($condtion) 
             ->selectRaw(DB::raw($select))
             ->leftJoin("advertiser_campaigns","advertiser_campaigns.id","=","con.id_advertiser")
             ->leftJoin("advertiser","advertiser_campaigns.id_advertiser","=","advertiser.id")
             // ->groupby("con.id_advertiser")
               ->groupby("advertiser.id")
             ->groupby("advertiser_campaigns.id")
             ->orderby("advertiser_campaigns.name","DESC");
             
              $data =  $data->get();

              return $data;

}


	public function data_list(Request $request,$condtion){

		$fields = ["advertiser.name",
                   "con.id_conversion",
                   "con.id_ad",
                   "con.id_zone",
                   "con.cc_token", 
                   "date(con.click_date_time)",
                   "date(con.datetime)",
                   "con.id_advertiser",
                   "con.parent_cca",
                   "con.siteid",  
                   "con.network_token",
                   "con.status", 
                   "con.country",
                   "con.price", 
                   "con.click_hour", 
                   "con.activation_mode",
                   "con.client_ip",
                   "con.pubid",
                   "con.subid",
                   "con.subid1",
                   "con.subid2",
                   "con.dollar_price as dollar_price",
                   // "ad_network.name AS network_name" 
                ];
            $fields =  implode(",",$fields);    
            $sql = "select $fields from conversions_$current_date  as con Left join advertiser_campaigns ON  

            con.id_advertiser=advertiser.id  where 1 $condtion  group by con.id_advertiser limit $total_pages";
            $data = DB::select(DB::raw($sql));

            return $data;

	}

  //Advertiser log reports function date - 2018-04-11

  public function Advertiser_log_reports(Request $request){

          
           if(!empty($request->start)){
             $dtvalue = $request->start;
            }else{
             $dtvalue = date('Y-m-d');      
              }

           $enddate = $dtvalue2 = $request->end;
           $date = new \DateTime($request->start);
           $table_date = $date->format('Ymd');

            $result =[];
            
            $advertiser_list= Advertiser::select('advertiser.id','advertiser.name','advertiser.country')->get();

            $data1=[];
            
            $total=50;

            $data1=[];
            $ddCondition= $condtion = [];
          
            $id_ad=[];
            $advertiser_campaigns_id=$camapign_name= $id_advertiser="";

            if( !empty($request->advertiser) || !empty($request->Operator)  || !empty($request->camapign_name) && isset($request->camapign_name) )
                {
            $data1= $this->advertiser_log_reports_filter($table_date,$dtvalue,$request->advertiser,$request->Operator,$request->camapign_name);
            }
              
      $header="Advertiser Log Reports";

      return view('Advertiserlogreports.index',compact(['data1','id_advertiser','camapign_name','op_name','advertiser_list','routename','header','total','dtvalue','dtvalue2']));

  }

public function advertiser_log_reports_filter($table_date,$date,$advertiser,$operator_value,$camapign_name_data){

   $data1=[];
   $ddCondition= $condtion = [];
   $data=0;

if(!empty($advertiser)) {
    $advertiser = "  AND advertiser_campaigns.id_advertiser='" . $advertiser . "'";
}


 if(!empty($camapign_name_data!='null') && isset($camapign_name_data) ) {
  $camapign_name_data = implode("','",$camapign_name_data);  
  $camapign_name_value = "  AND advertiser_campaigns.id IN ('" . $camapign_name_data . "')";
}else{
  $camapign_name_value="";
}

if($operator_value!='null') {

    $operator = "  AND advertiser_campaigns.id_op='" . $operator_value . "'";              
}else{
  $operator ="";
}

 $advertiser_campaigns_id =" select id as id_ad, id_advertiser from advertiser_campaigns 
where  1  $advertiser  $operator   $camapign_name_value "  ;
$data_id_ad = DB::select(DB::raw($advertiser_campaigns_id));
  $data_id_ad = json_decode(json_encode($data_id_ad),true);
    if(count($data_id_ad)>0)
    {
    foreach ($data_id_ad as $key => $value) {
      $id_ad[]= $value['id_ad'];
    }

   }

    
    if(empty($camapign_name_data) ){
      if(count($id_ad) > 0){
        $list_ad= implode(',', $id_ad);
        $id_advertiser= ' conversions.id_advertiser IN ('.$list_ad.')';
    }
  $sql ="select conversions.datetime,conversions.id_ad,conversions.cc_token,conversions.id_advertiser,advertiser_campaigns.name as campagin_name,advertiser_campaigns.url,conversions.parent_cca, conversions.siteid,conversions.network_token,conversions.postback_url,conversions.price, conversions.client_ip,dollar_price,conversions.pubid, conversions.subid , conversions.click_date_time, conversions.id_zone , conversions.sale 
  from conversions_$table_date as conversions left join advertiser_campaigns ON advertiser_campaigns.id=conversions.id_advertiser  where $id_advertiser  and date(`conversions`.`datetime`) = '$date' order by `conversions`.`datetime` desc ";  
    $data = DB::select(DB::raw($sql));
    $data = json_decode(json_encode($data),true);
     foreach ($data as $key => $fetch_records) {
                  
                $array = [];
                   array_push($array,
                    $fetch_records['datetime'],$fetch_records['id_ad'],$fetch_records['cc_token'],$fetch_records['id_advertiser'],
                     $fetch_records['campagin_name'],$fetch_records['url'],
                    $fetch_records['parent_cca'],$fetch_records['siteid'],$fetch_records['network_token'],$fetch_records['postback_url'],$fetch_records['price'],$fetch_records['client_ip'],$fetch_records['dollar_price'],$fetch_records['pubid'],$fetch_records['subid'],$fetch_records['click_date_time'],$fetch_records['id_zone'],$fetch_records['sale']);
                   array_push($data1, $array);
              }
  }
  else if(!empty($camapign_name_data!='null') ){
  // $camapign_name_data = implode("','",$camapign_name_data);   
  $sql ="select conversions.datetime,conversions.id_ad,conversions.cc_token,conversions.id_advertiser,advertiser_campaigns.name as campagin_name,advertiser_campaigns.url,conversions.parent_cca, conversions.siteid,conversions.network_token,conversions.postback_url,conversions.price, conversions.client_ip,dollar_price,conversions.pubid, conversions.subid , conversions.click_date_time, conversions.id_zone , conversions.sale from conversions_$table_date as conversions left join advertiser_campaigns ON advertiser_campaigns.id=conversions.id_advertiser where conversions.id_advertiser IN ('$camapign_name_data')  and date(`conversions`.`datetime`) = '$date' order by `conversions`.`datetime` desc ";  



$data = DB::select(DB::raw($sql));
$data = json_decode(json_encode($data),true);
 foreach ($data as $key => $fetch_records) {
                  
                $array = [];
                   array_push($array,
                   $fetch_records['datetime'],$fetch_records['id_ad'],$fetch_records['cc_token'],$fetch_records['id_advertiser'],
                     $fetch_records['campagin_name'],$fetch_records['url'],
                    $fetch_records['parent_cca'],$fetch_records['siteid'],$fetch_records['network_token'],$fetch_records['postback_url'],$fetch_records['price'],$fetch_records['client_ip'],$fetch_records['dollar_price'],$fetch_records['pubid'],$fetch_records['subid'],$fetch_records['click_date_time'],$fetch_records['id_zone'],$fetch_records['sale']);
                   array_push($data1, $array);
              }
  }

              

        
                   return $data1;


}


public function advertiser_log_reports_filter_BACKUPS($table_date,$date,$advertiser,$operator,$camapign_name){
                $data1=[];
                $ddCondition= $condtion = [];
                  $data=0;
                    if( empty($operator!="null") && empty($camapign_name!="null") && !empty($advertiser) ){
  
  $advertiser_campaigns_id ="select id as id_ad, id_advertiser from advertiser_campaigns where id_advertiser=".$advertiser ;
  $data_id_ad = DB::select(DB::raw($advertiser_campaigns_id));
  $data_id_ad = json_decode(json_encode($data_id_ad),true);
    if(count($data_id_ad)>0)
    {
    foreach ($data_id_ad as $key => $value) {
      $id_ad[]= $value['id_ad'];
    }

   }
    if(count($id_ad) > 0){
        $list_ad= implode(',', $id_ad);
        $id_advertiser= 'conversions.id_advertiser IN ('.$list_ad.')';
    }

    $sql ="select conversions.datetime,conversions.id_ad,conversions.cc_token,conversions.id_advertiser,advertiser_campaigns.name as campagin_name,advertiser_campaigns.url,conversions.parent_cca, conversions.siteid,conversions.network_token,conversions.postback_url,conversions.price, conversions.client_ip,dollar_price,conversions.pubid, conversions.subid , conversions.click_date_time, conversions.id_zone , conversions.sale 
  from conversions_$table_date as conversions left join advertiser_campaigns ON advertiser_campaigns.id=conversions.id_advertiser  where $id_advertiser  and date(`conversions`.`datetime`) = '$date' order by `conversions`.`datetime` desc ";  
    $data = DB::select(DB::raw($sql));
    $data = json_decode(json_encode($data),true);
     foreach ($data as $key => $fetch_records) {
                  
                $array = [];
                   array_push($array,
                    $fetch_records['datetime'],$fetch_records['id_ad'],$fetch_records['cc_token'],$fetch_records['id_advertiser'],
                     $fetch_records['campagin_name'],$fetch_records['url'],
                    $fetch_records['parent_cca'],$fetch_records['siteid'],$fetch_records['network_token'],$fetch_records['postback_url'],$fetch_records['price'],$fetch_records['client_ip'],$fetch_records['dollar_price'],$fetch_records['pubid'],$fetch_records['subid'],$fetch_records['click_date_time'],$fetch_records['id_zone'],$fetch_records['sale']);
                   array_push($data1, $array);
              }
  }
  else if(!empty($camapign_name) ){

  $sql ="select conversions.datetime,conversions.id_ad,conversions.cc_token,conversions.id_advertiser,advertiser_campaigns.name as campagin_name,advertiser_campaigns.url,conversions.parent_cca, conversions.siteid,conversions.network_token,conversions.postback_url,conversions.price, conversions.client_ip,dollar_price,conversions.pubid, conversions.subid , conversions.click_date_time, conversions.id_zone , conversions.sale from conversions_$table_date as conversions left join advertiser_campaigns ON advertiser_campaigns.id=conversions.id_advertiser where conversions.id_advertiser=$camapign_name  and date(`conversions`.`datetime`) = '$date' order by `conversions`.`datetime` desc ";  
$data = DB::select(DB::raw($sql));
$data = json_decode(json_encode($data),true);
 foreach ($data as $key => $fetch_records) {
                  
                $array = [];
                   array_push($array,
                   $fetch_records['datetime'],$fetch_records['id_ad'],$fetch_records['cc_token'],$fetch_records['id_advertiser'],
                     $fetch_records['campagin_name'],$fetch_records['url'],
                    $fetch_records['parent_cca'],$fetch_records['siteid'],$fetch_records['network_token'],$fetch_records['postback_url'],$fetch_records['price'],$fetch_records['client_ip'],$fetch_records['dollar_price'],$fetch_records['pubid'],$fetch_records['subid'],$fetch_records['click_date_time'],$fetch_records['id_zone'],$fetch_records['sale']);
                   array_push($data1, $array);
              }
  }

              

        
                   return $data1;


}


  public function advertiser_operator_list(Request $request){

      $advertiser = $request->advertiser_id;
      $operator_list = DB::table('advertiser_campaigns')
      ->select('operator.id',DB::raw('concat(operator.name,"(",operator.country_code,")" ) as name'))->join('operator', 'operator.id', '=', 'advertiser_campaigns.id_op')->where('advertiser_campaigns.id_advertiser','=',$advertiser)->groupby('advertiser_campaigns.id_op')->orderby('operator.name','ASC')->get();
      return $operator_list;

  }

  public function advertiser_log_campagin(Request $request){
    $op_id= $request->Operator_id;
    $advertiser_id = $request->advertiser_id;
    $camapain_list = DB::table('advertiser_campaigns')
    ->select('advertiser_campaigns.id',DB::raw('concat(advertiser_campaigns.name,"(",advertiser_campaigns.id,")") as name') ) 
    ->where('advertiser_campaigns.id_advertiser','=',$advertiser_id)
    ->where('advertiser_campaigns.id_op','=',$op_id)->orderby('advertiser_campaigns.name','ASC')->get();
    return $camapain_list;
  }



}

?>