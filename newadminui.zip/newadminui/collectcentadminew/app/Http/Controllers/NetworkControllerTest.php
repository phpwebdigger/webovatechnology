<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\AdNetwork;
use App\Users;
use Illuminate\Support\Facades\Redis;
use Cache;
use App\Ad;

class NetworkControllerTest extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function redisConnection(){
      $redis; 
        try{
            $redis = Redis::connection();
            return $redis; 
        }catch(\Exception $e){
           return false;
        }
        
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request,$type="",$routename = "networkfilter",$header="Network CR Update")
    {
            $redis = Redis::connection();
            $dtvalue = date('Y-m-d');
            $enddate = date('Y-m-d',strtotime("+1 days"));
            $adData = $condtion = $cond = $appends = $ddCondition =  []; 
            $adDataArray = "";
            $is_smart = $request->is_smart_cca ? $request->is_smart_cca : 0;
            array_push($ddCondition,["ads.description","!=","default"] );
            if($request->is_smart_cca == 1){
                array_push($ddCondition,["ads.is_smart_cca","=","1"] );
            }
            array_push($ddCondition,['crc_network_campaign_new.create_time','>=',$dtvalue] );
            array_push($ddCondition,['crc_network_campaign_new.create_time','<=',$enddate] );
            $key = "network_cr_dropdowns$is_smart";
            try{
                if($request->cache == 1){
                    $redis->delete($network_cr_key);
                } 
                if(!$redis->exists($key)){
                  $ddData = $this->createDD($request,$type,$ddCondition);
                  Redis::set($key, json_encode($ddData));
                  $redis->expire($key,900);
                }else{
                    $ddData = json_decode(Redis::get($key),true);
                }
            } catch(\Exception $e){
                $ddData = $this->createDD($request,$type,$ddCondition);
            }
            $start = microtime(true);
            $network_cr_key = "network_cr_data$is_smart";
                try{
                  if($request->cache == 1){
                      $redis->delete($network_cr_key);
                  } 
                  if(!$redis->exists($network_cr_key)){
                    $data = $this->getNetworkCrData($request);
                    if(count($data['data']) > 0){ 
                        Redis::set($network_cr_key, json_encode($data));
                        $redis->expire($network_cr_key,450);
                    }
                  }else{
                      $data = json_decode(Redis::get($network_cr_key),true);
                  }
                }catch(\Exception $e){
                    $data = $this->getNetworkCrData($request);
                }
                $allData = '';
                if(count($data['data']) > 0){
                    $allData = $data['data'];
                }
            $result  = array(
                          'data' => $data, 
                          'data1' => $allData,
                          "routename"=>$routename,
                          'header'=>$header,
                          'dtvalue' => $dtvalue,
                          'dtvalue2' => $enddate,
                          'ddData' => $ddData,
                          'id_channel'=>$request->id_channel,
                          'operator_id'=>$request->operator_id,
                          'traffic_type' => $request->traffic_type,
                          'country'=> $request->country,
                          'total'=>$request->total,
                          'lastRow'=>$data['lastRow'],
                          'is_smart'=>$is_smart,
                          'update_time'=> $data['update_time']
                    );
         
          if(sizeof($adData)>0){
              $viewPage = "network.network_cr_update_cps";
          }else{
               $viewPage = "network.network_cr_update_test";
          }
         $dataN =  view($viewPage)->with($result);
         $time_elapsed_secs = microtime(true) - $start;
         return $dataN;
    }



    public function smart_index(Request $request){
      $request->is_smart_cca = 1;
      return $this->index($request,$type="",$routename = "networkfilter",$header="Smart Network CR Update"); 
    }

    
    
    
        /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index_parent_new(Request $request,$type="",$routename = "filterNetworkCrUpdateParent",$header="Network CR Update")
    {
            $redis = Redis::connection();
            $dtvalue = date('Y-m-d');
            $enddate = date('Y-m-d',strtotime("+1 days"));
            $adData = $condtion = $cond = $appends = $ddCondition =  []; 
            $adDataArray = "";
            $appends['id_channel'] = $request->id_channel;
            $appends['operator_id'] = $request->operator_id;
            $appends['traffic_type'] = $request->traffic_type;
            $appends['country'] = $request->country;
            $appends['total'] = $request->total;
            $appends["colorder"]=$request->colorder;
            $appends["order"]=$request->order;
            array_push($ddCondition,["ads.description","!=","default"] );
            array_push($ddCondition,['crc_network_campaign_new.create_time','>=',$dtvalue] );
            array_push($ddCondition,['crc_network_campaign_new.create_time','<=',$enddate] );
            $key = 'network_cr_dropdowns_parent';
            try{
                if($request->cache == 1){
                    $redis->delete($network_cr_key);
                } 
                if(!$redis->exists($key)){
                  $ddData = $this->createDD($request,$type,$ddCondition);
                  Redis::set($key, json_encode($ddData));
                  $redis->expire($key,900);
                }else{
                    $ddData = json_decode(Redis::get($key),true);
                }
            } catch(\Exception $e){
                $ddData = $this->createDD($request,$type,$ddCondition);
            }
            $start = microtime(true);
            $network_cr_key = "network_cr_data_parent";
                try{
                  if($request->cache == 1){
                      $redis->delete($network_cr_key);
                  } 
                  if(!$redis->exists($network_cr_key)){
                    $data = $this->getNetworkCrDataParent($request);
                    if(count($data['data']) > 0){ 
                        Redis::set($network_cr_key, json_encode($data));
                        $redis->expire($network_cr_key,450);
                    }
                  }else{
                      $data = json_decode(Redis::get($network_cr_key),true);
                  }
                }catch(\Exception $e){
                    $data = $this->getNetworkCrDataParent($request);
                }
                $allData = '';
                if(count($data['data']) > 0){
                    $allData = $data['data'];
                }
            $result  = array(
                          'data' => $data, 
                          'data1' => $allData,
                          "routename"=>$routename,
                          'header'=>$header,
                          'dtvalue' => $dtvalue,
                          'dtvalue2' => $enddate,
                          'ddData' => $ddData,
                          'id_channel'=>$request->id_channel,
                          'operator_id'=>$request->operator_id,
                          'traffic_type' => $request->traffic_type,
                          'country'=> $request->country,
                          'total'=>$request->total,
                          'lastRow'=>$data['lastRow'],
                          'update_time'=> $data['update_time']
                    );
         
          if(sizeof($adData)>0){
              $viewPage = "network.network_cr_update_cps_parent";
          }else{
               $viewPage = "network.network_cr_update_test_parent";
          }
         $dataN =  view($viewPage)->with($result);
         $time_elapsed_secs = microtime(true) - $start;
         return $dataN;
    }
    
         function getNetworkCrDataParent($request){
             
            //echo "<pre>";print_r($request); die;
            $dtvalue = $request->start;
            $enddate = $dtvalue2 = $request->end;
            $adData = $condtion = $id_channel_arr = $operator_id_arr = $traffic_type_arr = $country_arr = [];
            $type = $request->type;
            if(is_null($dtvalue)){
              $dtvalue = date('Y-m-d');
            }
            if(is_null($enddate)){
              $enddate = date('Y-m-d',strtotime("+1 days"));
            }

            if($request->id_ad){
              array_push($condtion,['crc_records_new.parent_cca','=',$request->id_ad]);
            }

            if($type != "" && $type != "CPS"){
                array_push($condtion,['ads.type','=',strtoupper($type)] );
            }
		
		  if($type != "" && $type == "CPA"){
                array_push($condtion,['crc_records_new.report_type','=',strtoupper($type)] );
            }

            if($request->id_channel && $request->id_channel != 0){
              if(count($request->id_channel) > 1 ){
                  $id_channel_arr = $request->id_channel;
              }else{
                  array_push($condtion,['ads.id_zone','=',$request->id_channel[0]]);   
              }              
            }
            
            if($request->operator_id){
                if(count($request->operator_id) > 1 ){
                $operator_id_arr = $request->operator_id;
                }else{
                array_push($condtion,['ads.cco','=',$request->operator_id[0]]);
                }
            }

            if($request->traffic_type){
              $flag = 1;
              if(count($request->traffic_type) > 1){
               $traffic_type_arr = $request->traffic_type;
              }else{ 
                array_push($condtion,['ads.traffic_type','=',$request->traffic_type[0]] );
              } 
            }

            if($request->country && $request->country !== 0){
              $flag = 1;
              if(count($request->country) > 1 ){
                $country_arr = $request->country;
              }else{
                array_push($condtion,['ads.country_code','=',$request->country[0]] );
              }
            }
            //array_push($condtion,["ads.description","!=","'default'"] );
            //array_push($condtion,["ads.description2","!=","'default'"] );
            array_push($condtion,['crc_records_new.create_time','>=',$dtvalue] );
            array_push($condtion,['crc_records_new.create_time','<=',$enddate] );
            $select =  [
                        "advertiser_campaigns.cpa",
                        "advertiser_campaigns.id as adv_ids",
                        "advertiser_campaigns.name as adv_name",
                        "sum(crc_records_new.conversion_count_unique) as conversion_count_unique",
                        "crc_records_new.parent_cca as id_ad",
                        "ads.network_name as network_name",
                        "ads.id_zone",
                        "ads.cco",
                      // "manage_crc_campaign.remark as remark",
                        "sum(crc_records_new.revenue_dollar) as revenue_dollar ",
                        "sum(crc_records_new.clickcount_fraud) as fraud",
                        "ads.country_code",
                        "ads.operator_name",
                        "ads.os_type",
                        "ads.incent_type",
                        "ads.traffic_type as traffic_type",
                        // "crc_records_new.total_cost",
                        "sum( IF(crc_records_new.traffic_type = 'WG' OR crc_records_new.traffic_type = 'WM',crc_records_new.cost_dollar, crc_records_new.total_cost)) as total_cost",
                        "crc_records_new.op_name",
                        "crc_records_new.op_id",  
                         //"country.name  cntry",
                        "sum(crc_records_new.clickcount) as clickcount",
                        "sum(crc_records_new.conversion_count) as conversion_count",
                        "ads.network_cpa",
                        "sum(crc_records_new.clicks_active_count)  as clicks_active_count",
                        "ads.cr_goal as cr_goal",
                        "sum(cr_received) as cr_received",
                        "sum(cr_given) as cr_given",
                        "crc_records_new.create_time",
                        "ads.traffic_type as remark" ,
                      ];

                  $select = implode(",",$select);
                  $data =  DB::table("ads")->where($condtion);
                  if($id_channel_arr){
                    $data = $data->whereIn('ads.id_zone',$id_channel_arr);
                  }
                  if($operator_id_arr){
                    $data = $data->whereIn('ads.cco',$operator_id_arr);
                  }
                  if($traffic_type_arr){
                      $data = $data->whereIn('ads.traffic_type',$traffic_type_arr);
                  }
                  if($country_arr){
                      $data = $data->whereIn('ads.country_code',$country_arr);
                  }
                 $data = $data->selectRaw($select)
                 ->leftJoin("crc_records_new","crc_records_new.parent_cca","=","ads.id_ad")
                 ->leftJoin("advertiser_campaigns","ads.id_advertiser","=","advertiser_campaigns.id")
                 // ->leftJoin("manage_crc_campaign","manage_crc_campaign.ad_id","=","ads.id_ad")
                 ->groupby('crc_records_new.parent_cca');
                 //->groupby('crc_records_new.op_id');
                 if($request->colorder){
                   $data = $data->orderby($request->colorder,$request->order);
                  }else{
                    $data = $data->orderby("network_name","ASC");
                  }
                  $adDataArray = "";
                  if($type == "CPS"){
                      $adDataArray = AdNetwork::where("account_manager","=","anshul.tyagi@collectcent.com")->get(["name"]);
                      foreach($adDataArray as $value){
                          if($value->name && (!in_array($value->name, $adData))){
                            array_push($adData, $value->name);
                          }
                      }
                  }
                  if(sizeof($adData) > 0){
                      $data =  $data->whereIn('ads.network_name', $adData);
                  }
                  $data =  $data->get();
                  $data1 = [];
                  $clickcount = $conversion_count = $clicks_active_count = 0;
                  $conversion_count_unique  = $conversion_count_unique = 0;
                  $sourcost = $cc_revenueDller_ecpm = $convCount = $revenue_dollarX = 0;
                  $profit = $clickcount_fraud=0;
                    if(sizeof($data) !== 0){
                        $update_time =  $data[sizeof($data)-1]->create_time;
                    }else{
                        $update_time = "";
                    }
                    foreach ($data as $fetch_records) {
                    //if($fetch_records->cco == $fetch_records->op_id){
                    $array = [];
                    // $country = array_key_exists($fetch_records->country_code,$ddData['country_dropdown'])?$ddData['country_dropdown'][$fetch_records->country_code]:"";
                    $country = $fetch_records->country_code;
                    $camp_name = mb_convert_encoding($fetch_records->adv_name, 'UTF-8', 'UTF-8');
                    $camp_name_short = mb_convert_encoding(substr($fetch_records->adv_name,0,10),'UTF-8', 'UTF-8');
                    $remark    = mb_convert_encoding($fetch_records->remark,'UTF-8', 'UTF-8');
                    $network_name =  mb_convert_encoding($fetch_records->network_name,'UTF-8', 'UTF-8');   
                    array_push($array,
                          $fetch_records->id_ad,
                        '<a title="'.$network_name.'"href="/network-cr-update-single-network/'.$fetch_records->id_ad.'?start='.$dtvalue.'&end='.$enddate.'">'.$fetch_records->network_name.'('.$fetch_records->id_zone.')</a>',
                          $fetch_records->network_cpa,
                          $fetch_records->op_name,
                          $fetch_records->traffic_type,
                          '<span title="'.$camp_name.'('.$fetch_records->adv_ids.')">('.$fetch_records->adv_ids.')'.$camp_name_short.'....</span>',
                          '<span title="'.$country.'">'.$fetch_records->country_code.'</span>',
                          $fetch_records->os_type,
                          $fetch_records->incent_type,
                          $fetch_records->clickcount,
                          $fetch_records->clickcount-$fetch_records->fraud,
                          $fetch_records->conversion_count,
                          $fetch_records->conversion_count_unique,
                          $fetch_records->clicks_active_count,
                          $fetch_records->cr_received.'%', 
                          $fetch_records->cr_given.'%',
                          round($fetch_records->total_cost,2)."/".round($fetch_records->total_cost * 65, 2),
                          round($fetch_records->revenue_dollar,2)."/".round($fetch_records->revenue_dollar * 65, 2),
                          round($fetch_records->revenue_dollar/1000,2)."/".round($fetch_records->revenue_dollar/1000,2)*65,
                           // $fetch_records->cpa * $fetch_records->conversion_count,
                          round(($fetch_records->revenue_dollar - $fetch_records->total_cost),2)."/". round(($fetch_records->revenue_dollar - $fetch_records->total_cost),2)*65,
                          '<input class="remark" myID="'.$fetch_records->id_ad.'" type="text" value="'.$remark.'" id="example-text-input">');
                       
                          array_push($data1, $array);
                          $clickcount += $fetch_records->clickcount;
                          $clickcount_fraud += $fetch_records->fraud;
                          $conversion_count += $fetch_records->conversion_count;
                          $clicks_active_count += $fetch_records->clicks_active_count;
                          $conversion_count_unique += $fetch_records->conversion_count_unique;
                          $sourcost +=  round($fetch_records->total_cost,2);
                          $revenue_dollarX +=  round($fetch_records->revenue_dollar,2);
                          $cc_revenueDller_ecpm +=  round($fetch_records->revenue_dollar/1000,2);
                          $convCount += $fetch_records->cpa * $fetch_records->conversion_count;
                          $profit += ($fetch_records->revenue_dollar - $fetch_records->total_cost);
                        
                    }
                $lastRow = [ "Total","","","","","","","","",
                             $clickcount,
                             $clickcount-$clickcount_fraud,
                             $conversion_count,
                             $conversion_count_unique,
                             $clicks_active_count,
                             "",
                             "",
                            round($sourcost,2),
                            round($revenue_dollarX,2),
                            round($cc_revenueDller_ecpm,2),
                            round($profit,2),
                            ""
                            ];
                $status = array("status"=>"1",'data'=>$data1,'lastRow'=>$lastRow,'update_time'=>$update_time); 
                return $status;
     }

    
     function getNetworkCrData($request){
            $ads = Ad::where('description2','=','default')->select('id_ad')->get();
            $ads_arr = [];
            foreach($ads as $ad){
              $ads_arr[] = $ad->id_ad;
            }
            $dtvalue = $request->start;
            $enddate = $dtvalue2 = $request->end;
            $adData = $condtion = $id_channel_arr = $operator_id_arr = $traffic_type_arr = $country_arr = [];
            $type = $request->type;
            if(is_null($dtvalue)){
              $dtvalue = date('Y-m-d');
            }
            if(is_null($enddate)){
              $enddate = date('Y-m-d',strtotime("+1 days"));
            }
            if($request->id_ad){
              array_push($condtion,['crc_records_new.parent_cca','=',$request->id_ad]);
            }
            if($type != "" && $type != "CPS"){
                array_push($condtion,['ads.type','=',strtoupper($type)] );
            }
			 if($type != "" && $type == "CPA"){
                array_push($condtion,['crc_records_new.report_type','=',strtoupper($type)] );
            }
            if($request->id_channel && $request->id_channel != 0){
              if(count($request->id_channel) > 1 ){
                  $id_channel_arr = $request->id_channel;
              }else{
                  array_push($condtion,['ads.id_zone','=',$request->id_channel[0]]);   
              }              
            }
            if($request->operator_id){
                if(count($request->operator_id) > 1 ){
                $operator_id_arr = $request->operator_id;
                }else{
                array_push($condtion,['ads.cco','=',$request->operator_id[0]]);
                }
            }

            if($request->traffic_type){
              $flag = 1;
              if(count($request->traffic_type) > 1){
               $traffic_type_arr = $request->traffic_type;
              }else{ 
                array_push($condtion,['ads.traffic_type','=',$request->traffic_type[0]] );
              } 
            }

            if($request->country && $request->country !== 0){
              $flag = 1;
              if(count($request->country) > 1 ){
                $country_arr = $request->country;
              }else{
                array_push($condtion,['ads.country_code','=',$request->country[0]] );
              }
            }
            // array_push($condtion,["ads.description","!=","'default'"] );
            if($request->is_smart_cca){
                array_push($condtion,["ads.is_smart_cca","=","1"]);
            }
            //array_push($condtion,["ads.description2","!=","'default'"] );
            array_push($condtion,['crc_records_new.create_time','>=',$dtvalue]);    
            array_push($condtion,['crc_records_new.create_time','<=',$enddate]);

            $select =  [
                        "advertiser_campaigns.cpa",
                        "advertiser_campaigns.id as adv_ids",
                        "advertiser_campaigns.name as adv_name",
                        "sum(crc_records_new.conversion_count_unique) as conversion_count_unique",
                        "crc_records_new.parent_cca as id_ad",
                        "ads.network_name as network_name",
                        "ads.id_zone",
                        "ads.cco",
                      // "manage_crc_campaign.remark as remark",
                        "sum(crc_records_new.revenue_dollar) as revenue_dollar ",
                        "sum(crc_records_new.clickcount_fraud) as fraud",
                        "ads.country_code",
                        "ads.operator_name",
                        "ads.os_type",
                        "ads.incent_type",
                        "ads.traffic_type as traffic_type",
                        // "crc_records_new.total_cost",
                        "sum( IF(crc_records_new.traffic_type = 'WG' OR crc_records_new.traffic_type = 'WM',crc_records_new.cost_dollar, crc_records_new.total_cost)) as total_cost",
                        "crc_records_new.op_name",
                        "crc_records_new.op_id",  
                         //"country.name  cntry",
                        "sum(crc_records_new.clickcount) as clickcount",
                        "sum(crc_records_new.conversion_count) as conversion_count",
                        "ads.network_cpa",
                        "sum(crc_records_new.clicks_active_count)  as clicks_active_count",
                        "ads.cr_goal as cr_goal",
                        "sum(cr_received) as cr_received",
                        "sum(cr_given) as cr_given",
                        "crc_records_new.create_time",
                        "ads.traffic_type as remark" ,
                      ];

                  $select = implode(",",$select);
                  $data =  DB::table("ads")->where($condtion);
                  if($id_channel_arr){
                    $data = $data->whereIn('ads.id_zone',$id_channel_arr);
                  }
                  if($operator_id_arr){
                    $data = $data->whereIn('ads.cco',$operator_id_arr);
                  }
                  if($traffic_type_arr){
                      $data = $data->whereIn('ads.traffic_type',$traffic_type_arr);
                  }
                  if($country_arr){
                      $data = $data->whereIn('ads.country_code',$country_arr);
                  }
                  if($ads_arr){
                     $data = $data->whereNotIn('crc_records_new.id_ad',$ads_arr); 
                  }
                 $data = $data->selectRaw($select)
                 ->leftJoin("crc_records_new","crc_records_new.parent_cca","=","ads.id_ad")
                 ->leftJoin("advertiser_campaigns","ads.id_advertiser","=","advertiser_campaigns.id")
                 // ->leftJoin("manage_crc_campaign","manage_crc_campaign.ad_id","=","ads.id_ad")
                 ->groupby('crc_records_new.parent_cca');
                 // ->groupby('crc_records_new.op_id');
                 if($request->colorder){
                   $data = $data->orderby($request->colorder,$request->order);
                  }else{
                    $data = $data->orderby("network_name","ASC")->orderby("operator_name","ASC");
                  }
                  $adDataArray = "";
                  if($type == "CPS"){
                      $adDataArray = AdNetwork::where("account_manager","=","anshul.tyagi@collectcent.com")->get(["name"]);
                      foreach($adDataArray as $value){
                          if($value->name && (!in_array($value->name, $adData))){
                            array_push($adData, $value->name);
                          }
                      }
                  }
                  if(sizeof($adData) > 0){
                      $data =  $data->whereIn('ads.network_name', $adData);
                  }
                  $data =  $data->get();
                  $data1 = [];
                  $clickcount = $conversion_count = $clicks_active_count = 0;
                  $conversion_count_unique  = $conversion_count_unique = 0;
                    $sourcost = $cc_revenueDller_ecpm = $convCount = $revenue_dollarX = 0;
                    $profit = $clickcount_fraud=0;
                    if(sizeof($data) !== 0){
                        $update_time =  $data[sizeof($data)-1]->create_time;
                    }else{
                        $update_time = "";
                    }
                    if(count($data)){
                    foreach ($data as $fetch_records) {
                    // if($fetch_records->cco == $fetch_records->op_id){
                    $array = [];
                    // $country = array_key_exists($fetch_records->country_code,$ddData['country_dropdown'])?$ddData['country_dropdown'][$fetch_records->country_code]:"";
                    $country = $fetch_records->country_code;
                    $camp_name = mb_convert_encoding($fetch_records->adv_name, 'UTF-8', 'UTF-8');
                    $camp_name_short = mb_convert_encoding(substr($fetch_records->adv_name,0,10),'UTF-8', 'UTF-8');
                    $remark    = mb_convert_encoding($fetch_records->remark,'UTF-8', 'UTF-8');
                    $network_name =  mb_convert_encoding($fetch_records->network_name,'UTF-8', 'UTF-8');   
                    array_push($array,
                          $fetch_records->id_ad,
                        '<a title="'.$network_name.'"href="/network-cr-update-single-network/'.$fetch_records->id_ad.'?start='.$dtvalue.'&end='.$enddate.'">'.$fetch_records->network_name.'('.$fetch_records->id_zone.')</a>',
                          $fetch_records->network_cpa,
                          $fetch_records->operator_name,
                          $fetch_records->traffic_type,
                          '<span title="'.$camp_name.'('.$fetch_records->adv_ids.')">('.$fetch_records->adv_ids.')'.$camp_name_short.'....</span>',
                          '<span title="'.$country.'">'.$fetch_records->country_code.'</span>',
                          $fetch_records->os_type,
                          $fetch_records->incent_type,
                          $fetch_records->clickcount,
                          $fetch_records->clickcount-$fetch_records->fraud,
                          $fetch_records->conversion_count,
                          $fetch_records->conversion_count_unique,
                          $fetch_records->clicks_active_count,
                          $fetch_records->cr_received.'%', 
                          $fetch_records->cr_given.'%',
                          round($fetch_records->total_cost,2)."/".round($fetch_records->total_cost * 65, 2),
                          round($fetch_records->revenue_dollar,2)."/".round($fetch_records->revenue_dollar * 65, 2),
                          round($fetch_records->revenue_dollar/1000,2)."/".round($fetch_records->revenue_dollar/1000,2)*65,
                           // $fetch_records->cpa * $fetch_records->conversion_count,
                          round(($fetch_records->revenue_dollar - $fetch_records->total_cost),2)."/". round(($fetch_records->revenue_dollar - $fetch_records->total_cost),2)*65,
                          '<input class="remark" myID="'.$fetch_records->id_ad.'" type="text" value="'.$remark.'" id="example-text-input">');
                       
                          array_push($data1, $array);
                          $clickcount += $fetch_records->clickcount;
                          $clickcount_fraud += $fetch_records->fraud;
                          $conversion_count += $fetch_records->conversion_count;
                          $clicks_active_count += $fetch_records->clicks_active_count;
                          $conversion_count_unique += $fetch_records->conversion_count_unique;
                          $sourcost +=  round($fetch_records->total_cost,2);
                          $revenue_dollarX +=  round($fetch_records->revenue_dollar,2);
                          $cc_revenueDller_ecpm +=  round($fetch_records->revenue_dollar/1000,2);
                          $convCount += $fetch_records->cpa * $fetch_records->conversion_count;
                          $profit += ($fetch_records->revenue_dollar - $fetch_records->total_cost);
                       }    
                    }
                $lastRow = [ "Total","","","","","","","","",
                             $clickcount,
                             $clickcount-$clickcount_fraud,
                             $conversion_count,
                             $conversion_count_unique,
                             $clicks_active_count,
                             "",
                             "",
                            round($sourcost,2),
                            round($revenue_dollarX,2),
                            round($cc_revenueDller_ecpm,2),
                            round($profit,2),
                            ""
                            ];
                $status = array("status"=>"1",'data'=>$data1,'lastRow'=>$lastRow,'update_time'=>$update_time); 
                return $status;
     }

     /* filter network data */
     public function filterNetworkCrData(Request $request){
         $status = $this->getNetworkCrData($request); 
         if($status['status'] ==1){
           $data = json_encode($status); 
          }else{
            $data = json_encode(array('status'=>2,'data'=>''));
          }
          return $data;
     }
     /* filter network data */
     public function filterNetworkCrDataParent(Request $request){
         $status = $this->getNetworkCrDataParent($request); 
         if($status['status'] ==1){
           $data = json_encode($status); 
          }else{
            $data = json_encode(array('status'=>2,'data'=>''));
          }
          return $data;
     }
      
      public function index_single(Request $request, $id_ad, $type="CPA",$routename = "network-wise-record-filter",$header="CR Update")
      {
            $condtion = $data1 = $parent_ids = [];
            $dtvalue = $request->start;
            $dtvalue2 = $request->end;
            $clickcount = $conversion_count = $clicks_active_count = $sourcost = 
            $revenue_total = $profit_total =$parent_id = $conversion_count_unique = 0;
            if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                  $enddate = $dtvalue2 = date('Y-m-d',strtotime("+1 days"));
            }else{
               $enddate = date('Y-m-d',strtotime($dtvalue2));
            }
            if($type != "CPICPA"){
                // array_push($condtion,['report_type','=',strtoupper($type)] );
            }
            if($id_ad && $id_ad!=0){
                array_push($condtion,['crc_records_new.parent_cca','=',$id_ad] );
                $parent_id =  DB::table("ads")->where('parent_id',"=",$id_ad) 
                ->select('id_ad')->get();
            }
            if($request->id_advertiser_campaign){
                array_push($condtion,['crc_records_new.id_advertiser_campaign','=',$request->id_advertiser_campaign] );
            }
            array_push($condtion,['crc_records_new.create_time','>=',$dtvalue] );
            array_push($condtion,['crc_records_new.create_time','<=',$enddate] );
            // print"<pre>";print_r($condtion);print"</pre>";
            $select = [ "crc_records_new.parent_cca",
                        "advertiser_campaigns.cpa",
                        "advertiser_campaigns.id as curcampid",
                        "advertiser_campaigns.name",
                        "crc_records_new.network_name",
                        "operator.country_code AS country_code",
                        "operator.name as op_name",
                        "crc_records_new.id_advertiser_campaign",
                        "crc_records_new.total_cost",
                        "crc_records_new.id_ad",
                        "crc_records_new.id_channel",
                        "crc_records_new.create_time"
                        ]; 
            $data =  DB::table("crc_records_new")
                          ->where($condtion) 
                          ->select($select)
                          ->selectRaw(
                            '
                            sum(crc_records_new.clickcount) as clickcount, 
                            sum(crc_records_new.conversion_count) as conversion_count,
                            sum(crc_records_new.conversion_count_unique) as conversion_count_unique,
                            sum(crc_records_new.clicks_active_count) as clicks_active_count, 
                            sum(crc_records_new.cr_goal) as cr_goal,
                            sum(crc_records_new.cr_received) as cr_received,
                            sum(crc_records_new.cr_given) as cr_given,
                            sum(crc_records_new.revenue_dollar) as revenue_dollar, 
                            sum( IF(crc_records_new.traffic_type = "WG" OR crc_records_new.traffic_type = "WM",crc_records_new.cost_dollar, crc_records_new.total_cost)) as total_cost
                            '
                            )
                ->leftJoin("operator","crc_records_new.op_id","=","operator.id")
                ->leftJoin("advertiser_campaigns","advertiser_campaigns.id","=","crc_records_new.id_advertiser_campaign");
                if($routename == 'smart-network-wise-record-filter'){
                  $data = $data->groupby('crc_records_new.parent_cca');
                  $data = $data->groupby('crc_records_new.op_id');
                }else{
                  $data = $data->groupby('crc_records_new.op_id');
                  $data = $data->groupby('crc_records_new.id_advertiser_campaign');
                }
                $data = $data->orderby("crc_records_new.id_ad","ASC")->get();
                if(sizeof($data) !== 0){
                    $update_time =  $data[sizeof($data)-1]->create_time;
                }else{
                    $update_time = "";
                }            
                if($parent_id){
                  foreach($parent_id as $pid){
                    $parent_ids[] = $pid->id_ad;                
                  }
                }
                foreach ($data as $fetch_records){
                  $class = "white";
                  if(in_array($fetch_records->id_ad, $parent_ids)){
                      $class = "text-danger";
                  }
                  $array = [];
                  $share = ($fetch_records->revenue_dollar - $fetch_records->total_cost);
                  $profit = round($share, 2)."/".round($share * 65, 2);
                  $revenue = round($fetch_records->revenue_dollar, 2)."/".round($fetch_records->revenue_dollar * 65, 2);
                  $ecpm = round(($fetch_records->revenue_dollar/1000), 2)."/".round(($fetch_records->revenue_dollar/1000) * 65, 2);
                  $source_code = round($fetch_records->total_cost, 2)."/".round($fetch_records->total_cost * 65, 2);
                  $payVal = 0;
                  if($fetch_records->conversion_count > 0){
                  $payVal = $fetch_records->revenue_dollar/$fetch_records->conversion_count;
                  }
                  $average_payout = round($payVal, 2)."/".round($payVal*65, 2);
                      array_push($array,
                        $fetch_records->name."(".$fetch_records->id_advertiser_campaign.")",
                        '<a href="/network-cr-update-single-chanel?id_channel='.$fetch_records->id_channel.'&start='.$dtvalue.'&end='.$dtvalue2.'">'.$fetch_records->network_name.'('.$fetch_records->id_channel.')</a>',
                        $fetch_records->parent_cca,
                        $fetch_records->op_name."(".$fetch_records->country_code.")",
                        $fetch_records->clickcount,
                        $fetch_records->conversion_count,
                        $fetch_records->conversion_count_unique, 
                        $fetch_records->clicks_active_count,
                        $fetch_records->cr_received.'%',
                        $fetch_records->cr_given.'%',
                        $revenue,
                        $ecpm,
                        $source_code,
                        $profit,
                        $average_payout
                        );
                        array_push($data1, $array);
                        $clickcount += $fetch_records->clickcount;
                        $conversion_count += $fetch_records->conversion_count;
                        $conversion_count_unique += $fetch_records->conversion_count_unique;
                        $clicks_active_count += $fetch_records->clicks_active_count;
                        $revenue_total += $fetch_records->revenue_dollar;
                        $sourcost += $fetch_records->total_cost;
                        $profit_total += $share;
                  }
                  $revenue_total = round($revenue_total, 2)."/".round($revenue_total * 65, 2);
                  $sourcost = round($sourcost, 2)."/".round($sourcost * 65, 2);
                  $profit_total = round($profit_total, 2)."/".round($profit_total * 65, 2);

              $lastRow =[$clickcount,$conversion_count,$clicks_active_count,$revenue_total,$sourcost,$profit_total,$conversion_count_unique];


         $result  = array(
                          'data1' => $data1,
                          "routename"=>$routename,
                          'header'=>$header,
                          'dtvalue' => $dtvalue,
                          'id'=>$id_ad,
                          'dtvalue2' => $dtvalue2,
                          'lastRow' => $lastRow,
                          'update_time'=>$update_time
                        );
        
         return view('network.network_cr_update_single')->with($result);

     }

     public function smart_single(Request $request,$id_ad){
           return $this->index_single($request,$id_ad,"","smart-network-wise-record-filter","Smart CR Update");
     }

     private function createDD(Request $request,$type,$condition){

        $select = ["crc_network_campaign_new.parent_cca as id_ad"
                    ,"ads.network_name"
                    ,"country.name as cntry"
                    ,"crc_network_campaign_new.conversion_count_unique as unique_conversion_count"
                    ,"ads.id_zone"
                    ,"ads.traffic_type"
                    ,"ads.country_code"
                    ,"ads.cco"
                    ,"ads.operator_name"
                    ,"crc_network_campaign_new.total_cost"
                    ,"crc_network_campaign_new.op_name"
                    ,"crc_network_campaign_new.clickcount"
                    ,"crc_network_campaign_new.conversion_count"
                    ,"ads.network_cpa"
                    ,"crc_network_campaign_new.clicks_active_count"
                    ,"ads.cr_goal as cr_goal"
                    ,"cr_received"
                    ,"cr_given"
                    ,"crc_network_campaign_new.create_time"];

          $data =  DB::table("ads")
          ->where($condition) 
         ->select($select)
         ->rightJoin("crc_network_campaign_new","crc_network_campaign_new.parent_cca","=","ads.id_ad")
         ->leftJoin("country","ads.country_code","=","country.iso")
         ->orderby("network_name","ASC")
         ->orderby("operator_name","ASC")->get();
        
        
         $ddDataResult  = array(
                'network_dropdown' => [],
                'country_dropdown' => [],
                'operator_dropdown' => [],
                'idad_dropdown' => [],
                'traffictype_dropdown' => []
            );
         foreach ($data as $dropdown) {

            if ($dropdown->id_zone){
                $ddDataResult['network_dropdown'][$dropdown->id_zone] = $dropdown->network_name;
            }
            if ($dropdown->country_code){
                 $ddDataResult['country_dropdown'][$dropdown->country_code] = $dropdown->country_code."(".$dropdown->cntry.")";
             }
            if ($dropdown->cco && $dropdown->operator_name){
                  $ddDataResult['operator_dropdown'][$dropdown->cco] = $dropdown->operator_name."(".$dropdown->country_code.")";
            }
            if ($dropdown->id_ad){
                   $ddDataResult['idad_dropdown'][$dropdown->id_ad] = $dropdown->id_ad;
            }
            if($dropdown->traffic_type){
               $ddDataResult['traffictype_dropdown'][$dropdown->traffic_type] = $dropdown->traffic_type;
            }
          }
          
        return $ddDataResult;
     }

      private function createDDCareer(Request $request,$type,$condition){
      $select = 
              [
              //"crc_network_campaign_new.parent_cca as id_ad",
               "crc_records_new.parent_cca as id_ad",
               "ads.network_name",
               "ads.id_zone"
              ,"ads.traffic_type"
              ,"ads.country_code"
              ,"ads.cco"
              ,"ads.operator_name"
              ,"crc_records_new.op_name"
              ,"ads.network_cpa"
              ,"country.name as cntry"
              ];
            
            $data =  DB::table("ads")->where($condition);
            if($type == "A"){
                $data = $data->whereIn('ads.traffic_type', ['A','IG'])->whereNotIn('ads.cco',['-1','33']);
            }else if($type == "Rotator"){
                $data = $data->whereIn('ads.traffic_type', ['WM','WG']);
            }else if($type == "C"){
                $data =  $data->whereIn('ads.traffic_type', ['C','I'])->whereNotIn('ads.cco',['-1','33']);
            }else if($type == "WIFIA"){
                $data =  $data->whereIn('ads.traffic_type', ['A','IG']);
            }else if($type == "WIFIC"){
                $data =  $data->whereIn('ads.traffic_type', ['C','I']);
            }else{
                $data =  $data->whereIn('ads.traffic_type', ['C','I']);
            }
            

           /* $data = $data->select($select)
            ->rightJoin("crc_network_campaign_new","crc_network_campaign_new.parent_cca","=","ads.id_ad")
            ->leftJoin("country","ads.country_code","=","country.iso")
            ->orderby("network_name","ASC")
            ->orderby("operator_name","ASC")->get();
           */

            $data = $data->select($select)
            ->rightJoin("crc_records_new","crc_records_new.parent_cca","=","ads.id_ad")
            ->leftJoin("country","ads.country_code","=","country.iso")
            ->orderby("network_name","ASC")
            ->orderby("operator_name","ASC")->get();

            $ddDataResult  = array(
                'network_dropdown' => [],
                'country_dropdown' => [],
                'operator_dropdown' => [],
                'idad_dropdown' => [],
                'traffictype_dropdown' => []
            );
          foreach ($data as $dropdown) {
            if ($dropdown->id_zone){
                $ddDataResult['network_dropdown'][$dropdown->id_zone] = $dropdown->network_name;
            }
            if ($dropdown->country_code){
                 $ddDataResult['country_dropdown'][$dropdown->country_code] = $dropdown->country_code."(".$dropdown->cntry.")";
             }
            if ($dropdown->cco && $dropdown->operator_name){
                  $ddDataResult['operator_dropdown'][$dropdown->cco] = $dropdown->operator_name."(".$dropdown->country_code.")";
            }
            if ($dropdown->id_ad){
                   $ddDataResult['idad_dropdown'][$dropdown->id_ad] = $dropdown->id_ad;
            }
            if($dropdown->traffic_type){
               $ddDataResult['traffictype_dropdown'][$dropdown->traffic_type] = $dropdown->traffic_type;
            }
          }
          
        return $ddDataResult;


}


     public function cpa_cr_update(Request $request){

        return $this->index($request,"CPA","networkfilterCPA","CPA Cr Update");

     }
     public function organizr_cr_update(Request $request){

        return $this->index($request,"organizr","networkfilterOrganizr","Organizr Report");

     }
     public function cps_cr_update(Request $request){

        return $this->index($request,"CPS","networkfilterCPS","CPS Cr Update");

     }
     public function index_back_campaign(Request $request,$routename = "backCompaignFilter",$header="CR Back Update"){

            $condtion = [];
            
            $dtvalue = $request->start;
            $dtvalue2 = $request->end;
            
            
            if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                    $dtvalue2 = date('Y-m-d');
                    $enddate = date('Y-m-d',strtotime("+1 days"));
            }else{
                //$dtvalue2 = date('Y-m-d',strtotime("+1 days"));
               $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));

            }
            
             $request->total = $request->total ? $request->total : 50;

            array_push($condtion,['crc_network_campaign_new.create_time','>=',$dtvalue] );
            array_push($condtion,['crc_network_campaign_new.create_time','<=',$enddate] );
            array_push($condtion,['report_type','=',"CPA"] );
            
             $select =  "advertiser_campaigns.cpa"
                        .",advertiser_campaigns.name as adv_name"
                        .",crc_network_campaign_new.conversion_count_unique as conversion_count_unique,"
                        . "ads.network_name,"
                        . "crc_network_campaign_new.parent_cca as id_ad,"
                        . "ads.id_zone,"
                        . "ads.cco,"
                        . "ads.country_code,"
                        . "ads.operator_name,"
                        . "ads.traffic_type,"
                        . "crc_network_campaign_new.total_cost,"
                        . "crc_network_campaign_new.op_name,"
                        . "country.name as cntry,"
                        . "crc_network_campaign_new.clickcount,"
                        . "crc_network_campaign_new.conversion_count,"
                        . "ads.network_cpa,"
                        . "crc_network_campaign_new.clicks_active_count,"
                        . "concat(ads.cr_goal,'%') as cr_goal,"
                        . "concat(cr_received,'%') as cr_received,"
                        . "concat(cr_given,'%') as cr_given,"
                        . "crc_network_campaign_new.create_time";
       
             $data =  DB::table("ads")
              ->whereIn('crc_network_campaign_new.parent_cca', ['4623','4779','4780','4834','4835'])
              ->where($condtion) 
             ->selectRaw(DB::raw($select))
             ->leftJoin("advertiser_campaigns","ads.id_advertiser","=","advertiser_campaigns.id")
             ->leftJoin("country","ads.country_code","=","country.iso")
             ->rightJoin("crc_network_campaign_new","crc_network_campaign_new.parent_cca","=","ads.id_ad")
             ->groupby("crc_network_campaign_new.parent_cca")
             ->orderby("network_name","ASC")
             ->orderby("operator_name","ASC")
             ->paginate($request->total);
       
        // dd($data);
         $result  = array('data' => $data,
            "routename"=>$routename,
            'header'=>$header,
            'dtvalue' => $dtvalue,
            'dtvalue2' => $dtvalue2,
            'total'=> $request->total
          );

         return view('network.network_cr_update_back')->with($result);


     }

      public function cpi_cr_update(Request $request){
          return $this->index($request,"CPI","networkfilterCPI","CPI Cr Update");
      }

      public function cpicpa_cr_update(Request $request){
              return $this->index($request,"CPICPA","networkfilterCPICPA","CPICPA Cr Update");
        }
     
     //cariar specific routes
    public function CarrierIndexA(Request $request,$type="A",$routename = "homeCariarFilter",$header="CR Update WG")
    {
        $ddCondition = [];
        $dtvalue = $request->start;
        $dtvalue2 = $request->end;
        if(is_null($dtvalue)){
          $dtvalue = date('Y-m-d');
        }
        if(is_null($dtvalue2)){
          $dtvalue2 = $enddate = date('Y-m-d',strtotime("+1 days"));
        }else{
           $enddate = date('Y-m-d',strtotime($dtvalue2));
        }
        $key = "carrier_specific_default_$type";
        try{
          if($request->cache == 1){
              $redis->delete($key);
          } 
        if(!$redis->exists($key)){
            $data = $this->carrierFilteration($request,$type);
            if(count($data['data']) > 0){ 
                Redis::set($key, json_encode($data));
                $redis->expire($key,450);
            }
          }else{
              $data = json_decode(Redis::get($key),true);
          }
        }catch(\Exception $e){
          $data = $this->carrierFilteration($request,$type);
        }
        $lastRow = $data['lastRow'];
        $update_time = $data['update_time'];
        $data = $data['data'];
        if($type == 'A'){
            array_push($ddCondition,["ads.description2","=","default"]);
        }else{
            array_push($ddCondition,["ads.description2","!=","default"]);
            array_push($ddCondition, ["ads.cco","=","33"]);  
        }
        array_push($ddCondition,['create_time','>=',$dtvalue] );
        array_push($ddCondition,['create_time','<=',$enddate] );
        $dd_key = 'carrier_dd1_$type';  
        try{
          if($request->cache == 1){
              $redis->delete($dd_key);
          } 
          if(!$redis->exists($dd_key)){
            $ddData = $this->createDDCareer($request,$type,$ddCondition);
            // if($ddData) > 0){ 
                Redis::set($dd_key, json_encode($ddData));
                $redis->expire($dd_key,1000);
            // }
          }else{
              $ddData = json_decode(Redis::get($dd_key),true);
          }
        }catch(\Exception $e){
           $ddData = $this->createDDCareer($request,$type,$ddCondition);
        }
        
        
          $result  = array('data1' => $data,
            "routename"=>$routename,
            'header'=>$header,
            'dtvalue' => $dtvalue,
            'dtvalue2' => $dtvalue2,
            'ddData' => $ddData,
            'id_channel'=>$request->id_channel,
            'operator_id'=>$request->operator_id,
            'traffic_type' => $request->traffic_type,
            'country'=> $request->country,
            'total'=>$request->total,
            'lastRow'=>$lastRow,
            'update_time'=>$update_time
          );
          return view('network.network_cr_update_cariar')->with($result);
      }


      function carrierFilteration(Request $request,$type = "A"){
        $condtion = $ddCondition = $appends =  [];
        $dtvalue = $request->start;
        $dtvalue2 = $request->end;
        if(is_null($dtvalue)){
          $dtvalue = date('Y-m-d');
        }
        if(is_null($dtvalue2)){
          $dtvalue2 = date('Y-m-d');
          $enddate = date('Y-m-d',strtotime("+1 days"));
        }else{
           $enddate = date('Y-m-d',strtotime($dtvalue2));
        }
            array_push($condtion,['crc_records_new.create_time','>=',$dtvalue] );
            array_push($condtion,['crc_records_new.create_time','<=',$enddate] );
            if($request->id_channel){
                array_push($condtion,['ads.id_zone','=',$request->id_channel] );
            }
            if($request->operator_id){
                array_push($condtion,['ads.cco','=',$request->operator_id] );
            }
            if($request->traffic_type){
                array_push($condtion,['ads.traffic_type','=',$request->traffic_type] );
            }
            if($request->country){
                array_push($condtion,['ads.country_code','=',$request->country] );
            }
            $request->total = $request->total ? $request->total : 50;
            $select =    "advertiser_campaigns.cpa"
                        .",advertiser_campaigns.id as adv_ids"
                        .",advertiser_campaigns.name as adv_name"
                        .",sum(crc_records_new.conversion_count_unique) as conversion_count_unique "
                        .",crc_records_new.id_ad as id_ad"
                        .",crc_records_new.parent_cca"
                        .",ads.network_name"
                        .",ads.id_zone"
                        .",ads.cco"
                        .",crc_records_new.clickcount_fraud as fraud"
                        .",ads.country_code"
                        .",concat(ads.operator_name,'(', ads.cco,')')  as op_name "
                        .",ads.traffic_type"
                        .",sum(crc_records_new.total_cost) as total_cost"
                        // .",crc_records_new.op_name"
                        .",sum(crc_records_new.clickcount) as clickcount"
                        .",sum(crc_records_new.conversion_count) as conversion_count"
                        .",ads.network_cpa"
                        .",sum(crc_records_new.revenue_dollar) as revenue_dollar"
                        // .",sum(crc_records_new.cost_dollar) as cost_dollar"
                        .",sum( IF(crc_records_new.traffic_type = 'WG' OR crc_records_new.traffic_type = 'WM',crc_records_new.cost_dollar, crc_records_new.total_cost)) as cost_dollar"
                        .",sum(crc_records_new.clicks_active_count) as clicks_active_count"
                        .",concat(ads.cr_goal,'%') as cr_goal"
                        .",concat(round(AVG(cr_received),2),'%') as cr_received"
                        .",concat(round(AVG(cr_given),2),'%') as cr_given"
                        .",crc_records_new.create_time as create_time";
                    $data =  DB::table("ads");
                    if($type == "A"){
                            array_push($condtion,["ads.description2","=","default"] );
                            $data->whereIn('ads.traffic_type', ['A','IG'])
                            ->whereNotIn('ads.cco',['-1','33']);
                    }else if($type == "Rotator"){
                          array_push($condtion,["ads.description2","=","default"] );
                          $data = $data->whereIn('ads.traffic_type', ['WM','WG']);
                    }else if($type == "C"){
                           array_push($condtion,["ads.description2","=","default"] );
                           $data = $data->whereIn('ads.traffic_type', ['C','I'])
                            ->whereNotIn('ads.cco',['-1','33']);
                    }else if($type =="WIFIA"){
                          array_push($condtion,["ads.description2","=","default"] );
                          // array_push($condtion, ["ads.cco","=","33"]);
                          array_push($condtion, ["crc_records_new.op_id","=","33"]);
                          $data = $data->whereIn('ads.traffic_type', ['A','IG']);
                    }else{
                          array_push($condtion,["ads.description2","=","'default'"] );
                          array_push($condtion, ["ads.cco","=","33"]);
                          array_push($condtion, ["crc_records_new.op_id","=","33"]);
                          $data  = $data->whereIn('ads.traffic_type', ['C','I']);
                    }
              
                    $data = $data->where($condtion)->selectRaw(DB::raw($select))
                            ->leftJoin("advertiser_campaigns","ads.id_advertiser","=","advertiser_campaigns.id")
                            ->leftJoin("crc_records_new","crc_records_new.id_ad","=","ads.id_ad")
                            ->groupby("crc_records_new.id_ad");
                          if($request->colorder){
                              $data = $data->orderby($request->colorder,$request->order);
                              $appends["colorder"]=$request->colorder;
                              $appends["order"]=$request->order;
                          }else{
                             $data = $data->orderby("crc_records_new.clickcount","DESC");
                             $data = $data->orderby("ads.network_name","ASC");
                             $data = $data->orderby("ads.operator_name","ASC");
                          }
                  $data =  $data->get();

                  if(sizeof($data) !== 0){
                        $update_time =  $data[sizeof($data)-1]->create_time;
                  }else{
                    $update_time = "";
                  }
                  $data1 = [];
                  $clickcount = $conversion_count = $clicks_active_count = $conversion_count_unique = $conversion_count_unique = 0;
                  $sourcost = $convCount = $profit = $fraud = 0;
          foreach($data as $fetch_records){
                $array = [];
                array_push($array,
                    $fetch_records->id_ad,
                    '<a title="'.$fetch_records->network_name.'"href="/carrier-specific-default-a-single-network/'.$fetch_records->id_ad.'?start='.$dtvalue.'&end='.$dtvalue2.'">'.substr($fetch_records->network_name,0,10).'</a>',
                    $fetch_records->network_cpa,
                    $fetch_records->op_name,
                    $fetch_records->traffic_type,
                    '<span title="'.$fetch_records->adv_name.'">'.substr($fetch_records->adv_name,0,10).'...</span>',
                    $fetch_records->country_code,
                    $fetch_records->clickcount,
                    $fetch_records->clickcount - $fetch_records->fraud,
                    $fetch_records->conversion_count,
                    $fetch_records->clicks_active_count,
                    $fetch_records->cr_received, 
                    $fetch_records->cr_given,
                    $fetch_records->conversion_count_unique,
                    round($fetch_records->total_cost,2)."/".round($fetch_records->total_cost * 65, 2),
                    round($fetch_records->revenue_dollar,2)."/".round($fetch_records->revenue_dollar*65,2),
                    round(($fetch_records->revenue_dollar - $fetch_records->total_cost),2)."/".round(($fetch_records->revenue_dollar - $fetch_records->total_cost)*65,2),
                    '<input class="" type="text" value="" id="example-text-input">');
                    array_push($data1, $array);
                    $clickcount += $fetch_records->clickcount;
                    $conversion_count += $fetch_records->conversion_count;
                    $clicks_active_count += $fetch_records->clicks_active_count;
                    $fraud += $fetch_records->fraud;
                    $conversion_count_unique += $fetch_records->conversion_count_unique;
                    $sourcost +=  round($fetch_records->total_cost);
                    $convCount += $fetch_records->revenue_dollar;
                    $profit += ($fetch_records->revenue_dollar - $fetch_records->total_cost);

                }
                $clickcount = round($clickcount,2);
                $conversion_count = round($conversion_count,2);
                $clicks_active_count = round($clicks_active_count,2);
                $fraud = round($fraud,2);
                $conversion_count_unique = round($conversion_count_unique,2);
                $sourcost =  round($sourcost,2);
                $convCount = round($convCount,2);
                $profit = round($profit,2);
            
            $lastRow =["Total","","","","","","",$clickcount,$clickcount-$fraud,$conversion_count,$clicks_active_count,"","",$conversion_count_unique,$sourcost,$convCount,$profit,""];
            $status = array('status'=>'1','data'=>$data1, 'lastRow'=>$lastRow,'update_time'=>$update_time);
            return $status;
          }

        function FilterationCarrierIndex(Request $request){
            $type = 'A';
            if($request->type){
              $type = $request->type;
            }  
            $data = $this->carrierFilteration($request,$type);
            return json_encode($data);          
          }

      //cariar specific routes
    public function CarrierIndexA_single(Request $request,$id,$type="",$routename = "carrier-specific-network-wise-record-filter",$header="CR Update WG")
    {


            $condtion = [];
            $dtvalue = $request->start;
            $dtvalue2 = $request->end;
            
            
            if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                    $dtvalue2 = date('Y-m-d');
                    $enddate = date('Y-m-d',strtotime("+1 days"));
            }else{
                //$dtvalue2 = date('Y-m-d',strtotime("+1 days"));
               $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));

            }
            
            

            array_push($condtion,['crc_records_new.create_time','>=',$dtvalue] );
            array_push($condtion,['crc_records_new.create_time','<=',$enddate] );
            
            if($id){
                array_push($condtion,['crc_records_new.id_ad','=',$id] );
            }
            if($request->id_advertiser_campaign){
                array_push($condtion,['crc_records.id_advertiser_campaign','=',$request->id_advertiser_campaign] );
               // dd($condtion);
            }
          
           $select = "advertiser_vw.advertiser_campaign_cpa"
                     .",advertiser_vw.advertiser_campaign_name as name"
                     .",crc_records_new.network_name"
                     .",crc_records_new.parent_cca"
                     .",crc_records_new.id_advertiser_campaign"
                     .",sum(crc_records_new.total_cost) as total_cost"
                     .",crc_records_new.id_ad"
                     .",sum(crc_records_new.revenue_dollar) as revenue_dollar"
                     .",sum(crc_records_new.conversion_count_unique) as conversion_count_unique"
                     .",crc_records_new.id_channel"
                     .",sum(crc_records_new.clickcount) as clickcount" 
                 .",sum(crc_records_new.conversion_count) as conversion_count" 
                 .",sum(crc_records_new.clicks_active_count) as clicks_active_count"  
                 .",crc_records_new.create_time";
  
             $data =  DB::table("crc_records_new")
              ->where($condtion) 
             ->selectRaw(DB::raw($select))
             ->leftJoin("advertiser_vw","crc_records_new.id_advertiser_campaign","=","advertiser_vw.id_advertiser_campaign")
             ->groupby("advertiser_vw.id_advertiser_campaign")
             
             ->orderby("advertiser_vw.advertiser_campaign_name","ASC")
             ->get();
        // dd($data);
         $result  = array('data' => $data,
            "routename"=>$routename,
            'header'=>$header,
            'id'=>$id,
            'dtvalue' => $dtvalue,
            'dtvalue2' => $dtvalue2
          );
        

         return view('network.network_cr_update_cariar_single')->with($result);


     }
     public function CarrierIndexC(Request $request){
        return $this->CarrierIndexA($request,"C","homeCariarFilterC","CR Update WM");
     }
     public function CarrierIndexRotator(Request $request){
        return $this->CarrierIndexA($request,"Rotator","homeCariarFilterRotator","Rotator CR Update");
     }

     public function CarrierIndexWIFIA(Request $request){
        return $this->CarrierIndexA($request,"WIFIA","homeCariarFilterWIFIA","CR Update WG");
     }
     public function CarrierIndexWIFIC(Request $request){
        return $this->CarrierIndexA($request,"WIFIC","homeCariarFilterWIFIC","CR Update WM");
     }

      function getNetworkList(Request $request) 
     {
       

        $select =  ["ad_network.name as network_name",
                        "ad_network.ccz as ccz",
                        "ad_network.token_key as token_key",
                        "ad_network.clickid_parameter as clickid_parameter",
                        "ad_network.create_time as create_time",
                        "ad_network.account_manager as account_manager",
                        "ad_network.update_time as update_time",
                        "ad_network.status as status",
                        "ad_network.id"];
         $data =  AdNetwork::with('User')
            ->select($select)   
            ->orderBy('ad_network.id', 'DESC')
            ->get();
        return view('/Resources.NetworkList',['network' => $data]);
    }
        function showaddnetworkview()
        {
            return view ('Resources.addnetwork');
        }

        function AddNetwork(Request $request)
        {

            $data  = array(
                'name' => $request->network_name,
                'clickid_parameter'=> $request->clickid,
                'billing_trafficker'=> $request->billing,
                'account_manager'=> $request->account_manager,
                'ccz'=> 0);

            AdNetwork::create($data);
            return redirect('/Resources/list-network');
        }
    function editNetwork($id)
        {
        $network=AdNetwork::find($id);
        return view ('Resources.editnetwork',compact('network'));
        }
    public function update(Request $request)
        {
       
        $network=AdNetwork::find($request->id);
        $network->name = $request->network_name;
        $network->ccz = $request->ccz;
        $network->token_key = $request->token_key;
        $network->clickid_parameter = $request->clickid;
        $network->account_manager = $request->account_manager;
        $network->billing_trafficker = $request->billing;
        $network->status = $request->status;
        $network->save();

        return redirect('/Resources/list-network');
        
        }

    public function publisher_cr_index(Request $request){
            
            $condtion = [];
            $dtvalue = $request->start;
            $dtvalue2 = $request->end;
    
            if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                    $dtvalue2 = date('Y-m-d');
                    $enddate = date('Y-m-d',strtotime("+1 days"));
            }else{
                //$dtvalue2 = date('Y-m-d',strtotime("+1 days"));
               $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));

            }
            
            

            array_push($condtion,['create_time','>=',$dtvalue] );
            array_push($condtion,['create_time','<=',$enddate] );
            
            
            array_push($condtion,['report_type','=',"CPA"] );

 
            $select = ["network_name",
                    "total_cost",
                    "op_name",
                    "id_channel",
                    "clickcount",
                    "conversion_count",
                    "network_cpa",
                    "clicks_active_count",
                    "cr_goal AS cr_goal",
                    "cr_received AS cr_received",
                    "cr_given AS cr_given",
                    "create_time"];

            $data =  DB::table("crc_network")
                    ->where($condtion) 
                    ->select($select)
                    ->orderby("network_name","ASC")
                    ->orderby("op_name","ASC")
                    ->get();

        
         $result  = array('data' => $data,
            "routename"=>"publisherCrFilter",
            'header'=>"Publisher CR Update",
            'dtvalue'=>$dtvalue,
            'dtvalue2'=>$dtvalue2
          );

         return view('network.publisher_cr_update')->with($result);

        }

}


