<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Ad;
use App\ads;
use App\operator;

class AdsControllerTest extends Controller
{
   
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */


    public function getAdData(Request $request)
     {
   
           $keyword = $request->keyword;
           $metaData = Ad::where('network_name', 'like', ''.$keyword['term'] .'%')
            ->get(['network_name as text', 'id_zone as id']);
           $returnRes['results'] = $metaData;
           return $returnRes;
      
     }

    public function index(Request $request,$type="",$page_name="URL MANAGEMENT",$urlFilter = "urlFilter")

    {
        $select = [
        "id_ad",
        "operator_name",
        "network_name","title","status","click_url","id_advertiser",
        "traffic_type"
        ];
        //dd($request->all());
          
        $condtion = [];
        $net_id="";
        $op_id ="";
        if($request->net_id && $request->net_id != ""){
          array_push($condtion,['network_name','=',$request->net_id] );
          $net_id = $request->net_id;
        }
        if($request->op_id && $request->op_id != ""){
          array_push($condtion,['cco','=',$request->op_id] );
          $op_id = $request->op_id;
        }
        if($type != ""){
            array_push($condtion,['type','=',$type] );
        }
        $appends = [];
        $total = $request->total ? $request->total:50;
        $appends['net_id']=$request->net_id;
        $appends['cco']=$request->cco;
        $appends['total']=$request->total;
       
 
        $data = Ad::where($condtion)
            ->select($select)
            ->orderby('id_ad','ASC')
            ->get();

            $data1 = [];
            foreach ($data as $dat) {
                $id = $dat->id_ad;
                $link = '<a class = "fa fa-edit" href="urls/manage/'.$id.'"></a>';
                $title = $dat->title;
                $traffic_type = $dat->traffic_type;
                $network_name = $dat->network_name;
                $operator_name = $dat->operator_name;
                $id_advertiser = $dat->id_advertiser;
                $click_url = $dat->click_url;
                array_push($data1, [$id,$link,$title,$traffic_type,$network_name,$operator_name,$id_advertiser,$click_url]);
               // data1.push( [$id,$link,$title,$traffic_type,$network_name,$operator_name,$id_advertiser,$click_url]);
            }
      


          return view('ad.ad_url_test',compact(['data1','net_id','op_id','page_name','total','urlFilter']));


    }
    
    public function index_cpa(Request $request){
          return $this->index($request,"CPA","CPA URL MANAGEMENT","urlcpaFilter");

    }


    public function index_cpi(Request $request){
         return $this->index($request,"CPI","CPI URL MANAGEMENT","urlcpiFilter");

    }


    public function index_cps(Request $request){
       return $this->index($request,"CPS","CPS URL MANAGEMENT","urlcpsFilter");

    }


    public function index_cpicpa(Request $request){
        return $this->index($request,"CPICPA","CPICPA URL MANAGEMENT","urlcpicpaFilter");

    }



    public function index_collect_ads(Request $request){
        return $this->index($request,"","URL MANAGEMENT","urlcollectadsFilter");

    }

    public function ajaxOperator(Request $Request){
        $op_id = $Request->opval;
        $op_id1 = $Request->opvals;
        $op_id2 = $Request->opval3;
        $operator_id =$Request->op_id3;
         $optype = $Request->optype;
       

    
        /*This for campaign dropdown to show on change in operator*/
   if($op_id !='')
  { 
            $select = "advertiser_campaigns.id as campid,advertiser_campaigns.id_advertiser as idadv1,advertiser_campaigns.name as idname,advertiser_campaigns.url as idurl";
            $data1 = DB::table('advertiser_campaigns')
            ->selectRaw(DB::raw($select))
            ->where('advertiser_campaigns.id_op', '=',$op_id)
            ->where('advertiser_campaigns.status','=','1')
            ->orderby('advertiser_campaigns.name')
            ->get()
            ->toArray();

            $dts1="<option value=''>Select </option>";
                foreach($data1 as $key => $val)
                {
                  $dts1 .='<option value="'.$val->idadv1.'" id="'.$val->idadv1.'"  title="'.$val->idurl.'">'.$val->idname.'('.$val->idadv1.')</option>';
                }
              return $dts1;
  }  

            /* this take apply cca column*/
             elseif (!empty($op_id1)) {
               $select = "ads.id_ad as idadv,ads.title as title";
                  $data2 = DB::table('ads')
                  ->selectRaw(DB::raw($select))
                  ->where('ads.cco','=',$op_id1)
                  ->get()
                  ->toArray();

             $dts='';
                foreach($data2 as $key => $val)
                {
                  $dts .='<option value="'.$val->idadv.'" >'.$val->idadv.'('.$val->title.')</option>';
                }
                return $dts;
             }
            /*live cca*/
             elseif(($op_id2!='')&& ($operator_id!=''))
          {
              $select = "ads.id_ad as idadv,ads.title as title";
                    $data3 = DB::table('ads')
                    ->selectRaw(DB::raw($select))
                    ->where('ads.id_advertiser','=',$op_id2)
                    ->where('ads.cco','=', $operator_id)
                    ->get()
                    ->toArray();

                    $dts2='';
                    foreach($data3 as $key => $val)
                {
                  $dts2 .='<option value ="'.$val->idadv.'">' .$val->idadv.'('.$val->title.')'.'</option>'.'<br>';
                }
                      return $dts2;

          }


   
  
}
public function ajaxsubmit(Request $Request){

    if($Request->optype ==2) {
     
                   $opids = $Request->op_data;
                    $campid = $Request->camp_data;
                       $idadsdataArr = $Request->id_advertiser;
                       
                        $select="advertiser_campaigns.name as name,advertiser_campaigns.url as url ";
                         $data4=DB::table('advertiser_campaigns')
                         ->selectRaw($select)
                          ->where('advertiser_campaigns.id','=',$campid)

                          ->get()
                          ->first();
                              foreach ($idadsdataArr as $key => $val) {
                              
                               $update = array('title' => $data4->name,'click_url' => $data4->url,'id_advertiser'=>$campid);
                                 


                              $upt1 = ads::where('id_ad','=',$val)->update($update);            
                              }

           return redirect('urls');                                                   
      }        

 elseif ($Request->optype ==1) {
 
                   
                   $opids = $Request->op_data;
                    $campid = $Request->camp_data;
                      $opcurrentArr = $Request->option;
                  
                        $select="advertiser_campaigns.name as name,advertiser_campaigns.url as url ";
                         $data4=DB::table('advertiser_campaigns')
                         ->selectRaw($select)
                          ->where('advertiser_campaigns.id','=',$campid)

                          ->get()
                          ->first();
                      foreach ($opcurrentArr as $key => $val) {
                               $update = array('title' => $data4->name,'click_url' => $data4->url,'id_advertiser'=>$campid);
                                 


                              $upt1 = ads::where('id_ad','=',$opcurrentArr)->update($update);
                            }
            


 return redirect('urls');                
                      

}

}


    public function editUrl() {
          return view('Ad.edit-url-management');
    }

    public function manageUrlPage(){
      $select = "operator.id, operator.name, country.iso as cc";
        $data = DB::table('operator')
        ->where('id_ad',$id_ad)
        ->selectRaw(DB::raw($select))
        ->leftjoin("country","operator.country_code","=","country_code.iso")
        ->first();
        return view('Ad.edit-url-management',compact('data'));
    }


    

    
     public function update(Request $request)
           {
            $select = [
        "id_ad",
        "operator_name",
        "network_name","title","status","click_url","id_advertiser",
        "traffic_type"
        ];
        //dd($request->all());
          
        $condtion = [];
        $net_id="";
        $op_id ="";
        if($request->net_id && $request->net_id != ""){
          array_push($condtion,['network_name','=',$request->net_id] );
          $net_id = $request->net_id;
        }
        if($request->op_id && $request->op_id != ""){
          array_push($condtion,['cco','=',$request->op_id] );
          $op_id = $request->op_id;
        }
        if($type != ""){
            array_push($condtion,['type','=',$type] );
        }
        $appends = [];
        $total = $request->total ? $request->total:50;
        $appends['net_id']=$request->net_id;
        $appends['cco']=$request->cco;
        $appends['total']=$request->total;
       
 
        $data = Ad::where($condtion)
            ->select($select)
            ->orderby('id_ad','ASC');
        $update = array('advetiser_id' => $request->advertiser,'operator_id' => $request->operator,'reverse_cca_id' => $request->reverse_cca);

           $url = reverse_setting::where(['reverse_id' =>  $request->ereverse])->update($update);
      
            /*$users->reverse_id = $request->ereverse;
            $users->advetiser_id = $request->eadvertiser_drop;
            $users->operator_id = $request->eoperator_drop;
            $users->reverse_cca_id = $request->ereverseId;
            $users->save();*/
            return redirect()->route('reverseAdvertiserShowGet');
           }
    public function cronmanage(Request $request,$type="",$page_name="CRON MANAGEMENT")
    {
        $select = [
        "id_ad",
        "operator_name",
        "network_name","title","status","click_url","id_advertiser",
        "traffic_type"
        ];
        //dd($request->all());
          
        $condtion = [];
        $net_id="";
        $op_id ="";
        if($request->net_id && $request->net_id != ""){
          array_push($condtion,['network_name','=',$request->net_id] );
          $net_id = $request->net_id;
        }
        if($request->op_id && $request->op_id != ""){
          array_push($condtion,['cco','=',$request->op_id] );
          $op_id = $request->op_id;
        }
        if($type != ""){
            array_push($condtion,['type','=',$type] );
        }
 
        $data = Ad::where($condtion)
            ->select($select)
            ->orderby('id_ad','ASC')
            ->paginate(20);
   



         return view('ad.ad-url',compact(['data','net_id','op_id','page_name']));

    }

          
}
