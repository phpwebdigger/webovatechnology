<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;
use App\FraudClickInfo;
use Response;
use Session;
use Simplehelper;

class FraudClickInfoController extends Controller
{
   
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
  public function index(Request $request){
        $flag = 0;
        $condition = [];  
        $dtvalue = $request->start;
        $dtvalue2 = $request->end;
         $group_by = [];
        if(is_null($dtvalue)){
            $dtvalue = date('Y-m-d');
        }
        if(is_null($dtvalue2)){
                $dtvalue2 = date('Y-m-d');
                $enddate = date('Y-m-d',strtotime("+1 days"));
        }else{
           if($dtvalue == $dtvalue2){ 
              $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));
           }else{
            $enddate = date('Y-m-d',strtotime($dtvalue2));
           }
        }

        if($request->ipAddress){
            array_push($condition,["ipAddress","=",$request->ipAddress]); 
        }
        if($request->ccz){
            array_push($condition,["ccz","=",$request->ccz]); 
        }
        if($request->cca){
            array_push($condition,["cca","=",$request->cca]); 
        }
        if($request->siteId){
            array_push($condition,["siteId","=",$request->siteId]); 
        }
        if($request->PubId){
            array_push($condition,["PubId","=",$request->PubId]); 
        }
        if($request->SubId){
            array_push($condition,["SubId","=",$request->SubId]); 
        }
        if($request->referralUrl){
            array_push($condition,["referralUrl","=",$request->referralUrl]); 
        }
        if($request->group_by){
            $flag = 2;
            $group_by  = $request->group_by;
        }

        if($flag == 2){
          // $select = "fdCkId,reqDate,ipAddress,cca,ccz,siteId,pubId,subId,referralUrl,sum(count) as count, sum(saleCount) as saleCount, sum(conversionCount) as conversionCount,
            //      sum(conversionClickPerMins) as conversionClickPerMins";
             $select = ['fdCkId',
                'reqDate',
                'ipAddress',
                'cca',
                'ccz',
                'siteId',
                'pubId',
                'subId',
                'referralUrl',
                'sum(count) as count',
                'saleCount',
                'conversionCount',
                'conversionClickPerMins',
                ];     
          }else{ 
           $select = ['fdCkId',
                'reqDate',
                'ipAddress',
                'cca',
                'ccz',
                'siteId',
                'pubId',
                'subId',
                'referralUrl',
                'count',
                'saleCount',
                'conversionCount',
                'conversionClickPerMins',
                ];
         }      
         
        array_push($condition,["reqDate","=",$dtvalue]); 
        if($flag == 2){
          $data = FraudClickInfo::where($condition)
                    ->selectRaw('fraud_click_info.*, sum(fraud_click_info.count) as count, sum(fraud_click_info.saleCount) as saleCount,sum(fraud_click_info.conversionCount) as conversionCount,sum(fraud_click_info.conversionClickPerMins) as conversionClickPerMins')
                    ->groupBy($group_by)
                    ->orderby('count', 'desc')
                    ->paginate(1000);
        }else{
                $data = FraudClickInfo::where($condition)
                    ->select($select)
                    ->orderby('count','desc')
                    ->paginate(1000);      
        } 
        $data1 = $lastRow = [];
        $totalCount = $totalCoversionCount = $totalConversionClickperMins = 0;
        // print_r($data);die;
          foreach ($data as $fetch_url){
                  $array = [];
                  $submitValue = "<input type='text' name=".$fetch_url->fdCkId." class='submit-to' value=''>&nbsp;<a href=javascript:void(0) class='btn btn-primary submit'  data-value =".$fetch_url->fdCkId.",".$fetch_url->cca.",".$fetch_url->ccz.",".$fetch_url->count.">Go</a>";   
                  array_push($array,
                    $fetch_url->ipAddress,
                    $fetch_url->cca,
                    $fetch_url->ccz,
                    $fetch_url->siteId,
                    $fetch_url->pubId,
                    $fetch_url->subId,
                    $fetch_url->referralUrl,
                    $fetch_url ->count,
                    $fetch_url ->saleCount,
                    $fetch_url->conversionCount??"",
                    $fetch_url->conversionClickPerMins??"",
                    $submitValue
                   );
                    $totalCount = $totalCount + $fetch_url->count;
                    $totalCoversionCount = $totalCoversionCount + $fetch_url->conversionCount;
                    $totalConversionClickperMins = $totalConversionClickperMins + $fetch_url->conversionClickPerMins;
            array_push($data1, $array);

        }
        $lastRow = [$totalCount,$totalCoversionCount,$totalConversionClickperMins];
       // $networks = json_decode(Simplehelper::getNetworks());
        // $operators = json_decode(Simplehelper::getOperators());
       $result  = array(
                        'data' => $data,
                        'data1' => $data1,            
                        'dtvalue' => $dtvalue,
                        // 'dtvalue2' => $dtvalue2,
                        'lastRow'=>$lastRow,
                         'cca' => $request->cca,
                         'ccz' => $request->ccz,
                         'siteId' => $request->siteId,
                         'subId' => $request->subId,
                         'pubId' => $request->pubId,
                         'referralUrl' => $request->referralUrl,
                         'group_by' => $group_by
                       );
      return view('FraudClickInfo.index',$result);
  }



    
        
          
}
