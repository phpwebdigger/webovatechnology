<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Response;
use Illuminate\Support\Facades\Redis;
use App\Ad;
use App\AdvertiserCampaigns;
use App\Advertiser;
use App\CTIITwise;
use DateTime;
use Config;
class CTIITController extends Controller
{

     public function __construct()
    {
        $this->middleware('auth');
    }


     
    /**;
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
   
    public function index(Request $request){
      $items = $this->getConversionData();
      $lastUpdated = $this->lastUpdated();
      $dataN =  view('CTIIT.index')->with($items);
      return $dataN;
//      return view('Conversion.index',compact('items','hour','lastUpdated'));
    }

    /**
     * To Show the data on landing page for current day Only
     *
     * @return \Illuminate\Http\Response
     */
    public function getConversionData(){
        $date = date('Y-m-d');
        $date2 = date('Ymd');
        $dtvalue = date('Y-m-d');
        $enddate = date('Y-m-d');
//        $enddate = date('Y-m-d',strtotime("+1 days"));
        $table = "conversions_$date2 as con1";
        $key  =  "conversion_$date";
        try {
             $items = $this->getconversion(); 
         }
         catch (\Exception $e) {
          $items = $this->getconversion();  
          
      }
      $allData = '';
        if(count($items['data']) > 0){
            $allData = $items['data'];
        }
        
        
        $osdata =  DB::table("$table");
        $osdata = $osdata->selectRaw("distinct os")
                ->where("os","!=","")
                ->get();
        
        $networkdata =  DB::table("ad_network");
        $networkdata = $networkdata->selectRaw("distinct(ad_network.id),ad_network.name")
                ->rightJoin("conversions_$date2 as con1","ad_network.id","con1.id_zone")
                ->orderby("ad_network.name")
                ->get();
        $advInnerdata =  DB::table("advertiser_campaigns");
        $advInnerdata = $advInnerdata->selectRaw("distinct advertiser_campaigns.id_advertiser")
                ->rightJoin("conversions_$date2 as con1","con1.id_advertiser","advertiser_campaigns.id")
        
                ->get();
        $string = array();
        $i = 0;
        
        foreach($advInnerdata as $value)
        {
            $string[$i] = $value->id_advertiser;
            $i++;
        }
        
        $advInnerdata = json_decode($advInnerdata);
        
        $advertiserdata =  DB::table("advertiser");
        $advertiserdata = $advertiserdata->selectRaw("id,name")
                ->whereIn('id',$string)
                ->orderby("name")
                ->get();
        
        
        
        $campaigndata =  DB::table("conversions_$date2 as con1");
        $campaigndata = $campaigndata->selectRaw("distinct(con1.id_advertiser),advertiser_campaigns.name")
                ->leftJoin("advertiser_campaigns","con1.id_advertiser","advertiser_campaigns.id")
                ->orderby("advertiser_campaigns.name")
                ->get();
        
        $countrydata =  DB::table("country");
        $countrydata = $countrydata->selectRaw("distinct(country.iso),country.name")
                ->rightJoin("conversions_$date2 as con1","country.iso","con1.country")
                ->orderby("country.name")
                ->get();
      
        $time_zone = Config::get('app.time_zone');$report_type='today';

        $lastUpdated = $this->lastUpdated();

        $result  = array(
                          'data' => $items, 
                          'data1' => $allData,
                          'osarray' => $osdata,
                          'networkarray' => $networkdata,
                          'countryarray' => $countrydata,
                          'advertiserarray' => $advertiserdata,
                          'campaignarray' => $campaigndata,
                          'lastUpdated' => $lastUpdated,
                          'dtvalue' => $date,
                          'dtvalue2' => $enddate,
                          'lastRow'=>$items['lastRow'],
                          'timezone'=>$time_zone,
                          'report_type'=>$report_type,
                    );
        return $result;
    }

    public function getconversion(){
       $date = date('Ymd');
       $hour = date("H");
       $condtion = [];
       $table_name = "conversions_$date as con1";
       $select = [
                "con1.click_hour",
                "con1.id_ad",
                "con1.id_zone",         
                "date(con1.datetime) as datetime",        
                "con1.id_advertiser",
                "(select advertiser.name from advertiser left join advertiser_campaigns on advertiser_campaigns.id_advertiser=advertiser.id where advertiser_campaigns.id=con1.id_advertiser) as advert_name",
                "(select advertiser_campaigns.name from advertiser_campaigns  where advertiser_campaigns.id=con1.id_advertiser) as advert_camp_name",
//                "advertiser.name as advert_name",   
                "ads.network_name as publisher_namea",
                  // "ad_network.name  as publisher_name",  
                "CONCAT(ad_network.name,' (',ad_network.ccz,')') as publisher_name",
                "con1.parent_cca",      
                "con1.from_server",     
                "con1.siteid",          
                "con1.browser",          
                // "con1.country",   
                "(select advertiser_campaigns.country_code from advertiser_campaigns  where advertiser_campaigns.id=con1.id_advertiser) as country",      
                "sum(con1.dollar_price) as dollar_price",
                // "(select sum(CASE WHEN con1.sale=0 THEN con1.dollar_price ELSE 0 END) from advertiser_campaigns  where advertiser_campaigns.sale_rev_cal_status=con1.sale and advertiser_campaigns.id=con1.id_advertiser ) as Revenue",
                "sum(CASE WHEN con1.sale=1 THEN con1.dollar_price ELSE 0 END) as Revenue",
                "con1.cc_token",
                "con1.network_token",
                // "con1.os",
                 "(select advertiser_campaigns.os_type from advertiser_campaigns  where advertiser_campaigns.id=con1.id_advertiser) as os",
                "con1.os_version",
                "con1.app_version",
                "con1.client_ip",
                "con1.is_duplicate",
                "con1.googleid",
                "con1.campaign_timezone",
                "con1.uid",
                "ads.traffic_type",
                "con1.status",
                "con1.price as price",
                'con1.pubid',
                'con1.from_server',
                'con1.transaction_id',
                'con1.ctit as ctit',
                'sum(IF(con1.sale = "1",1,0)) as sale',
                "CASE WHEN ads.traffic_type in('SM','SG','WM','WG') THEN (SELECT operator.name FROM operator where con1.id_ad=operator.id) WHEN con1.traffic_type not in('SM','SG','WM','WG') THEN (SELECT ads.operator_name from ads where con1.id_ad=ads.id_ad) ELSE 'HELLO' END as operator_name",
                "sum(IF(con1.sale =0,1,0)) as conversion"
      ];
//        $fields = implode(",", $field);
        $select = implode(",",$select);
        $data =  DB::table($table_name)->where($condtion);
        $data = $data->selectRaw($select)
                ->leftJoin("advertiser","con1.id_advertiser","advertiser.id")
                ->leftJoin("ad_network","con1.id_zone","ad_network.id")
                ->leftJoin("ads","con1.parent_cca","ads.id_ad")
                ->groupby('click_hour')
                ->orderby('click_hour','DESC');
        $data =  $data->get();
        $data1 = [];
        $total_price = $crv= $total_dollar_price2 = $total_conversion = $total_sale = $total_Revenue= $total_crv=0; 
        
        if(count($data))
        {
            foreach ($data as $fetch_records) {
                $array = [];
                if($fetch_records->conversion>0){
                  $crv= ( $fetch_records->sale/$fetch_records->conversion)*100;
                }else{
                  $crv= 0;
                }
                
                array_push($array,
                      $fetch_records->datetime,
                          $fetch_records->click_hour,
                          $fetch_records->publisher_name,
                          $fetch_records->parent_cca,
                          $fetch_records->id_ad,
                          $fetch_records->siteid,
                          
                          $fetch_records->advert_name,
                          $fetch_records->advert_camp_name.' ('.$fetch_records->id_advertiser.')',
                        
                          $fetch_records->os_version,
                          $fetch_records->app_version,
                          $fetch_records->uid,
                          $fetch_records->from_server,
                            $fetch_records->browser,
                          $fetch_records->os,
                          $fetch_records->country,
                          $fetch_records->campaign_timezone,
                          
                          $fetch_records->ctit,
                          $fetch_records->transaction_id,
                          $fetch_records->conversion,
                          $fetch_records->sale,
                          round($crv,2) .'%',
                          round($fetch_records->price,2),
                          '$'.round($fetch_records->dollar_price,2),
                          round($fetch_records->Revenue)
                        );
                       
                        array_push($data1, $array);
                        $total_dollar_price2 = $total_dollar_price2 + $fetch_records->dollar_price;
                        $total_price = $total_price + round($fetch_records->price,2);
                        $total_conversion = $total_conversion + $fetch_records->conversion;
                        $total_sale = $total_sale + $fetch_records->sale;
                        $total_Revenue =$total_Revenue + $fetch_records->Revenue;
                        $total_crv = $total_crv + round($crv,2);
            }
        }
        $lastRow = ["Total",
                     "",
                                             "",
                                             "",
                                             "",
                                             "",
                                             "",
                                             "",
                                             "",
                                             "",
                                             "",
                                             "",
                                             "",
                                             "",
                                             "",
                                             "",
                                             "",
                    $total_conversion,
                    $total_sale,
                    round($total_crv,2),
                    round($total_price,2),
                    round($total_dollar_price2,3),
                    round($total_Revenue,2)
                    ];
        
        $status = array("status"=>"1",'data'=>$data1,'lastRow'=>$lastRow); 
        return $status;
    }

  
    public function filterData(Request $request){
      $current_url = $request->fullUrl();
        $current_url = explode("?",$current_url);
        try{
              $item = $this->getFilterQuery($request);
        
      } catch(\Exception $e){
         $item = $this->getFilterQuery($request);
      } 
       return $item;
   }





   function getFilterQuery(Request $request){

      if($request->input('reportrange'))
        {
            $dateRange = explode(" ",$request->input('reportrange'));
            $dtvalue = $dateRange[0]; 
            $enddate  = $dateRange[2];
            // $condition .= "BETWEEN $dtvalue AND $enddate ";  
        }else{
            $dtvalue = date('Y-m-d');
            $date = date('Ymd');
            $enddate = date('Y-m-d',strtotime("+1 days"));
        } 

       $id_zone_arr = $click_hour_arr = $from_server_arr = $country_arr = $traffic_type_arr = $os_arr = $id_advertiser_arr = $group_by_arr = $time_zone =[];
       $vertical='';
        
          $total_price = $crv= $total_dollar_price1 = $total_conversion = $total_sale =  $total_Revenue = $total_crv=0; 
        
        $report_type=isset($request->report_type) ? $request->report_type :'';

        // if($report_type=="monthly"){
        //   $table_name = "conversions as con1";   
        // }else{
        //   $table_name = "conversions_$date as con1";   
        // }

           $date_now = date('Y-m-d');
          //if(strtotime($date_now)===strtotime($dtvalue) && strtotime($date_now)===strtotime($enddate))  {
          if($date_now==date('Y-m-d', strtotime($dtvalue)) && $date_now==date('Y-m-d', strtotime($enddate)))  {
             $table_name = "conversions_".date('Ymd',strtotime($date_now))." as con1";  
             $report_type='today';
          }else{
             $table_name = "conversions as con1"; 
             $report_type='monthly';
          }

         

      $condition = [];
      $groupCondition = [];
      $checkedCond = [];
      $extra_fields = '';
      $citit_lessthen10mnit = isset($request->citit_lessthen10mnit) ? $request->citit_lessthen10mnit:'0';

          if($request->time_zone && $request->time_zone != '')
         {
            if(count($request->time_zone) > 0 )
            {
                $time_zone = $request->time_zone;
            }
           

        }else{
        $date = explode(" - ",$request->date);
          if(count($date) > 1){
           $startDate = date('Ymd',strtotime($date[0]));
           $endDate = date('Ymd',strtotime($date[1]));
          }

    
        }


      

     // if($request->exists('group_by') && $request->group_by){
     //     $group_by = implode("','",$request->group_by);
     // }
        if($request->parent_cca){
//            $condition .= " AND con1.parent_cca IN ('".$request->parent_cca."')";
            array_push($condition,['con1.parent_cca','=',$request->parent_cca]);
        }
        if($request->id_ad){
//            $condition .= " AND id_ad IN ('".$request->id_ad."')";
            array_push($condition,['con1.id_ad','=',$request->id_ad]);
        }
        if($request->id_zone && $request->id_zone != 0)
        {
            if(count($request->id_zone) > 1 )
            {
                $id_zone_arr = $request->id_zone;
            }
            else
            {
                array_push($condition,['con1.id_zone','=',$request->id_zone[0]]);
            }              
        }
        if($request->from_server && $request->from_server != '')
        {
            if(count($request->from_server) > 1 )
            {
                $from_server_arr = $request->from_server;
            }
            else
            {
                array_push($condition,['con1.from_server','=',$request->from_server[0]]);   
            }              
        }
        if($request->country && $request->country != '')
        {
            if(count($request->country) > 1 )
            {
                $country_arr = $request->country;
            }
            else
            {
                array_push($condition,['con1.country','=',$request->country[0]]);   
            }              
        }
     

        if($request->traffic_type && $request->traffic_type != '')
        {
            if(count($request->traffic_type) > 1 )
            {
                $traffic_type_arr = $request->traffic_type;
            }
            else
            {
                array_push($condition,['advertiser_campaigns.type','=',$request->traffic_type]);   
            }              
        }

             if($request->vertical && $request->vertical != '')
        {
            if(count($request->vertical) > 1 )
            {
                $vertical = $request->vertical;
            }
            else
            {
                array_push($condition,['advertiser_campaigns.vertical','=',$request->vertical]);   
            }              
        }
        if($request->os && $request->os != '')
        {
            if(count($request->os) > 1 )
            {
                $os_arr = $request->os;
            }
            else
            {
                array_push($condition,['con1.os','=',$request->os[0]]);   
            }              
        }
        if($request->id_advertiser && $request->id_advertiser != '')
        {
            if(count($request->id_advertiser) > 1 )
            {
                $id_advertiser_arr = $request->id_advertiser;
            }
            else
            {
                array_push($condition,['con1.id_advertiser','=',$request->id_advertiser[0]]);   
            }              
        }
        if($request->click_hour && $request->click_hour != '')
        {
            if(count($request->click_hour) > 1 )
            {
                $click_hour_arr = $request->click_hour;
            }
            else
            {
                array_push($condition,['con1.click_hour','=',$request->click_hour[0]]);   
            }              
        }
        if($request->siteid)
        {
            array_push($condition,['con1.siteid','=',$request->siteid]);
        }
        if($request->network_token)
        {
            array_push($condition,['con1.network_token','=',$request->network_token]);
        }
        if($request->cc_token)
        {
            array_push($condition,['con1.cc_token','=',$request->cc_token]);
        }
        if($request->pubid)
        {
            array_push($condition,['con1.pubid','=',$request->pubid]);
        }
        if($request->group_by && $request->group_by != '')
        {
            $group_by_arr = $request->group_by;

         
            if(count($request->group_by) > 1 )
            {
                
                $groupCondition = $request->group_by;
            }
            else
            { 
              if($request->group_by[0]=='datetime'){
                array_push($groupCondition,DB::raw('Date(con1.datetime)'));//'con1.datetime');  
              }else{
                array_push($groupCondition,'con1.'.$request->group_by[0]);   
              }
              
//                $groupCondition .= "'".$request->group_by[0]."'";
            }              
        }
        else
        {
            // array_push($groupCondition,'click_date_time');
          // $groupCondition .= "con1.click_hour";
        }



      $field = [ "con1.click_hour",
                "con1.id_ad",
                "con1.id_zone",         
                "date(con1.datetime) as datetime",        
                "con1.id_advertiser",
                "(select advertiser.name from advertiser left join advertiser_campaigns on advertiser_campaigns.id_advertiser=advertiser.id where advertiser_campaigns.id=con1.id_advertiser) as advert_name",
                "(select advertiser_campaigns.name from advertiser_campaigns  where advertiser_campaigns.id=con1.id_advertiser) as advert_camp_name",
               "(select CONCAT(adname.name,' (',adname.ccz,')')  from ad_network as adname where adname.ccz=con1.id_zone)  as publisher_name",  
                "con1.parent_cca",
                "con1.from_server",     
                "con1.siteid",          
                "(select advertiser_campaigns.country_code from advertiser_campaigns  where advertiser_campaigns.id=con1.id_advertiser) as country",      
                "sum(con1.dollar_price) as dollar_price",
                "sum(CASE WHEN con1.sale=1 THEN con1.dollar_price ELSE 0 END)  as Revenue",
                "con1.cc_token",
                "con1.network_token",
                // "con1.os",
                 "(select advertiser_campaigns.os_type from advertiser_campaigns  where advertiser_campaigns.id=con1.id_advertiser) as os",
                "con1.os_version",
                "con1.app_version",
                "con1.client_ip",
                "con1.is_duplicate",
                "con1.googleid",
                 "con1.browser",
                "con1.uid",
                "advertiser_campaigns.type",
                "con1.status",
                "con1.price as price",
                'con1.pubid',
                'con1.from_server',
                'con1.transaction_id',
                'con1.ctit as ctit',
                'con1.campaign_timezone as campaign_timezone',
                'sum(IF(con1.sale = "1",1,0)) as sale','sum(IF(con1.sale =0,1,0)) as conversion'               
      ];
      
        

        $fields = implode(",", $field); 
           $ddCondition =  []; 
        $data =  DB::table($table_name)->where($condition);
      
 
        if($id_zone_arr)
        {
            $data = $data->whereIn('con1.id_zone',$id_zone_arr);
        }
        if($click_hour_arr)
        {
            $data = $data->whereIn('con1.click_hour',$click_hour_arr);
        }
        if($from_server_arr)
        {
            $data = $data->whereIn('con1.from_server',$from_server_arr);
        }
        if($country_arr)
        {
            $data = $data->whereIn('con1.country',$country_arr);
        }
         if($time_zone)
        {
            // echo $dtvalue; print_r($time_zone);
          $result=$this->time_zone_rt($dtvalue,$timezone='true',$time_zone[0]);


          $data = $data->where(DB::raw('date(con1.datetime)'),'>=',$result);
          // $data = $data->where('con1.campaign_timezone',$request->time_zone[0]);
          
        }
        if($traffic_type_arr)
        {
            $data = $data->whereIn('advertiser_campaigns.type',$traffic_type_arr);
        }
         if($vertical)
        {
            $data = $data->whereIn('advertiser_campaigns.vertical',$vertical);
        }
        if($os_arr)
        {
            $data = $data->whereIn('con1.os',$os_arr);
        }
        if($id_advertiser_arr)
        {
            $data = $data->whereIn('con1.id_advertiser',$id_advertiser_arr);
        }
       
       

         if($request->value_type =='second' && !empty($request->ctit_check) && $request->ctit_check=='on'){
          
          $min_value = ($request->value_type=='second') ? $request->min_time : ($request->min_time*60);

          $max_value = ($request->value_type=='second') ? $request->max_time : ($request->max_time*60);

          $data= $data->whereBetween(DB::raw('con1.ctit'), array($min_value, $max_value));
            $data=  $data->where('con1.sale','0');

          // $groupCondition .= "con1.ctit";
          array_push($groupCondition,'con1.ctit');
          $data = $data->whereDate('con1.click_date_time',array($dtvalue,$enddate));
          $data = $data->whereBetween(DB::raw('date(con1.datetime)'),array($dtvalue,$enddate));

        }
     
        if(!empty($report_type) && $report_type=="monthly" && !empty($request->ctit_check) && $request->ctit_check=='on'){
        $data = $data->whereDate('con1.click_date_time',array($dtvalue,$enddate));
        $data = $data->whereBetween(DB::raw('date(con1.datetime)'),array($dtvalue,$enddate));
        
        }
        
     
       if(!empty($report_type) && $report_type=="monthly"){
     
        // $data = $data->whereDate('con1.click_date_time',array($dtvalue,$enddate));
        // $data = $data->whereBetween('con1.datetime',[$dtvalue.' 00:00:00',$enddate.' 23:59:59']);
        $data = $data->whereBetween(DB::raw('date(con1.datetime)'),[$dtvalue,$enddate]);
        }
         
     
        if($group_by_arr)
        {
            if(!in_array('client_ip',$group_by_arr))
            {
                array_push($checkedCond,'20');
            }
            if(!in_array('is_duplicate',$group_by_arr))
            {
                array_push($checkedCond,'21');
            }
            if(!in_array('googleid',$group_by_arr))
            {
                array_push($checkedCond,'22');
            }
//            foreach ($group_by_arr as $value) {
//                $groupCondition .= "'".$value."',";
//            }
//            rtrim($groupCondition,',');
//            rtrim($groupCondition,"'");
//            ltrim($groupCondition,"'");
//            $groupCondition = $group_by_arr;
//            $data = $data->whereIn('con1.id_advertiser',$id_advertiser_arr);
        }
      if(!empty($groupCondition)){
       $data = $data->groupby($groupCondition);
      }
      
        $data = $data->selectRaw($fields)
                // ->leftJoin("advertiser","con1.id_advertiser","advertiser.id")
                // ->leftJoin("ad_network","con1.id_zone","ad_network.id")
                ->leftJoin("advertiser_campaigns","con1.id_advertiser","advertiser_campaigns.id")
                // ->leftJoin("ads","con1.parent_cca","ads.id_ad")
                ->where($ddCondition)
               
                ->orderby('click_hour','DESC');
        $data =  $data->get();
        $data1 = [];

       
        
        if(count($data)>0)
        {
           foreach ($data as $fetch_records) {
                $array = [];
                if($fetch_records->conversion>0){
                $crv= ($fetch_records->sale/$fetch_records->conversion)*100;
                }else{
                  $crv=0;
                }
                array_push($array,
                    $fetch_records->datetime,
                          $fetch_records->click_hour,
                          $fetch_records->publisher_name,
                          $fetch_records->parent_cca,
                          $fetch_records->id_ad,
                          $fetch_records->siteid,
                          $fetch_records->advert_name,
                          $fetch_records->advert_camp_name.' ('.$fetch_records->id_advertiser.')',
                          $fetch_records->os_version,
                          $fetch_records->app_version,
                          $fetch_records->uid,
                          $fetch_records->from_server,
                          $fetch_records->browser,
                          $fetch_records->os,
                          $fetch_records->country,
                          $fetch_records->campaign_timezone,
                          $fetch_records->ctit,
                          $fetch_records->transaction_id,
                          $fetch_records->conversion,
                          $fetch_records->sale,
                          round($crv,2).'%',
                          round($fetch_records->price,2),
                        '$'.round($fetch_records->dollar_price,2),
                        round($fetch_records->Revenue)
                        );
                       
                        array_push($data1, $array);
                        $total_dollar_price1 = $total_dollar_price1 + $fetch_records->dollar_price;
                        $total_price = $total_price + round($fetch_records->price,2);
                        $total_conversion = $total_conversion + $fetch_records->conversion;
                        $total_sale = $total_sale + $fetch_records->sale;
                        $total_crv = $total_crv + round($crv,2);
                         $total_Revenue =$total_Revenue + round($fetch_records->Revenue,2);
            }
        }

         $lastRow = ["Total",
                     "",
                     "",
                     "",
                     "",
                     "",
                     "",
                     "",
                     "",
                     "",
                     "",
                     "",
                     "",
                     "",
                     "",
                     "",
                     "",
                     "",
                    $total_conversion,
                    $total_sale,
                    round($total_crv,2),
                    round($total_price,2),
                    round($total_dollar_price1,2),
                    round($total_Revenue,2)
                    ];
        
        $status = array("status"=>"1",'data'=>$data1,'lastRow'=>$lastRow,'checkedCond'=>$checkedCond,'report_type'=>$report_type); 
        return $status;
      
//      $total_record = count($data);
//      $status = array("status"=>"1",'data'=>$data1,'lastRow'=>$lastRow); 
//        return $status;
//      return view('Conversion.filterData',compact('items','flag','total_record')); 
    }


    function lastUpdated(){
        $date = date('Ymd');
        $table_name = "conversions_$date";
        $lastUpdated = DB::select("SELECT max(datetime) as click_date_time from $table_name  order by datetime desc limit 1");
        $lastUpdated_count = count($lastUpdated);
        if($lastUpdated_count > 0)
          if($lastUpdated[0]->click_date_time){
          return $lastUpdated[0]->click_date_time;  
        }
        return "No Update time";  
      }

       public function getdateRangeCondtion($dateRange){
         if(!empty($dateRange)){
           $dateRange = explode(" ",$dateRange);
            $start_date = $dateRange[0];
            $end_date =   $dateRange[2];
            $diff = strtotime($end_date) - strtotime($start_date);
            $diff =  $diff/86400;
            if($start_date == $end_date){
             $condition =  "(date(crc.create_time) = '$start_date')";
            }else if($diff > 0){
             $condition = "(date(crc.create_time) BETWEEN '$start_date' AND '$end_date')";   
            } 
          }else{
          $condition = '1=1';
        }
        return $condition;
    }



    public function time_zone_rt($tdate,$timezone='false' , $timezone_value){
      if($timezone){
      $datetime1 = new \DateTime();
          $datetime1->setTimezone(new \DateTimeZone('Asia/Calcutta'));
          $local_time=$datetime1->format('Y-m-d H:i:s');


           $datetime = new \DateTime();
           $datetime->setTimezone(new \DateTimeZone($timezone_value));
           $new_date=$datetime->format('Y-m-d');

           

            $MNTTZ = new \DateTimeZone($timezone_value);
            $ESTTZ = new \DateTimeZone('Asia/Calcutta');
              
            $dt = new \DateTime($tdate.' 00:00:00', $MNTTZ);
            $dt->format('Y-m-d H:i:s');
            $dt->setTimezone($ESTTZ);
            $result =$dt->format('Y-m-d H:i:s');
          }

          return $result;
    }

}

?>
