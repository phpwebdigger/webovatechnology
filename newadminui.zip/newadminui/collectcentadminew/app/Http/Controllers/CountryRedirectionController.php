<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CountryRedirectionController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        
        
        $select =  [
            "id",
            "parent_cca",
            "country",
            "id_ad",
            "status"
          ];

         $data =  DB::table("country_redirection")
         ->select($select)

         ->get();
         $data1= [];
         $isLive_st = "";
         
         
         
         foreach ($data as $result) {

                if($result->status==1)
                {
                    $isLive_st = 'Live'; 
                    $isLive_st_temp = '<span id="is_live_'.$result->id.'">'.$isLive_st.'</span> | <a  href="javascript:void(0);" onclick="EditStatus('.$result->id.','.$result->status.')" <i id="is_live_temp_'.$result->id.'" class="fa fa-square" style="color:#32CEA7"></i> </a>';
                    
                }else
                {
                    $isLive_st = 'NotLive';
                    $isLive_st_temp = '<span id="is_live_'.$result->id.'">'.$isLive_st.'</span> | <a  href="javascript:void(0);" onclick="EditStatus('.$result->id.','.$result->status.')" <i id="is_live_temp_'.$result->id.'" class="fa fa-square" style="color:#F05355"></i> </a>';
                }
             $array = [];
             array_push($array,

                            $result->id,
                            '<a href="/country-redirection/edit/'.$result->id.'"><button type="button" class="btn btn-success btn-circle "><i class="fa fa-edit"></i> </button></a>',
                            $result->parent_cca,
                            $result->country,
                            $result->id_ad,
                            $isLive_st_temp
//                            '<span id="is_live_'.$result->id.'">'.$isLive_st.'</span> | <a  href="javascript:void(0);" onclick="EditStatus('.$result->id.','.$result->status.')" <i class="fa fa-edit"></i> </a>'
                            );
                array_push($data1, $array);
         }
         
         
        return view('country.country_redirection_view',compact('data1'));
//        return view('country.country_redirection_view');
    }

    public function status_update(Request $request)
    {
       
        $id = $request->id;
        $status = $request->status;

//        echo "<pre>";
//        print_r($request->all());
//        echo "</pre>";die();
        
        if($id != '' && $status != '')
        {
            
            if($status=='1')
            {
                $statuss = '0';
            }else
            {
                $statuss = '1';
            }
            
            $update = DB::table('country_redirection')
            ->where('id', $id)

            ->limit(1)  // optional - to ensure only one record is updated.
            ->update(array('status' => $statuss)); 
            if($update)
            {
               echo 1;
                exit();
            }
            else 
            {
                echo 2;
                exit();
            }
        }
        else
        {
            echo 3;
                exit();
            
        }
    }
    
    public function add(Request $request)
    {

        $select_country =  [
            "iso",
            "name"
          ];
        
        $data =  DB::table("country")
        ->select($select_country)
        ->get();
        $ddDataResult  = array(
                'country_dropdown' => []
            );
        
        foreach ($data as $dropdown) {

            if ($dropdown->iso){
                $ddDataResult['country_dropdown'][$dropdown->iso] = $dropdown->name;
            }
            
          }
        $result  = array(
            'country_data' => $ddDataResult,
          );
        
        $viewPage = "country.country_redirection_add";
        
        $dataN =  view($viewPage)->with($result);
        return $dataN;
    }
    public function add_details(Request $request)
    {

//                echo "<pre>";
//        print_r($request->all());
//        echo "</pre>";die();
        
        $country = $request->country;
        $parent = $request->parent;
        $id_ad = $request->id_ad;
        
        
        
        
        if($country !='' && $parent != '' && $id_ad != '')
        {
            $select =  [
                "id",
                "parent_cca",
                "id_ad"
            ];
            $condtion = [];
            array_push($condtion,["parent_cca","=",$parent] );
            array_push($condtion,["id_ad","=",$id_ad] );
            
            $data =  DB::table("country_redirection")
            ->select($select)
            ->where($condtion)
            ->limit(1)
            ->get();
            $id="";
            $cca="";
            $id_a="";
            foreach ($data as $result) {
                $id = $result->id;
                $cca = $result->parent_cca;
                $id_a = $result->id_ad;
             
            }
            if($id=="" && $cca =="" && $id_a =="")
            {
                $insert = DB::table('country_redirection')->insert(
                    ['parent_cca' => $parent, 'id_ad' => $id_ad,'country' => $country]
                );
                if($insert)
                {
                   echo 1;
                    exit();
                }
                else 
                {
                    echo 2;
                    exit();
                }                
            }else
            {
                echo 4;
                exit();
            }
        }
        else
        {
            echo 3;
            exit();
            
        }
    }
    public function edit(Request $request,$id)
    {
        
        $condtion = [];
        $opr_condition = [];
        
        if(!empty($id))
        {
            array_push($condtion,["id","=",$id] );
        }
        
        $select_data =  [
            "id",
            "parent_cca",
            "id_ad",
            "country"
          ];
        
        $camp_data =  DB::table("country_redirection")
         ->where($condtion) 
         ->select($select_data)
         ->limit(1)
         ->get();
        
        $select_country =  [
            "iso",
            "name"            
        ];
        
        $country_data =  DB::table("country")
//         ->where($country_condition) 
         ->select($select_country)
         ->get();
        foreach ($country_data as $dropdown) {

            if ($dropdown->iso){
                $countryCodeResult['country_code_data'][$dropdown->iso] = $dropdown->name;
            }
            
          }
        

        $decode_data = json_decode($camp_data, true);
        
        $result  = array(
            'data' => $decode_data[0],
            'id' => $id,
            'parent_cca' => $decode_data[0]['parent_cca'],
            'id_ad' => $decode_data[0]['id_ad'],
            'country_code' => $decode_data[0]['country'],
            'country_data' => $countryCodeResult,
          );
        $viewPage = "country.country_redirection_edit";
         
         $dataN =  view($viewPage)->with($result);
        return $dataN;
    }
    public function edit_details(Request $request)
    {
//        echo "<pre>";
//        print_r($request->all());
//        echo "</pre>";die();
        $id = $request->id;
        $id_ad = $request->id_ad;
        $parent = $request->parent;
        $country = $request->country;

        
        if($id!='' && $country != '' && $id_ad != '' && $parent != '')
        {
            
            $update = DB::table('country_redirection')
            ->where('id', $id)
            ->limit(1)  // optional - to ensure only one record is updated.
            ->update(array('parent_cca' => $parent,'id_ad' => $id_ad,'country' => $country)); 
            if($update)
            {
               echo 1;
                exit();
            }
            else 
            {
                echo 2;
                exit();
            }
        }
        else
        {
            echo 3;
                exit();
            
        }
        
    }

}
