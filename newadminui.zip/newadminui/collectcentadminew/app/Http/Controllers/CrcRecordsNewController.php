<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use DB;
use App\Crc;
use Response;
use Simplehelper;


class CrcRecordsNewController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    
    public function __construct()
    {
        $this->middleware('auth');
    }
    
    public function index(Request $request){
        $items= array();
	    return view('CrcRecordNew.index',compact('items'));
	  }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function getdata(Request $request){
       $type = $request->input('type');
       $dateRange = $request->input('daterange');
       $condition= $this->getdateRangeCondtion($dateRange);
       $total_sale = "sum(IF(traffic_type = 'WG' OR traffic_type = 'WM',crc.cost_dollar, crc.total_cost))";
       $fields = [
                      "crc.id", 
                      "op.country_code",
                      "crc.op_name", 
                      "crc.`op_id`",
                      "crc.network_name", 
                      "sum(crc.clickcount ) AS clickcount", 
                      "sum( crc.conversion_count ) AS conversion_count", 
                      "sum( crc.conversion_count_unique ) AS conversion_count_unique", 
                      "sum( crc.clicks_active_count ) AS clicks_active_count", 
                      "sum(crc.`revenue_dollar` ) AS revenue_dollar", 
                      // "sum( crc.`total_cost` ) AS cost_dollar", 
                      "$total_sale  as cost_dollar",
                      "(sum(crc.`revenue_dollar`) - $total_sale) AS profit",
                      "crc.`create_time`",
                      "crc.traffic_type",
                    ];
        $fields = implode(",",$fields); 
       if($type == 'country'){
        $items = DB::select("SELECT $fields 
            FROM crc_records_new AS crc
            INNER JOIN operator as op ON crc.op_id = op.id
            WHERE $condition 
            GROUP BY op.country_code");
        }else{
       $items = DB::select("SELECT $fields
            FROM crc_records_new AS crc 
            INNER JOIN operator as op ON crc.op_id = op.id
            WHERE $condition
            GROUP BY crc.op_id");
        }
        $lastUpdated = Simplehelper::lastUpdated();  
        return view('CrcRecordNew.getdata',compact('items','type','dateRange','lastUpdated'))->with('i', ($request->input('page', 1) - 1) * 5);
      }


    /* main Function used to fetch data for all condition except first one*/
    public function getCountry(Request $request)
    {

        $advertiser = $publisher = $operator = '';
        $country = $request->input('country');
        $country_exist = $request->exists('country');
        $op_name = $request->input('op_name');
        $op_id_exist = $request->exists('op_id');
        $op_id = $request->input('op_id');
        $pub_id = $request->input('pub_id');
        $pub_flag = 0;
        $dateRange = $request->input('daterange');
        $condition= $this->getdateRangeCondtion($dateRange);
        if($request->exists('pub_id')){
            $pub_flag = 1;
        }
                          
        if(($country || $country_exist) && !$request->input('op_name')){
          $total_sale = "sum(IF(traffic_type = 'WG' OR traffic_type = 'WM',crc.cost_dollar, crc.total_cost))";
          $fields = [
                  "op.`country_code`",
                  "crc.`id`, op.`name` as op_name", 
                  "crc.`op_id`,crc.`network_name`",
                  "sum(crc.`clickcount`) as clickcount" , 
                  "sum(crc.`conversion_count`) as conversion_count", 
                  "sum( crc.`conversion_count_unique`) as conversion_count_unique", 
                  "sum(crc.`clicks_active_count`) AS clicks_active_count", 
                  "sum(crc.`revenue_dollar`) AS revenue_dollar", 
                  "$total_sale as cost_dollar",
                  "(sum(crc.`revenue_dollar`) - $total_sale) AS profit"
                  ]; 
          $fields  = implode(",",$fields);
          $items =  DB::select("SELECT $fields 
            FROM crc_records_new AS crc INNER JOIN operator as op ON crc.op_id = op.id
            WHERE  op.`country_code` = '".$country."' and $condition
            GROUP BY crc.op_id");
            return view('CrcRecordNew.operatorAjax',compact('items','country'))->with('i', ($request->input('page', 1) - 1) * 5);
        }else if(($op_id || $op_id_exist) && $pub_flag == 0){
                $total_sale = "sum(IF(traffic_type = 'WG' OR traffic_type = 'WM',crc.cost_dollar, crc.total_cost))";
                $fields = [
                            "crc.`id_channel`", 
                            "crc.`id`", 
                            "crc.`op_name`", 
                            "crc.`op_id`", 
                            "crc.`network_name`", 
                            "sum( crc.`clickcount` ) AS clickcount", 
                            "sum( crc.`conversion_count` ) AS conversion_count", 
                            "sum( crc.`conversion_count_unique` ) AS conversion_count_unique", 
                            "sum( crc.`clicks_active_count` ) AS clicks_active_count", 
                            "sum( crc.`revenue_dollar` ) AS revenue_dollar", 
                            "$total_sale as cost_dollar", 
                            "(sum(crc.`revenue_dollar` ) - $total_sale) AS profit"
                          ];
            $fields = implode(",", $fields);         
            $items =  DB::select("SELECT $fields
                FROM crc_records_new AS crc WHERE crc.op_id = $op_id and $condition
                GROUP BY crc.id_channel");
                $publishers = $this->getPublishers($items);
                $operator = $this->getOperatorName($request->input('op_id'));
              return view('CrcRecordNew.publisherAjax',compact('items','operator','publishers'))->with('i', ($request->input('page', 1) - 1) * 5);  
        }else if(($op_id || $op_id_exist) && $request->input('pub_id') || $pub_flag == 1){
                $total_sale = "sum(IF(traffic_type = 'WG' OR traffic_type = 'WM',crc.cost_dollar, crc.total_cost))";
                $fields = [
                           "adv.`name` as advertiser", 
                           "crc.`id_channel`" , 
                           "crc.`id`", 
                           "crc.`op_name`", 
                           "crc.`op_id`", 
                           "crc.`network_name`", 
                           "adv.`id_advertiser`", 
                           "sum( crc.`clickcount` ) AS clickcount", 
                           "sum( crc.`conversion_count` ) AS conversion_count", 
                           "sum( crc.`conversion_count_unique` ) AS conversion_count_unique", 
                           "sum( crc.`clicks_active_count` ) AS clicks_active_count", 
                           "sum( crc.`revenue_dollar` ) AS revenue_dollar", 
                           "$total_sale as cost_dollar", 
                           "(sum( crc.`revenue_dollar` ) - $total_sale) AS profit"
                          ]; 

                $fields = implode(",", $fields);
                $items =  DB::select("SELECT $fields
                FROM crc_records_new AS crc
                INNER JOIN advertiser_campaigns as adv ON crc.id_advertiser_campaign = adv.id
                WHERE crc.op_id = $op_id AND crc.id_channel = $pub_id and $condition
                GROUP BY adv.id_advertiser");
                $advertisers = $this->getAdvertisers($items);
                $publisher = $this->getPublisher($request->input('pub_id'));
                return view('CrcRecordNew.advertiserAjax',compact('items','publisher','advertisers'))->with('i', ($request->input('page', 1) - 1) * 5); 
            }
            $items = Response::json(array('status'=>'OK','records'=>$items,
              'country'=>$country,'publisher'=> $publisher ,'advertiser'=>$advertiser,'operator'=>$operator));
        return $items;
    }

    /* return the advertisers on the of passed array*/
    public function getAdvertisers($items){
         $advertisers = [];
         foreach($items as $key=>$item){
         if($item->id_advertiser > 0) {    
            $advertiser = DB::table('advertiser')->select('name')->where('id', $item->id_advertiser)->get();
              if($advertiser){
                $advertisers[$key] = $advertiser[0]->name;
              }else{
                $advertisers[$key] = 'No advertisers';
              }
            }
          }
          return $advertisers;  
      }
    

    /* function to get campaigns on the based of operator id , publisher id and advertiser id (Final step)*/
    public function getCampaigns(Request $request)
    {
        $advertiser = $publisher = $operator = '';
        $op_id = $request->input('op_id');
        $op_id_exist = $request->exists('op_id');
        $pub_id = $request->input('pub_id');
        $adv_id = $request->input('adv_id');
        $dateRange = $request->input('daterange');
        $condition= $this->getdateRangeCondtion($dateRange);
        if(($op_id || $op_id_exist) && $request->exists('pub_id') && $request->exists('adv_id' )){
             $total_sale = "sum(IF(traffic_type = 'WG' OR traffic_type = 'WM',crc.cost_dollar, crc.total_cost))";
            $fields = [
                       "crc.`id`", 
                       "crc.`op_id`", 
                       "crc.`id_channel`",
                       "crc.`id_advertiser`",
                       "crc.`network_name`",
                       "crc.`id_advertiser_campaign`", 
                       "sum(crc.`clickcount`) AS clickcount", 
                       "sum(crc.`conversion_count`) AS conversion_count", 
                       "sum( crc.`conversion_count_unique` ) AS conversion_count_unique", 
                       "sum( crc.`clicks_active_count` ) AS clicks_active_count", 
                       "sum( crc.`revenue_dollar` ) AS revenue_dollar", 
                       "$total_sale as cost_dollar", 
                       "(sum( crc.`revenue_dollar` ) - $total_sale) AS profit", 
                       "crc.`create_time`"
                      ];
                  $fields  = implode(",", $fields);      
              $items =  DB::select("SELECT $fields  from crc_records_new as crc INNER JOIN advertiser_campaigns as adc ON adc.id = crc.id_advertiser_campaign where crc.op_id = $op_id and crc.id_channel = $pub_id and adc.id_advertiser = $adv_id and $condition group by crc.id_advertiser_campaign");
              $campaigns = $this->Campaigns($items);
              $advertiser = $this->getAdvertiser($op_id);
            return view('CrcRecordNew.campaigns',compact('items','advertiser','campaigns'))->with('i', ($request->input('page', 1) - 1) * 5);
        }
        return redirect("/crc");

    }


    /* to get the Advertiser
      *  parameter : object  
    */
   public function getOperatorName($item){
            $operator = ''; 
            if($item > 0) {    
            $operator = DB::table('operator')->select('name')->where('id', $item)->get();
            }
            $operator = isset($operator[0]->name)?$operator[0]->name:"no operator";
            return $operator;
        }

    /* to get the publisher
      *  parameter : object  
    */
    public function getPublisher($item){
        $publisher = ''; 
        if($item) {    
            $publishers = DB::table('publisher_profile')->select('name')->where('ccz', $item)->get();
            $publisher = isset($publishers[0]->name)?$publishers[0]->name:"no publisher";
        }
        return $publisher;
    }


    public function getPublishers($items){
        $publisher = ''; 
        foreach($items as $item){
             if($item->id_channel > 0) {    
            $publishers = DB::table('publisher_profile')->select('name')->where('ccz', $item->id_channel)->get();
            }
            $publisher[] = isset($publishers[0]->name)?$publishers[0]->name:"no publisher";
        }
        return $publisher;
    }

      public function Campaigns($items){
        $campaign = ''; 
        foreach($items as $item){
             if($item->id_advertiser_campaign > 0) {    
            $campaigns = DB::table('advertiser_campaigns')->select('name')->where('id', $item->id_advertiser_campaign)->get();
              $campaign[] = isset($campaigns[0]->name)?$campaigns[0]->name:"no campaign";
            }
        }
        return $campaign;
    }

    /* to get the advertiser
      *  parameter : object  
    */
    public function getAdvertiser($item){
        $advertiser = ''; 
        if($item) {    
            $advertiser = DB::table('advertiser')->select('name')->where('id', $item)->get();
            $advertiser = isset($publishers[0]->name)?$publishers[0]->name:"no advertiser";
        }
        return $advertiser;
    }

    public function getdateRangeCondtion($dateRange){
         if(!empty($dateRange)){
           $dateRange = explode(" ",$dateRange);
           $start_date =  "'".$dateRange[0]." 00:00:00'";
            $end_date =  "'".$dateRange[2]." 23:59:59'";
             $condition =  "(crc.create_time BETWEEN $start_date and $end_date)"; 
          }else{
          $condition = '1=1';
        }
        return $condition;

    }

    /* To check when crc_records_new was last updated 
     * Developer: Sumit  
     * Date : 19 July 2017 #12.00PM
     */
    function lastUpdated1(){
     $lastUpdated = DB::select("SELECT max(create_time) as create_time from crc_records_new limit 1");
	 $lastUpdated_count = count($lastUpdated);
	 if($lastUpdated_count > 0)
	    if($lastUpdated[0]->create_time){
		  return $lastUpdated[0]->create_time;	
		}
      return "No Update time";  
   }

    
    

    
}
