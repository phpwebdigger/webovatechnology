<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SpecialDeliveryController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        
        
        $select =  [
            "id",
            "ccz",
            "cca",
            "post_back_url",
            "active_status",
            "status"
          ];

         $data =  DB::table("double_delivery_url")
         ->select($select)

         ->get();
         $data1= [];
         $isLive_st = "";
         
         
         
         foreach ($data as $result) {

                if($result->active_status==1)
                {
                    $isLive_st = 'Live'; 
                    $isLive_st_temp = '<span id="is_live_'.$result->id.'">'.$isLive_st.'</span> | <a  href="javascript:void(0);" onclick="EditActiveStatus('.$result->id.','.$result->status.')" <i id="is_live_temp_'.$result->id.'" class="fa fa-square" style="color:#32CEA7"></i> </a>';
                    
                }else
                {
                    $isLive_st = 'NotLive';
                    $isLive_st_temp = '<span id="is_live_'.$result->id.'">'.$isLive_st.'</span> | <a  href="javascript:void(0);" onclick="EditActiveStatus('.$result->id.','.$result->status.')" <i id="is_live_temp_'.$result->id.'" class="fa fa-square" style="color:#F05355"></i> </a>';
                }
             $array = [];
             array_push($array,

                            $result->ccz,
                            $result->cca,
                            $result->post_back_url,
                            $isLive_st_temp,
                            '<a  href="javascript:void(0);" onclick="EditUrl('.$result->ccz.','.$result->cca.')" <i class="fa fa-edit"></i> </a>'
                           );
                array_push($data1, $array);
         }
         
         
        return view('special-delivery.special-delivery-view',compact('data1'));
    }

    
    
    public function add(Request $request)
    {

        $viewPage = "special-delivery.special-delivery-add";
        
        $dataN =  view($viewPage);
        return $dataN;
    }
    public function add_details(Request $request)
    {

//        echo "<pre>";
//        print_r($request->all());
//        echo "</pre>";die();
        
        $post_back_url = $request->post_back_url;
        $parent = $request->parent;
        $id_zone = $request->id_zone;
                
        if($post_back_url !='' && $parent != '' && $id_zone != '')
        {
            $select =  [
                "id",
                "cca",
                "ccz"
            ];
            $condtion = [];
            array_push($condtion,["cca","=",$parent] );
            array_push($condtion,["ccz","=",$id_zone] );
            
            $data =  DB::table("double_delivery_url")
            ->select($select)
            ->where($condtion)
            ->limit(1)
            ->get();
        
//            echo "<pre>";
//            print_r($data);
//            echo "</pre>";die();

            
//            echo "Count = ".count($data);die();
            
//            
//            $id = $data[0]->id;
//            $cca = $data[0]->cca;
//            $zone = $data[0]->ccz;

            if(count($data) == 0)
            {
                $insert = DB::table('double_delivery_url')->insert(
                    ['cca' => $parent, 'ccz' => $id_zone,'post_back_url' => $post_back_url]
                );
                if($insert)
                {
                    $status = ['status'=>'1','message'=>'Successfully Inserted'];
                    echo json_encode($status);
//                    echo $status;
                    exit;
                }
                else 
                {
                    $status = ['status'=>'2','message'=>'Problem while inserting...'];
                    echo json_encode($status);
//                    echo  $status;
                    exit;
                }   
                
            }
            else
            {
                $status = ['status'=>'4','message'=>'CCA & ZONE Already Exists'];
                echo json_encode($status);
                exit;
                
                
            }
        }
        else
        {
            $status = ['status'=>'3','message'=>'Something went wrong.....'];
                echo json_encode($status);
                exit;  
             
            
        }
    }
    
    public function update_url(Request $request)
    {
//        echo "<pre>";
//        print_r($request->all());
//        echo "</pre>";
//        die();
        
        $cca =  $request->cca;
        $ccz =  $request->ccz;
        $url =  $request->url;
        
        $update = DB::table('double_delivery_url')
                      ->where('cca', $cca)
                      ->where('ccz', $ccz)
                      ->limit(1)  // optional - to ensure only one record is updated.
                      ->update(array('post_back_url' => $url));
        if($update)
        { 
            $status = ['status'=>'1','message'=>'Successfully Url Updated'];
            echo json_encode($status);
            exit;
        }
        else
        {
            $status = ['status'=>'2','message'=>'Problem in diversion update'];
            echo json_encode($status);
            exit;
        }
    }

}
