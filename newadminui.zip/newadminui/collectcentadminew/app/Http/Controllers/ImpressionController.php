<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Response;
use Cache;
use Session;
class ImpressionController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }


    public function index(Request $request, $routename="impression_countreportpost", $header_name="Impression Count Management"){


	  		$condtion = [];
            $ddCondition = [];
             $dtvalue = $request->start;
            $dtvalue2 = $request->end;
            	if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            	}else{
           		 $dtvalue = str_replace('-', '', $request->start); 		
            	}
            if(is_null($dtvalue2)){
                    $dtvalue2 = date('Y-m-d');
                    $enddate = date('Y-m-d',strtotime("+1 days"));
            }else{
                //$dtvalue2 = date('Y-m-d',strtotime("+1 days"));
               // $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));
            	$dtvalue2 = str_replace('-', '', $request->end);

            }
           
                $groupCondition = [];
            
              if($request->group_by && $request->group_by != '')
        {
            $group_by_arr = $request->group_by;
            if(count($request->group_by) > 1 )
            {
                
                $groupCondition = $request->group_by;
            }
            else
            {
                array_push($groupCondition,$request->group_by);
                array_push($groupCondition,'impression_count.date');   
            }              
        }
        else
        {
            array_push($groupCondition,'impression_count.campaign_id');
            array_push($groupCondition,'impression_count.date');
        }

            array_push($condtion,['impression_count.date','>=',$dtvalue] );
            array_push($condtion,['impression_count.date','<=',$dtvalue2] );
            
           
          $request->total = $request->total ? $request->total : 50;
            
            $select = "advertiser_campaigns.id,"
                      ."advertiser_campaigns.id_advertiser,"
                      ."advertiser_campaigns.name,"
                      ."advertiser_campaigns.url,"
                      ."advertiser_campaigns.payout_type,"
                      ."advertiser_campaigns.type,"
                      ."advertiser_campaigns.id_op,"
                      
                      ."advertiser_campaigns.cpa as ac_cpa,"
                      ."impression_count.network_id	,"
                      ."impression_count.campaign_id,"
                      ."impression_count.date as dates	,"
                      ."impression_count.campaign_id as smart_rotator_id,"
                      ."count(impression_count.campaign_id) AS clickcount,"
                      ."ad_network.name as network_name,"
                    
                      ."advertiser.id as advtr_id,"
                      ."advertiser.name  as advertiser_campain_name";
                       
        $appends = [];
	   
		 $data =  DB::table("impression_count as impression_count")
                     ->selectRaw(DB::raw($select))
                     ->where($condtion)
                     ->leftJoin("advertiser_campaigns","advertiser_campaigns.id","=","impression_count.campaign_id")
                     ->leftJoin("ad_network","ad_network.ccz","=","impression_count.network_id")
                     ->leftJoin("advertiser","advertiser.id","=","advertiser_campaigns.id_advertiser")
                     ->groupby($groupCondition)
            
                     ->orderby('impression_count.date','DESC')
                     ->get();
           $i=0;
            $data1 = [];
           $total_impression= 0; 
        
            if($data){
foreach ($data as $fetch_records)
{

  $i++;

            $array = [];
            array_push($array,
                $fetch_records->dates,
                $fetch_records->name .'('.$fetch_records->id_advertiser.')',
                $fetch_records->smart_rotator_id,
                $fetch_records->network_name,
                $fetch_records->network_id,
                $fetch_records->id_op,
                $fetch_records->clickcount
                );
            array_push($data1, $array);
              $total_impression = $total_impression + $fetch_records->clickcount;

}
 }else{
	 $data1='No data found';
	 }      
        
        $lastRow = ["Total",
                                             "",
                                             "",
                                             "",
                                             "",
                                             "",
                                            $total_impression,
                    ];

              $ddData = $this->createDDCareer($request,$ddCondition);
       
         $result  = array('data1' => $data1,
            "routename"=>$routename,
            'header'=>$header_name,
            'dtvalue' => $dtvalue,
            'dtvalue2' => $dtvalue2,
            'ddData' => $ddData,
            'id_channel'=>$request->id_channel,
            'operator_id'=>$request->operator_id,
            'traffic_type' => $request->traffic_type,
            'country'=> $request->country,
            'groupby'=>$request->group_by,
            'total'=>$request->total,
            'lastRow'=>$lastRow,
          );
         return view('Impressionmanage.impressionmanagementreport')->with($result);


    }
    private function createDDCareer(Request $request,$condition){
		   
		   }


}
?>