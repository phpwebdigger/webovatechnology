<?php

namespace App\Http\Controllers;
use App\User;
use App\Role;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Cookie;


class MacController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */


    
    public function get_key()
    {
        $year = date("Y");
        $mon =  date("m");
        $date = date("d");
        $hour = date("H");
        $key = $date.$hour.$mon.$hour."_my_".$year."_mac_".$mon."_address_".$date.$hour.$year.$mon;

        return view('mac.getkey');

    }
    
    public function post_mac(Request $request)
    {
        $cookie_life = time() + 31536000;
        $first_name = $request->first_name;
        $last_name = $request->last_name;
        $mobile = $request->mobile_no;
        $cookie_val = $first_name.$mobile.$last_name;
        $cookie_name = "LARAVELMAC";
        Cookie::queue(Cookie::make($cookie_name, $cookie_val, $cookie_life));
        return view('mac.getkey')->with('successMsg','Successfully Added .');

    }

  
}
