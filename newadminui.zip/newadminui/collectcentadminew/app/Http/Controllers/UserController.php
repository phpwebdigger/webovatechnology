<?php

namespace App\Http\Controllers;
use App\User;
use App\Role;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;

class UserController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */


    public function index(Request $request)
       {
           $keyword = $request->get('search');
           $perPage = 20;

           if (!empty($keyword)) {
               $user = User::where('name', 'LIKE', "%$keyword%")
                ->orWhere('email', 'LIKE', "%$keyword%")
                ->paginate($perPage);
           } else {

            
              $users = User::with('roles')->paginate($perPage);
              //dd($users);
           }
      
           return view('users.userlist', compact('users'));
    }
    public function index_role(Request $request){
           $keyword = $request->get('search');
           $perPage = 20;
            if (!empty($keyword)) {
               $roles = User::where('name', 'LIKE', "%$keyword%")
                ->orWhere('email', 'LIKE', "%$keyword%")
                ->paginate($perPage);
           } else {
              $roles = Role::paginate($perPage);
           }
      
           return view('users.rolelist', compact('roles'));
    }

    public function roleget($id=""){
      
      if($id != ""){
        $users = Role::find($id);
      }else{
          $users = new \stdClass();
          $users->id="";
          $users->name="";
          $users->description="";
      }
     
      return view('users.role-register',compact('users'));
    }
    public function rolepost(Request $req){
               
         if($req->id){
           $role = Role::find($req->id);
         }else{
           $role = new Role;
         }
        
         $role->name = $req->name;
         $role->description = "";
         
         $role->permission = implode($req->permissions, ",");
         $role->save();
         if($req->id == Auth::id()){
          $req->session()->put('roles', $role);
         }
         
         return redirect('/users/roles');
      //return view('users.role-register', compact('roles'));
    }

    public function getUserForm()
      {
          
          return view('users.register');
      
      }
    public function addUser(Request $req)
      {
     
          User::create([
              'name' => $req->name,
              'email' => $req->email,
              'password' => bcrypt($req->password),
              'status'=>$req->status,
              'role_id'=>$req->role,
            ]);
          return redirect('users');
      
      }

       //Database edit
      
    public function edit($id)
      {
          $users=User::with("roles")->find($id);
          
          return view('users.edit',compact('users'));
      
      }

      //Database updation

    public function update(Request $request)
      {
       
        $users=User::find($request->id);
        $users->name = $request->name;
        $users->email = $request->email;
        $users->password = bcrypt($request->password);
        $users->status = $request->status;
        $users->role_id = $request->role;
        
        $users->save();

        return redirect('users');
      }

      // Database Delete

    public function destroy($id)
     {
            
             // delete
             $user = User::find($id);
             $user->delete();

             // redirect
             return redirect('users');
     }
     public function roledelete($id)
     {
            $role = Role::find($id);
            $role -> delete();
            return redirect('users/roles');
     }
     public function profile()
      { 
          return view('profile');
      }
      
    public function ccalist() 
    {

      return view('cca.list');
      
    }
   
   public function UpdateCampaigns()

   {
      return view('cca.UpdateCampaigns');

   }

   public function ConversionStatusReport()

   {

    return view('cca.ConversionStatusReport');

   }
  
}
