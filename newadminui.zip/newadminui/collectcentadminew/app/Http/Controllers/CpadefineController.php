<?php


namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\AdNetwork;
use App\Users;
use Illuminate\Support\Facades\Redis;
use Cache;
use App\Ad;
use App\ads;


class CpadefineController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }



public function  index(Request $request){

	$list_add = $offer_list =  $id_channel='';

   $netData1 =  DB::table("ad_network")->selectRaw(DB::raw("distinct ccz,name"))->where("name", "NOT LIKE",'%...%')->where("name","NOT LIKE", '%abc%')->where('ccz',"!=",'0')->orderby("name","ASC")->get();

        $netData=array();
        foreach($netData1 as $fetch_dt)
        { 
            $netData[$fetch_dt->ccz] = $fetch_dt->name;
        }

return view('CpaDefine.index', ['request'=>$request,'netData'=>$netData,'id_channel'=>$id_channel,'publisher'=>$list_add,'offerlist'=>$offer_list]);


}


public function getnetwrok_name($id){


   $netData1 =  DB::table("ad_network")->selectRaw(DB::raw("distinct ccz,name"))->where('ccz',$id)->where("name", "NOT LIKE",'%...%')->where("name","NOT LIKE", '%abc%')->where('ccz',"!=",'0')->orderby("name","ASC")->get();
   		$netDatas=[];
        foreach($netData1 as $fetch_dt)
        { 
            $netDatas[$fetch_dt->ccz] = $fetch_dt->name;
        }

        return $netDatas;

}

	public function getnetwrok_details(Request $request){
		$this->campaing_url_list($request);
	}




	function display_geo(Request $request){

 $countries = \App\Country::all();
 
 $dts='';
 if($countries!=null)
    {
        foreach($countries as $key => $val){
                    $dts .='<option value="'.$val->iso.'#id_zone='.$val->id_zone.'" id="'.$val->country_code.'"  '
                            . 'title="' . $val->iso. '">' . $val->nicename .'('.$val->iso.')</option>';
                  
                    }
                    echo $dts;  
        
    }else{
        echo "No match Found";
    }
    
        }


        function display_operator(Request $request){
    $country_code=rtrim($request->country_name,',');
    $arr = explode(',', $country_code);
    $newArray = array();
    foreach($arr as $val) {
    $temp = explode('#id_zone=', $val);
    $newTemp['country_code'] = $temp[0];
    //$newTemp['id_zone'] = $temp[1];
    $newArray[] = $newTemp;
    $temp = array();
    }
    $country_code = $network_id  = array();
    foreach($newArray as $val){
    $country_code[]= $val['country_code'];
    }
    $da= "'". implode("','", $country_code)."'";
    $dts='';
    $OperatorName = new \App\Operators();
    $OperatorName = $OperatorName->whereIn('country_code',$country_code)->orderBy('country_code','asc')->get();
                    $dts .='<option value="'.'-2'.'##op_name='.'Both'.'" id="'.'-2'.'"  title="' . 'Both'. '">' . 'Both' .'('.'-2'.') ('.'WW'.')</option>';
                    $dts .='<option value="'.'-1'.'##op_name='.'WifiDefault'.'" id="'.'-1'.'"  title="' . 'WifiDefault'. '">' . 'WifiDefault' .'('.'-1'.') ('.'WW'.')</option>';
                    $dts .='<option value="'.'0'.'##op_name='.'AllOperator'.'" id="'.'0'.'"  title="' . 'AllOperator'. '">' . 'AllOperator' .'('.'0'.') ('.'WW'.')</option>';
 $dts .='<option value="'.'1005'.'##op_name='.'SuperSmartlink'.'" id="'.'1005'.'"  title="'.'SuperSmartlink'.'">'.'Super Smartlink' .'('.'1005'.') ('.'WW'.')</option>';
                    if($OperatorName!=""){ foreach($OperatorName as $key => $val){
                    $dts .='<option value="'.$val->id.'##op_name='.$val->name.'" id="'.$val->id.'"  title="' . $val->name. '">' . $val->name .'('.$val->id.') ('.$val->country_code.')</option>';
                    }
                     echo $dts; 
    }else{
                  echo "No match found";
    }
    
    
}

public function getcpadefinecampain(Request $request){

	$action_select=$request->action_select;
	$country_code=$request->country;
	if($action_select=='Operator'){
		  $OperatorName = new \App\Operators();
	      $OperatorName = $OperatorName->whereIN('country_code',array($country_code))->orderBy('country_code','asc')->get();
	      return json_encode($OperatorName);

	}
	if($action_select=="Campaign_list"){

		$Operator= $request->Operator;
		$country= $request->country;
				$advertiser_campagin_name = new \App\AdvertiserCampaigns();
                     $campgain_ulr = $advertiser_campagin_name->selectRaw('id,id_advertiser,name,url,id_op')
                    ->whereIN('id_op',array($Operator)) 
                    ->WhereIN('country_code',array($country))
                    ->where('type','=','CPA')
                    ->orderBy('name','asc')->get();
 			return json_encode($campgain_ulr);
	}


}


 function campaing_url_list(Request $request){
          $countries = new \App\Country();
          $countries = $countries->selectRaw("distinct nicename as country_name,iso as country_iso")->orderBy('id','asc')->get();
           $str="";
           $str= '
            <div class="row table-responsive"><table class="table table-condensed"><thead style="background: aliceblue;">
            <tr>
            <th>Geo</th>
            <th class="op_id_list" style="display:none">Operator</th>
            <th class="cmp_id_list" style="display:none">Campaign Name</th>
            <th>Action</th>
            </tr>
            </thead>
            <tbody>';
           $fdg=1;
           $str .= '<td><select class="selectpicker" id="country" data-container="body"  data-dropup-auto="false" name="country"  data-live-search="true" data-actions-box="true" data-selected-text-format="count > 3" data-size="5" placeholder="Select Country" >';
           			$str .='<option value="" selected disabled>Please Country</option>'; 
                    foreach($countries as $key => $val){
                    $str .='<option value="'.$val->country_iso.'" id="country_'.$val->country_iso.'" data_country_id="'.$val->country_iso.'">' . $val->country_name .'('.$val->country_iso.')</option>';
                      } 
            $str .= '</select></td>';

           $str .= '<td class="op_id_list" style="display:none"><select class="selectpicker"  data-dropup-auto="false" data-width="fit" data-container="body"  id="Operator" name="operator"  data-live-search="true" data-actions-box="true" data-selected-text-format="count > 3" data-size="5" title="Select Operator">';
           
            $str .= '</select></td>';

            $str .= '<td class="cmp_id_list" style="display:none"><div class="col-sm-2"><select class="selectpicker" data-dropdown-align-right="true"  data-dropup-auto="false" data-container="body" id="Campaign"  name="Campaign" multiple  data-actions-box="true"   data-live-search="true" data-selected-text-format="count > 2" data-size="3" title="Select Campaign">';
            
 			$str .='</select></div></td>';
	         
          $str .='<td class="buttonlist" style="display:none"><button type="submit"  name="submit_button" id="submit_button" class="btn btn-primary">GO</button></td></tr>';
          $fdg++;
     
    $str .='</tbody></table></div>' ;
    echo $str;
     
}

public function getnetwrok_details_config(Request $request){


	$Campaign_id_comms=rtrim($request->Campaign_id,',');

	$Campaign_id_comm=ltrim($Campaign_id_comms,',');

	$Campaign_id = explode(",",$Campaign_id_comm);


	$country_name = $request->Country;


	$Operator = $request->Operator;

	$network_id =$request->Network_id;

	$srsst= $this->getnetwrok_name($network_id);
	
	$str="";
           $str= '
            <div class="row"><table class="table table-condensed"><thead style="background: beige;">
            <tr>
            <th>Network Name</th>
            <th>Geo</th>
            <th>Operator</th>
            <th>Campaign</th>
            <th>Enter CPA</th>
            <th>Action</th>
            </tr>
            </thead>
            <tbody><tr>';
           $fdg=1;

           $advertiser_campagin_name = new \App\AdvertiserCampaigns();

                     $campgain_ulr = $advertiser_campagin_name->selectRaw('id,id_advertiser,name,url,id_op')
                     ->whereIN('id',$Campaign_id)
                     ->get();


			foreach($campgain_ulr as $key => $val_valu){


			
				$str .="<input type='hidden' name='network_id_cpa' id='networkidcpa__".$val_valu->id."' value=".$network_id.">";
				$str .="<input type='hidden' name='network_id_name' id='networknamecpa__".$val_valu->id."' value=".$srsst[trim($network_id)].">";

           $str .="<td>".$srsst[trim($network_id)].' ('.$network_id.')'."</td>";
          $countries = new \App\Country();
          $countries = $countries->selectRaw("distinct nicename as country_name,iso as country_iso")->where('iso',$country_name)->orderBy('id','asc')->get();
            foreach($countries as $key => $val){
            	$str .="<input type='hidden' name='country_id_cpa[]' id='countryidcpa_".$val_valu->id."' value=".$val->country_iso.">";
          	$str .='<td data-value="'.$val->country_iso.'" id="country_'.$val->country_iso.'" data_country_id="'.$val->country_iso.'">' . $val->country_name .'('.$val->country_iso.')</td>';
            } 
             

     $OperatorNames = new \App\Operators();
     $OperatorName = $OperatorNames->selectRaw("operator.name as name,operator.id as id,operator.country_code as country_code")->where("id",$Operator)->orderBy('name','asc')->get();
   	        foreach($OperatorName as $key => $val){
   	        		$str .="<input type='hidden' name='operator_id_cpa[]' id='operatoridcpa_".$val_valu->id."' value=".$val->id.">";
   	        		$str .="<input type='hidden' name='operator_id_name[]' id='operatornamecpa_".$val_valu->id."' value=".$val->name.">";
                    $str .='<td data-value="'.$val->id.'" id="cad_'.$val->id.'" data_opertor_id="'.$val->id.'">' . $val->name .'('.$val->id.')</td>';
            } 
             $str .="<input type='hidden' name='selected_campaign_id_cpa[]' id='selectedcampaignidcpa_".$val_valu->id."' value=".$val_valu->id.">";
             $str .="<input type='hidden' name='selectedcampaignurl[]' id='selectedcampaignurl_".$val_valu->id."' value=".$val_valu->url.">";
             $str .="<input type='hidden' name='selectedcampaignamel[]' id='selectedcampaigname_".$val_valu->id."' value=\"".addslashes(htmlspecialchars($val_valu->name,ENT_QUOTES))."\">";
            $str .='<td data-value="'.$val_valu->id.'" id="advert_id_'.$val_valu->id_advertiser.'" data_advertiser_id="'.$val_valu->id_advertiser.'">'.$val_valu->name.'('.$val_valu->id.')</td>';
            
         	//id = network_id_advertisercampaign_id_,
         	$str .='<td><input type="text" required name="CPA[]" id="CPA_'.$val_valu->id.'" value="" data-cpa="'.$network_id.'_'.$val_valu->id.'"  placeholder="Enter CPA" /></td>';
       
         
          $str .='</td><td><button type="button"  name="submit_cpa_config" class="submit_cpa_config" id="submitcpaconfig_'.$network_id.'_'.$val_valu->id.'" class="btn btn-primary">Submit</button></td></tr>';
          }
          $fdg++;
     
    		$str .='</tbody></table></div>' ;
    		echo $str;
	}


public function getadvertiser_campaign_url($id_advertiser){
	  $advertiser_campagin_name = new \App\AdvertiserCampaigns();
                     $campgain_ulr = $advertiser_campagin_name->selectRaw('id,id_advertiser,name,url,id_op')
                     ->whereIN('id',$id_advertiser)
                    ->where('status','1')
                    ->orderBy('name','asc')->get();
}



public function savecpadetailsconfig(Request $request){

	$id_advertiser= $request->Campaign_id;
	$id_zone=$request->id_zone;
	$country=$request->Country;
	$Operator=$request->Operator;
	$CPA_value=$request->CPA_value;
	$URL= $request->URL;
	$title = $request->advt_name;
	$operator_name= $request->operator_name_cpa;
	$network_name =$request->netwrok_name;
	$message="";
	$tru=0;
	$advt_cmas=[];
	$advt_cma=[];
		$list_add = [
                    'campaignid'=>'20',
                    'id_group'=>'0',
                    'id_ad_type'=> '0',
                    'status'=> 'active',
                    'title'=> $title,
                    'click_url'=>htmlentities($URL),
                    'operator_name'=>$operator_name,
                    'cco'=>$Operator,
                    'type'=> 'CPA',
                    'network_cpa'=>$CPA_value,
                    'network_name'=> $network_name,
                    'id_zone'=>$id_zone,
                    'id_advertiser'=> $id_advertiser,
                    'country_code'=>$country,
                    'cpa_api'=>'1'
                     ];	

                     	try{
                             $ddaf=DB::table('ads')->insert($list_add);
                     		$message="Insert Ok";
                     		$tru=1;
                     		$id_zone_hit=$id_zone;
                     		$advt_cma=$id_advertiser;
                     	}catch (\Exception $e) {

					    $e->getMessage();
					    $message="Some Problem in Insert data";
					    $id_zone_hit=$id_zone;
					    $tru=0;
						}
                      	
                      	$array_result = array('message' =>$message,'status'=>$tru,'id_zone'=>$id_zone_hit,'id_avt'=>$advt_cma);

					return json_encode($array_result);

		}


		public function getcpapreviewconfig(Request $request){

		   $keyword = $request->id_zone;
		   $campgain_id=$request->campaign_id;

           $metaData = Ad::select('id_ad','campaignid','id_group','id_ad_type','status','bid','title','description','description2','display_url','click_url','impression_start','creation_date','protocol','operator_name','cco','type','network_cpa','network_name','id_zone','cr_goal','id_advertiser','network_margin','redirect_operator_config','traffic_type','is_live','is_cpi','target_audiance','redirect_isfail','network_postback_source','blocked_ids','blocked_status','parent_id','country_code','outward_status','os_type','incent_type','delivery_status','wifi_status','payout_currency','remarks','vertical','range_start','range_end','range_status','app_server','company_name','url_change','is_smart_cca','pub_offer_name','update_time','cpa_api')->whereIN('id_advertiser',$campgain_id)->where('id_zone',$keyword)->where('cpa_api','1')->get();
				return json_encode($metaData);


		}


}


?>