<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;


    public function getTableDataForSelect(Request $request)
     {
         
           $keyword = $request->keyword;
           $tablename = $request->table;
           $key = $request->key;

           //$fetch = $request->fetch;
           if($keyword){
                $where = [[$key, 'like', ''.$keyword['term'] .'%']];
           }else{
               $where = [];
           }
           
           if($request->condition){
              $conArray = explode(',',$request->condition);
              $newCond = [$conArray[0],$conArray[1],$conArray[2]];
              array_push($where,$newCond);
           }

           // $metaData = DB::table($tablename)
           // ->select([DB::raw($request->text) ." as text", $request->id.' as id'],false)
           // ->where($where)
           //  ->get();
             $metaData = DB::table($tablename)
           ->select([DB::raw($request->text." as text"), DB::raw($request->id." as id")])
           ->where($where)
            ->get();
           $returnRes['results'] = $metaData;
           return $returnRes;
      
     }
}
