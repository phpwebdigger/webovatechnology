<?php

namespace App\Http\Controllers;
use App\User;
use App\Role;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Cookie;
use App\ConfigDeactivation;


class DeactivationController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

    function index(Request $request){
        
//        $view = 'deactivation.index';
//        return view($view);
        return view('deactivation.index',["errors"=>""]);
    }
    function add_data(Request $request){
        $time_stamp = date("Y-m-d H:i:s");
//        echo "<pre>";
//        print_r($request->all());
//        echo "</pre>";die();
        
        $cca = $request->cca;
        $ccz = $request->ccz;
        $url = $request->url;
        
        $dataS  = array(
            'cca'=>$cca,
            'ccz'=>$ccz,
            'deactivation_url'=>$url,
            'updated_at'=>$time_stamp
          ); 
        
        
        if(DB::table('deactivation_config')->insert($dataS))
        {
            $status = ['status'=>'1','message'=>'Successfully inserted '];
            echo json_encode($status);
            exit;
        }
        else
        {
            $status = ['status'=>'0','message'=>'Problem while insetion'];
            echo json_encode($status);
            exit;
        }

    }
    function edit_deactivation(Request $request){
        $time_stamp = date("Y-m-d H:i:s");
        
        $id = $request->id;
        $st = $request->status;
        $url = $request->url;
        
        $update = DB::table('deactivation_config')
            ->where('id', $id)
            ->limit(1)
            ->update(['deactivation_url' => $url,'updated_at'=>$time_stamp,'status'=>$st]);

        if($update)
        {
            $status = ['status'=>'1','message'=>'Successfully updated '];
            echo json_encode($status);
            exit;
        }
        else
        {
            $status = ['status'=>'0','message'=>'Problem while updation'];
            echo json_encode($status);
            exit;
        }

    }
    
    function data(Request $request){
        $select =  [
            "id",
            "cca",
            "ccz",
            "deactivation_url",
            "status"
        ];
        
//        $condtions=[];
        
//        array_push($condtions, ['status','=','1'] );
        
        $data =  DB::table("deactivation_config")
        ->select($select)
//        ->where($condtions)
        ->orderBy('id', 'desc')
//        ->limit(100)
         ->get();
        $data1= [];
        $count = 0;
         
//        dd($data);die();
         
        foreach ($data as $result) {
               $array = [];
                if($result->status == '0')
                {
                    $st = "Inactive";
                }
                else
                {
                    $st = "Active";
                }
               $count++;
               array_push($array,
                           $result->cca,
                           $result->ccz,
                           $result->deactivation_url,
                           $st,
                           '<a href="edit-deativation/'.$result->id.'"<i class="fa fa-edit"></i>'                       
                       );
               array_push($data1, $array);

        }
        $view = 'deactivation.display-data';
        return view($view,compact('data1'));
    }
    
    function edit(Request $request){
        $data1=ConfigDeactivation::find($request->id);
        return view('deactivation.deactivation_edit',compact('data1'));
    }
    
}
