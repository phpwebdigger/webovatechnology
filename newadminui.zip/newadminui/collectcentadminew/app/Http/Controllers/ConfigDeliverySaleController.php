<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\QueryAccess;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Auth;
use App\Ad;
use App\ConfigDeliverySale;
use Illuminate\Support\Facades\Redis;
use Cache;
use App\CronConfig; 

class ConfigDeliverySaleController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $select =  [
            "config_delivery.id",
            "config_delivery.id_zone",
            "config_delivery.id_ad",
            "config_delivery.lower_limit",
            "config_delivery.higher_limit",
            "config_delivery.filter_status",
            "config_delivery.post_back_url",
            "config_delivery.postback_status",
            "config_delivery.is_child",
            "ads.cco",
            "ads.traffic_type", 
            "ads.delivery_status", 
//            "ads.operator_name",
            "ads.network_name"
          ];
        $condtion = [];
        if($request->ntname){
          array_push($condtion,['config_delivery.id_zone','=',$request->ntname] );
        }
        if($request->opname){
          array_push($condtion,['ads.cco','=',$request->opname] );
        }
        if($request->filter_status){
          array_push($condtion,['config_delivery.filter_status','=',$request->filter_status] );
        }
        if($request->postback_status){
          array_push($condtion,['config_delivery.postback_status','=',$request->postback_status] );
        }
          $data =  DB::table("config_delivery_sale as config_delivery")
         ->select($select)
         ->leftJoin("ads","ads.id_ad","=","config_delivery.id_ad")
         ->where($condtion)
         ->get();
         $data1= [];
         $count = 0;
          foreach ($data as $result) {
                $array = [];
                $delvchecked = $checked = $check = $pchecked = "";
                $ptext = $text = "Off";
                $is_child_text = $dlv_ststs = "Inactive";
                if($result->filter_status == 1){
                    $checked = "checked";
                    $text = "On";
                }
                if($result->postback_status == 1){
                    $pchecked = "checked";
                    $ptext = "On";
                }
                if($result->is_child == '1'){
//                  $pchecked = "checked";
                    $is_child_text = "Active";
                }
                if($result->delivery_status == 1){
                    $delvchecked = "checked=checked";
                    $dlv_ststs = "Active";
                }
                $count++;
                array_push($array,
                            $result->id,
                            '<a href="/delivery-sale/edit/'.$result->id.'"><button type="button" class="btn btn-success btn-circle "><i class="fa fa-edit"></i> </button></a>',
                            $result->traffic_type,
                            '<input type ="checkbox" '.$delvchecked.' name="isSmart" id="'.$result->id_ad.'" class="isSmart"><span id="isSmartValue_'.$result->id_ad.'">'.$dlv_ststs.'</span>',
                            $is_child_text,
                            $result->network_name,
                            $result->id_zone,
                            $result->id_ad,
                            $result->lower_limit,
                            $text,
                            $ptext,
                            '<span  class="urltext"  title="'.$result->post_back_url.'" style="max-width: 100px;overflow: none">'.$result->post_back_url.'</span><input type="text" class="hide" value="'.$result->post_back_url.'">');
                array_push($data1, $array);
            }
          return view('deliverysale.delivery_mgmt',compact('data1'));

    }
    
    public function add(Request $request){
        return view('deliverysale.delivery_add',["errors"=>""]);
    }
     
    
    public function store(Request $request){
        $id_zone = $request->ccz;
        $id_ad = $request->cca;
        $lower_limit = $request->lower_limit;
        $filter_status = $request->filter_status;
        $post_back_url = $request->post_back_url;
        $postback_status = $request->postback_status;
        $higher_limit = $request->higher_limit;
        $networkstatus = $request->status;
        // is child 
        $isChild = $request->isChild;
        // child id 
        $childId = $request->childId;
        $postback_status = $postback_status == "on"? 1:0;
        $filter_status = $filter_status == "on"? 1:0 ; 
        $isChild = $isChild == "on" ? '1':'0';
        $checkVal = ""; 
        
        $data = DB::table("config_delivery_sale")
         ->select(["id_ad"])
        ->where([["id_ad","=",$id_ad]])
        ->get();

        if(sizeof($data) != 0){
              $checkVal=$data[0]->id_ad;
        }else{
            $checkVal = "";
        }
        if($childId != ''){
            $Ads = Ad::select(["description","network_postback_source"])
                    ->where([["id_ad","=",$childId]])
                    ->get()->toArray();
            $checkVal2 = $Ads[0]['description'];
            if($checkVal2 == 'default'){
                    $ads->outward_status = '1';
                    $Ads->save();
            }
        }
        $AdsNEW = Ad::select(["network_postback_source"])
                    ->where([["id_ad","=",$id_ad]])
                    ->get()->toArray();
        if($AdsNEW[0]['network_postback_source'] == "" || strpos($post_back_url, $AdsNEW[0]['network_postback_source']) !== false) {
            if($checkVal==''){
                if($isChild =='1' && $childId!= ''){
                    $dataS  = array('id_zone'=>$id_zone,
                            'id_ad'=>$id_ad,
                            'lower_limit'=>$lower_limit,
                            'higher_limit'=>$higher_limit,
                            'filter_status'=>$filter_status,
                            'post_back_url'=>$post_back_url,
                            'postback_status'=>1,
                            'is_child'=>$isChild,
                            'id_child' =>$childId );
                ConfigDeliverySale::create($dataS);
            }else if($isChild=='0'){
                $dataS  = array('id_zone'=>$id_zone,
                        'id_ad'=>$id_ad,
                        'lower_limit'=>$lower_limit,
                        'higher_limit'=>$higher_limit,
                        'filter_status'=>$filter_status,
                        'post_back_url'=>$post_back_url,
                        'postback_status'=>1
                        );

                ConfigDeliverySale::create($dataS);
               
            }else if($isChild=='1' && $childId==''){
                return view('deliverysale.delivery_add',['results'=>[],'errors'=>'Enter id for Child']);
            }
        }else{
                return view('deliverysale.delivery_add',['results'=>[],'errors'=>'There is Already an entry for this CCA']);
            }
        }
        return redirect('/delivery-sale');
    }

    public function edit($id){
      $delivery=ConfigDeliverySale::find($id);
      $select = ["ad_network.name","ad_network.ccz"];
      $data = DB::table('ad_network') 
          ->select($select)
          ->get();
      
      $select1 = ["ads.id_ad","ads.title"];
      $data1 = DB::table('ads') 
          ->select($select1)
          ->where('id_zone', '=',$delivery->id_zone)
          ->get();
        return view('deliverysale.delivery_edit',compact('delivery','data','data1'));
    }

    public function update(Request $req){
        $ccz = $req->ccz;
        $cca = $req->cca;
        $post_back_url = $req->post_back_url;
        $postback_status = $req->postback_status;
        $lower_limit = $req->lower_limit;
        $higher_limit = $req->higher_limit;
        $filter_status = $req->filter_status;
        $AdsNEW = Ad::select(["network_postback_source"])
                    ->where("id_ad","=",$cca)
                    ->get();
        if($AdsNEW !==true){
            if ($AdsNEW[0]['network_postback_source'] == "" || strpos($post_back_url, $AdsNEW[0]['network_postback_source']) !== false){
                $deliv=ConfigDeliverySale::find($req->id);
                $deliv->id_zone = $ccz;
                $deliv->id_ad = $cca;
                $deliv->post_back_url = $post_back_url;
                $deliv->postback_status = $postback_status;
                $deliv->lower_limit = $lower_limit;
                $deliv->higher_limit = $higher_limit;
                $deliv->filter_status = $filter_status;
                $deliv->save();
                return redirect('/delivery-sale');
            }   
            if($deliv !==true){
                echo "<script type='text/javascript'>";
                echo "alert('Records Updation Was Failed')";
                echo "</script>";
            }
          }
        }
    
     


}
