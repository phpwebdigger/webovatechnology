<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Response;
use App\city_mapping;
use App\AdvertiserCampaign;
class CitymappingController extends Controller
{


    //
    public function __construct()
    {
        $this->middleware('auth');
    }



    public function index(Request $request){

    	  $metaData = city_mapping::get();
    	  $data1= [];

    	  	foreach ($metaData as $key => $value) {
             if($value->status==1)
                {
                    $isLive_st = 'Live'; 
                    $isLive_st_temp = '<span id="is_live_'.$value->id.'">'.$isLive_st.'</span> | <a  href="javascript:void(0);" onclick="EditStatus('.$value->id.','.$value->status.')" <i id="is_live_temp_'.$value->id.'" class="fa fa-square" style="color:#32CEA7"></i> </a>';
                    
                }else
                {
                    $isLive_st = 'NotLive';
                    $isLive_st_temp = '<span id="is_live_'.$value->id.'">'.$isLive_st.'</span> | <a  href="javascript:void(0);" onclick="EditStatus('.$value->id.','.$value->status.')" <i id="is_live_temp_'.$value->id.'" class="fa fa-square" style="color:#F05355"></i> </a>';
                }
    	  		$array = [];
    	  		$city_n=json_decode($value->city_name,true);
              $rer=$this->searchcmap($value->campainid);
                $rer1=$this->searchcmap($value->routing_campaginid);
             
    	  	 array_push($array, 
             	$value->id,
              '<a href="/city-redirection/edit/'.$value->id.'"><button type="button" class="btn btn-success btn-circle "><i class="fa fa-edit"></i> </button></a>',
             	isset($rer[$value->campainid])?$rer[$value->campainid]:'',
             	$value->country,
             	$value->state_iso,
             	$value->city_name,
             	isset($rer1[$value->routing_campaginid])?$rer1[$value->routing_campaginid]:'',
               $isLive_st_temp,
              '<a href="/city-redirection/delete/'.$value->id.'"><button type="button" class="btn btn-success btn-circle "><i class="fa fa-trash"></i> </button></a>'
             	);
             array_push($data1, $array);


    	  	}


    	  	return view('Citywisediversion.cityredirection',compact('data1'));
    }


    public function add_city_mapping(Request $request){


    	 $select_country =  ["iso as iso", "name"];
        
        $data =  DB::table("country")->select($select_country)->get();
        $ddDataResult  = array('country_dropdown' => []);
        foreach ($data as $dropdown) {
            if ($dropdown->iso){
                $ddDataResult['country_dropdown'][$dropdown->iso] = $dropdown->name;
            }
            
          }

          $advertisers_list=array('advertiser_campaigns'=>[]);
         $campaignResult = DB::select("select distinct(ac.id),ac.name from advertiser_campaigns as ac where status=1");

           foreach ($campaignResult as $dropdown) {
            if ($dropdown->id){
                $advertisers_list['advertiser_campaigns'][$dropdown->id] = $dropdown->name."(".$dropdown->id.")";
            }
          }
        



            $state_list = DB::select("select ac.id as id,ac.country_name as name,ac.state_iso from city_list ac where  ac.state_iso !='?'  ORDER BY ac.state_iso desc");
           $ddDataStatusResult  = array('status_dropdown' => []);
        foreach ($state_list as $dropdown) {
            if ($dropdown->state_iso){
                $ddDataStatusResult['state_iso'][$dropdown->state_iso] = $dropdown->state_iso .' ('.$dropdown->name.')';
            }
            
          }


              $city_list = DB::select("select ac.id as id,ac.country_name as name,ac.state_iso,ac.city_name from city_list ac where  ac.state_iso !='?' and  ac.city_name !='?'  ORDER BY ac.state_iso desc");
           $ddDataCityResult  = array('city_dropdown' => []);

        
        foreach ($city_list as $dropdown) {
            if ($dropdown->city_name){
                $ddDataCityResult['city_name'][$dropdown->city_name] = $dropdown->city_name .' ('.$dropdown->state_iso .','. $dropdown->name.')';
            }
            
          }



        $result  = array('country_data' => $ddDataResult,'status_list'=>$ddDataStatusResult,'city_list'=>$ddDataCityResult,'advertiser_list'=>$advertisers_list);
        	
        return view('Citywisediversion.city_add')->with($result);

    }


    public function search(Request $request)
    {
          $search = $request->get('term');
        $advertisers_list=array('advertiser_campaigns'=>[]);
           $select="distinct(advertiser_campaigns.id) as id,concat(advertiser_campaigns.name,' (',advertiser_campaigns.id,')') as name";
                        $campaignResult=DB::table('advertiser_campaigns')
                                 ->selectRaw($select)
                                  ->where('advertiser_campaigns.id','=',$search)
                                  ->get();
                                 
 
          return response()->json($campaignResult);
            
    } 


    public function searchcmap($camp)
    {
          $search = $camp;
        $advertisers_list=array('advertiser_campaigns'=>[]);
           $select="distinct(advertiser_campaigns.id) as id,concat(advertiser_campaigns.name,' (',advertiser_campaigns.id,')') as name";
                        $campaignResult=DB::table('advertiser_campaigns')
                                 ->selectRaw($select)
                                  ->where('advertiser_campaigns.id','=',$search)
                                  ->get();

                            // print_r($campaignResult);     
                              $res=[];
                            foreach ($campaignResult as $key => $value) {
                              $res[$value->id]=$value->name;
                            }
 
          return $res;
            
    } 

    public function getdependdata(Request $request){

   	$action = $request->input('action');
        if($request->input('id') && $action == 'country'){
          $country_id =$request->country;
          $city_list=$this->getcityname($country_id);
          $status =  array('status'=>1,'data'=> $city_list);
        }

        $status = Response::json($status);
      return $status;

      // if($request->input('id') && $action == 'country'){
      //  $country_name = $request->input('id');
      //  $state_list = DB::select("select ac.id as id,ac.country_name as name,ac.state_iso from city_list ac where ac.country_name IN ('$country_name') and ac.state_iso !='?' group by ac.state_iso ORDER BY ac.state_iso desc");
      //   $status =  array('status'=>1,'data'=> $state_list);

      // }elseif ($request->input('action') && $action == 'state') {
      // 		// $state_name = "'".implode("','",explode(',',$request->input('id')))."'";

      //     $country = "'".implode("','",explode(',',$request->input('id')))."'";
      		
      // 		$city_list = DB::select("select ac.id as id,ac.country_name as name,ac.state_iso,ac.city_name from city_list ac where ac.country_name IN ($country) and city_name!='?'  group by ac.city_name  ORDER BY ac.state_iso desc");
      //   //   $city_list = DB::select("select ac.id as id,ac.country_name as name,ac.state_iso,ac.city_name from city_list ac where ac.country_name IN ($country) and city_name!='?'  group by ac.city_name  ORDER BY ac.state_iso desc");
      // 		$status =  array('status'=>1,'data'=> $city_list);

      // }
      // $status = Response::json($status);
      // return $status; 

    }


    public function getcityname($country_id){

        $city_list=DB::select("select ac.id as id,ac.country_name as name,ac.state_iso,ac.city_name from city_list ac left join country as c on c.iso3=ac.country_name where   c.iso='".$country_id."'  ORDER BY ac.state_iso desc");
        // $status =  array('status'=>1,'data'=> $city_list);
        return $city_list;

    }


     public function getdependdatacity(Request $request){


      $action = $request->input('action');
      
      
          $country = "'".implode("','",explode(',',$request->input('id')))."'";
          
          $city_list = DB::select("select ac.id as id,ac.country_name as name,ac.state_iso,ac.city_name from city_list ac where ac.country_name IN ($country) and city_name!='?'  group by ac.city_name  ORDER BY ac.state_iso desc");
        //   $city_list = DB::select("select ac.id as id,ac.country_name as name,ac.state_iso,ac.city_name from city_list ac where ac.country_name IN ($country) and city_name!='?'  group by ac.city_name  ORDER BY ac.state_iso desc");
          $status =  array('data'=> $city_list);

     
      $status = json_encode($status);
      return $status; 

    }



    public function save_city_mapping(Request $request){

      	      $campainid = isset($request->get_campaign) ? $request->get_campaign:'';

              $country = isset($request->country) ? $request->country:'';

              $state_iso = isset($request->state) ? $request->state:'';

              $city_iso = isset($request->city) ? $request->city:'';

              
              //75319 = {\"cca\":\"75318\",\"citys\":[\"BEAWAR\",\"GURGAON\",\"JIND\",\"PEHOWA\",\"SIRHIND\"],\"states\":[\"HR\"]}	
              $routing_campaign_name= isset($request->set_campaign) ? $request->set_campaign :'';

                  $city_name_array = array($request->get_campaign => array(
                  	'cca'=>$routing_campaign_name,
                  	'citys'=>$city_iso,
                  	'states'=>$state_iso
                  )
              	);

              	$city_json_list = json_encode($city_name_array,true);


              		// echo $city_json_list;
              	 try{
              	$cityConfig = new city_mapping;

              	$cityConfig->campainid = $campainid;
              	 if($country){
                  $cityConfig->country= '"'.implode('","',array_map('strtoupper', $country)).'"';  
                 }else{
                  $cityConfig->country= '';
                 }
                
              	if($state_iso){
                  $cityConfig->state_iso = '"'.implode('","',array_map('strtoupper', $state_iso)).'"';
                }else{
                  $cityConfig->state_iso = '';
                }
                  
                if($city_iso){
                $cityConfig->city_name = '"'.implode('","',array_map('strtoupper', $city_iso)).'"';  
              }else{
                $cityConfig->city_name ='';
              }
              	
              	
                $cityConfig->routing_campaginid =$routing_campaign_name;
              	
                $cityConfig->type = 'include';
              	
                $cityConfig->status = '1';
              	
                $cityConfig->created_date=date('Y-m-d H:i:s');
              	
                $cityConfig->save();
              	
                return redirect()->back()->with('message', 'Save Sucessfull !');
              	
                }
			    catch(\Exception $e){
			    	echo $e->getMessage();   // insert query
			    }
              	

    }

    public function editcitymapping(Request $request){
         $condtion = [];
        $opr_condition = [];
        $id=$request->id;
        if(!empty($id))
        {
            array_push($condtion,["id","=",$id] );
        }
        
        $select_data =  [
            "id",
            "campainid",
            "country",
            "state_iso","city_name","routing_campaginid","type","status"
          ];
        
        $camp_data =  DB::table("city_mapping")
         ->where($condtion) 
         ->select($select_data)
         ->limit(1)
         ->get();
        
       
        $decode_data = json_decode($camp_data, true);

        $select_country =  ["iso as iso", "name"];
        
        $data =  DB::table("country")->select($select_country)->get();
        $ddDataResult  = array('country_dropdown' => []);
        foreach ($data as $dropdown) {
            if ($dropdown->iso){
                $ddDataResult['country_dropdown'][$dropdown->iso] = $dropdown->name;
            }
            
          }

          $advertisers_list=array('advertiser_campaigns'=>[]);
         $campaignResult = DB::select("select distinct(ac.id),ac.name from advertiser_campaigns as ac where status=1");

           foreach ($campaignResult as $dropdown) {
            if ($dropdown->id){
                $advertisers_list['advertiser_campaigns'][$dropdown->id] = $dropdown->name."(".$dropdown->id.")";
            }
          }
        



            $state_list = DB::select("select ac.id as id,ac.country_name as name,ac.state_iso from city_list ac where  ac.state_iso !='?'  ORDER BY ac.state_iso desc");
           $ddDataStatusResult  = array('status_dropdown' => []);
        foreach ($state_list as $dropdown) {
            if ($dropdown->state_iso){
                $ddDataStatusResult['state_iso'][$dropdown->state_iso] = $dropdown->state_iso .' ('.$dropdown->name.')';
            }
            
          }


              $city_list = DB::select("select ac.id as id,ac.country_name as name,ac.state_iso,ac.city_name from city_list ac where  ac.state_iso !='?' and  ac.city_name !='?'  ORDER BY ac.state_iso desc");
           $ddDataCityResult  = array('city_dropdown' => []);

        
        foreach ($city_list as $dropdown) {
            if ($dropdown->city_name){
                $ddDataCityResult['city_name'][$dropdown->city_name] = $dropdown->city_name .' ('.$dropdown->state_iso .','. $dropdown->name.')';
            }
            
          }
        
        $result  = array(
            'data' => $decode_data[0],
            'id' => $id,
            'campainid' => $decode_data[0]['campainid'],
            'routing_campaginid' => $decode_data[0]['routing_campaginid'],
            'country_name' => $decode_data[0]['country'],
            'state_iso' => $decode_data[0]['state_iso'],
            'city_name' => $decode_data[0]['city_name'],
            'country_data' => $ddDataResult,
            'status_list'=>$ddDataStatusResult,
            'city_list'=>$ddDataCityResult,
            'advertiser_list'=>$advertisers_list
          );
        $viewPage = "Citywisediversion.city_redirection_edit";
        $dataN =  view($viewPage)->with($result);
        return $dataN;

    }


    public function update_city_mapping(Request $request){

             $id=$request->id;
          
              $campainid = isset($request->get_campaign) ? $request->get_campaign:'';

              $country = isset($request->country) ? $request->country:'';

              $state_iso = isset($request->state) ? $request->state:'';

              $city_iso = isset($request->city) ? $request->city:'';

               if($country){
                  $countr_list= '"'.implode('","',array_map('strtoupper', $country)).'"';  
                 }else{
                  $countr_list= '';
                 }
                
                if($state_iso){
                  $state_iso_list = '"'.implode('","',array_map('strtoupper', $state_iso)).'"';
                }else{
                  $state_iso_list = '';
                }
                  
                if($city_iso){
                $city_iso_list = '"'.implode('","',array_map('strtoupper', $city_iso)).'"';  
              }else{
                $city_iso_list ='';
              }


              $routing_campaign_name= isset($request->set_campaign) ? $request->set_campaign :'';
            $update = DB::table('city_mapping')
            ->where('id', $id)
            ->limit(1)  // optional - to ensure only one record is updated.
            ->update(array('campainid' => $campainid,'country'=>$countr_list,'state_iso'=>$state_iso_list,'city_name'=>$city_iso_list,'routing_campaginid'=>$routing_campaign_name )); 
            if($update)
            {
              return redirect()->back()->with('message', 'Save Sucessfull !');
            }
            else 
            {
                return redirect()->back()->with('message', 'Save Not Sucessfull !');
            }

    }


    public function deletecitymapping(Request $request){

          $id=$request->id;
          $delete=DB::table('city_mapping')->where('id',$id)->limit(1)->delete();
            if($delete)
            {
              return redirect()->back()->with('message', 'Save Sucessfull !');
            }
            else 
            {
                return redirect()->back()->with('message', 'Save Not Sucessfull !');
            }
    
    }

    public function status_update(Request $request)
    {
       
        $id = $request->id;
        $status = $request->status;

//        echo "<pre>";
//        print_r($request->all());
//        echo "</pre>";die();
        
        if($id != '' && $status != '')
        {
            
            if($status=='1')
            {
                $statuss = '0';
            }else
            {
                $statuss = '1';
            }
            
            $update = DB::table('city_mapping')
            ->where('id', $id)
            ->limit(1)  // optional - to ensure only one record is updated.
            ->update(array('status' => $statuss)); 
            if($update)
            {
               echo 1;
                exit();
            }
            else 
            {
                echo 2;
                exit();
            }
        }
        else
        {
            echo 3;
                exit();
            
        }
    }
    
}