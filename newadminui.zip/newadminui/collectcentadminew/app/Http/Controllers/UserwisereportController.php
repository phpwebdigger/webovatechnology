<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\SmartRotatorCampaignsOpeators;
use Response;
use Auth;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Redis;
use App\AdNetwork;

class UserwisereportController extends Controller
{


   public function index(Request $request)
    {   
        $dtvalue = date('Y-m-d');
        $dtvalue2 = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue)));
        $actdata= $this->getacountNetwork();
        $result  = array(
                        'dtvalue' => $dtvalue,
                        'dtvalue2' => $dtvalue2,
                        'account_manager'=>$actdata
                      );
                
                
           return  view('smart.networkuserwisepage')->with($result);
    }
        

    public function index_filter(Request $request){

            $dtvalue = $request->start;
           $type = "network";
        $dtvalue2 = $request->end;

        $condtion = $data221= [];
        
        $total_sale_count = $count = $totalClick = $actualcount = $totalconversion = $clicks_active_count = $unique_conversion = $totalCostDollar = $totalRevenueDollar = $totalprofit = $finalprofit_ECPM =  0;

         $role_id = isset($request->user_account) ? $request->user_account:'sanjeev@collectcent.com';

             if (Cache::has('accoutmanager_networkresults_'.$role_id)) { 

                 $account_manager_result  =Cache::get('accoutmanager_networkresults_'.$role_id);
                 }else{ 
                 $account_manager_result = Cache::remember('accoutmanager_networkresults_'.$role_id, 600, function() use($role_id)
                 {     
         $condtion =[];

          if(is_null($dtvalue)){
            $dtvalue = date('Y-m-d');
        }
        if(is_null($dtvalue2)){
                $dtvalue2 = date('Y-m-d');
                $enddate = date('Y-m-d',strtotime("+1 days"));
        }else{
           if($dtvalue == $dtvalue2){ 
              $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));
           }else{
            $enddate = date('Y-m-d',strtotime($dtvalue2));
           }
        }
        array_push($condtion,['crc_records_new.create_time','>=',$dtvalue] );

        array_push($condtion,['crc_records_new.create_time','<=',$enddate] );

        $role_ids="FIND_IN_SET('$role_id',trim(ad_network.account_manager))";

                $select="smart_rotator_campaigns_operators.campaign_id"
                        .",ad_network.account_manager"  
                        .",smart_rotator_campaigns_operators.redirect_diversion_config"
                        .",smart_rotator_campaigns_operators.id_zone as zone"
                        .",smart_rotator_campaigns_operators.smart_live as active"
                        .",ad_network.name as network_name"
                        .",smart_rotator_campaigns_operators.publisher_cpa as cpa"
                        .",smart_rotator_campaigns_operators.ads_cat as traffic_type"
                        .",crc_records_new.id_advertiser_campaign"
                        .",advertiser_campaigns.name"
                        .",advertiser_campaigns.offername"
                        .",advertiser_campaigns.id"
                        .",advertiser_campaigns.id_op as op_id"
                        .",smart_rotator_campaigns_operators.is_offer_direct as trfc"
                        .",advertiser_campaigns.vertical"
                        .",smart_rotator_campaigns_operators.status as cap_status"
                        .",smart_rotator_campaigns_operators.country_code as country_code"
                        .",advertiser_campaigns.os_type"
                        .",advertiser_campaigns.incent_type"
                        .",crc_records_new.parent_cca as parent_cca"
                        .",crc_records_new.id_channel as id_channel"
                        .",crc_records_new.clickcount_fraud as fraud"
                        .",crc_records_new.create_time as datetime"
                        .",CONCAT(crc_records_new.cr_received,'%') AS cr_received"
                        .",CONCAT(crc_records_new.cr_given,'%') AS cr_given"
                        .",sum(crc_records_new.clickcount) as clickcount"
                        .",sum(crc_records_new.conversion_count_unique) as conversion_count_unique"
                        .",sum(crc_records_new.conversion_count) as conversion_count"
                        .",sum(crc_records_new.clicks_active_count) as clicks_active_count"
                        .",sum(crc_records_new.sale_count) as sale_count"
                        .",sum(crc_records_new.total_cost) as cost_dollar"
                        .",sum(crc_records_new.revenue_dollar) as revenue_dollar";

                         // $select = implode(",", $select); 

            $dat_data=DB::table('smart_rotator_campaigns_operators')->select(DB::raw($select))
                    ->leftJoin("advertiser_campaigns","advertiser_campaigns.id","=","smart_rotator_campaigns_operators.campaign_id")
                    ->leftJoin("ad_network","ad_network.ccz", "=","smart_rotator_campaigns_operators.id_zone")
                    ->leftJoin("crc_records_new", function($join){                    
            $join->on("crc_records_new.parent_cca","=","smart_rotator_campaigns_operators.campaign_id");
            $join->on("smart_rotator_campaigns_operators.id_zone", "=","crc_records_new.id_channel");
           
            })
                    ->where($condtion)
                    ->whereRaw($role_ids)
                    ->whereIN("smart_rotator_campaigns_operators.ads_cat", array('OM', 'OG'))
                    ->groupby('smart_rotator_campaigns_operators.campaign_id')
                    ->groupby('smart_rotator_campaigns_operators.id_zone')->get();

                    return $dat_data;
                     });
                }
                
                $rst=json_decode($account_manager_result, true);


                  foreach ($rst as $result) {
                        $array = $data = $rtotal = [];
                        $count++;
                        $cap_status=0;
                        $totalCostDollar = round($totalCostDollar + ($result['cost_dollar']),2);  
                        $profit_dollar = $result['revenue_dollar'] - $result['cost_dollar'];
                        $profit_both = "<span class=dollar>".round($profit_dollar,2)."</span>";

                        $actualClick = $result['clickcount'] - $result['fraud'];
                        $cost_dollar = round($result['cost_dollar'],2);
                        
                        $totalRevenueDollar = round($totalRevenueDollar + ($result['revenue_dollar']),2);
                        
                        $totalprofitdoller = $result['revenue_dollar'] - $result['cost_dollar'] ;

                        $cr_in = '';
                        if($actualClick != 0)
                        {
                            $ecpm_doller = ($result['revenue_dollar']/$actualClick)*1000;
                            $cr_in = (($result['conversion_count_unique']/$actualClick)*100);
                            $cr_out = (($result['clicks_active_count']/$actualClick)*100);
                        }
                        else
                        {
                            $ecpm_doller = 0.000;
                        }
                        
                        if($result['conversion_count_unique'] == 0)
                        {
                            $cr_in = 0.00;
                        }
                        
                        if($result['clicks_active_count'] == 0)
                        {
                            $cr_out = 0.00;
                        }
                        if($result['active'] == 0)
                        {
                            $active = 'Pause';
                        }
                        else 
                        {
                            $active = 'Active';
                        }
                        

                        if($result['cap_status']==1){
                            $cap_status='<p  class="label label-success">Active</p>';
                        }else if($result['cap_status']==0){ 
                            $cap_status="<p  class='label label-warning'> Inactive </p>";
                        }else if($result['cap_status']==5){ 
                            $cap_status="<p class='label label-danger'>Pause</p>";
                        }
                        
                        $first_field = $result['id'];
                    
                        if($advertiser_id){
                            $first_field = $result['id'];
                        }else if($type == 'network'){
                           $first_field = $result['id_channel'];
                        } else if ($type == 'advertiser'){
                        $first_field = $result['id'];
                        }

                        if($type == 'advertiserByParentcca'){
                          $array[] =  $result['id'];
                          $first_field = $result['id'];
                        }
                        if($type == 'network'){
                            $array[] = $result['id'];
                            // $array[] = "$result->id";
                        }
                        
                       $array[] =    $result['account_manager'];
                      $array[] =    $result['name'];
                        $array[] =  $result['cpa'];  
                        $array[] =  $result['traffic_type']; 
                        // $array[] = "";                           
                        $array[] =  isset($result['name'])?htmlentities($result['name']):'';

                         $array[] =  isset($result['offername'])?htmlentities($result['offername']):'';

                       
                    // $array[] = ""; //'<a href="javascript:void(0);" onclick="changeTrfc('.$result['parent_cca'].','.$result['zone'].','.$result['campaign_id'].');"><i class="fa fa-pencil"></i><span id="trfc_'.$result['campaign_id'].'">'.$result['trfc'].'</span></a>
                    //<span href="javascript:void(0);" id="trigger" onmouseover="display_pop('.$result['parent_cca'].','.$result['zone'].','.$result['campaign_id'].');"> Details </span>';

            
                        $array[] =   $active;
                        $array[] =   $cap_status;
                        $array[] =   $result['vertical'];
                        $array[] =   $result['country_code'];
                        $array[] =   $result['os_type'];
                        $array[] =   $result['clickcount'];
                        $array[] =   $actualClick; 
                        $array[] =   $result['conversion_count'];
                        
                       
                            $array[] =   $result['conversion_count_unique'];
                        
                        
                        $array[] =   $result['clicks_active_count'];                                
                        $array[] =   $result['sale_count'];
                        
                      
                        $array[] =  round($cr_in,2)."%";
                        $array[] =  round($cr_out,2)."%";    
                      
                        $array[] =   '$'."<span class=dollar>".$cost_dollar."</span>";
                        $array[] =   '$'."<span class=dollar>".round($result['revenue_dollar'],2);
                        $array[] =   '$'.$profit_both;
                        $array[] =   '$'.round($ecpm_doller,3);

                        $array[] =   $result['datetime'];

                        array_push($data221, $array);
                        $total_sale_count = $total_sale_count + $result['sale_count']; 
                        $totalClick = $totalClick + $result['clickcount'];
                        $sum_act_Click = $sum_act_Click + $actualClick;
                        
                      
                        $unique_conversion = $unique_conversion + $result['conversion_count_unique'];
                        
                        
                        $actualcount = $actualcount + $actualClick;
                        $totalconversion = $totalconversion + $result['conversion_count'];
                        $clicks_active_count = $clicks_active_count + $result['clicks_active_count'];
                        
                        
                        $sum_revenue_doller = $sum_revenue_doller + $result['revenue_dollar'];
                        
                        $totalprofit = $totalprofit + $profit_dollar;
                        
                    }
                      


                        $lastRow =[$totalClick,$sum_act_Click,$totalconversion,$unique_conversion,$clicks_active_count,$total_sale_count,$totalCostDollar,round($sum_revenue_doller,2),round($totalprofit,2)];
 
                           $actdata= $this->getacountNetwork();
                    $result  = array('data1' => $data221,            
                        'dtvalue' => $dtvalue,
                        'dtvalue2' => $dtvalue2,
                        'role' => $role_id,
                        'lastRow'=>$lastRow,
                        'account_manager'=>$actdata

                      );
                   
                   return   view('smart.networkuserwisepage')->with($result);
                // return $this->index_adv_networ(json_encode($account_manager_result));
    }

    
      public function getacountNetwork(){
                
                 if (Cache::has('accoutmanager_networklist')) { 
                 $categories  =Cache::get('accoutmanager_networklist');
                 }else{        
                 $categories = Cache::remember('accoutmanager_networklist', 30, function()
                 {
                    $adDataArray = AdNetwork::where("account_manager","!=","")->groupby("account_manager")->select("account_manager")->get();
                    $name_rts=[];
                              foreach($adDataArray as $value){
                                    $name_rts[]= $value->account_manager;
                              }
                             return $name_rts;
                 });

                 }

        return $categories;
        }





       }     


       ?>    