<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\QueryAccess;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Auth;
use App\Ad;
use App\CronConfig;
use App\MaskingConfigDelivery;
use Redirect;
use App\ManualCron;
use Response;

class CronController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request){
        
        
        $zone = array();
        $post_back_url = array();
        
        $select_post =  ["id","id_zone","post_back_url"];
        
        $get =  DB::table("masking_config_delivery")
                ->select($select_post)
                ->get();
//        dd($get);die();
        
        foreach ($get as $zone_result) {
            $post_back_url[] = $zone_result->post_back_url;
            $zone[] = $zone_result->id_zone;

        }
//        echo "<pre>";
//        print_r($zone);
//        echo "</pre>";
//        die();        
        
        $condition = [];
        $cco =  $request->cco;
        $id_ad =  $request->id_ad;
        if($request->sort_adv){
            array_push($condition,['cron_config.ccz','=',$request->sort_adv]);
        }
        if($request->id_ad){
            array_push($condition,['cron_config.id_ad','=',$request->id_ad]);
        }
        $select = "cron_config.*,ad_network.name as name,"
        ."ads.operator_name as operator_name,ads.country_code as country_code";
        $data  = CronConfig::with(['Networks','Ads']);
        $data = $data->where($condition);
        if($request->cco){
          $data = $data->whereHas('Ads',function ($q) use ($cco){
                  $q->where('ads.cco',$cco);
          });
        }
        $data = $data->orderBy('cron_config.id_ad','desc')->limit(500)->get();

        
        $data1 = [];
        foreach ($data as $fetch_url) {
            
            if($fetch_url->ccz != '591')
            {
                $array = [];
                if($fetch_url->status == "1"){
                    $checked = "On";
                }else{
                    $checked = "Off";
                }
                
                if(in_array($fetch_url->ccz, $zone))
                {
                    $post = 'NA';
                }
                else{
                    $post = '<div class="urltext" style="max-width: 900px !important" title="'.$fetch_url->network_callback_url.'"><span>'.$fetch_url->network_callback_url.'</span><input type="text" class="hide" value="'.$fetch_url->network_callback_url.'"></div>';
                }
                
                array_push($array,
                    $fetch_url->Networks['name'],
                    $fetch_url->title,
                    $fetch_url->id_ad,
                    $fetch_url->Ads['operator_name']."(".$fetch_url->Ads['country_code'].")",
                    number_format($fetch_url->lower_cr_in_percentage, 2, '.',',' ),
                    number_format($fetch_url->higher_cr_in_percentage, 2, '.',',' ),
                    $fetch_url->time_interval,
                    $checked,
                    '<a href="/edit_cron_new/'.$fetch_url->id.'"><i class="fa fa-edit"></i></a>',
                    $post
                   );
                array_push($data1, $array);
            }
        }
          $result  = array('data' => $data1,
            'cco' => $request->cco,
            'sort_adv' => $request->sort_adv,
            'id_ad' => $request->id_ad
          );
        return view('cron.cron_management_new')->with($result);
    }
    public function filterCron(Request $request){
        
        $zone = array();
        $post_back_url = array();
        
        $select_post =  ["id","id_zone","post_back_url"];
        
        $get =  DB::table("masking_config_delivery")
                ->select($select_post)
                ->get();
        
        foreach ($get as $zone_result) {
            $post_back_url[] = $zone_result->post_back_url;
            $zone[] = $zone_result->id_zone;

        }
        
        $condition = [];

        $select = "cron_config.*,ad_network.name as name,"
        ."ads.operator_name as operator_name,ads.country_code as country_code";
        $data  = CronConfig::with(['Networks','Ads']);
        
        $data = $data->orderBy('cron_config.id_ad','desc')->limit(500)->get();

        
        $data1 = [];
        foreach ($data as $fetch_url) {
            
            if($fetch_url->ccz != '591')
            {
                $array = [];
                if($fetch_url->status == "1"){
                    $checked = "On";
                }else{
                    $checked = "Off";
                }
                
                if(in_array($fetch_url->ccz, $zone))
                {
                    $post = 'NA';
                }
                else{
                    $post = '<div class="urltext" style="max-width: 900px !important" title="'.$fetch_url->network_callback_url.'"><span>'.$fetch_url->network_callback_url.'</span><input type="text" class="hide" value="'.$fetch_url->network_callback_url.'"></div>';
                }
                
                array_push($array,
                    $fetch_url->Networks['name'],
                    $fetch_url->title,
                    $fetch_url->id_ad,
                    $fetch_url->Ads['operator_name']."(".$fetch_url->Ads['country_code'].")",
                    number_format($fetch_url->lower_cr_in_percentage, 2, '.',',' ),
                    number_format($fetch_url->higher_cr_in_percentage, 2, '.',',' ),
                    $fetch_url->time_interval,
                    $checked,
                    '<a href="/edit_cron_new/'.$fetch_url->id.'"><i class="fa fa-edit"></i></a>',
                    $post
                   );
                array_push($data1, $array);
            }
        }
        $status = array('status'=>1,'data'=>$data1);
        return $status;
//          $result  = array('data' => $data1,
//            'cco' => $request->cco,
//            'sort_adv' => $request->sort_adv,
//            'id_ad' => $request->id_ad
//          );
//        return view('cron.cron_management_new')->with($result);
    }
    
    public function oldindex(Request $request){
        
        if($request->auth === 'sanjeev')
        {
            $condition = [];
            $cco =  $request->cco;
            $id_ad =  $request->id_ad;
            if($request->sort_adv){
                array_push($condition,['cron_config.ccz','=',$request->sort_adv]);
            }
            if($request->id_ad){
                array_push($condition,['cron_config.id_ad','=',$request->id_ad]);
            }
            $select = "cron_config.*,ad_network.name as name,"
            ."ads.operator_name as operator_name,ads.country_code as country_code";
            $data  = CronConfig::with(['Networks','Ads']);
            $data = $data->where($condition);
            if($request->cco){
              $data = $data->whereHas('Ads',function ($q) use ($cco){
                      $q->where('ads.cco',$cco);
              });
            }
            $data = $data->orderBy('cron_config.id_ad','desc')->limit(500)->get();


            $data1 = [];
             foreach ($data as $fetch_url) {
                    $array = [];
                    if($fetch_url->status == "1"){
                        $checked = "On";
                    }else{
                        $checked = "Off";
                    }


                    array_push($array,
                        $fetch_url->Networks['name'],
                        $fetch_url->title,
                        $fetch_url->id_ad,
                        $fetch_url->Ads['operator_name']."(".$fetch_url->Ads['country_code'].")",
                        number_format($fetch_url->lower_cr_in_percentage, 2, '.',',' ),
                        number_format($fetch_url->higher_cr_in_percentage, 2, '.',',' ),
                        $fetch_url->time_interval,
                        $checked,
                        '<a href="/edit_cron_new/'.$fetch_url->id.'"><i class="fa fa-edit"></i></a>',
                        '<div class="urltext" style="max-width: 900px !important" title="'.$fetch_url->network_callback_url.'"><span>'.$fetch_url->network_callback_url.'</span><input type="text" class="hide" value="'.$fetch_url->network_callback_url.'"></div>'
                       );

                    array_push($data1, $array);
            }
              $result  = array('data' => $data1,
                'cco' => $request->cco,
                'sort_adv' => $request->sort_adv,
                'id_ad' => $request->id_ad
              );
            return view('cron.cron_management_old')->with($result);
        }
        else
        {
            echo '<script>window.location.href = "http://162.243.33.148/report/index.php";</script>';
            exit;
        }
        
        
    }

    public function add(Request $req){
      $condition = [];
      $result  = array('data1' => []);
      if($req->ccz){

      $sourceResult = Ad::where("id_ad", $req->idad)->select("network_postback_source")->get();
        if(sizeof($sourceResult) > 0){
              if($sourceResult[0]['network_postback_source'] == "" || strpos($req->adnetwork_url, $sourceResult[0]['network_postback_source']) !== false) { 
                  $cConfig = new CronConfig;
                  $cConfig->title = isset($req->title) ? $req->title:'';
                  $cConfig->ccz = isset($req->ccz) ? $req->ccz :'';
                  $cConfig->id_ad = isset($req->idad) ? $req->idad :'';
                  $cConfig->network_callback_url = isset($req->adnetwork_url) ? $req->adnetwork_url:'';
                  $cConfig->success_response = null;
                  $cConfig->lower_cr_in_percentage = isset($req->lower_cr)?$req->lower_cr:0;
                  $cConfig->higher_cr_in_percentage = isset($req->higher_cr)?$req->higher_cr:0;
                  $cConfig->time_interval = isset($req->time_interval)?$req->time_interval:30;
                  $cConfig->status = isset($req->filter_status)? $req->filter_status:0 ;
                  $cConfig->save();
                  return redirect('/cron');
                  }
              }
        }
        return view('cron.cron_add')->with($result);
      }


    public function add_new(Request $req){
      $condition = [];
      $result  = array('data1' => []);
      if($req->ccz){
       $sourceResult = Ad::where("id_ad", $req->idad)->select("network_postback_source")->get();
        if(sizeof($sourceResult) > 0){
          if($sourceResult[0]['network_postback_source'] == "" || strpos($req->adnetwork_url, $sourceResult[0]['network_postback_source']) !== false) {
                  $cConfig = new CronConfig;
                  $cConfig->title = '';//$req->title;
                  $cConfig->ccz = $req->ccz;
                  $cConfig->id_ad = $req->idad;
                  $cConfig->network_callback_url = $req->adnetwork_url;
                  $cConfig->success_response = null;
                  $cConfig->lower_cr_in_percentage = '0.1';//$req->lower_cr;
                  $cConfig->higher_cr_in_percentage = '0.2';//$req->higher_cr;
                  $cConfig->time_interval = '20';//$req->time_interval;
                  $cConfig->status = '0';//$req->filter_status;
                  $cConfig->save();
                  return redirect('/cron');
                  }
              }
        }
        return view('cron.cron_add_new')->with($result);
      }

function getAdsByNetwork(Request $request){
      if($request->id_zone){
            $id_zone = $request->id_zone;
            $get = DB::select("select id from masking_config_delivery where id_zone = $id_zone LIMIT 1 ");

            $id = '';
            if(!empty($get))
            {
                $id = $get[0]->id;
            }
           
            if($id == '')
            {
                $table = $request->table; 
                $tableName = "config_delivery".$table; 
                /*$result = DB::select("select concat(id_ad,'(',title,')') as cca , id_ad1, title from ads where id_zone = $id_zone AND id_ad NOT IN (select id_ad from $tableName where id_zone = $id_zone)");*/
                $result = DB::select("select concat(id_ad,'(',title,')') as cca , id_ad, title from ads where id_zone = $id_zone AND id_ad NOT IN (select id_ad from cron_config where ccz = $id_zone)");

                $select = ['post_back_url','count(*) as num'];
                $condition = [];
                array_push($condition,['id_zone','=',$id_zone]);
                $total = DB::raw("count(*) as total"); 
                $deliveryPostBack =  DB::select("Select distinct(post_back_url),count(*) as total from config_delivery where id_zone=$id_zone group by post_back_url order by post_back_url");
                $status = array('status'=>1,'cca'=>$result,'deliveryPostBack'=>$deliveryPostBack);
                return json_encode($status);                
            }
            else
            {
                $table = $request->table; 
                $tableName = "config_delivery".$table; 
                $result = DB::select("select concat(id_ad,'(',title,')') as cca , id_ad, title from ads where id_zone = $id_zone AND id_ad NOT IN (select id_ad from $tableName where id_zone = $id_zone)");
                $select = ['post_back_url','count(*) as num'];
                $condition = [];
                array_push($condition,['id_zone','=',$id_zone]);
                $total = DB::raw("count(*) as total"); 
                $deliveryPostBack =  DB::select("Select distinct(post_back_url),count(*) as total from config_delivery where id_zone=$id_zone group by post_back_url order by post_back_url");
                $status = array('status'=>1,'cca'=>$result,'deliveryPostBack'=>'');
                return json_encode($status);         
            }
            
        }
    }

   public function edit_cron(Request $request){
       $data = CronConfig::where('id', $request->id)->get();
       $ccz = $data[0]->ccz;
       $id = $data[0]->id;
        $id_ad =  DB::select("select ads.id_ad,ads.title from ads inner join cron_config as CD on ads.id_ad = CD.id_ad where CD.ccz = $ccz"); 
            if($request->ccz){
              //  $sourceResult = Ad::where("id_ad","=",$request->idad)->select("network_postback_source")->get();
               //  if (sizeof($sourceResult) > 0) {
                //     if ($sourceResult[0]['network_postback_source'] == "" || strpos($request->adnetwork_url, $sourceResult[0]['network_postback_source']) !== false) { 
                            $cConfig = CronConfig::find($request->id);
                            $cConfig->title = $request->title;
                            // $cConfig->ccz = $request->ccz;
                            // $cConfig->id_ad = $request->idad;
                            $cConfig->network_callback_url = $request->adnetwork_url;
                            $cConfig->success_response = null;
                            $cConfig->lower_cr_in_percentage = $request->lower_cr;
                            $cConfig->higher_cr_in_percentage = $request->higher_cr;
                            $cConfig->time_interval = $request->time_interval;
                            $cConfig->status = $request->filter_status=="on"?1:0;
                            $cConfig->save();
                return redirect::to('/cron')->with('success_msg', "Record Updated Successfully");
              //   }
              // }
             }  
            $result = array('data'=>$data,'id_ad'=>$id_ad);
            return view('cron.cron_edit')->with($result);
    }
 public function edit_cron_new(Request $request){
     
        $data = CronConfig::where('id', $request->id)->get();
        $ccz = $data[0]->ccz;
        $id = $data[0]->id;
        $cca = $data[0]->id_ad;
        $network_callback_url = $data[0]->network_callback_url;
        
        $zone = array();
        $post_back_url = '';
        
        $select_post =  ["id","id_zone","post_back_url"];
        
        $get =  DB::table("masking_config_delivery")
                ->select($select_post)
                ->get();
//        dd($get);die();
        
        foreach ($get as $zone_result) {
            $post_back_url = $zone_result->post_back_url;
            $zone[] = $zone_result->id_zone;
        }
        
        if(in_array($ccz, $zone))
        {
            $post_back_url = "NA";
        }
        else
        {
            $post_back_url = $network_callback_url;
        }
        
        if($request->adnetwork_url == 'NA')
        {
            $postback_url = $network_callback_url;
        }
        else
        {
            $postback_url = $request->adnetwork_url;
        }
        
        
        $id_ad =  DB::select("select ads.id_ad,ads.title from ads inner join cron_config as CD on ads.id_ad = CD.id_ad where CD.ccz = $ccz"); 
            if($request->ccz){
                         $cConfig = CronConfig::find($request->id);
                            // $cConfig->title = $request->title;
                            $cConfig->network_callback_url = $postback_url;
                            $cConfig->success_response = null;
                            // $cConfig->lower_cr_in_percentage = $request->lower_cr;
                            // $cConfig->higher_cr_in_percentage = $request->higher_cr;
                            // $cConfig->time_interval = $request->time_interval;
                            $cConfig->status = $request->filter_status=="on"?1:0;
                            $cConfig->save();
                return redirect::to('/cron')->with('success_msg', "Record Updated Successfully");
              //   }
              // }
             }  
      
             $datas = ['id'=>$id,'id_zone'=>$ccz,'id_ad'=>$cca,'network_callback_url'=>$post_back_url];
             
            $result = array('datas'=>$datas,'id_ad'=>$id_ad);
            return view('cron.cron_edit_new')->with($result);
    }


    public function manual(Request $request){
        $condition = [];
        $dtvalue = date('Y-m-d');
        $enddate = date('Y-m-d',strtotime("+1 days"));

        array_push($condition,['timestamp','>=',$dtvalue] );
        array_push($condition,['timestamp','<=',$enddate] );
           
        $select = "id as row_id,cca,activation_count,hour,is_child,id_child,response,status";
          $data =  DB::table("manualcorn")->where($condition)->selectRaw(DB::raw($select));
        if($request->colorder){
           $data = $data->orderby($request->colorder,$request->order);
           $appends["colorder"]=$request->colorder;
           $appends["order"]=$request->order;
        }else{
          $data = $data->orderby("id","DESC")->orderby("status","ASC")->orderby("timestamp","DESC");
        }
        $data =  $data->get();
         $data1 = [];
         if($data){
            foreach ($data as $fetch_url) {
                $array = [];
                if($fetch_url->status == 0){
                    $text = "Inprocess";
                }else{
                    $text = "Reprocess";
                }
                array_push($array,
                     $fetch_url->cca,
                      $fetch_url->is_child,
                      $fetch_url->id_child,
                      $fetch_url->activation_count,
                      $fetch_url->hour,
                      '<span class="showUrl" data-toggle="modal" data-target=".bs-example-modal-lg" >'.$fetch_url->response.'</span>',
                      '<button class="btn btn-success">'.$text.'</button></td>');
                   array_push($data1, $array);
            }
        }

        $result  = array(
                  'data1' => $data1,
                  'op_name'=>$request->op_name ?? "0" ,
                 'sort_adv' => $request->sort_adv ?? "0"
        );
             
        return view('cron.manual_cron')->with($result);

    }

    /* adding manual Cron */   
    public function add_manual_cron(Request $req)
    {
        $condition = [];
        $result  = array('data1' => []);
        if($req->cca && $req->activation && $req->is_child){
          $manualcron = new ManualCron;
          $manualcron->cca = $req->cca;
          $manualcron->activation_count = $req->activation;
          $manualcron->is_child = $req->is_child;
          if($req->is_child == 1){
          $manualcron->id_child = $req->child_id;
          $manualcron->price = $req->price;
          }
          $manualcron->hour = $req->priority;
          $manualcron->save();
          if($manualcron->id){
          $status = array('status'=>1, 'message' => 'Cron is succesfully saved');
        }else{
          $status = array('status'=>0, 'message' => 'Cron is not saved');
        }
        }
        
        $status = Response::json($status);
        return $status;
    }


      /*Smart manual corm*/
    public function smart_manual(Request $request){
        
        $zone = array();
        $post_back_url = array();
        
        $select_post =  ["id","id_zone","post_back_url"];
        
        $get =  DB::table("masking_config_delivery")
                ->select($select_post)
                ->get();
//        dd($get);die();
        
        foreach ($get as $zone_result) {
            $post_back_url[] = $zone_result->post_back_url;
            $zone[] = $zone_result->id_zone;

        }

        
        
      $condition = [];
      $dtvalue = date('Y-m-d');
      $enddate = date('Y-m-d',strtotime("+1 days"));
      array_push($condition,['timestamp','>=',$dtvalue] );
      array_push($condition,['timestamp','<=',$enddate] );
      $select = "id as row_id,network_id,parent_cca,activation_count,succescount,price,op_id,campaign_id,siteid,pubid,response,status,priority";
      $data =  DB::table("smartmanualcorn")->selectRaw(DB::raw($select));
      if($request->colorder){
         $data = $data->orderby($request->colorder,$request->order);
         $appends["colorder"]=$request->colorder;
         $appends["order"]=$request->order;
       }else{
        $data = $data->orderby("id","DESC")->orderby("status","ASC")->orderby("timestamp","DESC");
       }
       $data =  $data->get();
         $data1 = [];
         if($data){
            foreach ($data as $fetch_url) {
                
                if(in_array($fetch_url->network_id, $zone))
                {
                    $response = 'NA';
                }
                else{
                    $response = mb_substr($fetch_url->response, 0, 125).'<a href="javascript:return(0);" id="getUser" data-id="'.$fetch_url->row_id.'" data-toggle="modal" data-target="#view-modal" contenteditable="false" onclick="view_resposnce('.$fetch_url->row_id.');return false;"> Read More </a> </span>';
                }

                
                $array = [];
                if($fetch_url->status == 1)
                {
                    $text = '<button class="btn btn-success">Processed</button>';
                }
                else if($fetch_url->status == 4)
                {
                    $text = '<button class="btn btn-success">Cancelled</button>';
                }
                else
                {
                    $text = '<button class="btn btn-danger">Inprocess</button><button class="btn btn-warning" onclick="cancelSmartCronForm('.$fetch_url->row_id.')">Cancel</button>';
                }
                array_push($array,
                        $fetch_url->parent_cca,
                        $fetch_url->campaign_id,
                        $fetch_url->op_id,
                        $fetch_url->siteid,
                        $fetch_url->pubid,
                        $fetch_url->activation_count,
                        $fetch_url->succescount,
                        $fetch_url->price,
                        $fetch_url->priority,
                        $response,
                      $text);
                   array_push($data1, $array);
            }
        }
        $select_campaign = "distinct(ac.id),ac.name";
          $campaign_data =  DB::table("advertiser_campaigns as ac")
              ->join("crc_records_details as crd","ac.id","=","crd.id_advertiser_campaign")
              ->selectRaw(DB::raw($select_campaign))
              ->get();
          $campaign_array = json_decode(json_encode($campaign_data), true);
        $select_operator = "id,name,country_code";
          $operator_data =  DB::table("operator")
              ->selectRaw(DB::raw($select_operator))
                  ->orderBy("name","ASC")
              ->get();
          $operator_array = json_decode(json_encode($operator_data), true);
          $result  = array(
                  'data1' => $data1,
                  'op_name'=>$request->op_name ?? "0" ,
                  'campaign_list'=>$campaign_array,
                  'operator_list'=>$operator_array,
                  'sort_adv' => $request->sort_adv ?? "0"
        );
        return view('cron.smart_manual_cron')->with($result);
    }

    public function filterSmartManualCron(Request $request)
    {
      $cca = $request->cca;
      $condition = [];
      if($request->cca){
        array_push($condition,['parent_cca','=',$request->cca]);
      } 
      $select = "id as row_id,parent_cca,activation_count,succescount,price,op_id,campaign_id,siteid,pubid,response,status,priority";
      $data =  DB::table("smartmanualcorn")->where($condition)->selectRaw(DB::raw($select));
      if($request->colorder){
         $data = $data->orderby($request->colorder,$request->order);
      }else{
        $data = $data->orderby("id","DESC")->orderby("status","ASC")->orderby("timestamp","DESC");
      }
      $data =  $data->get();

         $data1 = [];
         if($data){
            foreach ($data as $fetch_url) {
            $array = [];
            if($fetch_url->status == 1){
                $text = '<button class="btn btn-success">Processed</button>';
            }
            else if($fetch_url->status == 4)
            {
                $text = '<button class="btn btn-success">Cancelled</button>';
            }
            else
            {
                $text = '<button class="btn btn-danger">Inprocess</button><button class="btn btn-warning" onclick="cancelSmartCronForm('.$fetch_url->row_id.')">Cancel</button>';
            }
            array_push($array,
                    $fetch_url->parent_cca,
                    $fetch_url->campaign_id,
                    $fetch_url->op_id,
                    $fetch_url->siteid,
                    $fetch_url->pubid,
                    $fetch_url->activation_count,
                    $fetch_url->succescount,
                    $fetch_url->price,
                    $fetch_url->priority,
                    mb_substr($fetch_url->response, 0, 125).'<a href="javascript:return(0);" id="getUser" data-id="'.$fetch_url->row_id.'" data-toggle="modal" data-target="#view-modal" contenteditable="false" onclick="view_resposnce('.$fetch_url->row_id.');return false;"> Read More </a> </span>',
                  $text);
               array_push($data1, $array);
            }
        }
        
        $status = array('status'=>1,'data'=>$data1);
        return $status;
    }

    public function responsce_list_details(Request $request)
    {
        $select = "id as row_id,parent_cca,activation_count,succescount,op_id,campaign_id,siteid,pubid,response,status,priority";
        $data =  DB::table("smartmanualcorn")->where('id','=',$request->id)->selectRaw(DB::raw($select))->orderby("id","DESC")->orderby("status","ASC")->orderby("timestamp","DESC")->get();
        return json_encode($data);
    }

    public function new_smart_manual(Request $request)
    {
       
        $condition = [];

        $dtvalue = date('Y-m-d');
        $enddate = date('Y-m-d',strtotime("+1 days"));

        array_push($condition,['timestamp','>=',$dtvalue] );
        array_push($condition,['timestamp','<=',$enddate] );
           
        $select = "id as row_id,cca,activation_count,campaign_id,response,status,priority";
          $data =  DB::table("smartmanualcorn")
              ->where($condition) 
             ->selectRaw(DB::raw($select));
        if($request->colorder){
           $data = $data->orderby($request->colorder,$request->order);
           $appends["colorder"]=$request->colorder;
           $appends["order"]=$request->order;
         }else{
          
          $data = $data->orderby("id","DESC")->orderby("status","ASC")->orderby("timestamp","DESC");
            
         }
         $data =  $data->get();
         $data1 = [];
         if($data){
            foreach ($data as $fetch_url) {
                $array = [];
                if($fetch_url->status == 0){
                    $text = "Inprocess";
                }else{
                    $text = "Reprocess";
                }
                array_push($array,
                     $fetch_url->cca,
                      $fetch_url->campaign_id,
                        $fetch_url->activation_count,
                        $fetch_url->priority,
                  
                      '<span class="showUrl" data-toggle="modal" data-target=".bs-example-modal-lg" >'.$fetch_url->response.'</span>',
                      '<button class="btn btn-success">'.$text.'</button></td>');
                   array_push($data1, $array);
            }
        }


        $result  = array(
                  'data1' => $data1,
                  'op_name'=>$request->op_name ?? "0" ,
                 'sort_adv' => $request->sort_adv ?? "0"
        );
             
        return view('cron.new_smart_manual_cron')->with($result);

    }


    public function cca_campaign_list(Request $request){

    $id_ad=$request->id_ad;
   $getactiveId= DB::table('ads')
            ->leftJoin('crc_records_new', 'ads.id_advertiser', '=', 'crc_records_new.id_advertiser_campaign')
            ->where('ads.id_ad','=',$id_ad)
            ->select('crc_records_new.id_ad','crc_records_new.advertiser_campain_name')
            ->groupBy('crc_records_new.id_ad')
            ->get();
            $cmap =array();

            foreach ($getactiveId as $key => $value) {
              # code...
              $cmap[$value->id_ad]= $value->advertiser_campain_name.' ('.$value->id_ad.')';
            }
      return $cmap;

    }
   
    public function add_smart_manual_cron(Request $request){
        
        $result  = array('data1' => []);
          $condtion = [];

          if($request->cca){
           array_push($condtion,['parent_cca','=',$request->cca] ); 
          }
          if($request->id_ad){
             array_push($condtion,['op_id','=',$request->id_ad] ); 
          }
          
          $con = [];
          
          array_push($con,['id_ad','=',$request->cca] ); 
          
          $select_post =  ["id_zone"];
        
            $get_zone =  DB::table("ads")
                    ->select($select_post)
                    -> where($con)
                    ->limit(1)
                    ->get();
            
            $zone = $get_zone[0]->id_zone;
            
//            dd($get_zone);
//            die();

//            foreach ($get as $zone_result) {
//                $post_back_url[] = $zone_result->post_back_url;
//                $zone[] = $zone_result->id_zone;
//
//            }
          
            $select = ["smartmanualcorn.parent_cca","smartmanualcorn.campaign_id","smartmanualcorn.status"];
            $data =  DB::table("smartmanualcorn")
                ->select($select)  
                -> where($condtion)
                ->where('status','=',0)
                ->limit(1);
            $data =  $data->get();
            $cron_array = json_decode(json_encode($data), true);
            if(!empty($cron_array)){
                $status = array('status'=>2, 'message' => 'Already in process');
            }else{
                $manualcron = new \App\SmartManualcorn;
                $manualcron->parent_cca = $request->cca;
                $manualcron->network_id = $zone;                
                $manualcron->activation_count = $request->activation;
                $manualcron->op_id = $request->id_ad;
                $manualcron->price = $request->price;
                $manualcron->campaign_id = isset($request->campaign) ? $request->campaign:0;
                $manualcron->siteid = $request->siteid;
                $manualcron->pubid = $request->pubid;
                $manualcron->priority = $request->priority;
                $manualcron->save();
                if($manualcron->id)
                {
                    $status = array('status'=>1, 'message' => 'Cron is succesfully saved');
                }
                else
                {
                    $status = array('status'=>0, 'message' => 'Cron is not saved');
                }
            }        
       
        $status = Response::json($status);
        return $status;


   }
    public function cancel_smart_manual_cron(Request $request){
        
        $result  = array('data1' => []);
          $condtion = [];
          $con = [];
          $ids = $request->del_id;

          if($request->del_id && $request->del_id !=''){
           array_push($condtion,['id','=',$request->del_id] ); 
           array_push($con,['id','=',$request->del_id] ); 
          }
            
          
            $select = ["smartmanualcorn.parent_cca","smartmanualcorn.campaign_id","smartmanualcorn.status"];
            $data =  DB::table("smartmanualcorn")
                ->select($select)  
                ->where($condtion)
                ->wherein('status', [0,-1])
                ->limit(1);
            $data =  $data->get();
            $cron_array = json_decode(json_encode($data), true);
            if(!empty($cron_array))
            {
                try
                { 
                    $update = DB::table('smartmanualcorn')
                        ->where('id',$ids)
                        ->update(array('status' => '4'));
                }
                catch(\Illuminate\Database\QueryException $ex)
                {
                    dd($ex->getMessage());
                }
                if($update)
                {
                    $status = array('status'=>1,'message'=>'Cancelled','id'=>$request->del_id);
                }else
                {
                    $status = array('status'=>0,'message'=>'not updated'); 
                }
                
            }
            else
            {
                $status = array('status'=>2, 'message' => 'Already Processed');
            }        
       
        $status = Response::json($status);
        return $status;


   }
   
}
