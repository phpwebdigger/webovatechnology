<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\QueryAccess;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Auth;

class QueryTechController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('query_tech',['totalRows'=>'','results'=>[],'query'=>'']);
    }


    public function execute(Request $req)
    {
     $query = trim($req->querycheck);
            try{
    		    $data =  DB::select(DB::raw($query));
//    		    $totalCount =  DB::select(DB::raw($query->count()));
//                    $totalCount = mysql_num_rows($data);
                    $totalCount = count($data);
             
	    	   	return view('query_tech',['results'=>$data,'totalRows'=>$totalCount,'query'=>$query]);
    	    	}
    	catch(\Illuminate\Database\QueryException $ex){ 
  					dd($ex->getMessage()); 
  				return view('query_tech',['results'=>[],'errors'=>'query in not correct']);
 					 
		}


        
    }
    public function getAccess(Request $request)
    {
           $keyword = $request->get('search');
           $perPage = 10;

           if (!empty($keyword)) {
               $QueryAccess = QueryAccess::where('name', 'LIKE', "%$keyword%")
                ->with('User')->orderBy('id','DESC')->paginate($perPage);
           } else {

              $QueryAccess = QueryAccess::with('User')->orderBy('id','DESC')->paginate($perPage);
         
           }
      
           return view('queryaccess', compact('QueryAccess'));
    }
}
