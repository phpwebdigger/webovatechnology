<?php

namespace App\Http\Controllers;
use App\User;
use App\Role;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Cookie;
use App\UrlRedirectionInfo;


class UrlRedirectionInfoController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

    function data(Request $request){
        
//        echo "<pre>";
//        print_r($request->all());
//        echo "</pre>";
        
        
        $from_date = $request->from;
        $to_date = $request->to;
        
        $hour = $request->hour;
        $advert = $request->advertiser;
        $oper = $request->operator;
        $response = $request->response;
        $loop_status = $request->loop_back_status;
        
        
        
        
        if($from_date == '')
        {
            $from_date = date('Y-m-d');
        }
        if($to_date == '')
        {
            $to_date = date('Y-m-d');
        }
        if($hour == '')
        {
            $hour = date('H');
//            $hour = '0';
        }
        
        if($hour == 'ALL')
        {
            $hour = '0';
        }
        
        $to_time = date(' H:i:s');
        $time = ' '.$hour.':00:00';
        
        
        $date_from = $from_date.$time;
        $date_to = $to_date.$to_time;

//        echo "From Date = ".$date_from."<br>";
//        echo "To Date = ".$date_to."<br>";
//        die();
        $condtions=[];
        
        array_push($condtions, ['url_redirection_info.request_date_time','>=',$date_from]);
        array_push($condtions, ['url_redirection_info.request_date_time','<=',$date_to]);
        
        if($advert != 'null' && $advert != '')
        {
            array_push($condtions,['advertiser_campaigns.id_advertiser','=',$advert]);  
        }
        if($oper != 'null' && $oper != '')
        {
            array_push($condtions,['advertiser_campaigns.id_op','=',$oper]);  
        }
        if($response != 'null' && $response != '')
        {
            array_push($condtions,['url_redirection_info.http_response_code','=',$response]);  
        }
        if($loop_status != 'null' && $loop_status != '')
        {
            array_push($condtions,['url_redirection_info.loopBack_status','=',$loop_status]);  
        }
        
        
        $select =  [
            "url_redirection_info.id_advertiser",
            "url_redirection_info.src_url",
            "url_redirection_info.dest_url",
            "url_redirection_info.http_response_code",
            "url_redirection_info.loopBack_status",
            "url_redirection_info.request_date_time",
            "advertiser_campaigns.id_advertiser as adv_id",
            "advertiser_campaigns.id as camp_id",
            "advertiser_campaigns.id_op",
            "advertiser_campaigns.country_code as c_code",
            "operator.name as opr_name",
            "advertiser.name as adv_name",
            
            ];

        $data =  DB::table("url_redirection_info")
        ->select($select)
        ->where($condtions)
        ->leftJoin("advertiser_campaigns","advertiser_campaigns.id","=","url_redirection_info.id_advertiser")
        ->leftJoin("operator","operator.id","=","advertiser_campaigns.id_op")
        ->leftJoin("advertiser","advertiser.id","=","advertiser_campaigns.id_advertiser")
        ->orderBy('url_redirection_info.request_date_time', 'DESC')
//        ->limit(100)
         ->get();
        $data1= [];
        $count = 0;
         
         
//        dd($data);die();
         
        foreach ($data as $result) {
               $array = [];

               $count++;
               array_push($array,
                        '<a title="View Info In Details" href="view-redirectinfo-details/'.$result->id_advertiser.'"<i class="fa fa-eye">('.$result->camp_id.')</i>',
                           $result->adv_name,
                           $result->opr_name.' ('.$result->c_code.') ',
                           $result->src_url,
                           $result->dest_url,
                           $result->http_response_code,
                           $result->loopBack_status,
                           $result->request_date_time
                       
                       );
               array_push($data1, $array);

        }
//        $operators =  DB::table("advertiser_campaigns")
//                                  ->leftJoin("operator","operator.id","=","advertiser_campaigns.id_op")
//                                  ->selectRaw(DB::raw("distinct advertiser_campaigns.id_op as id_op,operator.name as operator,advertiser_campaigns.country_code as c_code"))
//                                  ->orderby("operator.name","ASC")->get();
        $operators =  DB::table("operator")
                                  ->leftJoin("country","operator.country_code","=","country.iso")
                                  ->selectRaw(DB::raw("operator.id as id_op, operator.name as operator,country.iso as c_code"))
                                  ->orderby("operator.name","ASC")->get(); 
        $advertiser =  DB::table("advertiser_campaigns")
                          ->leftJoin("advertiser","advertiser_campaigns.id_advertiser","=","advertiser.id")
                          ->selectRaw(DB::raw("distinct advertiser_campaigns.id_advertiser as id_advertiser, advertiser.name as campaign_advertiser"))
                          ->orderby("advertiser.name","ASC")->get(); 
        $loop_back_status =  DB::table("url_redirection_info")
                          ->selectRaw(DB::raw("distinct loopBack_status"))
                          ->orderby("loopBack_status","ASC")->get(); 
        $responseCode =  DB::table("url_redirection_info")
                          ->selectRaw(DB::raw("distinct http_response_code"))
                          ->orderby("http_response_code","ASC")->get(); 
          
        
        $view = 'redirect.redirectInfo-data';
        return view($view,compact('data1','from_date','to_date','advert','oper','response','loop_status','hour','advertiser','operators','loop_back_status','responseCode'));
    }
    
  
}
