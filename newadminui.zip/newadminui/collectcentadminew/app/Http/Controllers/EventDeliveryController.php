<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\QueryAccess;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Database\QueryException;
use Auth;
use App\Ad;
use App\ConfigDelivery;
use App\DeliveryMapping;
use App\MaskingConfigDelivery;
use App\ConfigDeliveryEvent; 
use Illuminate\Support\Facades\Redis;
use Cache;
use Log;
use App\CronConfig;use Response;
use Session;

class EventDeliveryController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request,$view = 'event.event_mgmt')
    {

        $zone = array();
        $post_back_url = array();
        
        
        $select =  
        [
            "delivery_mapping.id as id", 
            "delivery_mapping.id_channel as id_channel", 
            "delivery_mapping.s2s_offerwall as s2s_offerwall", 
            "delivery_mapping.parent_cca as parent_cca", 
            "delivery_mapping.campaign_id as campaign_id", 
            "delivery_mapping.publisher_goal_id as publisher_goal_id", 
            "delivery_mapping.event_name as event_name", 
            "delivery_mapping.sale as sale", 
            "delivery_mapping.event_postback as event_postback",
            "delivery_mapping.filter as filter",
            "delivery_mapping.status as status",
            "ad_network.name as network_name", 
            "ad_network.ccz as ccz",
            "ac.name as campaign_name"
        ];
        
        
        $condtions=[];
        $id_ad = $request->id_ad;
        $id_zone = $request->zone;
//        $filter_stat=$request->filter_status;
//        $opname=$request->opname;
        $postback_status=$request->status;
//        $ntname=$request->ntname;
//
        if(isset($request->id_ad)){
          array_push($condtions, ['delivery_mapping.parent_cca','=',$request->id_ad]);
        }
        if(isset($request->zone))
        {
          array_push($condtions, ['delivery_mapping.id_channel','=',$id_zone]);
        }
//
//        if(isset($request->ntname) && $request->ntname!=0){
//          array_push($condtions, ['config_delivery.id_zone','=',$request->ntname] );
//        }

        
//        if(isset($request->filter_status)){
//         array_push($condtions, ['config_delivery.filter_status','=',$request->filter_status] );
//        }
        if(isset($request->status)){
          array_push($condtions, ['delivery_mapping.status','=',$postback_status] );
        }

        $data =  DB::table("delivery_mapping as delivery_mapping")
            ->select($select)
            ->where($condtions)
            ->leftJoin("ad_network as ad_network","ad_network.ccz","=","delivery_mapping.id_channel")
            ->leftJoin("advertiser_campaigns as ac","ac.id","=","delivery_mapping.campaign_id")
            ->orderBy('delivery_mapping.id', 'desc')
//            ->limit(100)
            ->get();
            $data1= [];
            $count = 0;
        
//        echo "<pre>";
//        print_r($data);
//        echo "</pre>";die();
            
            foreach ($data as $result) 
            {
                $array = [];
                $delvchecked = $is_filter_active = $check = $is_postback_active = "";
                $post_back_status = $filter_status = $dlv_ststs = "Off";
                
                $is_child_text =  "Inactive";
                
                if($result->status == 1)
                {
                    $is_postback_active = "checked";
                    $post_back_status = "On";
                }
                

                $count++;
                array_push($array,
                    $result->network_name.' {'.$result->id_channel.' }',
                    $result->parent_cca,
                    $result->campaign_name.' {'.$result->campaign_id.' }',
                    $result->publisher_goal_id,
                    $result->event_name,
                    $result->sale,
                    $result->filter,
                    '<input type ="checkbox" '.$is_postback_active.' name="postback_status" id=postback_'.$result->id.' class="statusUpdate"><span id="postback_status-'.$result->id.'">'.$post_back_status.'</span>',
                    $result->event_postback,                    
                    '<a href="/event/edit/'.$result->id.'/'.$result->id_channel.'"><button type="button" class="btn btn-success btn-circle "><i class="fa fa-edit"></i> </button></a>'
                );
                array_push($data1, $array);                
            }
            
        return view($view,compact('data1','id_ad','filter_stat','opname','postback_status','ntname','filter_status','id_zone'));
    }
    
    
    
    
    
    
    
    public function index2(Request $request,$view = 'delivery.delivery_mgmt'){

        $select =  [
            "config_delivery.id",
            "config_delivery.id_zone",
            "ads.id_ad",
            "config_delivery.lower_limit",
            "config_delivery.higher_limit",
            "config_delivery.filter_status",
            "config_delivery.post_back_url",
            "config_delivery.postback_status",
            "config_delivery.is_child",
            "config_delivery.is_offer",
            "ads.cco",
            "ads.operator_name",
            "ads.traffic_type", 
            "ads.delivery_status", 
            //  "ads.operator_name",
            "ads.network_name"
        ];
        $condtions=[];
        $id_ad = $request->id_ad;
        $filter_status=$request->filter_status;
        $opname=$request->opname;
        $postback_status=$request->postback_status;
        $ntname=$request->ntname;

        if(isset($request->id_ad)){
          array_push($condtions, ['ads.id_ad','=',$request->id_ad]);
        }

        if(isset($request->ntname) && $request->ntname!=0){
          array_push($condtions, ['config_delivery.id_zone','=',$request->ntname] );
        }
        if(isset($request->opname)){
          array_push($condtions, ['ads.cco','=',$request->opname] );
        }
        if(isset($request->filter_status)){
         array_push($condtions, ['config_delivery.filter_status','=',$request->filter_status] );
        }
        if(isset($request->postback_status)){
          array_push($condtions, ['config_delivery.postback_status','=',$request->postback_status] );
        }

        $data =  DB::table("config_delivery")
            ->select($select)
            ->where($condtions)
            ->leftJoin("ads","ads.id_ad","=","config_delivery.id_ad")
            ->orderBy('id_ad', 'desc')
            ->limit(100)
            ->get();
            $data1= [];
            $count = 0;
            foreach ($data as $result) {
                $array = [];
                $delvchecked = $is_filter_active = $check = $is_postback_active = "";
                $post_back_status = $filter_status = $dlv_ststs = "Off";
                $is_child_text =  "Inactive";
                if($result->filter_status == 1){
                    $is_filter_active = "checked";
                    $filter_status = "On";
                }
                if($result->postback_status == 1){
                    $is_postback_active = "checked";
                    $post_back_status = "On";
                }
                if($result->is_child == '1'){
                  $is_child_text = "Active";
                }
                if($result->delivery_status == 1){
                    $delvchecked = "checked=checked";
                    $dlv_ststs = "On";
                }

                $count++;
                array_push($array,
                            $result->traffic_type,
                            $is_child_text,
                            $result->network_name,
                            $result->id_zone,
                            $result->id_ad,
                            $result->operator_name.'('.$result->cco.')',
                            '<span id="percentage_'.$result->id.'" class="container-lowerlimit"><span id="lowerInnerContainer_'.$result->id.'" class="lowerInnerContainer">'.$result->lower_limit.'<a href="javascript:void(0)" class="edit-percentage" data-id="'.$result->id.'" data-value="'.$result->lower_limit.'"><span class="glyphicon glyphicon-pencil"></span></a></span><span id="inputLowerLimit_'.$result->id.'"></span></span>',
                            '<input type ="checkbox" '.$is_filter_active.' name="filter_status" id=filter_'.$result->id.' class="statusUpdate"><span id="filter_status-'.$result->id.'">'.$filter_status.'</span>',
                            '<input type ="checkbox" '.$is_postback_active.' name="postback_status" id=postback_'.$result->id.' class="statusUpdate"><span id="postback_status-'.$result->id.'">'.$post_back_status.'</span>',
                            '<input type ="checkbox" '.$delvchecked.' name="delivery_status" id="delivery_'.$result->id_ad.'"  class="statusUpdate"><span id="delivery_status-'.$result->id_ad.'">'.$dlv_ststs.'</span>',
                            $result->is_offer == 1 ? "Yes":"No",
                            '<a href="/delivery/edit/'.$result->id.'/'.$result->id_zone.'"><button type="button" class="btn btn-success btn-circle "><i class="fa fa-edit"></i> </button></a>',
                            '<span  class="urltext"  title="'.$result->post_back_url.'" style="max-width: 100px;overflow: none">'.$result->post_back_url.'</span><input type="text" class="hide" value="'.$result->post_back_url.'">'                          
                        );
                array_push($data1, $array);
            }
        return view($view,compact('data1','id_ad','filter_status','opname','postback_status','ntname'));
    }


    function smart_index(Request $request){
      $view = 'delivery.smart_index';
      return $this->index($request,$view);
    }
    
    function smart_index2(Request $request){
        
        if($request->auth === 'sanjeev')
        {
            $view = 'delivery.smart_index2';
            return $this->index2($request,$view);
        }
        else
        {
            echo '<script>window.location.href = "http://162.243.33.148/report/index.php";</script>';
            exit;
        }
        
        
      
    }
    
    function smart_index_event(Request $request){
      $view = 'delivery.smart_index_event';
      return $this->index_event($request,$view);
    }
    
    public function index_event(Request $request,$view){

        
        $select =  [
            "config_delivery_event.id",
            "config_delivery_event.id_zone",
            "ads.id_ad",
            "config_delivery_event.lower_limit",
            "config_delivery_event.higher_limit",
            "config_delivery_event.filter_status",
            "config_delivery_event.post_back_url",
            "config_delivery_event.postback_status",
            "config_delivery_event.id_advertiser",
            "ads.cco",
            "ads.operator_name",
            "ads.traffic_type",
            //  "ads.operator_name",
            "ads.network_name"
        ];
        $condtions=[];
        $id_ad = $request->id_ad;
        $filter_status=$request->filter_status;
        $opname=$request->opname;
        $postback_status=$request->postback_status;
        $ntname=$request->ntname;

        if(isset($request->id_ad)){
          array_push($condtions, ['ads.id_ad','=',$request->id_ad]);
        }

        if(isset($request->ntname) && $request->ntname!=0){
          array_push($condtions, ['config_delivery_event.id_zone','=',$request->ntname] );
        }
        if(isset($request->opname)){
          array_push($condtions, ['ads.cco','=',$request->opname] );
        }
        if(isset($request->filter_status)){
         array_push($condtions, ['config_delivery_event.filter_status','=',$request->filter_status] );
        }
        if(isset($request->postback_status)){
          array_push($condtions, ['config_delivery_event.postback_status','=',$request->postback_status] );
        }

        $data =  DB::table("config_delivery_event")
            ->select($select)
            ->where($condtions)
            ->leftJoin("ads","ads.id_ad","=","config_delivery_event.id_ad")
            ->orderBy('id_ad', 'desc')
            ->limit(100)
            ->get();
            $data1= [];
            $count = 0;
            foreach ($data as $result) {

                $array = [];
                $delvchecked = $is_filter_active = $check = $is_postback_active = "";
                $post_back_status = $filter_status = "Off";
                
                if($result->filter_status == 1){
                    $is_filter_active = "checked";
                    $filter_status = "On";
                }
                if($result->postback_status == 1){
                    $is_postback_active = "checked";
                    $post_back_status = "On";
                }



                $count++;
                array_push($array,
                            $result->id_advertiser,
                            $result->traffic_type,
                            $result->network_name,
                            $result->id_zone,
                            $result->id_ad,
                            $result->operator_name.'('.$result->cco.')',
                            '<span id="percentage_'.$result->id.'" class="container-lowerlimit"><span id="lowerInnerContainer_'.$result->id.'" class="lowerInnerContainer">'.$result->lower_limit.'<a href="javascript:void(0)" class="edit-percentage" data-id="'.$result->id.'" data-value="'.$result->lower_limit.'"><span class="glyphicon glyphicon-pencil"></span></a></span><span id="inputLowerLimit_'.$result->id.'"></span></span>',
                            '<input type ="checkbox" '.$is_filter_active.' name="filter_status" id=filter_'.$result->id.' class="statusUpdate"><span id="filter_status-'.$result->id.'">'.$filter_status.'</span>',
                            '<input type ="checkbox" '.$is_postback_active.' name="postback_status" id=postback_'.$result->id.' class="statusUpdate"><span id="postback_status-'.$result->id.'">'.$post_back_status.'</span>',
                            '<a href="/delivery_event/edit/'.$result->id.'/'.$result->id_zone.'"><button type="button" class="btn btn-success btn-circle "><i class="fa fa-edit"></i> </button></a>',
                            '<span  class="urltext"  title="'.$result->post_back_url.'" style="max-width: 100px;overflow: none">'.$result->post_back_url.'</span><input type="text" class="hide" value="'.$result->post_back_url.'">'                            
                        );
                array_push($data1, $array);

                
            }
        return view($view,compact('data1','id_ad','filter_status','opname','postback_status','ntname'));
    }
    
    public function add_event(Request $request,$is_smart = null){
        $campaigns = DB::select("select id,name from advertiser_campaigns where status = '1'");
//        
//        die();
        
        return view('delivery.delivery_add_event',["errors"=>"","success"=>"",'is_smart'=>$is_smart],compact('campaigns'));
    }
    
    public function smart_event_add(Request $request){
        
        return $this->add_event($request,'smart');
    }
    
    public function add_delivery_event(Request $request,$is_smart = null){
        
        $campaigns = DB::select("select id,name from advertiser_campaigns where status = '1'");
//        echo "<pre>";
//        print_r($request->all());
//        echo "</pre>";
//        die();
        
        $id_zone = $request->ccz;
        $id_ad = $request->cca[0];
        $id_advertiser = $request->id_advertiser;
        $post_back_url = $request->post_back_url;
        $postback_status = $request->postback_status;
        $filter_status = $request->filter_status;
        $lower_limit = $request->lower_limit;
        $higher_limit = $request->higher_limit;

        if($postback_status == 'on')
        {
            $postback_status = '1';
        }
        else
        {
            $postback_status = '0';
        }
        if($filter_status == 'on')
        {
            $filter_status = '1';
        }
        else
        {
            $filter_status = '0';
        }

            $dataS  = array(
                'id_zone'=>$id_zone,
                'id_ad'=>$id_ad,
                'lower_limit'=>$lower_limit,
                'higher_limit'=>$higher_limit,
                'filter_status'=>$filter_status,
                'post_back_url'=>trim($post_back_url),
                'postback_status'=>$postback_status,
                'id_advertiser'=>$id_advertiser
            );
            
//            echo "<pre>";
//            print_r($dataS);
//            echo "</pre>";
//            die();
            
            
            
 
            $success = ConfigDeliveryEvent::insert($dataS);
            
            
            if($success == true)
            {
                return view('delivery.delivery_add_event',["errors"=>"","success"=>"Successfully added",'is_smart'=>$is_smart],compact('campaigns'));
            }
    }

    function offerdelivery(Request $request){
       $select =  [
            "config_delivery.id",
            "config_delivery.id_zone",
            "config_delivery.id_ad as campaign_id",
            "config_delivery.lower_limit",
            "config_delivery.higher_limit",
            "config_delivery.filter_status",
            "config_delivery.post_back_url",
            "config_delivery.postback_status",
            "config_delivery.is_child",
            "config_delivery.is_offer",
            "advertiser_campaigns.id_op",
            "advertiser_campaigns.ads_cat as traffic_type",
            "advertiser_campaigns.name as campaign_name", 
//             "ads.delivery_status", 
//            "ads.operator_name",
            "ad_network.name as network_name"
          ];
        $condtion = [];
        $id_ad = $request->id_ad;
        if($request->id_ad){
          array_push($condtion,['advertiser_campaigns.id','=',$request->id_ad] );
        }
        if($request->ntname){
          array_push($condtion,['config_delivery.id_zone','=',$request->ntname] );
        }
        if($request->opname){
          array_push($condtion,['ads.id_op','=',$request->opname] );
        }
        if($request->filter_status){
          array_push($condtion,['config_delivery.filter_status','=',$request->filter_status] );
        }
        if($request->postback_status){
          array_push($condtion,['config_delivery.postback_status','=',$request->postback_status] );
        }
        array_push($condtion,['config_delivery.is_offer','=','1']); 
        $data = DB::table("config_delivery")
         ->select($select)
         ->leftJoin("advertiser_campaigns","advertiser_campaigns.id","=","config_delivery.id_ad")
         ->leftJoin("ad_network","ad_network.ccz","=","config_delivery.id_zone")
         ->where($condtion)
         ->orderBy('id_ad', 'desc')
         ->limit(100)
         ->get();
         $data1= [];
         $count = 0;
          foreach ($data as $result) {
                $array = [];
                $delvchecked = $is_filter_active = $check = $is_postback_active = "";
                $post_back_status = $filter_status = $dlv_ststs = "Off";
                $is_child_text =  "Inactive";
                if($result->filter_status == 1){
                    $is_filter_active = "checked";
                    $filter_status = "On";
                }
                if($result->postback_status == 1){
                    $is_postback_active = "checked";
                    $post_back_status = "On";
                }
                if($result->is_child == '1'){
                  $is_child_text = "Active";
                }
                /* 
                if($result->delivery_status == 1){
                    $delvchecked = "checked=checked";
                    $dlv_ststs = "On";
                }
                */
                $count++;
                array_push($array,
                            $result->traffic_type,
                            $is_child_text,
                            $result->network_name,
                            $result->id_zone,
                            $result->campaign_id,
                            $result->campaign_name,
                            '<span id="percentage_'.$result->id.'" class="container-lowerlimit"><span id="lowerInnerContainer_'.$result->id.'" class="lowerInnerContainer">'.$result->lower_limit.'<a href="javascript:void(0)" class="edit-percentage" data-id="'.$result->id.'" data-value="'.$result->lower_limit.'"><span class="glyphicon glyphicon-pencil"></span></a></span><span id="inputLowerLimit_'.$result->id.'"></span></span>',
                            '<input type ="checkbox" '.$is_filter_active.' name="filter_status" id=filter_'.$result->id.' class="statusUpdate"><span id="filter_status-'.$result->id.'">'.$filter_status.'</span>',
                            '<input type ="checkbox" '.$is_postback_active.' name="postback_status" id=postback_'.$result->id.' class="statusUpdate"><span id="postback_status-'.$result->id.'">'.$post_back_status.'</span>',
                            // '<input type ="checkbox" '.$delvchecked.' name="delivery_status" id="delivery_'.$result->id_ad.'"  class="statusUpdate"><span id="delivery_status-'.$result->id_ad.'">'.$dlv_ststs.'</span>',
                            $result->is_offer == 1 ? "Yes":"No",
                            '<a href="/delivery/edit/'.$result->id.'"><button type="button" class="btn btn-success btn-circle "><i class="fa fa-edit"></i> </button></a>',
                            '<span  class="urltext"  title="'.$result->post_back_url.'" style="max-width: 100px;overflow: none">'.$result->post_back_url.'</span><input type="text" class="hide" value="'.$result->post_back_url.'">');
                array_push($data1, $array);

            }
          return view('delivery.offerdelivery',compact('data1','id_ad'));
    }

    /*To change ads status */
    public function updateSmtUrlSt(Request $request)
    {
//        echo "<pre>";
//        print_r($request->all());
//        echo "</pre>";
//        die();
        
//        $action = $request->action;
//        $fields = $action.'_status';
        $id = $request->id;
        $check_value = $request->check_value;
        try { 
          $update = DB::table('delivery_mapping')
                ->where('id',$id)
                ->update(array('status' => $check_value));
        }catch(\Illuminate\Database\QueryException $ex){
          dd($ex->getMessage());
        }
        if($update){
          $status = array('status'=>1,'message'=>'updated','id_ad'=>$request->id,'check_value'=>$request->check_value);
        }else{
          $status = array('status'=>2,'message'=>'not updated'); 
        }
        return json_encode($status);
    }

    public function add(Request $request,$is_smart = null){
        return view('event.event_add',["errors"=>"",'is_smart'=>$is_smart]);
    }
    
    public function smartadd(Request $request){
        return $this->add($request,'smart');
    }

    public function store(Request $request)
    {
        
//        echo "<pre>";
//        print_r($request->all());
//        echo "</pre>";
//        die();
        
        $id_zone = $request->ccz;        
        $cca = $request->parent_cca;        
        $camp_id = $request->campaign_id;        
        $event_name = $request->event_name;        
        $sale_count = $request->sale_count;        
        $post_back_url = $request->post_back_url;
        $publisher_goal_id = $request->publisher_goal_id;
        $postback_status = $request->postback_status;
        $filter_data = $request->filter_data;
        $postback_status = $postback_status == "on" ? '1' : '0' ;
        
//        $temp_cron  = array(
//            'id_channel'=> $id_zone,
//            'parent_cca'=>$cca,
//            'campaign_id'=>$camp_id,
//            'event_name'=>$event_name,
//            'sale'=>$sale_count,
//            'event_postback'=>$post_back_url,
//            'filter'=>$filter_data,
//            'status'=>$postback_status,
//        );
        
        $list_add = [
            'id_channel'=> $id_zone,
            'parent_cca'=>$cca,
            'campaign_id'=>$camp_id,
            'publisher_goal_id'=>$publisher_goal_id,
            'event_name'=>$event_name,
            'sale'=>$sale_count,
            'event_postback'=>$post_back_url,
            'filter'=>$filter_data,
            'status'=>$postback_status,
        ];
        
        
//        array_push($cronData,$temp_cron);
        
        $del_map = new \App\DeliveryMapping;
        $del_map::insert($list_add);
        
        return view('event.event_add',['results'=>[],'errors'=>'Event Delivery is successfully added']);
        
//        // print"<pre>";print_r($data);die; 
//        if(sizeof($data) != 0){
//          $checkVal = $data[0]->id_ad;
//          if($checkVal != ''){
//            return view('delivery.delivery_add',['results'=>[],'errors'=>'There is already an entry for '.$checkVal.' cca']); 
//          }
//        }
//        if($request->isCron == 'on'){
//          $cronData = DB::table("cron_config")->select(["id_ad"])->where("ccz",'=',$id_zone)->whereIN("id_ad",$id_ad)->get();
//          if(sizeof($cronData) > 0){
//            return view('delivery.delivery_add',['results'=>[],'errors'=>'Cron already exist please uncheck cron option']);  
//          }
//        }
//            $dataS  = array(
//                      'id_zone'=>$id_zone,
//                      'id_ad'=>$id_ad[0],
//                      'lower_limit'=>$lower_limit,
//                      'higher_limit'=>$higher_limit,
//                      'filter_status'=>$filter_status,
//                      'post_back_url'=>trim($post_back_url),
//                      'postback_status'=>$postback_status
//                    );  
//            
////            echo "<pre>";
////            print_r($dataS);
////            echo "</pre>";die();
//          if(count($id_ad) < 1){
//              if($isChild == '1' && $childId!=''){
//                  $dataS[0]['is_child'] = $isChild;
//                  $dataS[0]['id_child'] = $childId;
//                  ConfigDelivery::create($dataS);
//                  if($request->isCron == 'on'){
//                        $this->createCron($request);
//                  }
//                  $this->adsUpdate($request);
//               }else if($isChild == '0'){
//                   ConfigDelivery::create($dataS);
//                   $this->createCron($request);
//               }else if($isChild == '1' && $childId == ''){
//                  return view('delivery.delivery_add',['results'=>[],'errors'=>'Enter id for Child']);
//               }
//          }else{
//                $data = $cronData = [];
//                foreach($id_ad as $cca){
//                   $temp = [];
//                   $temp_cron =  [];
//                   $temp = array(
//                              'id_zone' => $id_zone,
//                              'id_ad' => $cca,
//                              'lower_limit' => $lower_limit,
//                              'higher_limit'=>$higher_limit,
//                              'filter_status'=>$filter_status,
//                              'post_back_url'=>trim($post_back_url),
//                              'postback_status'=>$postback_status
//                            );
//                array_push($data,$temp);
//                if($request->isCron == 'on'){     
//                    $temp_cron  = array(
//                        'title'=> $request->title,
//                        'ccz'=>$request->ccz,
//                        'id_ad'=>$cca,
//                        'time_interval'=>20,
//                        'lower_cr_in_percentage'=>0,
//                        'higher_cr_in_percentage'=>0,
//                        'network_callback_url'=>trim($post_back_url),
//                        'status'=>0,
//                        );
//                      array_push($cronData,$temp_cron);
//                                 
//                  }
//             }
//              ConfigDelivery::insert($data);  
//              if($request->isCron == 'on'){ 
//                  CronConfig::insert($cronData);
//              }   
//          }
//        return view('event.event_add',['results'=>[],'errors'=>'Event Delivery is successfully submited']);
    }

    
    function createCron($request){
      if($request->isCron = 'on'){
         $cronData  = array(
                  'title'=> $request->title,
                  'ccz'=>$request->ccz,
                  'id_ad'=>$request->cca,
                  'time_interval'=>20,
                  'lower_cr_in_percentage'=>0,
                  'higher_cr_in_percentage'=>0,
                  'network_callback_url'=>$request->post_back_url,
                  'status'=>0,
                  );
         CronConfig::create($cronData);
      }      
    }

    function adsUpdate($request){
      $childId = $request->childId;
      if($childId != ''){
            $Ads = Ad::select(["description","network_postback_source"])
                      ->where([["id_ad","=",$childId]])
                      ->get()->toArray();
            $checkVal2 = $Ads[0]['description'];
            if($checkVal2 == 'default'){
              $ads->outward_status = '1';
              $Ads->save();
            }
        }
    }

    public function edit($id, $id_zone){
        
        
        
        $condition = [];            
        array_push($condition,['id','=',$id]);
        
        $select_post =  ["id","id_channel","parent_cca","campaign_id","publisher_goal_id","event_name",
            "sale","event_postback", "filter", "status"];
               
        $delivery =  DB::table("delivery_mapping")
            ->where($condition)
            ->select($select_post)
            ->limit(1)
            ->get();
//		echo '<pre>';print_r($delivery);echo '<pre>';


        $id_zne = $delivery[0]->id_channel;
        $id = $delivery[0]->id;
        $parent_cca = $delivery[0]->parent_cca;
        $campaign_id = $delivery[0]->campaign_id;
        $publisher_goal_id = $delivery[0]->publisher_goal_id;
        $event_name = $delivery[0]->event_name;
        $sale = $delivery[0]->sale;
        $event_postback = $delivery[0]->event_postback;
        $filter = $delivery[0]->filter;
        $status_data = $delivery[0]->status;

        
        $status = 
                    [
                        'id'=>$id,'id_zone'=>$id_zne,'parent_cca'=>$parent_cca,'campaign_id'=>$campaign_id,'publisher_goal_id'=>$publisher_goal_id,
                        'event_name'=>$event_name,'sale'=>$sale,'event_postback'=>$event_postback, 'filter'=>$filter,
                        'status'=>$status_data
                    ];

//        $select = ["ad_network.name","ad_network.ccz"];
//        $select1 = ["ads.id_ad","ads.title"];
//        $data1 =  DB::select("select ads.id_ad,ads.title from ads inner join config_delivery as CD on ads.id_ad = CD.id_ad where CD.id_zone = $id_zne");     
//        return view('event.event_edit',compact('status','data1'));
        return view('event.event_edit',compact('status'));
    }



    public function update(Request $req)
    {
//        echo "<pre>";
//        print_r($req->all());
//        echo "</pre>";
//        die();

        
        $campaign_id = $req->campaign_id;
        $event_name = $req->event_name;
        $sale_count = $req->sale_count;
        $post_back_url = $req->post_back_url;
        $publisher_goal_id = $req->publisher_goal_id;
        $postback_status = $req->postback_status;
        $filter = $req->filter_data;
        
        $deliv = DeliveryMapping::find($req->id);
        $deliv->campaign_id = $campaign_id;
        $deliv->publisher_goal_id = $publisher_goal_id;
        $deliv->event_name = $event_name;
        $deliv->sale = $sale_count;
        $deliv->event_postback = $post_back_url;
        $deliv->filter = $filter;
        $deliv->status = $postback_status;
        
        $deliv->save();
        
        
        
        
        return redirect('/event-delivery');
        
        
        
        
        
        
        
//        $ccz = $req->ccz;
//        
//        if($req->post_back_url == 'NA')
//        {
//            $condition = [];            
//            array_push($condition,['id_zone','=',$ccz]);
//            
//            $select_post =  ["post_back_url"];
//        
//            $get_postback =  DB::table("masking_config_delivery")
//                ->select($select_post)
//                ->where($condition)
//                ->limit(1)
//                ->get();
//            
//            $post_back_url = $get_postback[0]->post_back_url;
//            
//        }
//        else
//        {
//            $post_back_url = $req->post_back_url;
//        }
//        
//        
//        if(count($req->cca) == 1){
//            $is_cca_multiple = 1;
//        }
//        $cca = $req->cca;
//        $cca_string = implode("','",$req->cca);
//        $cca_string = $cca_string;
////        $post_back_url = $req->post_back_url;
//        $postback_status = $req->postback_status;
//        $lower_limit = $req->lower_limit;
//        $higher_limit = $req->higher_limit;
//        $filter_status = $req->filter_status;
//         // $cap_count_conversions=$req->cap_count_conversions;
//	if(count($cca) > 1){ 
//           $updateSql = "Update config_delivery Set post_back_url = '".$post_back_url."'  where ccz = $ccz AND id_ad IN ('".$cca_string."')";
//            $updateresult = DB::statement($updateSql);
//          // print"<pre>";print_r($updateresult);print"</pre>";
//        }
//        $deliv = ConfigDelivery::find($req->id);
//        $deliv->id_zone = $ccz;
//        $deliv->id_ad = $req->id_ad;
//        $deliv->post_back_url = $post_back_url;
//        $deliv->postback_status = $postback_status;
//        $deliv->lower_limit = $lower_limit;
//        $deliv->higher_limit = $higher_limit;
//        $deliv->filter_status = $filter_status;
//	//$deliv->cap_count_conversions = $cap_count_conversions;
//        $deliv->save();
//        return redirect('/delivery');
       
    }
    
    public function update_event(Request $req)
    {
        // print"<pre>";print_r($req->input());die;
        
        
//        echo "<pre>";
//        print_r($req->all());
//        echo "</pre>";die();

        $ccz = $req->ccz_name;
        
        if(count($req->cca) == 1){
            $is_cca_multiple = 1;
        }
        $cca = $req->cca;
        $cca_string = implode("','",$req->cca);
        $cca_string = $cca_string;
        $post_back_url = $req->post_back_url;
        $postback_status = $req->postback_status;
        $lower_limit = $req->lower_limit;
        $higher_limit = $req->higher_limit;
        $filter_status = $req->filter_status;
        $id_advertiser = $req->id_advertiser;
//        if(count($cca) > 1){ 
//           $updateSql = "Update config_delivery_event Set post_back_url = '".$post_back_url."'  where ccz = $ccz AND id_ad IN ('".$cca_string."')";
//            $updateresult = DB::statement($updateSql);
//          // print"<pre>";print_r($updateresult);print"</pre>";
//        }
        $deliv = ConfigDeliveryEvent::find($req->id);
        $deliv->id_zone = $ccz;
        $deliv->id_ad = $req->id_ad;
        $deliv->post_back_url = $post_back_url;
        $deliv->postback_status = $postback_status;
        $deliv->lower_limit = $lower_limit;
        $deliv->higher_limit = $higher_limit;
        $deliv->filter_status = $filter_status;
        $deliv->id_advertiser = $id_advertiser;
        $deliv->save();
        return redirect('/smart-delivery-event');
       
    }

    public function edit_event($id, $id_zone)
    {
        
//        echo "Id ADV = ".$id."<br>";
//        echo "Id Zone = ".$id_zone."<br>";
        
        
        
        $condition = [];            
        array_push($condition,['id','=',$id]);
        
        $select_post =  ["id","id_zone","id_ad","lower_limit","higher_limit","post_back_url","filter_status","postback_status","id_advertiser"];
               
        $delivery =  DB::table("config_delivery_event")
            ->where($condition)
            ->select($select_post)
            ->limit(1)
            ->get();
        
//        dd($delivery);
//        
//        
//        die();

        $id_zne = $delivery[0]->id_zone;
        $id = $delivery[0]->id;
        $id_ad = $delivery[0]->id_ad;
        $lower_limit = $delivery[0]->lower_limit;
        $higher_limit = $delivery[0]->higher_limit;
        $filter_status = $delivery[0]->filter_status;
        $postback_status = $delivery[0]->postback_status;
        $id_advertiser = $delivery[0]->id_advertiser;
        $post_back_url = $delivery[0]->post_back_url;
                
        $status = ['id'=>$id,'id_zone'=>$id_zne,'id_ad'=>$id_ad,'lower_limit'=>$lower_limit,'higher_limit'=>$higher_limit,'post_back_url'=>$post_back_url,'filter_status'=>$filter_status,'postback_status'=>$postback_status,'id_advertiser'=>$id_advertiser];

        $select = ["ad_network.name","ad_network.ccz"];
        $select1 = ["ads.id_ad","ads.title"];
        $data1 =  DB::select("select ads.id_ad,ads.title from ads inner join config_delivery as CD on ads.id_ad = CD.id_ad where CD.id_zone = $id_zne");     
        return view('delivery.delivery_event_edit',compact('status','data1'));
    }

    
    
     public function deliveryreport(Request $request){
      $hour = date("H",time());
      $items = json_decode($this->getDeliveryData());
      $data = [];
      foreach($items as $result){
          $array = [];   
          array_push($array,
                            $result->click_hour,
                            $result->from_server,
                            $result->country,
                            $result->parent_cca,
                            $result->siteid,
                            $result->conversion,
                            $result->activation_mode,
                            $result->id_ad,
                            $result->id_zone,
                            $result->datetime,
                            $result->id_advertiser,
                            $result->price,
                            $result->dollar_price,
                            $result->network_token,
                            $result->cc_token,
                            $result->pubid,
                            $result->status
                        );    
              array_push($data,$array);
        }
      $lastUpdated = $this->lastUpdated();
      return view('delivery.indexdelivery',compact('data','hour','lastUpdated'));
    }

    /**
     * To Show the data on landing page for current day Only
     *
     * @return \Illuminate\Http\Response
     */
    public function getDeliveryData(){
        $redis = Redis::connection();
        $date = date('Y-m-d');
        $key  =  "delivery_$date";
        try {
          if(!$redis->exists($key)){
             $items = $this->getdelivery(); 
             Redis::set($key, $items);
             $redis->expire($key,600);
            }else{
            $items = Redis::get($key);
         }
      } catch (\Exception $e) {
          $items = $this->getconversion();  
          
      }
      return $items; 
    }

    public function getdelivery(){
       $date = date('Ymd');
       $hour = date("H");
       $field = [
                "click_hour",
                "id_ad",
                "id_zone",         
                "datetime",        
                "id_advertiser",   
                "parent_cca",      
                "from_server",     
                "siteid",          
                // "network_token",   
               //  "status",          
                "country",         
                "activation_mode", 
                "dollar_price",
                "cc_token",
                "network_token",
                "status",
                "price",
                'pubid',

      ];
        $fields = implode(",", $field);
        $sql = "SELECT $fields,count(1) as conversion from delivery group by click_hour ORDER BY click_hour DESC";
        $items = DB::select($sql);
        $items = json_encode($items,JSON_NUMERIC_CHECK);
        $items = json_encode(json_decode($items));
        return $items;
    }

  
    public function filterData(Request $request){
        $redis = Redis::connection();
        $current_url = $request->fullUrl();
      $current_url = explode("?",$current_url);
      if(count($current_url) > 1){
         $allParameters = $current_url[1];
         $key = "Deliverydata_$allParameters";
      }
      try{
          if(!$redis->exists($key)){
              $item = $this->getFilterQuery($request);
              Redis::set($key, $item);
              $redis->expire($key,500);
              }else{
               $item = $this->getFilterQuery($request);
              }
      } catch(\Exception $e){
         $item = $this->getFilterQuery($request);
      } 
       return $item;
     }

   function getFilterQuery(Request $request){
      $condition = "1=1";
      $price_field = '';
      $date = explode(" - ",$request->date);
      if(count($date) > 1){
      $startDate = date('Ymd',strtotime($date[0]));
      $endDate = date('Ymd',strtotime($date[1]));
      }
      if($request->exists('from_server') && $request->from_server){
          $server = implode("','",$request->from_server);
      }
      if($request->exists('group_by') && $request->group_by){
          $group_by = implode("','",$request->group_by);
      }
      if($request->exists('click_hour') && $request->click_hour){
      $click_hour = implode("','",$request->click_hour);  
      }

      if($request->parent_cca){
          $condition .= " AND parent_cca IN ('".$request->parent_cca."')";
      }
      if($request->id_ad){
          $condition .= " AND id_ad IN ('".$request->id_ad."')";
      } 
      if($request->id_zone){
          $condition .= " AND id_zone IN ('".$request->id_zone."')";
      }
      if($request->from_server){
          $condition .= " AND from_server IN ('".$server."')";
      }
      if($request->id_advertiser){
          $condition .= " AND id_advertiser IN ('".$request->id_advertiser."')";
      }
      if(trim($request->cc_token)){
          $cc_token = explode(",",$request->cc_token);
      $cc_token = implode("','",$cc_token);
      $condition .= " AND cc_token IN ('".$cc_token."')";
      }
      if(trim($request->network_token)){
      $network_token = explode(",",$request->network_token);
      $network_token = implode("','",$network_token);
          $condition .= " AND network_token IN ('".$network_token."')";
      }
      if($request->click_hour){
          $condition .= " AND click_hour IN ('".$click_hour."')";
      }
      if($request->siteid){
      $siteid = explode(",",$$request->siteid);
      $siteid = implode("','",$siteid);
          $condition .= " AND siteid IN ('".$siteid."')";
      }
      if(trim($request->pubid)){
      $pubid = explode(",",$request->pubid);
      $pubid = implode("','",$pubid);
          $condition .= " AND pubid IN ('".$pubid."')";
      }
      if(trim($request->activation_mode) || $request->exists('activation_mode')){
        if($request->activation_mode !='All'){
          if($request->activation_mode == 'Empty'){
          $condition .= " AND activation_mode = ''";    
          }else{
          $condition .= " AND activation_mode = $request->activation_mode";
          } 
        }
      }
      if(trim($request->http_status)){
       $http_status = explode(",",$request->http_status);
       $http_status = implode("','",$http_status);
          $condition .= " AND http_status IN ('".$http_status."')"; 
      }
      if(trim($request->final_url)){
       $final_url = explode(",",$request->final_url);
       $final_url = implode("','",$final_url);
          $condition .= " AND final_url IN ('".$final_url."')"; 
      }
      if($request->group_by){
          $condition .= " group by $group_by";
          // $condition .= " order by $request->group_by";
          $flag = 1;
          $price_field .= "sum(price) as price,count(1) as conversion"; 
      }else{
         $price_field .= "price";
         $flag=0;
         $conversion = 1; 
         // $condition .= " group by click_hour";

      }

      $field = [
                'click_hour',
                'from_server',
                'country',
                'parent_cca',
                'siteid',
                'id_ad',
                'id_zone',
                'datetime',
                'id_advertiser',
                'price',
                'dollar_price',
                'network_token',
                'cc_token',
                'pubid',
                'status',
                "activation_mode",
          ];
      $fields = implode(",", $field);

      $sql = "Select $fields,$price_field from delivery where 
        $condition";
      $items = DB::select($sql);
      $data = [];
      $total_record = count($items);
      foreach($items as $result){
          if(isset($result->conversion)){
            $conversion =  $result->conversion;
          }
          $array = [];   
          array_push($array,
                            $result->click_hour,
                            $result->from_server,
                            $result->country,
                            $result->parent_cca,
                            $result->siteid,
                            $conversion,
                            $result->activation_mode,
                            $result->id_ad,
                            $result->id_zone,
                            $result->datetime,
                            $result->id_advertiser,
                            $result->price,
                            $result->dollar_price,
                            $result->network_token,
                            $result->cc_token,
                            $result->pubid,
                            $result->status
                        );    
              array_push($data,$array);
        }
      $status =  array('status'=>'1','message'=>'successful','data'=>$data,'total'=>$total_record);
      return json_encode($status);
    }


    function lastUpdated(){
        $date = date('Ymd');
        $table_name = "delivery";
        $lastUpdated = DB::select("SELECT max(click_date_time) as click_date_time from $table_name limit 1");
        $lastUpdated_count = count($lastUpdated);
        if($lastUpdated_count > 0)
          if($lastUpdated[0]->click_date_time){
          return $lastUpdated[0]->click_date_time;  
        }
        return "No Update time";  
      }

    
    /* 
      Ajax function on change of ccz 
    *  return id_ad and title  
    *  Developer : Sumit Manchanda
    *  Date : 4 Jan 2018
    */
    function getAdsByNetwork(Request $request)
    {
        if($request->id_zone)
        {
            $id_zone = $request->id_zone;
            
            $deliveryPostBack =  DB::select("Select distinct(event_postback), count(*) as total from delivery_mapping where id_channel= $id_zone group by event_postback limit 3");
            
            $count = $deliveryPostBack[0]->total;
            $event_url = $deliveryPostBack[0]->event_postback;
//            echo "<pre>";
//            print_r($deliveryPostBack);
//            echo "</pre>";
//            die();
            
            $status = array('status'=>1,'cca'=>$result,'deliveryPostBack'=>$deliveryPostBack, 'total'=>$count, 'event_url'=>$event_url);
//            $status = array('status'=>1,'cca'=>$result,'deliveryPostBack'=>$deliveryPostBack);
            return json_encode($status); 
            
            
//            $get = DB::select("select id from masking_config_delivery where id_zone = $id_zone LIMIT 1 ");
//
//            $id = '';
//            if(!empty($get))
//            {
//                $id = $get[0]->id;
//            }
//           
//            if($id == '')
//            {
//                $table = $request->table; 
//                $tableName = "config_delivery".$table; 
//                $result = DB::select("select concat(id_ad,'(',title,')') as cca , id_ad , title from ads where id_zone = $id_zone AND id_ad NOT IN (select id_ad from $tableName where id_zone = $id_zone)");
//                $select = ['post_back_url','count(*) as num'];
//                $condition = [];
//                array_push($condition,['id_zone','=',$id_zone]);
//                $total = DB::raw("count(*) as total"); 
//                $deliveryPostBack =  DB::select("Select distinct(post_back_url),count(*) as total from config_delivery where id_zone=$id_zone group by post_back_url limit 3");
//                $status = array('status'=>1,'cca'=>$result,'deliveryPostBack'=>$deliveryPostBack);
//                return json_encode($status);                
//            }
//            else
//            {
//                $table = $request->table; 
//                $tableName = "config_delivery".$table; 
//                $result = DB::select("select concat(id_ad,'(',title,')') as cca , id_ad , title from ads where id_zone = $id_zone AND id_ad NOT IN (select id_ad from $tableName where id_zone = $id_zone)");
//                $select = ['post_back_url','count(*) as num'];
//                $condition = [];
//                array_push($condition,['id_zone','=',$id_zone]);
//                $total = DB::raw("count(*) as total"); 
//                $deliveryPostBack =  DB::select("Select distinct(post_back_url),count(*) as total from config_delivery where id_zone=$id_zone group by post_back_url limit 3");
//                $status = array('status'=>1,'cca'=>$result,'deliveryPostBack'=>'');
//                return json_encode($status);         
//            }
            
        }
    }
    function getEventAdsByNetwork(Request $request){
        
//        echo "<pre>";
//        print_r($request->all());
//        echo "</pre>";die();
        
        
      if($request->id_zone){
            $id_zone = $request->id_zone;
            $get = DB::select("select id from masking_config_delivery where id_zone = $id_zone LIMIT 1 ");

            $id = '';
            if(!empty($get))
            {
                $id = $get[0]->id;
            }
           
            if($id == '')
            {
                $table = $request->table; 
                $tableName = "config_delivery_event".$table; 
                $result = DB::select("select concat(id_ad,'(',title,')') as cca , id_ad , title from ads where id_zone = $id_zone AND id_ad NOT IN (select id_ad from $tableName where id_zone = $id_zone)");
                $select = ['post_back_url','count(*) as num'];
                $condition = [];
                array_push($condition,['id_zone','=',$id_zone]);
                $total = DB::raw("count(*) as total"); 
                $deliveryPostBack =  DB::select("Select distinct(post_back_url),count(*) as total from config_delivery_event where id_zone=$id_zone group by post_back_url limit 3");
                $status = array('status'=>1,'cca'=>$result,'deliveryPostBack'=>$deliveryPostBack);
                return json_encode($status);                
            }
            else
            {
                $table = $request->table; 
                $tableName = "config_delivery_event".$table; 
                $result = DB::select("select concat(id_ad,'(',title,')') as cca , id_ad , title from ads where id_zone = $id_zone AND id_ad NOT IN (select id_ad from $tableName where id_zone = $id_zone)");
                $select = ['post_back_url','count(*) as num'];
                $condition = [];
                array_push($condition,['id_zone','=',$id_zone]);
                $total = DB::raw("count(*) as total"); 
                $deliveryPostBack =  DB::select("Select distinct(post_back_url),count(*) as total from config_delivery_event where id_zone=$id_zone group by post_back_url limit 3");
                $status = array('status'=>1,'cca'=>$result,'deliveryPostBack'=>'');
                return json_encode($status);         
            }
            
        }
    }

    /*To change ads status */
    public function lowerLimitUpdate(Request $request){
      $lower_limit = $request->lower_limit;
      $id = $request->id;
      try{ 
          $update = DB::table('config_delivery')
              ->where('id',$id)
              ->update(array('lower_limit' => $lower_limit));
      }catch(\Illuminate\Database\QueryException $ex){
        dd($ex->getMessage());
      }
      if($update){
        $status = array('status'=>1,'message'=>'updated','id'=>$request->id);
      }else{
        $status = array('status'=>2,'message'=>'not updated'); 
      }
      return json_encode($status);
    }

}

