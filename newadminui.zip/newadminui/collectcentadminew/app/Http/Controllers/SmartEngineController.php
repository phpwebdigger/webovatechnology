<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Response;
use Illuminate\Support\Facades\Redis;
use Cache;
use App\CrcRecordsSmart;

class SmartEngineController extends Controller
{
    //
    public function __construct(){
        $this->middleware('auth');
    }

    public function redisConnection(){
      $redis; 
        try{
            $redis = Redis::connection();
            return $redis; 
        }catch(\Exception $e){
           return false;
        }
        
    }


    /* Smart hourly */
    public function index(Request $request){
        $redis = $this->redisConnection();
        $networks_data = $this->network_data();
        $operator_key = 'operators';
//        $hour = date("H");
        $hour = '';
        $condition = "";
        $current_date = date('Ymd');      
        $dtvalue = date('Y-m-d');
        $dtvalue2 = date('Y-m-d');
        $condition .= " BETWEEN '$dtvalue' AND '$dtvalue2'";
        if($hour){
//           $condition .= ' AND hour = '.$hour;
        }
        $condition .= " AND  traffic_type IN ('SM','SG','WM','WG')";
        $condition .= ' group by parent_cca';
        $fields = [
                   "parent_cca",
                   "advertiser_campain_cpa",
                   "traffic_type",
                   "referrer", 
                   "browser",
                   "os",
                   "id_channel",
                   "siteid",
                   "op_name",
                   "country",
                   "date",  
                   "sum(clickcount) AS clickcount", 
                   "sum(conversion_count) AS conversion_count",
                   "CONCAT(cr_received,'%') AS cr_received",
                   "revenue", 
                   "report_type",
                   "revenue_dollar", 
                   "cost_dollar", 
                   "total_cost",
                   // "ad_network.name AS network_name" 
                ];
            $fields =  implode(",",$fields);    
            $sql = "select $fields from crc_records_smart_$current_date where date(date) $condition";
            $data = DB::select(DB::raw($sql));
            $data1= [];
            $count = 0;
            $totalClick = 0;
            $totalconversion = 0;
            $clicks_active_count = 0;
                foreach ($data as $result) {
                    $array = [];
                    $cr_recieved = "0"."%";
                    $ecpm = 0;
                    $revenue = round($result->conversion_count * $result->advertiser_campain_cpa,2); 
                    $revenue_dollar = round($revenue/65,2);
                    if($result->clickcount > 0){
                        $cr_recieved = round(($result->conversion_count/$result->clickcount)*100,2)."%";
                         $ecpm = round($revenue_dollar/$result->clickcount*1000,2);
                    }
                    $network_name = "no_network";
                    if(array_key_exists($result->id_channel,$networks_data)){
                        $network_name = $networks_data[$result->id_channel]; 
                    }
                    $count++;
                    array_push($array,
                       '<a href="/get-smartengine-details/'.$result->parent_cca.'/?hours='.$hour.'&start='.$dtvalue.'&end='.$dtvalue.'">'.$result->parent_cca.'</a>',
                        $network_name,
                        $result->op_name,
                        $result->country,
                        $result->traffic_type,
                        '<span title="'.$result->referrer.'">'.$result->referrer.'</span>',
                        $result->browser,
                        $result->os,
                        $result->siteid,
                        $result->clickcount,
                        $result->conversion_count,                        
                        $cr_recieved,
                        $revenue,
                        $revenue_dollar,
                        $result->cost_dollar,
                        $result->total_cost,
                        $ecpm
                    );
                    array_push($data1, $array);
                    $totalClick = $totalClick + $result->clickcount;
                    $totalconversion = $totalconversion + $result->conversion_count;
                }
                $lastRow =[$totalClick,$totalconversion];
                $operators = json_decode($this->getOperator());
                
                $country_key = 'countries';
                try{
                  if(!property_exists('Redis','exists')){
                      throw new \Exception("Error Processing Request", 1);
                  }
                  if(!$redis->exists($country_key)){
                  $countries = $this->getCountry();
                  Redis::set($country_key, json_encode($operators));
                  $redis->expire($country_key,900);
                  }else{
                    $countries = json_decode(Redis::get($key));
                  }
                } catch(\Exception $e){
                    $countries = $this->getCountry();
                } 

            $result  = array(
                'oprData' => $operators,
                'countries' => $countries,                          
                'dtvalue' => $dtvalue,
                'dtvalue2' => $dtvalue2,
                'data1' => $data1,
                'lastRow'=>$lastRow,
                'hour' => $hour
              );
                   $viewPage = "SmartEngine.smart_engine_view";

             $dataN =  view($viewPage)->with($result);
             return $dataN;
      }


    public function alldays(Request $request)
    {
        $redis = Redis::connection();
        $networks_data = $this->network_data();
        $operator_key = 'operators';
        $hour = date("H");
        $condition = "";      
        $dtvalue = date('Y-m-d');
        $dtvalue2 = date('Y-m-d');
        $condition .= " BETWEEN '$dtvalue' AND '$dtvalue2'";
        $condition .= " AND  traffic_type IN ('SM','SG')";
        $condition .= ' group by parent_cca';
        $fields = [
                   "parent_cca",
                   "advertiser_campain_cpa",
                   "traffic_type",
                   "referrer", 
                   "browser",
                   "os",
                   "id_channel",
                   "siteid",
                   "date",  
                   "sum(clickcount) AS clickcount", 
                   "sum(conversion_count) AS conversion_count",
                   "CONCAT(cr_received,'%') AS cr_received",
                   "revenue", 
                   "report_type",
                   "revenue_dollar", 
                   "cost_dollar", 
                   "total_cost",
                   // "ad_network.name AS network_name" 
                ];
            $fields =  implode(",",$fields);    
            $sql = "select $fields from crc_records_smart where date(date) $condition";
            $data = DB::select(DB::raw($sql));
            $data1= [];
            $count = 0;
            $totalClick = 0;
            $totalconversion = 0;
            $clicks_active_count = 0;
                foreach ($data as $result) {
                    $array = [];
                    $cr_recieved = "0"."%";
                    $ecpm = 0;
                    $revenue = round($result->conversion_count * $result->advertiser_campain_cpa,2); 
                    $revenue_dollar = round($revenue/65,2);
                    if($result->clickcount > 0){
                        $cr_recieved = round(($result->conversion_count/$result->clickcount)*100,2)."%";
                         $ecpm = round($revenue_dollar/$result->clickcount*1000,2);
                    }
                    $network_name = "no_network";
                    if(array_key_exists($result->id_channel,$networks_data)){
                        $network_name = $networks_data[$result->id_channel]; 
                    }
                    $count++;
                    array_push($array,
                       '<a href="/get-smartengine-details/'.$result->parent_cca.'/?hours='.$hour.'&start='.$dtvalue.'&end='.$dtvalue.'">'.$result->parent_cca.'</a>',
                        $network_name,
                        $result->traffic_type,
                        '<span title="'.$result->referrer.'">'.$result->referrer.'</span>',
                        $result->browser,
                        $result->os,
                        $result->siteid,
                        $result->clickcount,
                        $result->conversion_count,                        
                        $cr_recieved,
                        $revenue,
                        $revenue_dollar,
                        $result->cost_dollar,
                        $result->total_cost,
                        $ecpm
                    );
                    array_push($data1, $array);
                    $totalClick = $totalClick + $result->clickcount;
                    $totalconversion = $totalconversion + $result->conversion_count;
                }
                $lastRow =[$totalClick,$totalconversion];
                $operators = json_decode($this->getOperator());
                
                $country_key = 'countries';
                try{
                if(!$redis->exists($country_key)){
                  $countries = $this->getCountry();
                  Redis::set($country_key, json_encode($operators));
                  $redis->expire($country_key,900);
                  }else{
                    $countries = json_decode(Redis::get($key));
                  }
                } catch(\Exception $e){
                    $countries = $this->getCountry();
                }  

            $result  = array(
                'oprData' => $operators,
                'countries' => $countries,                          
                'dtvalue' => $dtvalue,
                'dtvalue2' => $dtvalue2,
                'data1' => $data1,
                'lastRow'=>$lastRow,
                'hour' => $hour
              );
                   $viewPage = "SmartEngine.alldayresult";

             $dataN =  view($viewPage)->with($result);
             return $dataN;
        }
  
    function getOperator(){
        $operator_key = 'operators';
        try{
          if(!$redis->exists($operator_key)){
            $operators = $this->operatorQuery();
            Redis::set($operator_key, json_encode($operators));
            $redis->expire($operator_key,900);
            }else{
              $operators = json_decode(Redis::get($key));
            }
          }catch(\Exception $e){
              $operators = $this->operatorQuery();
          }
          return $operators;
     }

     function operatorQuery(){
      $operator_dropdown = [];
      $operatorsResult = DB::select("select operator.id, operator.name, country.iso as cc from operator LEFT JOIN country on operator.country_code=country.iso order by operator.id");
      foreach ($operatorsResult as $dropdown) {
        if ($dropdown->id && $dropdown->name){
            $operator_dropdown[$dropdown->id]['operator'] = $dropdown->name."(".$dropdown->cc.")";
            $operator_dropdown[$dropdown->id]['id'] = $dropdown->id;
          }
        }
        $items = json_encode($operator_dropdown);
        return $items;

     } 

      /* to get countries
      * date : 20 Feb 2018
     */
    function getCountry(){
        $select_opr =  [
            "c.id",
            "c.name",
            "c.iso",
        ];
        $oprdata =  DB::table("country as c")
        ->select($select_opr)
        ->get();

        $ddDataResult1  = array(
                'countries' => []
            );
        foreach ($oprdata as $dropdown) {
            $ddDataResult1['countries'][$dropdown->iso] = $dropdown->name." (".$dropdown->iso.")";
        }
        return $ddDataResult1;
    }
     

     /* Ajax return on index page*/
     public function getSmartFilter(Request $request) : string {
        if($request->ajax()){
        $redis = Redis::connection();
        $current_url = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        $current_url1 = explode("?",$current_url);
        $current_url2 = explode("&_=",$current_url1[1]);
        if(count($current_url2) > 1){
         $allParameters = $current_url2[0];
         $key = "smartEngineIndex_$allParameters";
        }
        try{
          if(!$redis->exists($key)){
              $item = $this->getSmartQuery($request);
              Redis::set($key, $item);
              $redis->expire($key,500);
              }else{
                $item = Redis::get($key);
              }
        } catch(\Exception $e){
         $item = $this->getSmartQuery($request);
        } 
        return $item;
       }    
    }

     /* Ajax return on index page*/
     public function getSmartFilterHourly(Request $request) : string {
        if($request->ajax()){
        $redis = Redis::connection();
        $current_url = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        $current_url1 = explode("?",$current_url);
        $current_url2 = explode("&_=",$current_url1[1]);
        if(count($current_url2) > 1){
         $allParameters = $current_url2[0];
         $key = "smartEngineIndex_$allParameters";
        }
        try{
          if(!$redis->exists($key)){
              $item = $this->getSmartQuery($request);
              Redis::set($key, $item);
              $redis->expire($key,500);
              }else{
                $item = Redis::get($key);
              }
        } catch(\Exception $e){
         $item = $this->getSmartQuery($request);
        } 
        return $item;
       }    
    }

    public function getSmartQuery(Request $request) : string {
        
        
        $hour = date("H", time() - 3600*2);
        $condition = $group = $parent_id = ""; 
        $current_date = date('Ymd');     
        $dtvalue = $request->start;
        $dtvalue2 = $request->end;
        $group = [];
        if(is_null($dtvalue)){
            $dtvalue = date('Y-m-d');
        }
        if(is_null($dtvalue2)){
                $dtvalue2 = date('Y-m-d');
                $enddate = date('Y-m-d',strtotime("+1 days"));
                if($type == 'hourly'){
                  $condition .= " = '$dtvalue'";
                }else{
                  $condition .= " BETWEEN '$dtvalue' AND '$dtvalue2'";
                }
        }else{
           $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));
           $condition .= "BETWEEN '$dtvalue' AND '$dtvalue2'";
           
        }
        
        $traffic_types = $operators = $hours = $group_by = "";
        $group_by = $request->groupby;
        $hours = $request->hours;
        $type = $request->type;
        $hours = str_replace("'", "", $hours);
        $operator = $request->operator;
        $traffic_type = $request->traffic_type;
        $parent_cca = $request->parent_cca;
        $country = $request->country;
        /* added for search group by results*/

        $browser = $request->browser;


        if(empty($parent_cca)){
            $parent_id = 0;
        }else{
            $parent_id = $parent_cca;
        }

        if(!empty($traffic_type))
        {
            $traffic_type_arr = explode(",", $traffic_type);
-           $traffic_type_str = "'" . implode("','", $traffic_type_arr) . "'";
            $condition .= ' AND crc.traffic_type IN ('.$traffic_type_str.')';
        }
        if($operator != "")
        {
            $operator_arr = explode(",", $operator);
-           $operator_str = "'" . implode("','", $operator_arr) . "'";
            $condition .= ' AND crc.op_id IN ('.$operator_str.')';
        }
        if($country != "")
        {
            $country_arr = explode(",", $country);
-           $country_str = "'" . implode("','", $country_arr) . "'";
            $condition .= ' AND crc.country IN ('.$country_str.')';
        }
        if($country != "")
        {
            $country_arr = explode(",", $country);
-           $country_str = "'" . implode("','", $country_arr) . "'";
            $condition .= ' AND crc.country IN ('.$country_str.')';
        }
        if($hours != "")
        {
            $hours_arr = explode(",", $hours);
-           $hours_str = "'" . implode("','", $hours_arr) . "'";
            $condition .= ' AND crc.hour IN ('.$hours_str.')';
        }
        if($parent_cca != "")
        {
            $condition .= " AND crc.parent_cca = ".$parent_cca;
        }
        if(!empty($group_by))
        {
            $group = explode(",", $group_by);
            $group_by =  implode(",", $group);   
            $condition .= ' group by crc.'.$group_by; //."id_advertiser_campaign";
        }else{
            $condition .= ' group by crc.parent_cca'; //."id_advertiser_campaign";
        }
        $table_name = "crc_records_smart as crc";
        if($type == 'hourly'){
            $table_name = "crc_records_smart_$current_date as crc";
        }

            $fields = [
                    'parent_cca',
                    'advertiser_campain_cpa',
                    'hour', 
                    'traffic_type', 
                    'referrer', 
                    'browser', 
                    'os',
                    'id_channel', 
                    'siteid',  
                    'op_name',  
                    'country',   
                    'date', 
                    "sum(clickcount) AS clickcount", 
                    "sum(conversion_count) AS conversion_count",
                    "CONCAT(cr_received,'%') AS cr_received",
                    "revenue", 
                    "report_type",
                    "revenue_dollar", 
                    "cost_dollar", 
                    "total_cost", 
                    // "ad_network.name AS network_name",
                  ];
        $fields = implode(",",$fields);          
        $sql = "select $fields from $table_name where date(date) $condition";
        $data = DB::select(DB::raw($sql));
            $data1= [];
            $count = 0;
            $totalClick = 0;
            $totalconversion = 0;
            $clicks_active_count = 0;
            $networks_data = $this->network_data(); 
               foreach ($data as $result) {
                    $array = [];
                    /* Revenue and CR calculated */
                    $cr_recieved = "0%";
                    $ecpm = 0;
                    $revenue = round($result->conversion_count * $result->advertiser_campain_cpa,2); 
                    $revenue_dollar = $revenue * 65;
                    if($result->clickcount > 0){
                        $cr_recieved = round(($result->conversion_count/$result->clickcount)*100,2)."%";
                        $ecpm = round($revenue_dollar/$result->clickcount*1000,2);
                    }
                    
                   
                    ### condition to show parent CCA with link when there is no groupby
                    if(!empty($hours || $operator || $traffic_type || $parent_cca) && empty($group)){
                      $parent_cca_id = '<a href="get-smartengine-details/'.$result->parent_cca.'/?hours='.$hours.'&start='.$dtvalue.'&end='.$dtvalue.'';
                        if($operator){
                            $parent_cca_id .= '&operator='.$operator.'';
                        }
                        if($traffic_type){
                            $parent_cca_id .= '&traffic_type='.$traffic_type.'';
                        }
                        $parent_cca_id .= '">'.$result->parent_cca.'</a>';
                    }else{
                      $parent_cca_id = $result->parent_cca;
                    }
                       
                        /* commom string on the base of group by*/
                        $common_data = 'hours='.$hours.'&operator='.$operator.'&start='.$dtvalue.'&end='.$dtvalue.'&groupby=';
                        if(in_array("siteid",$group)){
                            $common_data .= '&site_id='.$result->siteid.'';
                        } 
                        if(in_array("browser",$group)){
                            $common_data .= '&browser='.$result->browser.'';
                        }
                        if(in_array("os",$group)){
                            $common_data .= '&os='.$result->os.'';
                        }
                        if(in_array("referrer",$group)){
                             $common_data .= '&referrer='.$result->referrer.'';   
                        }
                        if(in_array("traffic_type",$group)){
                            $common_data .= '&traffic_type='.$result->traffic_type.'';
                        }


                    if(in_array("siteid",$group)){
                        $site_id = $result->siteid? $result->siteid:'empty'; 
                        $site_data = '<a href="get-smartengine-details/'.$parent_id.'/?';
                        $site_data .= $common_data;
                        $site_data .= '">'.$site_id.'</a>';
                    }else{
                        $site_data = $result->siteid;
                    }
                    
                    if(in_array("browser",$group)){
                        $browser_id = $result->browser ? $result->browser:'empty'; 
                        $browser_data = '<a href=/get-smartengine-details/'.$parent_id.'/?';
                        $browser_data .= $common_data;
                        $browser_data.= '>'.$browser_id.'</a>';
                    }else{
                        $browser_data = $result->browser;
                    }
                    
                    if(in_array("os",$group)){
                       $os = $result->os ? $result->os:'empty'; 
                        $os_data = '<a href="/get-smartengine-details/'.$parent_id.'/?';
                        $os_data .= $common_data;
                        $os_data .= '">'.$os.'</a>'; 
                    }else{
                      $os_data = $result->os; 
                    }
                     
                    if(in_array("referrer",$group)){
                        $referrer = $result->referrer ? $result->referrer:'empty'; 
                        $referrer_data = '<a href="/get-smartengine-details/'.$parent_id.'/?';
                        $referrer_data .= $common_data;
                        $referrer_data .= '">'.$referrer.'</a>'; 
                    }else{
                      $referrer_data = $result->referrer; 
                    }
                    
                    if(in_array("traffic_type",$group)){
                        $traffic_type = $result->traffic_type ? $result->traffic_type:'empty'; 
                        $traffic_type_data = '<a href="/get-smartengine-details/'.$parent_id.'/?';
                        $traffic_type_data .= $common_data;
                        $traffic_type_data .= '">'.$traffic_type.'</a>'; 
                    }else{
                      $traffic_type_data = $result->traffic_type; 
                    }

                    $network_name = 'No Network'; 
                    if(array_key_exists($result->id_channel,$networks_data)){
                        $network_name = $networks_data[$result->id_channel];
                    }
                    array_push($array,

                        $parent_cca_id,
                        $network_name, 
                        $result->op_name,
                        $result->country,
                        $traffic_type_data, 
                        $referrer_data,
                        $browser_data, 
                        $os_data, 
                        $site_data, 
                        $result->clickcount,
                        $result->conversion_count,                        
                        $cr_recieved,
                        $revenue,
                        $revenue_dollar,
                        $result->cost_dollar,
                        $result->total_cost,
                        $ecpm

                    );
                    array_push($data1, $array);
                    $totalClick = $totalClick + $result->clickcount;
                    $totalconversion = $totalconversion + $result->conversion_count;
                }
                $lastRow =[$totalClick,$totalconversion];
                $heads2 =  [
                            'Total',
                            '',
                            '',
                            '',
                            '',
                            '',
                            '',
                            '',
                            '',
                            $lastRow[0],
                            $lastRow[1],
                            '',
                            '',
                            '',
                            '',
                            '',
                            '',
                            ];

            $status = ['status'=>'1','message'=>'', 'data'=>$data1,'lastRow'=>$heads2];
            return json_encode($status);
        }

    
    /* to show record on the bases of different parameter */
    public function getSmartDetails(Request $request,$parent_cca)
    {
        $condition = '';
        $groupby_flag = 0; 
        $current_date = date('Ymd'); 
        $traffic_types = $operators = $hours = $group_by = $groupby_selected = "";
        $traffic_arr = $operator_arr = $opData = $hours_arr = $groupby = [];
        $dtvalue = $request->start;
        $dtvalue2 = $request->end;
        $hours   = $request->hours;
        /* added for search group by results*/
        $browser = $request->browser;
        $operator = $request->operator;
        $traffic_type = $request->traffic_type;
        $siteid = $request->site_id;
        $os = $request->os;
        $referrer = $request->referrer;
        $activeFields = [];
        $allParameters = "";
        // $parent_cca = $request->parent_cca;
        $current_url = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        $current_url1 = explode("?",$current_url);
        if(count($current_url1) > 1){
         $allParameters = $current_url1[1];
        }
       
        
        if(is_null($dtvalue)){
            $dtvalue = date('Y-m-d');
        }
        if(is_null($dtvalue2)){
                $dtvalue2 = date('Y-m-d');
                $enddate = date('Y-m-d',strtotime("+1 days"));
                $condition .= " BETWEEN '$dtvalue' AND '$dtvalue2'";
                
        }else{
           $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));
           $condition .= "BETWEEN '$dtvalue' AND '$dtvalue2'";
           
        }
        if($parent_cca && $parent_cca!=0){
            $condition .= " AND parent_cca =$parent_cca";
        }
        if($hours != "")
        {
            $hours_arr = explode(",", $hours);
           $hours_str = "'" . implode("','", $hours_arr) . "'";
            $condition .= ' AND hour IN ('.$hours_str.')';
        }
        if($operator != "")
        {
            $operator_arr = explode(",", $operator);
-           $operator_str = "'" . implode("','", $operator_arr) . "'";
            $condition .= ' AND crc_records_smart.op_id IN ('.$operator_str.')';
        }
        /* all group by elements*/
        if($request->exists('site_id')){
            $groupby_selected = $condition .= " AND siteid ='".$siteid."'";
            $groupby_flag = 1;
            array_push($activeFields,0);
            array_push($groupby,'traffic_type');
        }
        if($request->exists('browser'))
        {
            $condition .= " AND browser ='".$browser."'";
            $groupby_flag = 1;
            array_push($activeFields,1);
            array_push($groupby,'browser');
            // $groupby_selected .= " AND browser ='".$browser."'";
        }
        if($request->exists('os')){
           $condition .= " AND os ='".$os."'";
           $groupby_flag = 1;
           array_push($activeFields,2);
           array_push($groupby,'os');
        }
        if($request->exists('referrer')){
           $condition .= " AND referrer ='".$referrer."'";
           $groupby_flag = 1;
           array_push($activeFields,3);
           array_push($groupby,'referrer');
           // $groupby_selected .= " AND referrer ='".$referrer."'";
        }
        if($request->exists('traffic_type'))
        {
            $traffic_arr = explode(",", $traffic_type);
           $traffic_str = "'" . implode("','", $traffic_arr) . "'";
            $condition .= ' AND traffic_type IN ('.$traffic_str.')';
            $groupby_flag = 1;
            array_push($activeFields,4);
            array_push($groupby,'traffic_type');
            // $groupby_selected .= ' AND traffic_type IN ('.$traffic_str.')';
        }
          
        $fields = [
                    'id_advertiser_campaign',
                    'advertiser_campain_name',
                    'advertiser_campain_cpa',
                    'parent_cca', 
                    'traffic_type',
                    'country',
                    'op_name',
                    'referrer', 
                    'browser', 
                     'os',
                     'id_channel', 
                     'siteid',  
                     'date', 
                     'sum(clickcount) AS clickcount', 
                     'sum(conversion_count) AS conversion_count',
                     'cr_received',
                     'revenue', 
                     'report_type',
                     'revenue_dollar', 
                     'cost_dollar', 
                     'total_cost'
                    ];
            $fields =  implode(',',$fields);        


        $sql = "select $fields
                from crc_records_smart_$current_date 
                where date(date) $condition group by id_advertiser_campaign";
       
        $data = DB::select(DB::raw($sql));
            // dd($data);      
            $data1= [];
            $count = 0;
            $totalClick = 0;
            $totalconversion = 0;
            $clicks_active_count = 0;
                foreach ($data as $result) {
                    $array = [];
                $cr_received = "0%";
                $ecpm = 0;
                $revenue = round($result->conversion_count * $result->advertiser_campain_cpa,2); 
                $revenue_dollar = round($revenue/65,2);
                if($result->clickcount > 0){
                    $cr_received = round(($result->conversion_count/$result->clickcount)*100,2)."%";
                    $ecpm = round($revenue_dollar/$result->clickcount*1000,2); 
                }
            
                  
                    if($allParameters){ 
                        $campaign_name = "<a href='/get-cca-by-smartcampaign/$result->id_advertiser_campaign/?$allParameters'>$result->advertiser_campain_name</a>"; 
                    }else{
                       $campaign = $result->advertiser_campain_name;  
                    }

                    $count++;
                   if($groupby_flag == 1){
                          array_push($array,
                            $result->siteid,
                            $result->browser,
                            $result->os,
                            $result->referrer,
                            $result->traffic_type,
                            $result->parent_cca,
                            $result->id_advertiser_campaign,
                            $campaign_name,
                            $result->country,
                            $result->op_name,
                            $result->clickcount,
                            $result->conversion_count,                        
                            $cr_received,
                            $revenue,
                            $revenue_dollar,
                            $result->cost_dollar,
                            $result->total_cost,
                            $ecpm
                        );
                    }else{
                        array_push($array,
                            $result->parent_cca,
                            $result->siteid,
                            $result->browser,
                            $result->os,
                            $result->referrer,
                            $result->traffic_type,
                            $result->id_advertiser_campaign,
                            $campaign_name,
                            $result->country,
                            $result->op_name,
                            $result->clickcount,
                            $result->conversion_count,                        
                            $cr_received,
                            $revenue,
                            $revenue_dollar,
                            $result->cost_dollar,
                            $result->total_cost,
                            $ecpm
                        );
                    }
                    array_push($data1, $array);
                    $totalClick = $totalClick + $result->clickcount;
                    $totalconversion = $totalconversion + $result->conversion_count;
                }
                $lastRow =[$totalClick,$totalconversion];
            $opData = json_decode($this->getOperator());
             
            $result  = array(
                'oprData' => $opData,    
                'dtvalue' => $dtvalue,
                'dtvalue2' => $dtvalue2,
                'data1' => $data1,
                'lastRow'=>$lastRow,
                'activeFields'=>$activeFields,
                'hour' => $hours_arr,
                'groupby'=> $groupby,
                'operator'=>$operator_arr,
                'traffic_type'=>$traffic_arr, 
                'parent_cca'=>$parent_cca,
            );
            // print"<pre>";print_r($opData);print"</pre>";
            if($groupby_flag){
            $viewPage = "SmartEngine.smart_engine_details_groupby";
            }else{
            $viewPage = "SmartEngine.smart_engine_details";    
            } 
             $dataN =  view($viewPage)->with($result);
            return $dataN;
  
      

    }

    /* Ajax return on internal detail page*/
     public function getSmartFilterByCca(Request $request) : string{
        // if($request->ajax()){
        $redis = Redis::connection();
        $current_url = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        $current_url1 = explode("?",$current_url);
        $current_url2 = explode("&_=",$current_url1[1]);
        if(count($current_url2) > 1){
         $allParameters = $current_url2[0];
         $key = "smartEngineByCca_$allParameters";
        }
        try{
          if(!$redis->exists($key)){
              $item = $this->getSmartFilterByCcaQuery($request);
              Redis::set($key, $item);
              $redis->expire($key,500);
              }else{
                $item = Redis::get($key);
              }
        } catch(\Exception $e){
         $item = $this->getSmartFilterByCcaQuery($request);
        } 
        return $item;
        // }    
    }

    function getSmartFilterByCcaQuery(Request $request) : string{
        $hour = date("H", time() - 3600*2);
        $condition = $group = $parent_id = "";      
        $dtvalue = $request->start;
        $dtvalue2 = $request->end;
        $group = [];
        if(is_null($dtvalue)){
            $dtvalue = date('Y-m-d');
        }
        if(is_null($dtvalue2)){
                $dtvalue2 = date('Y-m-d');
                $enddate = date('Y-m-d',strtotime("+1 days"));
                $condition .= " BETWEEN '$dtvalue' AND '$dtvalue2'";
                
        }else{
           $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));
           $condition .= "BETWEEN '$dtvalue' AND '$dtvalue2'";
           
        }
         $allParameters = "";
        // $parent_cca = $request->parent_cca;
        $current_url = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
        $current_url1 = explode("?",$current_url);
        $current_url2 = explode("&_=",$current_url1[1]);
        if(count($current_url2) > 1){
         $allParameters = $current_url2[0];
        }
        
        $traffic_types = $operators = $hours = $group_by = $parent_flag ="";
        $group_by = $request->groupby;
        $hours = $request->hours;
        $hours = str_replace("'", "", $hours);
        $operator = $request->operator;
        $traffic_type = $request->traffic_type;
        $parent_cca = $request->parent_cca;
        /* added for search group by results*/
        $browser = $request->browser;
        if(empty($parent_cca)){
            $parent_id = 0;
        }else{
            $parent_id = $parent_cca;
        }

        if(!empty($traffic_type))
        {
            $traffic_type_arr = explode(",", $traffic_type);
            $traffic_type_str = "'" . implode("','", $traffic_type_arr) . "'";
            $condition .= ' AND crc_records_smart.traffic_type IN ('.$traffic_type_str.')';
        }
        if($operator != "")
        {
            $operator_arr = explode(",", $operator);
           $operator_str = "'" . implode("','", $operator_arr) . "'";
            $condition .= ' AND crc_records_smart.op_id IN ('.$operator_str.')';
        }
        if($hours != "")
        {
            $hours_arr = explode(",", $hours);
           $hours_str = "'" . implode("','", $hours_arr) . "'";
            $condition .= ' AND crc_records_smart.hour IN ('.$hours_str.')';
        }
        if($parent_cca != "")
        {
            $condition .= " AND crc_records_smart.parent_cca = ".$parent_cca;
            $parent_flag = 1;
        }
        
        if(!empty($group_by))
        {
            $group = explode(",", $group_by);
            $group_by =  implode(",", $group);   
            $condition .= ' group by crc_records_smart.'.$group_by; //."id_advertiser_campaign";
        }else{
            $condition .= ' group by crc_records_smart.id_advertiser_campaign'; //."id_advertiser_campaign";
        }

        $fields = [
                   'id_advertiser_campaign',
                    'advertiser_campain_name',
                    'parent_cca',
                    'advertiser_campain_cpa',
                    'hour', 
                    'traffic_type', 
                    'referrer', 
                    'browser', 
                    'os',
                    'op_name',
                    'id_channel', 
                    'siteid',  
                    'date',
                    'sum(clickcount) AS clickcount', 
                    'sum(conversion_count) AS conversion_count',
                    'CONCAT(cr_received,"%") AS cr_received',
                    'revenue', 
                    'report_type',
                    'revenue_dollar', 
                    'cost_dollar', 
                    'total_cost', 
                  ];

            $fields =  implode(',',$fields);      
            $sql = "select $fields from crc_records_smart where date(date) $condition";
            
        $data = DB::select(DB::raw($sql));
            $data1= [];
            $count = 0;
            $totalClick = 0;
            $totalconversion = 0;
            $clicks_active_count = 0;

               foreach ($data as $result) {
                    $array = [];
                    /* Revenue and CR calculated */
                    $cr_received = "0%";
                    $ecpm = 0;
                    $revenue = round($result->conversion_count * $result->advertiser_campain_cpa,2); 
                    $revenue_dollar = $revenue * 65;
                    if($result->clickcount > 0){
                        $cr_received = round(($result->conversion_count/$result->clickcount)*100,2)."%";
                        $ecpm = round($revenue_dollar/$result->clickcount*1000,2);
                    }
                    
                   
                    ### condition to show parent CCA with link when there is no groupby
                    if(!empty($hours || $operator || $traffic_type || $parent_cca) && empty($group)){
                      $parent_cca_id = '<a href="get-smartengine-details/'.$result->parent_cca.'/?hour='.$hours.'&start='.$dtvalue.'&end='.$dtvalue.'';
                        if($operator){
                            $parent_cca_id .= '&operator='.$operator.'';
                        }
                        if($traffic_type){
                            $parent_cca_id .= '&traffic_type='.$traffic_type.'';
                        }
                        $parent_cca_id .= '">'.$result->parent_cca.'</a>';
                    }else{
                      $parent_cca_id = $result->parent_cca;
                    }
                       
                        /* commom string on the base of group by*/
                        $common_data = 'hour='.$hours.'&operator='.$operator.'&start='.$dtvalue.'&end='.$dtvalue.'';
                        if(in_array("siteid",$group)){
                            $common_data .= '&site_id='.$result->siteid.'';
                        } 
                        if(in_array("browser",$group)){
                            $common_data .= '&browser='.$result->browser.'';
                        }
                        if(in_array("os",$group)){
                            $common_data .= '&os='.$result->os.'';
                        }
                        if(in_array("referrer",$group)){
                             $common_data .= '&referrer='.$result->referrer.'';   
                        }
                        if(in_array("traffic_type",$group)){
                            $common_data .= '&traffic_type='.$result->traffic_type.'';
                        }


                    if(in_array("siteid",$group)){
                        $site_id = $result->siteid? $result->siteid:'empty'; 
                        $site_data = '<a href="get-smartengine-details/'.$parent_id.'/?';
                        $site_data .= $common_data;
                        $site_data .= '">'.$site_id.'</a>';
                    }else{
                        $site_data = $result->siteid;
                    }
                    
                    if(in_array("browser",$group)){
                        $browser_id = $result->browser ? $result->browser:'empty'; 
                        $browser_data = '<a href=/get-smartengine-details/'.$parent_id.'/?';
                        $browser_data .= $common_data;
                        $browser_data.= '>'.$browser_id.'</a>';
                    }else{
                        $browser_data = $result->browser;
                    }
                    
                    if(in_array("os",$group)){
                       $os = $result->os ? $result->os:'empty'; 
                        $os_data = '<a href="/get-smartengine-details/'.$parent_id.'/?';
                        $os_data .= $common_data;
                        $os_data .= '">'.$os.'</a>'; 
                    }else{
                      $os_data = $result->os; 
                    }
                     
                    if(in_array("referrer",$group)){
                        $referrer = $result->referrer ? $result->referrer:'empty'; 
                        $referrer_data = '<a href="/get-smartengine-details/'.$parent_id.'/?';
                        $referrer_data .= $common_data;
                        $referrer_data .= '">'.$referrer.'</a>'; 
                    }else{
                      $referrer_data = $result->referrer; 
                    }
                    
                    if(in_array("traffic_type",$group)){
                        $traffic_type = $result->traffic_type ? $result->traffic_type:'empty'; 
                        $traffic_type_data = '<a href="/get-smartengine-details/'.$parent_id.'/?';
                        $traffic_type_data .= $common_data;
                        $traffic_type_data .= '">'.$traffic_type.'</a>'; 
                    }else{
                      $traffic_type_data = $result->traffic_type; 
                    }
                    
                    if($allParameters){
                       $campaign_name = '<a href="/get-cca-by-smartcampaign/'.$result->id_advertiser_campaign.'/?'.$allParameters.'">'.$result->advertiser_campain_name.'</a>'; 
                    }else{
                       $campaign_name = $result->advertiser_campain_name;  
                    }
                    if($parent_id <= 0){
                    array_push($array,
                            $result->siteid,
                            $result->browser,
                            $result->os,
                            $result->referrer,
                            $result->traffic_type,
                            $result->parent_cca,
                            $result->id_advertiser_campaign,
                            $campaign_name,
                            $result->op_name,
                            $result->clickcount,
                            $result->conversion_count,                        
                            $cr_received,
                            $revenue,
                            $revenue_dollar,
                            $result->cost_dollar,
                            $result->total_cost,
                            $ecpm
                        );
                    }else{
                        array_push($array,
                            $result->parent_cca,
                            $result->siteid,
                            $result->browser,
                            $result->os,
                            $result->referrer,
                            $result->traffic_type,
                            $result->id_advertiser_campaign,
                            $campaign_name,
                            $result->op_name,
                            $result->clickcount,
                            $result->conversion_count,                        
                            $cr_received,
                            $revenue,
                            $revenue_dollar,
                            $result->cost_dollar,
                            $result->total_cost,
                            $ecpm
                        );    
                    }

                    array_push($data1, $array);
                    $totalClick = $totalClick + $result->clickcount;
                    $totalconversion = $totalconversion + $result->conversion_count;
                }
                $lastRow =[$totalClick,$totalconversion];
             
                        $heads2 =  [
                            'Total',
                            '',
                            '',
                            '',
                            '',
                            '',
                            '',
                            '',
                            '',
                            $lastRow[0],
                            $lastRow[1],
                            '',
                            '',
                            '',
                            '',
                            '',
                            '',
                            ];

                       

            $status = ['status'=>'1','message'=>'', 'data'=>$data1,'lastRow'=>$heads2];
            return Response::json($status);

    }

    
       
     /* show records on the bases of campaign id */
    function ccaBySmartCampaign(Request $request,$campaign_id){
       
        $redis = Redis::connection();
        $networks_data = $this->network_data();
        $condition = '';
        $traffic_types = $operators = $hours = $group_by = "";
        $dtvalue = $request->start;
        $dtvalue2 = $request->end;
        $hours   = $request->hours;
        /* added for search group by results*/
        $browser = $request->browser;
        $operator = $request->operator;
        $traffic_type = $request->traffic_type;
        $siteid = $request->site_id;
        $parent_cca = $request->parent_cca;
        $os = $request->os;
        $referrer = $request->referrer;
        // $parent_cca = $request->parent_cca;
        
        if(is_null($dtvalue)){
            $dtvalue = date('Y-m-d');
        }
        if(is_null($dtvalue2)){
                $dtvalue2 = date('Y-m-d');
                $enddate = date('Y-m-d',strtotime("+1 days"));
                $condition .= " BETWEEN '$dtvalue' AND '$dtvalue2'";
                
        }else{
           $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));
           $condition .= "BETWEEN '$dtvalue' AND '$dtvalue2'";
           
        }
        if($campaign_id && $campaign_id!=0){
            $condition .= " AND id_advertiser_campaign = $campaign_id";
        }
        if($hours != "")
        {
            $condition .= ' AND hour IN ('.$hours.')';
        }
        if($operator != "")
        {
            $operator = explode(",", $operator);
-           $operators = "'" . implode("','", $operator) . "'";
            $condition .= ' AND crc_records_smart.op_id IN ('.$operators.')';
        }
        /* all group by elements*/
        if($request->exists('browser'))
        {
            $condition .= " AND crc_records_smart.browser ='".$browser."'";
        }
        if($request->exists('traffic_type'))
        {
            $traffic_type = explode(",", $traffic_type);
-           $traffic_types = "'" . implode("','", $traffic_type) . "'";
            $condition .= ' AND crc_records_smart.traffic_type IN ('.$traffic_types.')';
        }
        if($request->exists('site_id')){
            $condition .= " AND crc_records_smart.siteid ='".$siteid."'";
        }
        if($request->exists('os')){
           $condition .= " AND crc_records_smart.os ='".$os."'";
        }
        if($request->exists('referrer')){
           $condition .= " AND crc_records_smart.referrer ='".$referrer."'";
        }
        if($parent_cca){
           $condition .= " AND crc_records_smart.parent_cca ='".$parent_cca."'";
        }

        
        /*if($hours != "")
        {
            $condition .= " AND hour =$hours";
        }*/
        $fields = [
                    'id_advertiser_campaign',
                    'advertiser_campain_name',
                    'advertiser_campain_cpa',
                    'parent_cca', 
                    'traffic_type',
                    'op_name',
                    'referrer', 
                    'browser', 
                     'os',
                     'id_channel', 
                     'siteid',  
                     'date', 
                     'sum(clickcount) AS clickcount', 
                     'sum(conversion_count) AS conversion_count',
                     'cr_received',
                     'revenue', 
                     'report_type',
                     'revenue_dollar', 
                     'cost_dollar', 
                     'total_cost',
                    // 'network_vw.network_name'
                    ];
            $fields =  implode(',',$fields);        


        $sql = "select $fields from crc_records_smart where date(date) $condition group by parent_cca";
        
        $data = DB::select(DB::raw($sql));
            // dd($data);      
            $data1= [];
            $count = 0;
            $totalClick = 0;
            $totalconversion = 0;
            $clicks_active_count = 0;

                foreach ($data as $result) {
                    $array = [];
                    $cr_received = "0%";
                    $ecpm = 0;
                    $revenue = round($result->conversion_count * $result->advertiser_campain_cpa,2); 
                    $revenue_dollar = round($revenue/65,2);
                    if($result->clickcount > 0){
                        $cr_received = round(($result->conversion_count/$result->clickcount)*100,2)."%";
                        $ecpm  = round($revenue_dollar/$result->clickcount*1000,2);
                    }
                    $network_name = "No Network";
                    if(array_key_exists($result->id_channel, $networks_data)){
                        $network_name = $networks_data[$result->id_channel];
                    }
                    
                    $count++;
                    array_push($array,
                        $result->parent_cca,
                        $network_name,
                        $result->id_advertiser_campaign,
                        $result->advertiser_campain_name,
                        $result->traffic_type,
                        '<span title="'.$result->referrer.'">'.$result->referrer.'</span>',
                        $result->browser,
                        $result->os,
                        $result->siteid,
                        $result->op_name,
                        $result->clickcount,
                        $result->conversion_count,                        
                        $cr_received,
                        $revenue,
                        $revenue_dollar,
                        $result->cost_dollar,
                        $result->total_cost,
                        $ecpm

                    );
                    array_push($data1, $array);
                    $totalClick = $totalClick + $result->clickcount;
                    $totalconversion = $totalconversion + $result->conversion_count;
                }
                $lastRow =[$totalClick,$totalconversion];

            $result  = array(
                'dtvalue' => $dtvalue,
                'dtvalue2' => $dtvalue2,
                'data1' => $data1,
                'lastRow'=>$lastRow
              );
                   $viewPage = "SmartEngine.cca-by-smartcampaign";

             $dataN =  view($viewPage)->with($result);
            return $dataN;


    }

     function getNetworks(){
        $network_data = [];
        $network = DB::select("Select ccz,name from ad_network");
        foreach($network as $key=>$nw){
            $network_data[$nw->ccz] = $nw->name;
        }
        return $network_data;  
    }

    public function network_data(){
        $redis = Redis::connection();
        $network_key = 'networks';   
        try{
          if(!$redis->exists($key)){
            $network_data = $this->getNetworks();
            Redis::set($network_key, json_encode($network_data));
            $redis->expire($key,86400);
            }else{
            $network_data = json_decode(Redis::get($key),true);
            }
        }catch(\Exception $e){
         $network_data = $this->getNetworks();
        } 
        return $network_data;
    }


    /* Function : countrywise
     * Date : 11 Dec 2017
     * Purpose : To filteration of crc_records_smart table country wise
     * Dev: Sumit Manchanda
     * Team: Collectcent  
    */ 
    function countrywise(Request $request){

        $operators = json_decode($this->getOperator());
        $result  = array(
                'oprData' => $operators,
              );
        $viewPage = "SmartEngine.country-wise";
        $dataN =  view($viewPage)->with($result);
        return $dataN;
    }
    
    /* Function : getcountrywise
     * Date : 11 Dec 2017
     * Purpose : To filteration of crc_records_smart table country wise
     * Dev: Sumit Manchanda
     * Team: Collectcent  
    */
    function getcountrywise(Request $request){
        $condition = $networks = [];
        $country = $operator = $network = '';
        $date = $request->daterange;
        $date =  explode(" - ",$date);
        $start_date = $date[0];
        $end_date = $date[1];
        $country = $request->country;
        if($request->op_id){
            $op_id = explode("_",$request->op_id);
            $operator_id = $op_id[0];
            $operator = $op_id[1];
        }
        if($request->pub_id){
            $pub_id = explode("_",$request->pub_id);
            $network_id = $pub_id[0];
            $network = $pub_id[1];
        }
        $action = $request->action;
        if($country){
            array_push($condition,['country','=',$country]);
        }
        if($start_date){
            array_push($condition,['date','=',$start_date]);
        }
        if($request->op_id){
            array_push($condition,['op_id','=',$operator_id]);
        }
        if($request->pub_id){
            array_push($condition,['id_channel','=',$network_id]);
        }   
        if($request->operator && $request->operator >= -2){
           array_push($condition,['op_id','=',$request->operator]);
        }
        $fields = [
                    'id_advertiser_campaign',
                    'advertiser_campain_name',
                    'advertiser_campain_cpa',
                    'parent_cca', 
                    'traffic_type',
                    'op_name',
                    'op_id',
                    'referrer', 
                    'browser', 
                     'os',
                     'id_channel', 
                     'siteid',  
                     'date', 
                     'traffic_type',
                     'country',
                     'sum(clickcount) as clickcount', 
                     'sum(conversion_count) AS conversion_count',
                     'cr_received',
                     'revenue', 
                     'report_type',
                     'revenue_dollar', 
                     'cost_dollar', 
                     'total_cost',
            ];
        $fields = implode($fields,",");
        if($action == 'operator'){
            $items = CrcRecordsSmart::groupBy('op_id')
                                  ->select(DB::raw($fields))
                                  ->whereIn('traffic_type', ['SG','SM'])   
                                  ->where($condition)
                                  ->get();
        $viewPage = "SmartEngine.operatorAjax";    
        }else if($action == 'publisher'){
        $items = CrcRecordsSmart::groupBy('id_channel')
                                  ->select(DB::raw($fields))
                                  ->whereIn('traffic_type', ['SG','SM'])    
                                  ->where($condition)
                                  ->get();
        $network_data  = $this->network_data();
        foreach($items as $key=>$item){
           if(array_key_exists($item->id_channel, $network_data)){
              $networks[$item->id_channel] = $network_data[$item->id_channel]; 
           }
        }
        $viewPage = "SmartEngine.publisherAjax";    
        }else if($action == 'campaigns'){
        $items = CrcRecordsSmart::groupBy('id_advertiser_campaign')
                                  ->select(DB::raw($fields))
                                  ->whereIn('traffic_type', ['SG','SM'])    
                                  ->where($condition)
                                  ->get();
        $viewPage = "SmartEngine.campaignAjax";    
        }else{
        $items = CrcRecordsSmart::groupBy('country')
                                  ->select(DB::raw($fields))
                                  ->whereIn('traffic_type', ['SG','SM'])    
                                  ->where($condition)
                                  ->get();
        $viewPage = "SmartEngine.countryAjax";    
        }                          
        $result = array(
        'items'=>$items,
        'country'=>$country,
        'operator'=>$operator,
        'network'=>$network,
        'networks'=>$networks,
        'daterange'=>$request->daterange,
        );
        $dataN =  view($viewPage)->with($result);
        return $dataN;
    }    


    
    
    
    
    
    
    

    

}
