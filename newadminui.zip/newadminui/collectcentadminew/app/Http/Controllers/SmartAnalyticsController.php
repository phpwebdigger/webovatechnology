<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Response;
use Illuminate\Support\Facades\Redis;
use Cache;
use Illuminate\Support\Facades\Schema;
use DateTime;

class SmartAnalyticsController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

   

    public function index(Request $request,$type="",$header="Smart Analytics",$routename="smartanalyticsreportsfilters") 
    {	
	
		ini_set('memory_limit','-1');

		   $data1 = [];

        $redis = Redis::connection();
        $operator_key = 'operators';

    $TrafficType_request=$request->traffic_type;
		$Country_request=$request->Country;
		$carrier_request=$request->carrier;
		$Os_request=$request->Os;
		$Browser_request=$request->Browser;
		
		$select = ['id_analytics','TrafficType','Country','Carrier','publisherId','subPublisherId','RefererUrl','Device','OS','Browser',
        'advertiserCampaignId',
		'ConversionPayOut','hour','date_time'
		];
		
		
		
		$dtvalue = $request->start;
		$dtvalue2 = $request->end;
		$start_date = $request->start;
		$hour = ($request->hours < 10)? '0'.$request->hours :$request->hours;
		
		if(is_null($dtvalue)){
				$dtvalue = date('Y-m-d');
		}
		if(is_null($dtvalue2)){
				$dtvalue2 = date('Y-m-d');
				$enddate = date('Y-m-d',strtotime("+1 days"));
				
		}else{
		  echo  $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));
		}
	
        
       $ddCondition= $condtion = [];
       
        if(!empty($TrafficType_request)){
                array_push($condtion,['TrafficType','=',$TrafficType_request] );
                array_push($ddCondition,['TrafficType','=',$TrafficType_request] );
        }
       if(!empty($Country_request)){
                array_push($condtion,['Country','=',$Country_request] );
                array_push($ddCondition,['Country','=',$Country_request] );
        }
		 if(!empty($carrier_request)){
                array_push($condtion,['Carrier','=',$carrier_request] );
                array_push($ddCondition,['Carrier','=',$carrier_request] );
        }
        if(!empty($Os_request)){
                array_push($condtion,['OS','=',$Os_request] );
                array_push($ddCondition,['OS','=',$Os_request] );
        }
        if(!empty($Browser_request)){
                array_push($condtion,['Browser','=',$Browser_request] );
                array_push($ddCondition,['Browser','=',$Browser_request] );
        }
        
     	if(empty($start_date) && empty($hour))
		{
		$table=$this->display_datewsie_data();
    if(!empty($table)){
		$data_ex=explode('_',$table);
		$dates_value=$data_ex[2];
		$hour = substr($dates_value, -2);
		$newdate = substr($dates_value,0, 8);
		$dtvalue = date('Y-m-d',strtotime($dtvalue));
  }
		}
		else{
		 $table = 'smart_analytics_'.date("Ymd", strtotime($start_date)).$hour;
		}
		
        $appends = [];
        $total = $request->total ? $request->total:50;
        
        $appends['total']=$request->total;
	    $tablesArray =Schema::hasTable($table);
        if($tablesArray){

        $data = DB::table($table)->where($condtion)->select($select)->groupBy('advertiserCampaignId')->orderBy('advertiserCampaignId','desc')->limit($total)->get();
        $data = (array)$data->toArray();
        $data1=[];
        foreach ($data as $fetch_url) {
           $array = [];
            array_push($array, 
				    	$fetch_url->TrafficType,
                    $fetch_url->Country,
                    $fetch_url->Carrier,
                    $fetch_url->publisherId,
                    $fetch_url->subPublisherId,
                    $fetch_url->RefererUrl,
                    $fetch_url->Device,
                    $fetch_url->OS,
                    $fetch_url->Browser,
                    $fetch_url->advertiserCampaignId,
                    $fetch_url->ConversionPayOut,
                    $fetch_url->hour
                  );
               array_push($data1, $array);
            }
        }else{
            $data1=array();
        }
      
              try{
                if(!$redis->exists($operator_key)){
                  $operators = $this->getOperatorList();
                  Redis::set($operator_key, json_encode($operators));
                  $redis->expire($operator_key,900);
                  }else{
                    $operators = json_decode(Redis::get($key));
                  }
                } catch(\Exception $e){
                    $operators = $this->getOperatorList();
                }

                $country_key = 'countries';
                try{
                if(!$redis->exists($country_key)){
                  $countries = $this->getCountryList();
                  Redis::set($country_key, json_encode($operators));
                  $redis->expire($country_key,900);
                  }else{
                    $countries = json_decode(Redis::get($key));
                  }
                } catch(\Exception $e){
                    $countries = $this->getCountryList();
                } 

        $lastRow=[];
        $display_pages="SmartAnalytics.smart_analytics_index";
             $result  = array(
                'operatorData' => $operators,
                'countriesData' => $countries,                          
                'dtvalue' => $dtvalue,
                'dtvalue2' => $dtvalue2,
                'data1' => $data1,
                'lastRow'=>$lastRow,
                'hour' => $hour,
                'header' => $header,
                'routename'=>$routename
              );
                  

             $dataN =  view($display_pages)->with($result);
             return $dataN;
    }
    


    
     /* to get operator*/
    function getOperatorList(){
        $select_opr =  [
            "opr.id",
            "opr.name",
            "count.iso",
        ];
        $oprdatas =  DB::table("operator as opr")
        ->select($select_opr)
        ->join('country as count', 'count.iso', '=', 'opr.country_code')
        ->get();

        $ddDataResult1  = array(
                'opr_dropdown' => []
            );
        foreach ($oprdatas as $dropdown) {
            $ddDataResult1['opr_dropdown'][$dropdown->id] = $dropdown->name." (".$dropdown->iso.")";
        }
        return $ddDataResult1;
    }


    /* to get countries
      * date : 20 Feb 2018
     */
    function getCountryList(){
        $select_opr =  [
            "c.id",
            "c.name",
            "c.iso",
        ];
        $oprdatas =  DB::table("country as c")
        ->select($select_opr)
        ->get();

        $ddDataResult1  = array(
                'countries' => []
            );
        foreach ($oprdatas as $dropdown) {
            $ddDataResult1['countries'][$dropdown->iso] = $dropdown->name." (".$dropdown->iso.")";
        }
        return $ddDataResult1;
    }



    public function check_data_in_table(){
			$datess = array();
			$date = new DateTime();
			$last = $date->format("Y-m-d");
			$end_date = $date->modify('+3 hour');
			$first = $end_date->format("Y-m-d");
			$step = '+1 hour'; $format = 'Ymd';
				$dates = array();
                $current = strtotime($first);
                $last = strtotime($last);
                while( $current <= $last ) {    
                    $dates[] = date($format, $current);
                    $current = strtotime($step, $current);
                }
                return $dates;
		}
    
	
		
		public function display_datewsie_data(){
			$flag=0;
			$date_ranges = $this->check_data_in_table();
			rsort($date_ranges);
			$today_date = date('Ymd');
			$start = date('H');
			$end = 0;
			if($flag==0){
			foreach($date_ranges as $dat){
				$start = ($dat == date('Ymd'))? date('H'):'24';	
				for($time = $start; $time > $end; $time--) {
				 $table_name ='smart_analytics_'.$dat.date("H", mktime($time-1));
				$check_table=Schema::hasTable($table_name);
				
				if($check_table){
					$data = DB::table($table_name)->count();
					if($data>0)
					{
						$flag=1;
						return $table_name;
						break 1;
						}
						}
					}
				}
				}
			}
	
	
		
		
		
}
