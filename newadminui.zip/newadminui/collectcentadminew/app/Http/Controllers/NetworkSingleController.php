<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\AdNetwork;
use App\Users;

class NetworkSingleController extends Controller
{
    //
     public function __construct()
    {
        $this->middleware('auth');
    }
    public function index_single(Request $request, $type="CPA" ,$routename = "network-wise-record-chanel",$header="CR Update")
    {


            $condtion = [];
            $dtvalue = $request->start;
            $dtvalue2 = $request->end;
            
            
            if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                    $dtvalue2 = date('Y-m-d');
                    $enddate = date('Y-m-d',strtotime("+1 days"));
            }else{
                //$dtvalue2 = date('Y-m-d',strtotime("+1 days"));
               $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));

            }
            
            

            array_push($condtion,['crc_records_new.create_time','>=',$dtvalue] );
            array_push($condtion,['crc_records_new.create_time','<=',$enddate] );
           

            if($type != "CPICPA"){
                
                array_push($condtion,['report_type','=',strtoupper($type)] );
            }


            if($request->id_channel){
                array_push($condtion,['crc_records_new.id_channel','=',$request->id_channel] );
            }
            if($request->id_advertiser_campaign){
                array_push($condtion,['crc_records_new.id_advertiser_campaign','=',$request->id_advertiser_campaign] );
               // dd($condtion);
            }
            
$select = ["advertiser_campaigns.name","crc_records_new.network_name","crc_records_new.op_name","crc_records_new.id_advertiser_campaign","crc_records_new.total_cost","crc_records_new.id_ad","crc_records_new.id_channel","crc_records_new.clickcount","crc_records_new.conversion_count","crc_records_new.clicks_active_count","crc_records_new.cr_goal AS cr_goal","crc_records_new.cr_received AS cr_received","crc_records_new.cr_given AS cr_given","crc_records_new.create_time"]; 


     $data =  DB::table("crc_records_new")
                ->where($condtion) 
                ->select($select)
                ->leftJoin("advertiser_campaigns","advertiser_campaigns.id","=","crc_records_new.id_advertiser_campaign")
                ->orderby("crc_records_new.id_ad","ASC")->get();

        
        
         $result  = array('data' => $data,
            "routename"=>$routename,
            'header'=>$header,
            'dtvalue' => $dtvalue,
            'dtvalue2' => $dtvalue2
          );

        
         return view('network.network_cr_update_single_chanel')->with($result);

     }
}
