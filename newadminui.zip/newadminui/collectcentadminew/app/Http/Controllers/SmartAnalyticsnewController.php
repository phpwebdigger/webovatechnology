<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Response;
use Illuminate\Support\Facades\Redis;
use Cache;
use Illuminate\Support\Facades\Schema;
use DateTime;
use App\Crc;
use App\Crcrecordsdetails;

class SmartAnalyticsnewController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    } 

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

   

    public function index(Request $request,$type="",$header="Smart Analytics",$routename="SmartAnalyticsdetailsnew") 
    {	
	
		ini_set('memory_limit','-1');

		$data1 = [];
		
		$condtion = $condtion1= [];
                $ddCondition = "where 1=1 AND crc.advertiser_name !='Dummy' ";
                $whereInCondition = "";
        
    $redis = Redis::connection();
        
    $operator_key = 'operators';

    $TrafficType_request=$request->traffic_type;
		
		$Country_request=$request->Country;
		
		$carrier_request=$request->carrier;
		
		$Os_request=$request->Os;
		
		$Browser_request=$request->Browser;
                
		$Hours_request=$request->hours;
		
        $dtvalue = date('Y-m-d');
        
        $enddate = date('Y-m-d',strtotime("+1 days"));
        $select='';
        
      
        
		$dtvalue = $request->start;
		$dtvalue2 = $request->end;
		$start_date = $request->start;
		$hour = ($request->hours < 10)? '0'.$request->hours :$request->hours;
		
		if(is_null($dtvalue)){
				$dtvalue = date('Y-m-d');
		}
		if(is_null($dtvalue2)){
				$dtvalue2 = date('Y-m-d');
				$enddate = date('Y-m-d',strtotime("+1 days"));
				
		}else{
		  echo  $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));
		}
	
		
       if(!empty($Country_request)){
                array_push($condtion,['Country','=',$Country_request] );
//                array_push($ddCondition,['Country','=',$Country_request] );
                $ddCondition .= " AND Country='".$Country_request."'";
        }
		 if(!empty($carrier_request)){
                array_push($condtion,['Carrier','=',$carrier_request] );
//                array_push($ddCondition,['Carrier','=',$carrier_request] );
                $ddCondition .= " AND Carrier='".$carrier_request."'";
        }
        if(!empty($Os_request)){
                array_push($condtion,['OS','=',$Os_request] );
//                array_push($ddCondition,['OS','=',$Os_request] );
                $ddCondition .= " AND OS='".$Os_request."'";
        }
        if(!empty($Browser_request)){
                array_push($condtion,['Browser','=',$Browser_request] );
//                array_push($ddCondition,['Browser','=',$Browser_request] );
                $ddCondition .= " AND Browser='".$Browser_request."'";
        }
        if(!empty($TrafficType_request))
        {
            if($TrafficType_request == 'A')
            {
                $whereInCondition = "AND TrafficType IN ('A','IG','SG','WG')";
            }
            else if($TrafficType_request == 'M')
            {
//                $data_result = $data_result->whereNotIn('TrafficType',['A','IG','SG','WG']);
                $whereInCondition = "AND TrafficType NOT IN ('A','IG','SG','WG')";
            }
        }
//        if(!empty($Hours_request)){
//                array_push($condtion,['Browser','=',$Browser_request] );
////                array_push($ddCondition,['Browser','=',$Browser_request] );
//                $ddCondition .= " AND Browser='".$Browser_request."'";
//        }
        
     	if(empty($start_date) && empty($hour)) 
		{
	  $table=$this->display_datewsie_data();
    if(!empty($table)){
		$data_ex=explode('_',$table);
		$dates_value=$data_ex[2];
		$hour = substr($dates_value, -2);
		$newdate = substr($dates_value,0, 8);
		$dtvalue = date('Y-m-d',strtotime($dtvalue));
  }
		}
		else{
		 $table = 'smart_analytics_'.date("Ymd", strtotime($start_date)).$hour;
		}
       
		    $appends = [];
        $total = $request->total ? $request->total:50;
        $appends['total']=$request->total;
	      $tablesArray =Schema::hasTable($table);
        if($tablesArray){

             array_push($condtion1,['date','>=',$dtvalue]);
            array_push($condtion1,['date','<=',$enddate]);
            array_push($condtion1,['publisherId','!=','0']);
            array_push($condtion1,['publisherId','!=','nan']);
            array_push($condtion1,['publisherId','REGEXP','^[0-9]+$']);
              array_push($condtion,['crc_records_details.date','=',$dtvalue]);
  
         array_push($condtion,['crc_records_details.hour','=',$hour]);
/*            if(!Cache::has('data_results_new_logics_dat')) {*/
  
            $data_result = DB::select("select anal.advertiserCampaignId,anal.Country,anal.Device,anal.OS,anal.Browser,anal.publisherId,crc.clickcount,crc.conversion_count,crc.advertiser_name,crc.traffic_type,crc.op_name,crc.network_name,crc.advertiser_campain_name from $table as anal left join (select parent_cca,sum(crc.clickcount) as clickcount,sum(crc.conversion_count) as conversion_count,crc.advertiser_name,crc.traffic_type,crc.op_name,crc.network_name,crc.advertiser_campain_name  from crc_records_details crc where crc.hour=$hour and crc.date='$dtvalue' group by crc.parent_cca) as crc on anal.publisherId=crc.parent_cca $ddCondition $whereInCondition group by anal.publisherId");
/*
             Cache::put('data_results_new_logics_dat', $data_result, 36000);
              }else{
               $data_result= Cache::get('data_results_new_logics_dat'); 
             }*/
          
        $data1=[];
        foreach ($data_result as $fetch_url) {
           $array = [];
           $traffic = "";
            if(in_array($fetch_url->traffic_type,['A','IG','SG','WG']))
            {
                $traffic = "A";
            }
            else
            {
                $traffic = "M";
            }
            array_push($array,
                    $fetch_url->publisherId,
                    $fetch_url->advertiser_name,
                    $fetch_url->advertiser_campain_name,
                    $traffic,
                    isset($fetch_url->Country)?($fetch_url->Country=='nan')?'NA':$fetch_url->Country:'NA',
                    isset($fetch_url->op_name)?($fetch_url->op_name=='nan')?'NA':$fetch_url->op_name:'NA',
                    isset($fetch_url->Device)?($fetch_url->Device=='nan')?'NA':$fetch_url->Device:'NA',
                    isset($fetch_url->OS)?($fetch_url->OS=='nan')?'NA':$fetch_url->OS:'NA',
				            isset($fetch_url->Browser)?($fetch_url->Browser=='nan')?'NA':$fetch_url->Browser:'NA',
                    $fetch_url->clickcount,
                    $fetch_url->conversion_count
                    
                  );
               array_push($data1, $array);
            }
        }else{
            $data1=array();
        }
      
              try{
                if(!$redis->exists($operator_key)){
                  $operators = $this->getOperatorList();
                  Redis::set($operator_key, json_encode($operators));
                  $redis->expire($operator_key,900);
                  }else{
                    $operators = json_decode(Redis::get($key));
                  }
                } catch(\Exception $e){
                    $operators = $this->getOperatorList();
                }

                $country_key = 'countries';
                try{
                if(!$redis->exists($country_key)){
                  $countries = $this->getCountryList();
                  Redis::set($country_key, json_encode($operators));
                  $redis->expire($country_key,900);
                  }else{
                    $countries = json_decode(Redis::get($key));
                  }
                } catch(\Exception $e){
                    $countries = $this->getCountryList();
                } 

        $lastRow=[];
        $display_pages="SmartAnalytics.smart_analytics_list2";
             $result  = array(
                'operatorData' => $operators,
                'countriesData' => $countries,                          
                'selectedTraffic' => $TrafficType_request,                          
                'selectedCountry' => $Country_request,                          
                'selectedCarrier' => $carrier_request,                          
                'selectedOs' => $Os_request,                          
                'selectedBrowser' => $Browser_request,                          
                'dtvalue' => $dtvalue,
                'dtvalue2' => $dtvalue2,
                'data1' => $data1,
                'lastRow'=>$lastRow,
                'hour' => $hour,
                'header' => $header,
                'routename'=>$routename
              );
                  

             $dataN =  view($display_pages)->with($result);
             return $dataN;
    }
    
     /* to get operator*/
    function getOperatorList(){
        $select_opr =  [
            "opr.id",
            "opr.name",
            "count.iso",
        ];
        $oprdatas =  DB::table("operator as opr")
        ->select($select_opr)
        ->join('country as count', 'count.iso', '=', 'opr.country_code')
        ->get();

        $ddDataResult1  = array(
                'opr_dropdown' => []
            );
        foreach ($oprdatas as $dropdown) {
            $ddDataResult1['opr_dropdown'][$dropdown->id] = $dropdown->name." (".$dropdown->iso.")";
        }
        return $ddDataResult1;
    }


    /* to get countries
      * date : 20 Feb 2018
     */
    function getCountryList(){
        $select_opr =  [
            "c.id",
            "c.name",
            "c.iso",
        ];
        $oprdatas =  DB::table("country as c")
        ->select($select_opr)
        ->get();

        $ddDataResult1  = array(
                'countries' => []
            );
        foreach ($oprdatas as $dropdown) {
            $ddDataResult1['countries'][$dropdown->iso] = $dropdown->name." (".$dropdown->iso.")";
        }
        return $ddDataResult1;
    }



    public function check_data_in_table(){
			$datess = array();
			$date = new DateTime();
			$last = $date->format("Y-m-d");
			$end_date = $date->modify('+3 hour');
			$first = $end_date->format("Y-m-d");
			$step = '+1 hour'; $format = 'Ymd';
				$dates = array();
                $current = strtotime($first);
                $last = strtotime($last);
                while( $current <= $last ) {    
                    $dates[] = date($format, $current);
                    $current = strtotime($step, $current);
                }
                return $dates;
		}
    
	
		
		public function display_datewsie_data(){
			$flag=0;
			$date_ranges = $this->check_data_in_table();
			rsort($date_ranges);
			$today_date = date('Ymd');
			$start = date('H');
			$end = 0;
			if($flag==0){
			foreach($date_ranges as $dat){
				$start = ($dat == date('Ymd'))? date('H'):'24';	
				for($time = $start; $time > $end; $time--) {
				 $table_name ='smart_analytics_'.$dat.date("H", mktime($time-1));
				$check_table=Schema::hasTable($table_name);
				
				if($check_table){
					$data = DB::table($table_name)->count();
					if($data>0)
					{
						$flag=1;
						return $table_name;
						break 1;
						}
						}
					}
				}
				}
			}
	
	
		
        public function report_details(Request $request,$parent_cca, $start,$end,$header="Smart Analytics Details",$routename="SmartAnalyticsdetails") {
            $table=$this->display_datewsie_data();
                   
        $condtion=[];
        array_push($condtion,['crc_records_new.create_time','>=',$start]);
        array_push($condtion,['crc_records_new.create_time','<=',$end]);
        $total = $request->total ? $request->total:50;
          

       $data = DB::select("select crc_records_new.id_ad as id_ad, crc_records_new.parent_cca as parent_cca, crc_records_new.network_name, crc_records_new.op_name, crc_records_new.traffic_type, crc_records_new.advertiser_name, crc_records_new.advertiser_campain_name, sum(crc_records_new.clickcount) AS clickcount, sum(crc_records_new.conversion_count)  AS conversion_count, sum(crc_records_new.conversion_count_unique) AS conversion_count_unique, sum(crc_records_new.clicks_active_count)  AS clicks_active_count, sum(crc_records_new.revenue_dollar)  AS revenue_dollar, $table.subPublisherId,$table.advertiserCampaignId, $table.RefererUrl, $table.Device, $table.OS, $table.Browser, $table.ConversionPayOut, $table.hour from crc_records_new left join $table on $table.publisherId = crc_records_new.parent_cca where (crc_records_new.create_time >= '$start' and crc_records_new.create_time <= '$end' and crc_records_new.parent_cca = '$parent_cca') and $table.advertiserCampaignId = crc_records_new.id_advertiser_campaign  group by $table.advertiserCampaignId order by $table.advertiserCampaignIds desc limit $total ");
      
                    $data1=[];
                    if(count($data)>0){
        foreach ($data as $fetch_url) {
           $array = [];
            array_push($array,
                    $fetch_url->advertiserCampaignId,
                    $fetch_url->advertiser_campain_name,
                    $fetch_url->subPublisherId,
                    $fetch_url->advertiser_name,
                    $fetch_url->RefererUrl,
                    $fetch_url->Device,
                    $fetch_url->OS,
                    $fetch_url->Browser,
                    $fetch_url->ConversionPayOut,
                    $fetch_url->hour
                  );
               array_push($data1, $array);
            }
        }else{
            $data1=array();
        }

                     $result  = array('data1' => $data1,
            "routename"=>$routename,
            'header'=>$header,
            'parent_cca'=>$parent_cca,
            'start'=>$start,
            'end'=>$end,   
            'dtvalue' => $start,
            'dtvalue2' => $end,
            'total' => $total
          );

                     $display_pages='SmartAnalytics.smart_analytics_list2';
                     $dataN =  view($display_pages)->with($result);
                    return $dataN;

                    $this->get_currenT_table();
        }



        public function get_currenT_table(){
           $table = 'smart_analytics_'.date("Ymd");
             $tables = DB::select("SHOW TABLES LIKE  '$table%'"); 

              echo '<pre>';
              print_r($tables);
              echo '</pre>';

        }
		
		       


}
