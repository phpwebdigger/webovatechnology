<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Operator;

class OperatorController extends Controller
{
 	
 	public function __construct()
    {
        $this->middleware('auth');
    }
    
	function getOperatorList(Request $request) 
	{
        $select =  ["operator.name as operator_name",
                         "operator.country as country",
                         "operator.language as language",
                         "operator.country_code as country_code",
                         "operator.rahul_cpa as rahul_cpa",
                         "operator.status as status",
                         "operator.id"];
         $data =  Operator::select($select)
         ->orderBy('operator.id', 'ASC')
         ->get();
         
        $data1 = [];
        $stat = '';
        $i=0;
        foreach ($data as $fetch_records)
        {
            $i++;

            $array = [];
            if($fetch_records->status==1)
            {
                $stat = 'Active';
            }
            else
            {
                $stat = 'Inactive';
            }

            array_push($array,
                    $i,
                $fetch_records->id,
                
                $fetch_records->operator_name,
                $fetch_records->country,
                $fetch_records->language,
                $fetch_records->country_code,
                $fetch_records->rahul_cpa,
                $stat,
                '<a href="/operator/edit/'.$fetch_records->id.'"><button type="button" class="btn btn-danger btn-circle "><i class="fa fa-edit"></i></button></a>'
                );
            array_push($data1, $array);

        }
        
        $result  = array('data1' => $data1);
         return view('Resources.OperatorList')->with($result);
//        return view('/Resources.OperatorList',['operator' => $data]);
    }

    function showaddoperatorview()
    {
        return view ('/Resources.addoperator');
    }

    function AddOperator(Request $request)
    {   
        // dd($request->all());
        $data  = array(
                'name' => $request->operator_name,
                'country'=> $request->country,
                'country_code'=> $request->country_code,
                'language'=> $request->language);
        Operator::create($data);
        return redirect('/Resources/list-operator');
   }
   function editOperator($id)
    {
        $operator=Operator::find($id);
        return view ('/Resources.editoperator',compact('operator'));
    }

      //Database updation

    public function update(Request $request)
     {
       
        $operator=Operator::find($request->id);
        $operator->name = $request->operator_name;
        $operator->country = $request->country;
        $operator->country_code = $request->country_code;
        $operator->language = $request->language;
        $operator->rahul_cpa = $request->rahul_cpa;
        $operator->status = $request->status;
        $operator->save();

        return redirect('/Resources/list-operator');
     }
        
}


