<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;
use App\QueryAccess;
use Illuminate\Foundation\Validation\ValidatesRequests;
use App\Advertiser;
use App\User;
use App\AdNetwork;
use App\reverse_setting;
use App\SmartRotatorCampaignsOpeators;
use App\Offerurl;
use Auth;
use Session;
use Response;
use Validator;

class NewofferurlmanagementController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }


    public function index_list(Request $request,$pagename="Url list",$routename = "Offerurllistdata",$header_name="Offerwall Url Management"){
    	    $dtvalue = date('Y-m-d');
        $dtvalue2 = date('Y-m-d');
        
 

        $select ="concat(adn.name,' (', adn.ccz ,')')  as advertiser_name,"
                  ."sco.id_zone,"
                  ."sco.id,"
                  ."ac.name,"
                  ."sco.offer_url,"
                  ."concat(ops.name,' (',sco.op_id,')') as operator_name,"
                  ."sco.redirect_operator_config,"
                  ."sco.is_offer_direct as smart_live,"
                  ."sco.redirect_country_config,"
                  ."sco.redirect_diversion_config,"
                  ."sco.id as smart_rotator_id,"
                  ."sco.campaign_id as parent_cca";

                   $data =  DB::table("smart_rotator_campaigns_operators as sco")
                            ->selectRaw(DB::raw($select))
                            ->whereIN('sco.ads_cat',['OM','OG']) 
                            ->leftJoin("ad_network as adn","adn.ccz","=","sco.id_zone")
                            ->rightJoin("advertiser_campaigns as ac","ac.id","=","sco.campaign_id")
                            ->leftJoin("operator as ops","ops.id","=","sco.op_id")
                            ->groupby("sco.campaign_id")
                            ->groupby("sco.id_zone")
                            ->get();

        // $data = DB::select( DB::raw("select concat(adn.name,' (', adn.ccz ,')')  as advertiser_name,sco.id_zone,sco.id,ac.name,sco.offer_url,concat(ops.name,' (',sco.op_id,')') as operator_name, sco.redirect_operator_config,sco.is_offer_direct as smart_live,sco.redirect_country_config,sco.redirect_diversion_config,sco.id as smart_rotator_id,sco.campaign_id as parent_cca

        //   from `smart_rotator_campaigns_operators` as `sco` 

        //   left join `ad_network` as `adn` on `adn`.`ccz` = `sco`.`id_zone` 

        //   right join `advertiser_campaigns` as `ac` on 

        //   `ac`.`id` = `sco`.`campaign_id`  

        //   left join operator as ops ON ops.id=sco.op_id  

        //   where   sco.ads_cat in ('OM','OG')   group by `sco`.`campaign_id`,`sco`.`id_zone`"));
            
            $i=0;
            $data1 = [];
         	$clickcount = $clicks_active_count= $conversion_count= $conversion_count_unique= 0;
              $array_re = (array)$this->getListopcamcountry(); 
          
           // // if($data)
          //  {
				foreach ($data as $fetch_records)
				{
						 $checked = $disable= $selected_radio_button1 = $selected_radio_button2= $selected_radio_button3="";
					   $i++;
	            $c_mae = $fetch_records->name;
                
                if($fetch_records->smart_live==2){
                  $selected_radio_button2='checked';
                } if($fetch_records->smart_live==1){
                  $selected_radio_button1='checked';
                }if($fetch_records->smart_live==3){
                  $selected_radio_button3='checked';
                }
                 // $cf =(array)$fetch_records->redirect_diversion_config;
             if(empty(json_decode($fetch_records->redirect_diversion_config,1))) {
                    $disable= 'disabled="disabled"';
                }
        

          $checked="<tr style='width:90px;'><td><input type='radio' id='smart_live' value='1' tg=".$fetch_records->smart_live."  name='smart_live_".$fetch_records->id."' dta-val='".$fetch_records->smart_rotator_id."' data-tag='".$fetch_records->id."' ".$selected_radio_button1." > Direct Offer </td>
           <td><input type='radio' value='2' id='smart_live' name='smart_live_".$fetch_records->id."' tg=".$fetch_records->smart_live." dta-val='".$fetch_records->smart_rotator_id."' data-tag='".$fetch_records->id."' ".$selected_radio_button2."> No Direct </td>
           <td><input type='radio' value='3' id='smart_live' tg=".$fetch_records->smart_live." name='smart_live_".$fetch_records->id."' dta-val='".$fetch_records->smart_rotator_id."' data-tag='".$fetch_records->id."' ".$selected_radio_button3." ".$disable." > Diversion </td></tr>";

               $button='<a href="#" onclick=Editoffer_diversion_config('.$fetch_records->smart_rotator_id.','.$fetch_records->parent_cca.') class="btn btn-primary btn-xs" name="diversion" value="Diversion" id="diversion" data-tag="'.$fetch_records->id.'">Edit</a>';

               $button2='<a href="#"  onclick =Editoffer('.$fetch_records->smart_rotator_id.','.$fetch_records->parent_cca.'); class="btn btn-primary btn-xs" name="diversion" value="Diversion" id="diversion" data-tag="'.$fetch_records->id.'">Edit</a>';

               $button3='<a href="#" onclick =Editoffer_country_config('.$fetch_records->smart_rotator_id.','.$fetch_records->parent_cca.'); class="btn btn-primary btn-xs" name="dountry_diversion" value="Country_Diversion" id="Country_Diversion" data-tag="'.$fetch_records->id.'">Edit</a>';

            $array = [];
             $josn_op = $json_coun= $josn_div="";
              
              $josn_op=json_decode( $fetch_records->redirect_operator_config);

              $json_coun = json_decode( $fetch_records->redirect_country_config);

              $json_div = json_decode( $fetch_records->redirect_diversion_config);
              
              $trf ='';
              if(isset($josn_op)){
               $trf .='<table class="table color-table    dataTable">';

          foreach((array)$josn_op as $key => $value) {
              if(isset($key) && isset($value)){   
               $trf .='<tr>';
              if( isset($array_re[2][$key]) ){ 
               $trf .='<td>'.$array_re[2][$key].'</td>';
               }
               else{
                $trf .='<td>'.$key.'</td>';
               }
              if( isset($array_re[1][$value]) ){ 
               $trf .='<td >'.$array_re[1][$value].'</td>';
                }
                else{
                   $trf .='<td >'.$value.'</td>';
                }
               $trf .='</tr>';
              }else{
              $trf .='<tr><td>NULL</td></tr>';

              }
            

              }

              $trf .='</table>';

            }
         
            $cntry ="";

            if(isset($json_coun)){

               $cntry .='<table class="table color-table    dataTable">';
          foreach ((array)$json_coun as $key => $value) {
              if(isset($key) && isset($value)){
               $cntry .='<tr>';
               $cntry .='<td>'.$array_re[0][$key].'</td>';
               $cntry .='<td >'.$array_re[1][$value].'</td>';
               $cntry .='</tr>';
             }
             else{
              $cntry .='<tr>';
               $cntry .='<td>Null</td>';
             $cntry .='</tr>';
             }
              }
              $cntry .='</table>';
            }


            $div ="";

            if(isset($json_div)){

               $div .='<table class="table color-table    dataTable">';
          foreach ((array)$json_div as $key => $value) {

              if(isset($key) && isset($value)){
               $div .='<tr>';
               if(!empty($array_re[1][$key]))
               {
               $div .='<td>'.$array_re[1][$key] .' : '. $value.'</td>'; 
               }else{
                $div .='<td></td>';
               }
               $div .='</tr>';
             }
             else{
              $div .='<tr>';
               $div .='<td>Null</td>';
             $div .='</tr>';
             }
              }
              $div .='</table>';
            }


             
            array_push($array,
           $fetch_records->advertiser_name,
           $c_mae,
           $fetch_records->parent_cca,
           $fetch_records->operator_name,
           $checked.'<span id="message_'.$fetch_records->id.'" style="display:block;"></span>',
            //$fetch_records->redirect_operator_config,
           // $trf,
           // $button2,
           //$cntry,
           //$button3,
           $div,
					 $button
                );
           	 array_push($data1, $array);
         
				}	



    		 $result  = array('data1' => $data1,
            'routename'=>$routename,
            'header_name'=>$header_name,
            
           
          );
    		  return view('Newofferurlmanagement.newofferwallurlmgntlist')->with($result);
	}


	public function diversion_list(Request $request,$id,$routename = "OfferwallDiversion-update",$header_name="Offerwall Diversion List"){

			$condtion=array();
			$data1=array();
			$lastRow='';
       $mess='';
			$dtvalue = date('Y-m-d');
			$enddate = date('Y-m-d');
			//array_push($condtion,['crc.create_time','>=',$dtvalue] );
            //array_push($condtion,['crc.create_time','<=',$enddate] );
      $id=$request->id;
			$select=['country_code','redirect_diversion_config','op_id'];
		
			$dat_data=DB::table('smart_rotator_campaigns_operators')->select($select)->where('id',$id)->first();
			$country_details= $dat_data->country_code;
      $operator_details= $dat_data->op_id;	
		
    	if($operator_details !="" || $operator_details == 0){
					$dataMain= DB::table("advertiser_campaigns")->select('advertiser_campaigns.name as offer_url','advertiser_campaigns.id as campaign_id')->where('advertiser_campaigns.status','=','1')
          ->whereIN('advertiser_campaigns.id_op',['0','-1','-2',$operator_details])
					->whereIN('advertiser_campaigns.country_code',[$country_details])->get();
					$dataMain=$dataMain->toArray();
        }
			
      if(!empty($request->campaign_name)){
        $get_update_ip=$request->id;
        $va = $cf = [];
        $campaigns=[];
        $percentage_value='10';
        $update_rotator='';
        foreach ($request->campaign_name as $key => $value) {
          $campaigns[$value] = $percentage_value;
        }
       
       
        $update_rotator = SmartRotatorCampaignsOpeators::find($get_update_ip);
        $cf = (array)json_decode($update_rotator->redirect_diversion_config);
        $va = $this->mergePerKey($campaigns,$cf);
        $update_rotator->redirect_diversion_config=json_encode($va);
        $update_rotator->save();
        if($update_rotator){
          $mess="Success";
        }
        
      }


			$result=array('campaigns'=>$dataMain,'data1' =>$data1,'id'=>$id, 'routename'=>$routename,'lastRow'=>$lastRow,'id'=>$id,'mess'=>$mess);
		 return $result;

	}	

public function updatenew_diversion(Request $request){


        $get_update_ip = $request->data_id_diversion;
        $va = $cf = [];
        $campaigns=[];
        $percentage=$request->percentage;
        $update_rotator='';
        $mess="";
        if(isset($request->campagin_name_diversion)){
        foreach ($request->campagin_name_diversion as $key => $value) {
          $campaigns[$value] = $percentage[$key];
        }
         $update_rotator = SmartRotatorCampaignsOpeators::find($get_update_ip);
         $cf = (array)json_decode($update_rotator->redirect_diversion_config);
         $va = $this->mergePerKey($campaigns,$cf);
         $update_rotator->redirect_diversion_config=json_encode($va);
         $update_rotator->save();
       if($update_rotator){
          $mess="Success";
        }
      }
        echo $mess;
} 



  public function diversion_remove(Request $request){
    $id=$request->id;
    $parent_cca=$request->parent_cca;
    $cf=array();
    $percentage_value=$request->parent_cca;
    $redirect_diversion_config=[];
    $redirect_diversion_config[$parent_cca]=$percentage_value;
    $update_rotator = SmartRotatorCampaignsOpeators::find($id);
    $update_rotator=$update_rotator->toArray();
    $cf = (array)json_decode($update_rotator['redirect_diversion_config'],true);
    unset($cf[$parent_cca]);
    $update_rotator_update = SmartRotatorCampaignsOpeators::find($id);
    $update_rotator_update->redirect_diversion_config=json_encode($cf,JSON_FORCE_OBJECT);
     $update_rotator_update->save();
    if($update_rotator_update){
   
       $mess="Successfull Diversion Remove ";
    }
    return $mess;
  }



  public function opratordiversion_list(Request $request,$id,$header_name="Offerwall Operator Diversion",$routename="OperatorDiversion"){

      $condtion = $operator_dataMain= $country_dataMain =[];
      $data1=array();
      $lastRow='';
      $mess='';
      $mess="";
      $select=['country_code','redirect_operator_config','op_id'];
      $id=$request->id;
      $dat_data=SmartRotatorCampaignsOpeators::select($select)->where('id',$id)->first();
      $dat_data=$dat_data->toArray();
      $country_details= $dat_data['country_code'];  
      if($country_details){
          $dataMain= DB::table("advertiser_campaigns")
          ->select('advertiser_campaigns.name as offer_url','advertiser_campaigns.id as campaign_id')
          ->where('advertiser_campaigns.status','=','1')
          ->where('advertiser_campaigns.country_code','=',$country_details)->get();
          $dataMain=$dataMain->toArray();
      }
          $operator_dataMain= DB::table("operator")->select('id as op_id','name as operator_name', 'country_code')->get();
          $operator_dataMain=$operator_dataMain->toArray();
          $operator_dataMain = array_map(function ($operator_dataMain) {
                        return (array)$operator_dataMain;
                    }, $operator_dataMain);
         
           $country_dataMain= DB::table("country")->select('iso as country_name_iso','nicename as country_name', 'iso3')->limit(100)->get();
          $country_dataMain=$country_dataMain->toArray();
          $country_dataMain = array_map(function ($country_dataMain) {
                        return (array)$country_dataMain;
                    }, $country_dataMain);
         

         $result=array('campaigns'=>$dataMain,'operator_list'=>$operator_dataMain,'country_list'=>$country_dataMain,'data1' =>$data1,'id'=>$id,'header_name'=>$header_name, 'routename'=>$routename,'id'=>$id,'mess'=>$mess);

        return $result;
        }


        public function opratordiversion_update(Request $request){
             
            if(empty($request->data_id)){

              $mess="Some Option Not Selected ! Data Not inserted";
            }
              elseif( empty($request->edit_waitage) ){
              $mess="Some Option Not Selected ! Data Not inserted";
            }
            elseif( empty($request->edit_operator) ){
              $mess="Some Option Not Selected ! Data Not inserted ";
            }

       else {
          $get_update_ip=$request->data_id;

          $edit_waitage =$request->edit_waitage;
           $edit_operator = $request->edit_operator;
          $campaigns=[];

          foreach ($request->edit_operator as $key => $value) {
          $campaigns[$value] = $edit_waitage[$key];
          }

        $update_rotator = SmartRotatorCampaignsOpeators::find($get_update_ip);
        $cf = (array)json_decode($update_rotator->redirect_operator_config);
        $va = $this->mergePerKey($campaigns,$cf);
        $update_rotator->redirect_operator_config=json_encode($va);
        $update_rotator->save();
        if($update_rotator){
          $mess="Success";
        }
      }
          return $mess;
        } 

         public function countrydiversion_update(Request $request){
          
          if(empty($request->data_id_country)){

              $mess="Some Option Not Selected ! Data Not inserted";
            }
              elseif( empty($request->country_oprator_edit_waitage) ){
              $mess="Some Option Not Selected ! Data Not inserted";
            }
            elseif( empty($request->country_edit_waitage) ){
              $mess="Some Option Not Selected ! Data Not inserted ";
            }
            elseif( empty($request->country_name_list) ){
              $mess="Some Option Not Selected ! Data Not inserted ";
            }

       else {

          $get_update_ip=$request->data_id_country;

          $edit_waitage =$request->country_name_list;

          $campaigns=[];

          foreach ($request->country_edit_waitage as $key => $value) {
          $campaigns[$value] = $edit_waitage[$key];
          }

        $update_rotator = SmartRotatorCampaignsOpeators::find($get_update_ip);
        $cf = (array)json_decode($update_rotator->redirect_country_config);
        $va = $this->mergePerKey($campaigns,$cf);
        $update_rotator->redirect_country_config=json_encode($va);
        $update_rotator->save();
        if($update_rotator){
          $mess="Success";
        }
      }
      return $mess;
        }



public function campaigns_list_operatorwaise(Request $request)
{
   $sql_url_s= DB::Select("select id as id_ad ,id as id_advertiser,name as titles,url from advertiser_campaigns 
    where id_op='".$request->operator_id."' AND status='1'  order by `name` asc");
    return json_encode($sql_url_s);
}

public function campaigns_list_countrywaise(Request $request)
{
   $sql_url_s= DB::Select("select id as id_ad ,id as id_advertiser,name as titles,url from advertiser_campaigns 
    where country_code='".$request->country_code."' AND status='1'  order by `name` asc");
    return json_encode($sql_url_s);
}


public function country_list(Request $request)
{
   $sql_url_Country= DB::Select("select distinct concat(nicename,'(',iso,')') as nicename ,iso from country");
    return json_encode($sql_url_Country);
}

 public function updateOfferurlreport(Request $request,$header_name="Update Offer") 
  {
      $status=$request->status;
      $id=$request->id;
      $action_step=$request->action_step;

         $data1=$dataMain=[];
          if(isset($status) && $status != ''){
         $update = array('is_offer_direct' => $status);
       }else{
         $update = array('is_offer_direct' => '0');
         }
          if($request->id){
                $dataMain = Offerurl::where('id',$request->id)->update($update);
                if($dataMain){
                  $status =  'Successfully updated is offer direct!';
               }
         
          }
             return $status; 

    }



    public function mergePerKey(array &$array1, array &$array2)
    {

      $merged = $array1;

  foreach ( $array2 as $key => &$value )
  {
    if ( is_array ( $value ) && isset ( $merged [$key] ) && is_array ( $merged [$key] ) )
    {
      $merged [$key] = array_merge_recursive_distinct ( $merged [$key], $value );
    }
    else
    {
      $merged [$key] = $value;
    }
  }
  return $merged;
    }

    public function diversion_list_status(Request $request){

      $id=$request->id;

       $select=['country_code','redirect_diversion_config','op_id','id_zone','campaign_id'];
    
        $dat_data=DB::table('smart_rotator_campaigns_operators')->select($select)->where('id',$id)->first();
        if(isset($dat_data->redirect_diversion_config)){
         $redirect_diversion_config = json_decode($dat_data->redirect_diversion_config);
       }

        if(isset($dat_data->id_zone)){
     $id_zone= $dat_data->id_zone;
    }
    
           if(isset($dat_data->campaign_id)){
     $campaign_id= $dat_data->campaign_id;
    }
    
          $data_camp=DB::table('advertiser_campaigns')->select('advertiser_campaigns.name as offer_url','advertiser_campaigns.id as campaign_id')->orderBy('name', 'asc')->get();
            // $data_camp=json_encode(json_decode($data_camp));
          $data_camp=(array)$data_camp->toArray();
              $camp_array=[];
            foreach ($data_camp as $keys => $values) {
                           $camp_array[$values->campaign_id]=$values->offer_url;
               }    
         
$data1 = [];

$trf ='';
          foreach ($redirect_diversion_config as $key => $value) {
          
                     $val=$id.'_'.$key.'_'.$value;  //15983_51464_100
                $tab_action = "<input type='button' class='btn btn-success remove_diversion' onclick='hide_button(this)' name='remove_diversion' id='remove_diversion' data_value='".$val."' value='Remove'/>"; 
             $trf .='<tr>';
            // $trf .='<td>'.$value.'</td>';
             $trf .="<td><span class='outer-container' id='outer-percent-container_".$key."'><span class='percentage-container'  id='percentage_container_".$key."' style='font-size:24px'>".$value."</span>
             <span id='percentage-".$key."' campain_data='".$key."' class='percentage-edit' data_id_zone=".$id_zone." campaign_id='".$campaign_id."' data-value=".$value.">&nbsp;<i class='fa fa-edit'></i></span></span></td>";
            if(isset($camp_array[$key])){
            $trf .='<td>'.$camp_array[$key].'{'.$key.'}'.'</td>';
          }else{
            $trf .='<td>'.$key.'</td>';
          }
            $trf .='<td>'.$tab_action.'</td>';
            $trf .='</tr>';
              }
         
        
        return $trf;

      }

      public function country_list_status(Request $request){
        
        $id=$request->id;

       $select=['country_code','redirect_country_config','op_id'];
    
        $dat_data=DB::table('smart_rotator_campaigns_operators')->select($select)->where('id',$id)->first();
        if(isset($dat_data->redirect_country_config)){
        $redirect_country_config = json_decode($dat_data->redirect_country_config);
      }
    
          $data_country=DB::table('country')->select('country.nicename as nicename','country.iso as iso')->orderBy('nicename', 'asc')->get();
            // $data_camp=json_encode(json_decode($data_camp));
          $data_country=(array)$data_country->toArray();
              $country_array=[];
            foreach ($data_country as $keys => $values) {
               $country_array[$values->iso]=$values->nicename;

               }  

 $data_camp=DB::table('advertiser_campaigns')->select('advertiser_campaigns.name as offer_url','advertiser_campaigns.id as campaign_id')->orderBy('name', 'asc')->get();
            // $data_camp=json_encode(json_decode($data_camp));
          $data_camp=(array)$data_camp->toArray();
              $camp_array=[];
            foreach ($data_camp as $keys => $values) {
                $camp_array[$values->campaign_id]=$values->offer_url;
               }    

         
$data1 = [];

$trf ='';
            if(isset($redirect_country_config)){
          foreach ($redirect_country_config as $key => $value) {
          
                     $val=$id.'_'.$key.'_'.$value; 
                $tab_action = "<input type='button' class='btn btn-success remove_country_list' onclick='hide_button(this)' name='remove_country_list' id='remove_country_list' data_value='".$val."' value='Remove'/>"; 
            $trf .='<tr>';
            if(isset($country_array[$key])){
            $trf .='<td>'.$country_array[$key].'</td>';
          }else{
            $trf .='<td>'.$key.'</td>';
          }
          if(isset($camp_array[$value])){
            $trf .='<td>'.$camp_array[$value].'</td>';
          }else{
            $trf .='<td>'.$value.'</td>';
          }
            $trf .='<td>'.$tab_action.'</td>';
            $trf .='</tr>';

              }
         }
        
        return $trf;

      }

public function country_list_remove(Request $request){

    $id=$request->id;
    
    $country_iso=$request->country_iso;
    
    $cf=array();
    
    $campaigns = $request->campaigns;
   
    
    $redirect_country_config=[];
    
    $redirect_country_config[$country_iso]=$campaigns;

    $update_rotator = SmartRotatorCampaignsOpeators::find($id);
    
    $update_rotator=$update_rotator->toArray();
    
    $cf = (array)json_decode($update_rotator['redirect_country_config'],true);

    unset($cf[$country_iso]);
    
    $update_rotator_update = SmartRotatorCampaignsOpeators::find($id);
    
    $update_rotator_update->redirect_country_config=json_encode($cf,JSON_FORCE_OBJECT);
    
    $update_rotator_update->save();
    if($update_rotator_update){
   
       $mess="Successfull Country Remove";
    }
    
    return $mess;

}

public function operator_list_status(Request $request){
        
        $id=$request->id;

       $select=['country_code','redirect_operator_config','op_id'];
    
        $dat_data=DB::table('smart_rotator_campaigns_operators')->select($select)->where('id',$id)->first();
        if(isset($dat_data->redirect_operator_config)){
        $redirect_operator_config = json_decode($dat_data->redirect_operator_config);
        }
    
          $data_operator=DB::table('operator')->select('operator.name as nicename','operator.id as iso')->orderBy('nicename', 'asc')->get();
           $data_operator=(array)$data_operator->toArray();
              $operator_array=[];
            foreach ($data_operator as $keys => $values) {
               $operator_array[$values->iso]=$values->nicename;

               }  

 $data_camp=DB::table('advertiser_campaigns')->select('advertiser_campaigns.name as offer_url','advertiser_campaigns.id as campaign_id')->orderBy('name', 'asc')->get();
            // $data_camp=json_encode(json_decode($data_camp));
          $data_camp=(array)$data_camp->toArray();
              $camp_array=[];
            foreach ($data_camp as $keys => $values) {
              $camp_array[$values->campaign_id]=$values->offer_url;
            }    

         
$data1 = [];

$trf ='';
          if(isset($redirect_operator_config)){

          foreach ($redirect_operator_config as $key => $value) {
          
                     $val=$id.'_'.$key.'_'.$value; 
                $tab_action = "<input type='button' class='btn btn-success remove_operator_list' onclick='hide_button(this)' name='remove_operator_list' id='remove_operator_list' data_value='".$val."' value='Remove'/>"; 
             $trf .='<tr>';
             if(isset($operator_array[$key])){
            $trf .='<td>'.$operator_array[$key].'</td>';  
          }else{
            $trf .='<td>'.$key.'</td>';
          }
            if(isset($camp_array[$value])){
            $trf .='<td>'.$camp_array[$value].'</td>';
          }else{
             $trf .='<td>'.$value.'</td>';
          }
            $trf .='<td>'.$tab_action.'</td>';
            $trf .='</tr>';
              }

         }
        else{
        $trf .='<tr>';
        $trf .='<td colspan="3" aling="center">No data Found</td>';
        $trf .='</tr>';
        }
        
        return $trf;

      }

public function operator_list_remove(Request $request){

    $id=$request->id;
    
    // $country_iso=$request->country_iso;
    $operator_id=$request->operator_id;
    
    $cf=array();
    
    $campaigns = $request->campaigns;
   
    
    $redirect_country_config=[];
    
    $redirect_country_config[$operator_id]=$campaigns;

    $update_rotator = SmartRotatorCampaignsOpeators::find($id);
    
    $update_rotator=$update_rotator->toArray();
    
    $cf = (array)json_decode($update_rotator['redirect_operator_config'],true);
    unset($cf[$operator_id]);
    $update_rotator_update = SmartRotatorCampaignsOpeators::find($id);
    $update_rotator_update->redirect_operator_config= json_encode($cf,JSON_FORCE_OBJECT);
    $update_rotator_update->save();
    if($update_rotator_update){
     $mess="Successfull Operator Remove";
    }
    
    return $mess;

}



      public function getListopcamcountry()
      {

          $data1=[];

          $data_country=DB::table('country')->select('country.nicename as nicename','country.iso as iso')->orderBy('nicename', 'asc')->get();
            // $data_camp=json_encode(json_decode($data_camp));
          $data_country=(array)$data_country->toArray();
              $country_array=[];
            foreach ($data_country as $keys => $values) {
               $country_array[$values->iso]=$values->nicename;
               }  

 $data_camp=DB::table('advertiser_campaigns')->select('advertiser_campaigns.name as offer_url','advertiser_campaigns.id as campaign_id')->orderBy('name', 'asc')->get();
            // $data_camp=json_encode(json_decode($data_camp));
          $data_camp=(array)$data_camp->toArray();
              $camp_array=[];
            foreach ($data_camp as $keys => $values) {
                           $camp_array[$values->campaign_id]=$values->offer_url;
               }    
                  $data_operator=DB::table('operator')->select('operator.name as nicename','operator.id as iso')->orderBy('nicename', 'asc')->get();
           $data_operator=(array)$data_operator->toArray();
              $operator_array=[];
            foreach ($data_operator as $keys => $values) {
               $operator_array[$values->iso]=$values->nicename;

               }  

               array_push($data1,$country_array, $camp_array,$operator_array);

                return $data1;

               }
}
