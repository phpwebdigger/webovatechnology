<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Auth;

class ReportController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function conversioncount() {
      return view('report.conversioncount_reports');
    }
     //cariar specific routes
    public function indexCountry(Request $request,$type="A",$routename = "indexCountryFilter",$header="Country wise CRC Records")
    {


            $condtion = [];
           
            $dtvalue = $request->start;
            $dtvalue2 = $request->end;
            
            
            if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                    $dtvalue2 = date('Y-m-d');
                    $enddate = date('Y-m-d',strtotime("+1 days"));
            }else{
                //$dtvalue2 = date('Y-m-d',strtotime("+1 days"));
               $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));

            }
            
            

            array_push($condtion,['crc_records_new.create_time','>=',$dtvalue] );
            array_push($condtion,['crc_records_new.create_time','<=',$enddate] );
          


           
        
            array_push($condtion,["crc_records_new.network_name","!=",""] );

            $request->total = $request->total ? $request->total : 50;
            
            $select =  "crc_records_new.parent_cca"
                       .",operator.country_code"
                       .",crc_records_new.op_id"
                       .",crc_records_new.network_name"
                       .",crc_records_new.op_name as op_name"
                       .",sum(crc_records_new.conversion_count_unique) as conversion_count_unique"
                       .",sum(crc_records_new.cost_dollar) as total_cost "
                       .",crc_records_new.id_ad"
                       .",crc_records_new.id_channel"
                       .",crc_records_new.revenue_dollar as revenue"
                       .",avg(advertiser_vw.advertiser_campaign_cpa) as cpa"
                       .",sum(crc_records_new.clickcount) as clickcount"
                       .",sum(crc_records_new.conversion_count) as conversion_count"
                       .",sum(crc_records_new.clicks_active_count) as clicks_active_count"
                       .",CONCAT(AVG(crc_records_new.cr_goal),'%') AS cr_goal"
                        .",CONCAT(AVG(crc_records_new.cr_received),'%')AS cr_received"
                        .",CONCAT(AVG(crc_records_new.cr_given),'%') AS cr_given"
                        .",crc_records_new.create_time";
        $appends = [];


        
              $data =  DB::table("crc_records_new")
              
              ->where($condtion) 
             ->selectRaw(DB::raw($select))
             ->leftJoin("operator","operator.id","=","crc_records_new.op_id")
             ->leftJoin("advertiser_vw","advertiser_vw.id_advertiser_campaign","=","crc_records_new.id_advertiser_campaign")
             ->groupby("crc_records_new.parent_cca");
             
              if($request->colorder){
                 $data = $data->orderby($request->colorder,$request->order);
                 $appends["colorder"]=$request->colorder;
                 $appends["order"]=$request->order;
              }else{
                 $data = $data->orderby("crc_records_new.network_name","ASC");
              
               }
            

             $data = $data->get();
             
             $data1 = [];
                $clickcount = 0;
                $conversion_count = 0;
                $clicks_active_count = 0;
                $distinct_conersion = 0;
                $sourcost = 0;
                $fraud = 0;
                $convCount = 0;
                $profit = 0;

          foreach ($data as $fetch_records) {
                $array = [];
//                $totalCost  =   array_key_exists($fetch_records->id_advertiser_campaign,$rtotal)?$rtotal[$fetch_records->id_advertiser_campaign]:0;
                array_push($array,
                            $fetch_records->parent_cca,
                                           
                            $fetch_records->network_name,
                            $fetch_records->clickcount,
                            $fetch_records->conversion_count,
                            $fetch_records->clicks_active_count,
                            round($fetch_records->cr_received,2),
                            round($fetch_records->cr_given,2),
                            $fetch_records->conversion_count_unique,
                            round($fetch_records->cr_goal,2),
                            round($fetch_records->total_cost,2).'/'.round($fetch_records->total_cost * 65, 2),
                            round($fetch_records->cpa * $fetch_records->conversion_count),
                            round($fetch_records->cpa * $fetch_records->conversion_count,2) - round($fetch_records->total_cost * 65, 2));
                            
                            
                 array_push($data1, $array);
                  

              }
              
              $result  = array('data1' => $data1,
            "routename"=>$routename,
            'header'=>$header,
            'dtvalue' => $dtvalue,
            'dtvalue2' => $dtvalue2,
           
            'total' => $request->total
           
            
          );

        

         return view('report.country-crc-report')->with($result);


     }


     
     public function crchouly(Request $request,$type="A",$routename = "crchoulyFilter",$header="CRC Hourly Records")
    {
          
          //print_r($request->select_group_by); die;
              $gbad=0;

              $select_group_by ='';
              if(isset($request->select_group_by))
              {
                //$select_group_by = ' group by ';
                          foreach($request->select_group_by as $key=>$val)
                          {
                             $select_group_by .= $val.",";
                             //echo $select_group_by; die;
                              if($val=='id_advertiser')
                              {
                                 $gbad=1;
                              }
                          }

                          $select_group_by = substr($select_group_by,0,strlen($select_group_by)-1);

              }

              $grpby = $select_group_by;



            $condtion = [];
           
            $dtvalue = $request->start;
            $dtvalue2 = $request->end;
            
            
            if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                    $dtvalue2 = date('Y-m-d');
                    $enddate = date('Y-m-d',strtotime("+1 days"));
            }else{
                //$dtvalue2 = date('Y-m-d',strtotime("+1 days"));
               $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));

            }
             
             $hour=[];

              if($request->hour)
              {
                $hour[]=$request->hour;
               array_push($condtion , ['chr.hour','=',$request->hour]);
              }

           

            if(isset($request->parent_cca))
            {
                $parent_cca=$request->parent_cca;
                array_push($condtion , ['chr.parent_cca','=',$request->parent_cca]);
            }
            else
            {
              $parent_cca="";

            }


            if($request->net_id)
            {
               //print_r($request->net_id); die;
              foreach($request->net_id as $key=>$val)
              {
                       array_push($condtion , ['chr.network_name','=',$val]);

              }
                
            }
          
            if(isset($request->Idad))
            {
                $idad=$request->Idad;
                array_push($condtion , ['chr.id_ad','=',$request->Idad]);

            }
            else
            {
              $idad="";
            }

            if(isset($request->idadvt))
            {
              $idadvt=$request->idadvt;
              array_push($condtion , ['chr.id_advertiser_campaign','=',$request->idadvt]);

            }
            else
            {
              $idadvt="";
            }

            

            array_push($condtion,['chr.date','>=',$dtvalue] );
            array_push($condtion,['chr.date','<=',$enddate] );

           
          
          if(isset($request->filter))
          {
            $filter ="filter"; 
          }
          else
          {
             $filter="";

          }

         
          
           
            $select =  "chr.id,"
                . "chr.op_name,"
                . "chr.id_ad, chr.parent_cca,chr.advertiser_campain_name,"
                . "chr.network_name,"
                  . "chr.advertiser_name,"
                . "sum(chr.clickcount) as clickcount ,"
                . "sum(chr.clicks_active_count) as clicks_active_count,"
                . "sum(chr.conversion_count) as conversion_count,"
                . "chr.network_cpa,"
                . "sum(chr.total_cost) as total_costv,"
                . "chr.cr_received,"
                . "chr.cr_given,"
                . "chr.hour,chr.total_cost,"
                . "chr.id_advertiser_campaign";
        
        if($request->report_base=='2')
        {  // echo $grpby; die;
           if($grpby!='')
           {

            $data =  DB::table("crc_records_details as chr")

            ->where($condtion) 
            ->selectRaw(DB::raw($select))
            ->groupby($request->select_group_by)
            ->orderby("hour");
          }
          
        }
         
        else if($request->report_base=='1'){
          //echo $request->report_base.$grpby; die;

              if($grpby!=''){

                    $data =  DB::table("crc_records_details as chr")

                            ->where($condtion) 
                            ->selectRaw(DB::raw($select))
                            ->groupby($request->select_group_by)
                            ->orderby("hour");
              }else{

                    $data =  DB::table("crc_records_details as chr")
                    ->where($condtion) 
                    ->selectRaw(DB::raw($select))
                    ->groupby("hour")
                    ->orderby("hour");
             }


         }else{
            //echo "eeeee" ; die;
            $data =  DB::table("crc_records_details as chr")
            ->where($condtion) 
            ->selectRaw(DB::raw($select))
            ->groupby("hour")
            ->orderby("hour");

        }

           
            if($request->advertiser)
            { 

            $data =  $data->whereIn('advertiser_name',$request->advertiser);

            }

            if($request->op_id)
            { 

              $data =  $data->whereIn('op_id',$request->op_id);

            }

             //$data = $data->toSql(); 
           // dd($data);


             $data = $data->get();
             //print_r($data); die;
            
              if($data->count() == 0)
              {
               $Nodata = "No Result Found";
              }
              else
              {
               $Nodata = "";
              }



              $opdata =  DB::table("operator")
             ->leftJoin("country","operator.country_code","=","country.iso")
             ->selectRaw(DB::raw("operator.id as id, operator.name as name,country.iso as cc"))
             ->orderby("operator.id","ASC")->get();

             $campaign_dropdown = [];
             foreach ($opdata as $dropdown1) {
                  if ($dropdown1->id && $dropdown1->name){
                     $campaign_dropdown[$dropdown1->id] = $dropdown1->name."(".$dropdown1->cc.")";
                  }
              }

        // dd($data);
         $result  = array('data' => $data,
            "routename"=>$routename,
            'header'=>$header,
            'dtvalue' => $dtvalue,
            "advertiser" =>$request->advertiser?$request->advertiser:[],
            "net_id" =>$request->net_id?$request->net_id:[],
            "select_group_by" =>$request->select_group_by?$request->select_group_by:[],
            "op_id" =>$request->op_id?$request->op_id:[],
            "report_base" =>$request->report_base?$request->report_base:'',
            "hour" =>$hour,
            'dtvalue2' => $dtvalue2,
            'NoResult' => $Nodata,
            'filter'=>$filter,
            'parent_cca'=>$parent_cca,
            'idad'=>$idad,
            'idadvt'=>$idadvt,
            'gbad'=>$gbad,
            'opdata'=>$campaign_dropdown
          );

         return view('report.crc_hourly_report')->with($result);


     }

public function appwise(Request $request,$type="A",$routename = "appwise-server-details-post",$header="Appwise Server Details")
    {


            $condtion = [];
           
            $dtvalue = $request->start;
            $dtvalue2 = $request->end;
            
            
            if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                    $dtvalue2 = date('Y-m-d');
                    $enddate = date('Y-m-d',strtotime("+0 days"));
            }else{
                //$dtvalue2 = date('Y-m-d',strtotime("+1 days"));
               $enddate = date('Y-m-d',strtotime("+0 day", strtotime($dtvalue2)));

            }
            $from = str_replace('-', '', $dtvalue);
            $to =str_replace('-', '', $enddate);

            $hours = $request->hours;

            
            if(!$request->hours)
            {
                $current_hour=date('H');
                if($current_hour < 10)
                {
                   $hours='0'.$current_hour;
                }
                else
                {
                   $hours = $current_hour;
                }

            }

            if($hours=="all")
            {
                $hours1="00";
                $hours2="23";
            }
            else {
                $hours1=$hours;
                $hours2=$hours;
            }

            if($request->appserver)
            {
              $string1=$from.$hours1.$request->appserver;
              $string2=$to.$hours2.$request->appserver;
            }
            else {
               $appserver_default='01';
              $appserver_deafult1='39';
              $string1=$from.$hours1.$appserver_default;
              $string2=$to.$hours2.$appserver_deafult1;
            }
            if(!empty($hours1) && !empty($hours2) && !$request->appserver)
            {

                 $string1=$from.$hours1.$appserver_default;
                 $string2=$to.$hours2.$appserver_deafult1;
                
            }
            
            if($request->groupby){
    
              $select = "* , sum(clickcount) as clickcount, sum(conversioncount) as conversioncount ,max(updatetime) as updatetime";
  
            }else{
              $select =  "*";
             // $request->groupby  = -1;
            }

            
        
        
              $data =  DB::table("app_wise_count as app")
              
              ->whereBetween('id',[$string1,$string2]) 
             ->selectRaw(DB::raw($select));
             //->groupby("hour");
          if($request->groupby){
                $data = $data->groupby($request->groupby);
          }         
             
            
             $data = $data->get();
           
        // dd($data);
         $result  = array('data' => $data,
            "routename"=>$routename,
            'header'=>$header,
            'dtvalue' => $dtvalue,
            'dtvalue2' => $dtvalue2,
            'groupby' => $request->groupby,
            'appserver'=>$request->appserver,
            'hours'=>$hours
          );

         return view('report.appwise-crc-report')->with($result);


     }
         public function deactivationReport(Request $request,$type="A",$routename = "deactivation-report-post",$header="Deactivations")
    {

      $advertiser_id = "";
          
$dtvalue = date('Y-m-d');
$dtvalue2 = date('Y-m-d');
$ShowDataResultArray = array();
             
$ShowDataResultArray = array();
$gbad=0;
$submit = false;

if (!empty($request->submit)) {
$submit = true;
    $dtvalue3 = date('H');
    $finalRecArr = array();    
    $report_base = $request->report_base;
    
    $opid = '';
   
    if(!empty($request->campaign)){
        foreach($request->campaign as $key=>$val)
        {
            $opid .= "'".$val."',";
        }
        $opid = substr($opid,0,strlen($opid)-1);
    }
    
    //print_r($request->campaign);
    
    $telco = '';
    if(!empty($request->operator_id))
    {
        foreach($request->operator_id as $key=>$val)
        {
            $telco .= "'".$val."',";
        }
        $telco = substr($telco,0,strlen($telco)-1);
    }

    $advertiser_name = '';
    if(!empty($request->parent_cca))
    {
//        foreach($request->parent_cca as $key=>$val)
//        {
//            $advertiser_name .= "'".$val."',";
//        }
//        $advertiser_name = substr($advertiser_name,0,strlen($advertiser_name)-1);
          $advertiser_name = $request->parent_cca;
    }
    
     $select_group_by = '';
     if(!empty($request->select_group_by))
     {
         $select_group_by = ' group by ';
          foreach($request->select_group_by as $key=>$val)
        {
            $select_group_by .= $val.",";
            if($val=='id_advertiser')
            {
                $gbad=1;
            }
        }
        $select_group_by = substr($select_group_by,0,strlen($select_group_by)-1);
     }
 else {
         $select_group_by = ' group by id_advertiser_campaign, parent_cca ';
     }
     
     $select_order_by = '';
     if(!empty($request->select_order_by))
     {
         $select_order_by = ' order by ';
          foreach($request->select_order_by as $key=>$val)
        {
            $select_order_by .= $val.",";
            
        }
        $select_order_by = substr($select_order_by,0,strlen($select_order_by)-1);
     }
    

    $idadvt = trim($request->idadvt);

    $idadvtm = trim($request->idadvtm);

    $id_adsval = trim($request->idad);
    
    $pcca = trim($request->parent_cca);
    
   
    
    
    $advertiser_id='';
    
    
    if(!empty($request->advertiser_id))
    {
        foreach($request->advertiser_id as $key=>$val)
        {
            $advertiser_id .= "'".$val."',";
        }
        $advertiser_id = substr($advertiser_id,0,strlen($advertiser_id)-1);
        
        $advertiser_id = " AND id_advertiser IN (" .$advertiser_id.")";
    }
    
    $active_array = $idad_dropdown = $operator_dropdown = $network_dropdown = array();
    
    $dtvalue =$request->from;
    
    $dtvalue2 =$request->to;

    //$traffic_type=$request->traffic_type;
    //crc_records_details

    $pcca_cond = '';

    $grpby = $select_group_by;
    $ordby = $select_order_by;
    $hourd='';
    
    if(!empty($request->hour))
    {
        $hourd =" AND chr.hour ='".trim($request->hour)."'";
    }

    if ($dtvalue == "" || $dtvalue2 == "") {
        $dtvalue = date('Y-m-d');
        $dtvalue2 = date('Y-m-d');
    }

    $channel_cond = $teco_cond = $op_cond = $idadvt_cond = $id_adsval_cond = '';
    
    if ($opid != "") {
        $op_cond = "  AND op_id IN (" . $opid . ")";
    }
    $ntwrk_cond = "";
    if ($telco != "") {
        $ntwrk_cond = "  AND network_name IN (" . $telco . ")";
    }
   
    if ($advertiser_name != "") {
        $teco_cond = "  AND parent_cca = '" . $advertiser_name . "'";
    }

    if ($id_adsval != "") {
        $id_adsval_cond = "  AND chr.id_ad='" . $id_adsval . "'";
    }

    if ($pcca != "") {
        
         if (strpos($inapps,',') !== false) 
         {
              $inapArr=explode(",",$pcca);
              $$pccaval='';
              foreach($inapArr as $key=>$val)
              {
                  $pccaval .="'".$val."',";
              }
              $pccaval=  substr($pccaval, 0,strlen($pccaval)-1);
              $pcca_cond = "  AND chr.parent_cca IN (" . $pccaval . ")";
         }else{
            $pcca_cond = "  AND chr.parent_cca='" . $pcca . "'"; 
         }
        
        
    }
    
//    if($report_base=='1')
//    {
    if ($select_order_by =='')
    {
        $dataquery = "SELECT id, advertiser_name,"
                . "operator_name,"
                . "url_name,"
                . "network_name,"
                . "parent_cca,"
                . "id_advertiser_campaign,"
                . "sum(conversion_count) as conCount,"
                . "sum(deactivation_count) as deCount,"
                . "sum(deactivation_count_twenty) as deCountTwenty,"
                . "sum(false_deactivation_count) as falseCount,"
                . "sum(false_deactivation_count_twenty) as falseTwenty,"
                . "summary_date"
                . " FROM "
                . "deactivation_summary_temp"
                . " WHERE  "
                . " DATE(summary_date) BETWEEN DATE('" . $dtvalue . "')  AND  DATE('" . $dtvalue2 . "') $ntwrk_cond $op_cond $advertiser_id $teco_cond $grpby order by id";
    }
    else
    {
        $dataquery = "SELECT id, advertiser_name,"
                . "operator_name,"
                . "url_name,"
                . "network_name,"
                . "parent_cca,"
                . "id_advertiser_campaign,"
                . "sum(conversion_count) as conCount,"
                . "sum(deactivation_count) as deCount,"
                . "sum(deactivation_count_twenty) as deCountTwenty,"
                . "sum(false_deactivation_count) as falseCount,"
                . "sum(false_deactivation_count_twenty) as falseTwenty,"
                . "summary_date"
                . " FROM "
                . "deactivation_summary_temp"
                . " WHERE  "
                . " DATE(summary_date) BETWEEN DATE('" . $dtvalue . "')  AND  DATE('" . $dtvalue2 . "') $ntwrk_cond $op_cond $advertiser_id $teco_cond $grpby $ordby ";
    }
    
}
else {
    $dataquery = "SELECT id, advertiser_name,"
                . "operator_name,"
                . "url_name,"
                . "network_name,"
                . "parent_cca,"
                . "id_advertiser_campaign,"
                . "sum(conversion_count) as conCount,"
                . "sum(deactivation_count) as deCount,"
                . "sum(deactivation_count_twenty) as deCountTwenty,"
                . "sum(false_deactivation_count) as falseCount,"
                . "sum(false_deactivation_count_twenty) as falseTwenty,"
                . "summary_date"
                . " FROM "
                . "deactivation_summary_temp"
                . " WHERE  "
                . " DATE(summary_date) BETWEEN DATE('" . $dtvalue . "')  AND  DATE('" . $dtvalue2 . "') GROUP BY id_advertiser_campaign, parent_cca";
}


$current_hour_from=date('H');
    $current_mintue_to=date('i');

     $current_hour_from = intval($current_hour_from);
    if ($current_hour_from < 10)
        $current_hour_from = '0' . $current_hour_from;
    if ($current_hour_from == date('H')) {
        $current_hour = date('H');
        $dtvalue_today = str_replace('-', '', $dtvalue);
        $date1 = $dtvalue_today . $current_hour_from . "0000";
        if (!empty($current_mintue_to) && $current_mintue_to > 0) {
            $current_mintue_to = intval($current_mintue_to);
            if ($current_mintue_to < 10) {
                $date2 = $dtvalue_today . $current_hour_from . '0' . $current_mintue_to . '00';
            } else {
                $date2 = $dtvalue_today . $current_hour_from . $current_mintue_to . '00';
            }
        }
    }
    
 
//select distinct deactivation_summary_temp.op_id,deactivation_summary_temp.operator_name, operator.country_code from deactivation_summary_temp LEFT JOIN operator ON deactivation_summary_temp.op_id = operator.id order by deactivation_summary_temp.operator_name

$dropdown_op = "select distinct deactivation_summary_temp.op_id, "
        . "deactivation_summary_temp.operator_name, "
        . "operator.country_code from deactivation_summary_temp "
        . "LEFT JOIN operator ON deactivation_summary_temp.op_id = operator.id order by deactivation_summary_temp.operator_name";
$opResultArray =DB::select($dropdown_op);

$dropdown_network = "select distinct network_name from deactivation_summary_temp order by network_name ASC";
$networksResultArray = DB::select($dropdown_network);

foreach ($opResultArray as $dropdown1) {
    if ($dropdown1->op_id && $dropdown1->operator_name)
        $campaign_dropdown[$dropdown1->op_id] = $dropdown1->operator_name." (".$dropdown1->country_code.")";
}
$n=1;
foreach ($networksResultArray as $dropdown2) {
    if ($dropdown2->network_name)
        $operator_dropdown[$n] = $dropdown2->network_name;
    $n++;
}

$m=1;
$dropdown_cca = "select distinct parent_cca from deactivation_summary_temp order by parent_cca ASC";
$ccaResultArray =DB::select($dropdown_cca);
foreach ($ccaResultArray as $dropdown4) {
    if ($dropdown4->parent_cca)
        $parent_dropdown[$m] = $dropdown4->parent_cca;
    $m++;
}


//Add the Advertsier code by date - 01-03-2016
$query_advertiser = "SELECT distinct id_advertiser, advertiser_name "
        . "from "
        . "deactivation_summary_temp "
        . "order by advertiser_name ASC";
$advertiser_Result_Array = DB::select($query_advertiser);
foreach ($advertiser_Result_Array as $dropdown3) {
    if ($dropdown3->id_advertiser && $dropdown3->advertiser_name)
        $advertiser_dropdown[$dropdown3->id_advertiser] = $dropdown3->advertiser_name;
}

$crinw=array();


 $ShowDataResultArray = DB::Select($dataquery);
//dd($ShowDataResultArray);
        // dd($data);
         $result  = array('data' => $ShowDataResultArray,
            "routename"=>$routename,
            'header'=>$header,
            'advertiser_id'=>$request->select_group_by ? $request->select_group_by : [],
            'dtvalue' => $dtvalue,
           
           
            "select_group_by2" =>$request->select_group_by ? $request->select_group_by:[],
         
           
            "advertiser_dropdown" =>$advertiser_dropdown,
            'dtvalue2' => $dtvalue2,
             'campaign_dropdown' => $campaign_dropdown,
            'campaign'=>$request->campaign ? $request->campaign : [],
            'operator_dropdown'=>$operator_dropdown,
            'operator_id'=>$request->operator_id ? $request->operator_id :  [],
             'parent_cca'=>$request->parent_cca ? $request->parent_cca : "",
             'select_order_by'=>$request->select_order_by ? $request->select_order_by : [],
            'gbad'=>$gbad,
            'submit'=>$submit,
          
           // 'opdata'=>$campaign_dropdown
          );
        //dd($result);

         return view('report.deactivation_report')->with($result);


     }

}
