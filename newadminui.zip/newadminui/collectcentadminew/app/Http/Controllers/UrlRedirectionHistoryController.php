<?php

namespace App\Http\Controllers;
use App\User;
use App\Role;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Cookie;
use App\UrlRedirectionHistory;


class UrlRedirectionHistoryController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

    function data(Request $request){
        
        $id_advertiser = $request->id_advertiser;
        $from_date = $request->from;
        $to_date = $request->to;
        
        $hour = $request->hour;
        
        if($from_date == '')
        {
            $from_date = date('Y-m-d');
        }
        
        if($to_date == '')
        {
            $to_date = date('Y-m-d');
        }
        
        if($hour == '')
        {
            $hour = date('H');
        }
        
        if($hour == 'ALL')
        {
            $hour = '0';
        }
        
        $to_time = date(' H:i:s');
        $time = ' '.$hour.':00:00';
        
        $date_from = $from_date.$time;
        $date_to = $to_date.$to_time;

//        echo "From Date = ".$date_from."<br>";
//        echo "To Date = ".$date_to."<br>";
//        die();

        $condtions=[];
        array_push($condtions, ['id_advertiser','=',$request->id_advertiser] );
        array_push($condtions, ['request_date_time','>=',$date_from]);
        array_push($condtions, ['request_date_time','<=',$date_to]);
        
        $select =  ["*"];

        $data =  DB::table("url_redirection_history")
        ->select($select)
//        ->where('requestDateTime', '>',$formatted_date)
        ->where($condtions)
        ->orderBy('request_date_time', 'DESC')
//        ->limit(100)
         ->get();
        $data1= [];
        $count = 0;        
//        dd($data);die();         
        foreach ($data as $result) {
                $array = [];

                $count++;
                array_push($array,
                    $result->id_advertiser,
                    $result->url,
                    $result->http_response_code,
                    $result->loopBack_status,
                    $result->loopBack_url_count,
                    $result->loopBack_error_count,
                    $result->request_date_time                       
                );
                array_push($data1, $array);
        }
        
        $view = 'redirect.redirectHistory-data';
        return view($view,compact('data1','from_date','to_date','hour','id_advertiser'));
    }
    
  
}
