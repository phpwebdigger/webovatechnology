<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Ad;
use App\ads;
use App\operator;
use Illuminate\Support\Facades\Input;
use Response;
use App\AdvertiserCampaign;
use Session;

class BlockController extends Controller
{
   
    public function __construct()
    {
        $this->middleware('auth');
    }


    public function addblockcca(){
    
    $advertisers = DB::select("SELECT DISTINCT adv.id_advertiser, advertiser.name FROM advertiser_campaigns as adv 
               JOIN advertiser ON adv.id_advertiser = advertiser.id ORDER BY advertiser.name");   
    $publishers = DB::select("select distinct id, name, ccz from ad_network order by name");

    return view('block.addblockcca',compact(['advertisers','publishers']));
    }

    public function getXByY(Request $request){
      $action = $request->input('action');
      
      if($request->input('id') && $action == 'advertiser'){
       $idAdvertiser = $request->input('id');
       $advertisers = DB::select("select op.id as id,op.name as name from advertiser_campaigns ac , operator op where ac.id_advertiser IN($idAdvertiser)
                         and ac.id_op=op.id group by op.name ORDER BY ac.id desc");
        $status =  array('status'=>1,'data'=> $advertisers);

      }else if($request->input('id') && $action == 'operator'){
       $idAdvertiser = $request->input('advertiser_id');
        $operator_ids = $request->input('id');       
           $data = DB::select("select id as campaignid ,name as name  from advertiser_campaigns "
              . " where  "
              . " advertiser_campaigns.id_advertiser IN('$idAdvertiser') "
              . "and advertiser_campaigns.id_op IN('$operator_ids') and advertiser_campaigns.status='1'"); 
        $status =  array('status'=>1,'data'=> $data);
      }else if($request->input('id') && $action == 'publisher'){
        $operator_ids = $request->input('operator_id');
        $network_id = $request->input('id');

        $data = DB::select("select distinct op_id as operator_id,op_name as operator_name "
            . "from crc_network_campaign_new where id_channel IN('$network_id') and op_id IN('$operator_ids') order by id_channel");

        $status =  array('status'=>1,'data'=> $data);
      }else if($request->input('id') && $action == 'pub_operator'){
          $networkoperator = $request->input('id');
          $network_id = $request->input('publisher_id');
          $data = DB::select("select distinct cnc.id_ad from crc_network_campaign_new cnc , ads  "
            . "where ads.id_ad=cnc.id_ad and ads.cco=cnc.op_id and ads.id_zone IN('$network_id') and cnc.op_id IN('$networkoperator') order by id_channel");
          $status =  array('status'=>1,'data'=> $data);
      }

      $status = Response::json($status);
      return $status; 
      
    }
    
    /* For adding Block CCA*/
    public function saveblockcca(Request $request){
    
    $ccas = implode(",",$request->parent_ids);
    $new_cca=  $ccas.",".$request->manual_parent_ids;
    $ccas = rtrim($new_cca,",");
    $mycca = explode(',', $ccas);
    $cca = implode("','",$mycca);
    $new_campaign =  implode(",",$request->campaign_name);
    $textcampaign =  $new_campaign.",".$request->campaign_ids;
    $arr =  rtrim($textcampaign,",");
    $id_operator=implode(",",$request->operator);
    if($request->id_ad == 0){
      
      $total = DB::select("select * from ads where id_ad IN ('$cca') and cco IN('$id_operator') and blocked_ids LIKE '%$arr%'");
     // print_r($total);die;
     // $total = $check_data[0];
     if(count($total) > 0){
      Session::flash('message', 'Data Already in database');
      return redirect('blockcca');
     }else{
     $update_sqls = DB::statement("update ads set blocked_ids ="."'".$arr."'"." where id_ad IN ("."'".$cca."'".")");
     Session::flash('message', 'Record added sucessfully');
      return redirect('listblockcca');
     }
    }else{
      $total = DB::select("select * from ads where id_ad IN ('$cca') and cco IN('$id_operator') and blocked_ids LIKE '%$arr%'");
      if(count($total) > 0){
         Session::flash('message', 'Data Already in database');
         return redirect('blockcca');
      }else{
        $update_sqls = DB::statement("update ads set blocked_ids =$arr where parent_id IN ($cca)"); 
        Session::flash('message', 'Record added sucessfully');
        return redirect('listblockcca'); 
      }
    }

  }

  public function listblockcca(Request $request){
    $data1 = [];
    $dtvalue = $request->from;
    $dtvalue2 = $request->to;
    if ($dtvalue == "" || $dtvalue2 == "") {
        $dtvalue = date('Y-m-d');
        $dtvalue2 = date('Y-m-d');
    } 
    $campaign = $request->campaign;
    $id_advertiser = $request->id_advertiser;
    $operator_id = $request->operator_id;
    if ($campaign != "") {
      $campaign = "  AND ads.campaignid='" . $campaign . "'";
    }
    if ($id_advertiser != "") {
      $id_advertiser = "  AND ac.id_advertiser='" . $id_advertiser . "'";
    }  
    if ($operator_id != "") {
    $operator_id = "  AND ads.cco='" . $operator_id . "'";
    }
    $data = DB::select("select ads.id_ad,ads.parent_id, ads.blocked_ids,ads.network_name,ads.id_zone,ac.name as advertiser_campaigns,"
         . "ac.id as advertiser_campaigns_id,a.id as advt_id,a.name as adv_name,ads.operator_name as network_oprator,"
         . "ads.cco as network_operator_id, ac.id_op as advertiser_operator,operator.name as op_name, ads.blocked_status "
         . "FROM ads, advertiser a,advertiser_campaigns ac,"
         . "operator where a.id=ac.id_advertiser and ac.id=ads.blocked_ids "
         . "and operator.id=ac.id_op  and ads.blocked_ids !='' $campaign $id_advertiser $operator_id  GROUP BY id_ad");
    
    foreach($data as $fetch_url){
          $array = [];
          $disable = $checked = "";
          if($fetch_url->blocked_status == 1)
          {
            $checked = 'checked';
          }else{
            $disable = 'checked'; 
          }  

          $status = '<input type="radio" name="status_'.$fetch_url->id_ad.'" value="1" onchange="javascript:enable_id('.$fetch_url->id_ad.')"'.$checked.'><label>Enable</label><input type="radio" name="status_'.$fetch_url->id_ad.'" value="0" onchange="javascript:enable_id('.$fetch_url->id_ad.')"'.$disable.'><label>Disable</label>';
          $manage = '<a href="/editblockcca/'.$fetch_url->id_ad.'"><span class="glyphicon glyphicon-pencil right10">Edit</span></a><a href="javascript:delete_id('.$fetch_url->id_ad.')"><span class="glyphicon glyphicon-remove">Delete</span></a>';
          array_push($array,
                    $fetch_url->adv_name,
                    $fetch_url->network_oprator,
                    $fetch_url->blocked_ids,
                    $fetch_url->network_name,
                    $fetch_url->id_ad,
                    $fetch_url->parent_id,
                    $status,
                    $manage 
                  );
                array_push($data1, $array);
    }
    return view('block.listblockcca',['data'=>$data1]);
  }


  public function deleteblockcca(Request $request){
    $id = $request->id;
    $status = array('status'=>0);
    // $delete = 1;
    $delete = DB::statement("update ads SET blocked_ids='' WHERE id_ad=".$id." limit 1");
    if($delete){
      $status = array('status'=>1);
    }
    $status = Response::json($status);
    return $status;  
  }

  public function editblockcca(Request $request){
    $id_ad = $request->id;
    $advertisers = DB::select("SELECT DISTINCT adv.id_advertiser, advertiser.name FROM advertiser_campaigns as adv 
               JOIN advertiser ON adv.id_advertiser = advertiser.id ORDER BY advertiser.name");   
    $publishers = DB::select("select distinct id, name, ccz from ad_network order by name");
    $data = DB::select("select ads.id_ad, ads.blocked_ids,ads.network_name,ads.id_zone,ac.name as advertiser_campaigns,"
         . "ac.id as advertiser_campaigns_id,a.id as advt_id,a.name as adv_name,ads.operator_name as network_oprator,"
         . "ads.cco as network_operator_id, ac.id_op as advertiser_operator,operator.name as op_name, ads.parent_id as parent_id  "
         . "FROM ads,advertiser a,advertiser_campaigns ac,"
         . "operator where a.id=ac.id_advertiser and ac.id=ads.blocked_ids "
         . "and operator.id=ac.id_op and ads.id_ad='$id_ad' GROUP BY id_ad");
     // print"<pre>";print_r($data);print"</pre>";
     $operator_ids = $data[0]->advertiser_operator;
     $network_id = $data[0]->id_zone;
     
     $publisher_operator = DB::select("select distinct op_id as operator_id,op_name as operator_name "
            . "from crc_network_campaign_new where id_channel IN('$network_id') and op_id IN('$operator_ids') order by id_channel");
        foreach($publisher_operator as  $po){
          $operator_id[] = $po->operator_id;
        }
        $networkoperator = implode(",", $operator_id);
          
          $parent_cca = DB::select("select distinct cnc.id_ad from crc_network_campaign_new cnc , ads  "
            . "where ads.id_ad=cnc.id_ad and ads.cco=cnc.op_id and ads.id_zone IN('$network_id') and cnc.op_id IN('$networkoperator') order by id_channel");
     // print"<pre>";print_r($publisher_operator);print"</pre>";
     // print"<pre>";print_r($parent_cca);print"</pre>";


  return view('block.editblockcca',compact(['advertisers','publishers','data','publisher_operator','parent_cca']));

  }
         
           
}
