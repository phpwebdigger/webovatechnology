<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Ad;
use App\ads;
use App\operator;
use App\AdNetwork;
use App\UrlTracking;
use App\Smarttrfcconfig;
use App\SmartTrafficConfig;
use Illuminate\Support\Facades\Input;
use Response;
use App\AdvertiserCampaign;
use App\SmartRotatorCampaignsOpeators;
use Session;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Redirect;
use App\Http\Traits\CommonTrait;

class AdssmarturlController extends Controller
{
    use CommonTrait;
    public function __construct()
    {
        $this->middleware('auth');
    }

    
    public function index(Request $request,$type="",$page_name="URL MANAGEMENT",$urlFilter = "urlFilter"){
           $data1 = $this->adsData($request,$type,$page_name,$urlFilter); 
           $view = 'ad.ad-url';
           $operators = $this->getOperators();
           $networks = $this->getNetworks();
           if($urlFilter == 'urlFilter'){
            $view = 'ad.url';
           }
          return view($view,compact(['data1','page_name','urlFilter','operators','networks']));
    }

    public function filterAds(Request $request){
      $status = array('status'=>'2','data'=>'');
      $type="";
      $page_name = "URL MANAGEMENT";
      $urlFilter = "urlFilter";
      if($request->page_name){
        $page_name = $request->page_name;  
      }
      if($request->urlFilter){
       $urlFilter = $request->urlFilter;  
      }
      $data1 = $this->adsData($request,$type,$page_name,$urlFilter,10000);
      if(count($data1) > 0){
        $status = array('status'=>'1','data'=>$data1);
      }
      return json_encode($status);
  }


    public function index_cpa(Request $request){
          return $this->index($request,"CPA","CPA URL MANAGEMENT","urlcpaFilter");

    }

    public function index_cpi(Request $request){
         return $this->index($request,"CPI","CPI URL MANAGEMENT","urlcpiFilter");

    }


    public function index_cps(Request $request){
       return $this->index($request,"CPS","CPS URL MANAGEMENT","urlcpsFilter");

    }


    public function index_cpicpa(Request $request){
        return $this->index($request,"CPICPA","CPICPA URL MANAGEMENT","urlcpicpaFilter");

    }

    public function index_collect_ads(Request $request){
        return $this->index($request,"","URL MANAGEMENT","urlcollectadsFilter");

    }
    
    public function index_ads(Request $request){
        return $this->index($request,"","Ads Managment","adsFilter");
    }


    /* Dev : Sumit Manchanda
     * To fetch ads Data
     */   
    public function adsData($request,$type = "",$page_name="URL MANAGEMENT",$urlFilter = "urlFilter",$limit='50'){
        $condtion = [];
        $select = [
        "id_ad","ads.id_advertiser","ads.operator_name","title","cco","ads.country_code",
        "click_url","traffic_type","wifi_status","ads.payout_currency",
        "ads.type","network_name","network_cpa","id_zone","ads.cr_goal","ads.status","ads.is_live",
        "ads.id_ad_type","ads.blocked_status","ads.is_smart_cca","ads.url_change",
        "advertiser.name as adverName","advertiser_campaigns.permanent_status"
        ];
        $net_id = $op_id ="";
        $id_ad = $request->id_ad;
        if($request->id_ad){
           array_push($condtion,['id_ad','=',$request->id_ad]); 
        }
        if($request->net_id && $request->net_id != ""){
          array_push($condtion,['id_zone','=',$request->net_id]);
          $net_id = $request->net_id;
        }
        if($request->op_id && $request->op_id != ""){
          array_push($condtion,['cco','=',$request->op_id]);
          $op_id = $request->op_id;
        }
        if($request->is_smart_cca && $request->is_smart_cca != ""){
          array_push($condtion,['is_smart_cca','=',$request->is_smart_cca] );
          $is_smart_cca = $request->is_smart_cca;
        }
        if($request->is_permanent_status && $request->is_permanent_status != ""){
          array_push($condtion,['advertiser_campaigns.permanent_status','=',$request->is_permanent_status] );
          $is_permanent_status = $request->is_permanent_status;
        }
        if($type != ""){
            array_push($condtion,['advertiser_campaigns.type','=',$type] );
        }
        $appends = [];
        $data = Ad::where($condtion)
            ->select($select)
            ->leftJoin("advertiser_campaigns","ads.id_advertiser","=","advertiser_campaigns.id")
            ->leftJoin("advertiser","advertiser_campaigns.id_advertiser","=","advertiser.id")
            ->orderby('id_ad','DESC')->limit($limit)->get();
        $data1 = [];
        if($type != ""){
          $dash = "-";
        }else{
          $dash ="";
        }
        foreach ($data as $fetch_url){
                $array = [];
                $wifi_status = $fetch_url->wifi_status == 1? "On":"Off";
                $manage = '<a class = "fa fa-edit" href="javascript:void(0);" onclick="EditUrl('.$fetch_url->id_ad.')"></a>';                           
                if($urlFilter == 'urlFilter'){
                  array_push($array,
                    $fetch_url->id_ad,
                    $fetch_url->country_code,
                    $manage,
                    // $fetch_url->adverName."(".$fetch_url->id_advertiser.")",
                    $fetch_url->adverName,
                    $fetch_url->title,
                    $fetch_url->traffic_type,
                    $fetch_url->network_name."(".$fetch_url->id_zone.")",
                    $fetch_url->operator_name."(".$fetch_url->country_code.")",
                    $fetch_url->id_advertiser,
                    '<span title="'.$fetch_url->click_url.'">'.$fetch_url->click_url."</span>",
                    $permanent_status =$fetch_url->permanent_status
                  );
                }else{ 
                $manage = '<a class = "fa fa-edit" href="/ads/edit/'.$fetch_url->id_ad.'"></a>';
                $is_checked = $fetch_url->id_ad_type? "checked":"";
                $checkbox = "<input type='checkbox' class='ad_type' name='id_ad_type[]' id='".$fetch_url->id_ad."' value='".$fetch_url->id_ad_type."' $is_checked>";
                $is_enable = $fetch_url->id_ad_type? "Enable":"Disable";
                $id_ad_type = "<span id='type_container-".$fetch_url->id_ad."'>".$is_enable."</span>";
                $permanent_status =$fetch_url->permanent_status;
                array_push($array,
                    $fetch_url->id_ad,
                    $manage,
                    $fetch_url->adverName,
                    $fetch_url->title,
                    $fetch_url->operator_name."(".$fetch_url->country_code.")",
                    // $fetch_url->cco,
                    $wifi_status,
                    $fetch_url->payout_currency,
                    $fetch_url->type,
                    $fetch_url->blocked_status?'Enable':'Disable',
                    $fetch_url->traffic_type,
                    $fetch_url->network_cpa,
                    $fetch_url->network_name."(".$fetch_url->id_zone.")",
                    $fetch_url->is_smart_cca?'Yes':'No',
                    $fetch_url->url_change?'Enable':'Disable',
                    $id_ad_type.$checkbox,
                    $fetch_url->status,
                    '<span title="'.$fetch_url->click_url.'">'.$fetch_url->click_url."</span>",
                    $permanent_status
                  );
                }
                array_push($data1, $array);
          }

          return $data1;
      }


     
    public function ajaxOperator(Request $Request){
        $op_id = $Request->opval;
        $op_id1 = $Request->opvals;
        $op_id2 = $Request->opval3;
        $operator_id =$Request->op_id3;
        $optype = $Request->optype;
        /*This for campaign dropdown to show on change in operator*/
        if($op_id !=''){ 
            $select = "advertiser_campaigns.id as campid,advertiser_campaigns.id_advertiser as idadv1,advertiser_campaigns.name as idname,advertiser_campaigns.url as idurl";
            $data1 = DB::table('advertiser_campaigns')
            ->selectRaw(DB::raw($select))
            ->where('advertiser_campaigns.id_op', '=',$op_id)
            ->where('advertiser_campaigns.status','=','1')
            ->orderby('advertiser_campaigns.name')
            ->get()
            ->toArray();
              $dts1="<option value=''>Select </option>";
                foreach($data1 as $key => $val){
                  $dts1 .='<option value="'.$val->idadv1.'" id="'.$val->idadv1.'"  title="'.$val->idurl.'">'.$val->idname.'('.$val->idadv1.')</option>';
                }
              return $dts1;
            }elseif (!empty($op_id1)) { /* this take apply cca column*/
               $select = "ads.id_ad as idadv,ads.title as title";
                  $data2 = DB::table('ads')
                  ->selectRaw(DB::raw($select))
                  ->where('ads.cco','=',$op_id1)
                  ->get()
                  ->toArray();
              $dts='';
                foreach($data2 as $key => $val){
                  $dts .='<option value="'.$val->idadv.'" >'.$val->idadv.'('.$val->title.')</option>';
                }
                return $dts;
             }elseif(($op_id2!='')&& ($operator_id!='')){ /*live cca*/
              $select = "ads.id_ad as idadv,ads.title as title";
                    $data3 = DB::table('ads')
                    ->selectRaw(DB::raw($select))
                    ->where('ads.id_advertiser','=',$op_id2)
                    ->where('ads.cco','=', $operator_id)
                    ->get()
                    ->toArray();
                  $dts2='';
                foreach($data3 as $key => $val){
                  $dts2 .='<option value ="'.$val->idadv.'">' .$val->idadv.'('.$val->title.')'.'</option>'.'<br>';
                }
                return $dts2;
              }
            }
           



            /* Change ads submit*/ 
            public function ajaxsubmit(Request $Request){
                try{
                    $view_url = '/urls/edit-url'; 
                    $id_camps = $Request->id_camps;
                    $data = $Request->session()->all();
                    $user_name = $data['roles']['name'];
                    $value = Cookie::get('LARAVELMAC');
                    $opcurrentArr = $Request->option;
                    if(!empty($value) && count($opcurrentArr) > 0 )
                    {
                        $opids = $Request->op_data;
                        $campid = $Request->camp_data;
                        $campaign_option = $Request->campaign_option;
                        if($campaign_option == 2){
                          $campid = $Request->campaign;
                        }
                        $select="advertiser_campaigns.name as name,advertiser_campaigns.url as url ";
                        $data4=DB::table('advertiser_campaigns')
                                 ->selectRaw($select)
                                  ->where('advertiser_campaigns.id','=',$id_camps)
                                  ->get()
                                  ->first();
                        $update = array('title' => $data4->name,'click_url' => $data4->url,'id_advertiser'=>$id_camps);          
                              $url_tracking = new UrlTracking();
                              $url_tracking->user_name = $user_name;
                              $url_tracking->id_advertiser = $campid;
                              $url_tracking->click_url = $data4->url;
                              $url_tracking->mac_address = $value;
                          if(count($opcurrentArr) > 1){
                              $parent_ccas = implode("','",$opcurrentArr);
                              $url_tracking->id_ad = 0;
                              $url_tracking->multiple_id_ad = $parent_ccas;
                              $sql = "update ads set title ='".$data4->name."',click_url ='".$data4->url."',id_advertiser ='".$id_camps."' where id_ad IN ('".$parent_ccas."')";
                              $result = DB::update($sql);
                          }else{ 
                              $upt1 = ads::where('id_ad','=',$opcurrentArr[0])->update($update);
                              $url_tracking->id_ad = $opcurrentArr[0];
                           }
                       $url_tracking->save();
                       $status = array('status'=>1);
                       // return redirect($view_url);
                    }else{
                       $status = array('status'=>2,'message'=>'You are not authorised to replace url'); 
                    }
                }catch(\Exception $e){
                     // dd($e);
                     $status = array('status'=>2,'message'=>$e);
                }
                return  json_encode($status);                
            }


         public function updateSmartUrls(Request $request){
            $campaigns = DB::select("select id,name,url from advertiser_campaigns where status = '1' AND is_smart = 'CPA'");
               try{
                   $id_camps = $request->id_camps;
                    $data = $request->session()->all();
                    $user_name = $data['roles']['name'];
                    $opcurrentArr = $request->input('option');
                    $smart_ccas_arr = $request->input('smart_ccas');
                    $value =Cookie::get('LARAVELMAC');   
                   if(!empty($value) && ($smart_ccas_arr || $opcurrentArr))
                    {
                         $upt1 = $result= '';
                        $opids = $request->input('op_data');
                        $campid = $request->input('camp_data');
                        $campaign_option = $request->input('campaign_option');
                            if($campaign_option == 2){
                              $campid = $request->input('campaign');
                            }
                        $select="advertiser_campaigns.name as name,advertiser_campaigns.url as url ";
                        $data4=DB::table('advertiser_campaigns')->selectRaw($select)->where('advertiser_campaigns.id','=',$id_camps)
                            ->get()->first();
                           
		
                        if($opcurrentArr){
                              $update = array('title' => $data4->name,'click_url' => $data4->url,'id_advertiser'=>$id_camps);
                                $url_tracking = new UrlTracking();
                                $url_tracking->user_name = $user_name;
                                $url_tracking->id_advertiser = $campid;
                                $url_tracking->click_url = $data4->url;
                                $url_tracking->mac_address = $value;
                              if(count($opcurrentArr) > 1){
                                  $parent_ccas = implode("','",$opcurrentArr);
                                  $url_tracking->id_ad = 0;

                                  $url_tracking->multiple_id_ad = $parent_ccas;
                                 $sql = "update ads set title ='".$data4->name."',click_url ='".$data4->url."',id_advertiser ='".$id_camps."' where id_ad IN ('".$parent_ccas."')";
                                   $result = DB::update($sql);
                              }else{ 
                                  $upt1 = ads::where('id_ad','=',$opcurrentArr[0])->update($update);
                                  $url_tracking->id_ad = $opcurrentArr[0];
                              }
                              $url_tracking->save();
                        }

                        if($smart_ccas_arr){
                                $url_tracking = new UrlTracking();
                                $url_tracking->user_name = $user_name;
                                $url_tracking->id_advertiser = $campid;
                                $url_tracking->click_url = $data4->url;
                                $url_tracking->mac_address = $value;
                            if(count($smart_ccas_arr) > 1){
                                  $smart_ccas = implode("','",$smart_ccas_arr);
                                  $url_tracking->id_ad = 0;
                                  $url_tracking->multiple_id_ad = $smart_ccas;
                                   $sql = "update smart_trfc_config set campaign_id='".$id_camps."' where id IN ('".$smart_ccas."')";
                                 $result = DB::update($sql);

 
                            }else{ 
                              $find_yes_no = SmartTrafficConfig::where('campaign_id','=',$campid)->get();
                                if(isset($find_yes_no[0]['is_primary_campaign']) && ($find_yes_no[0]['is_primary_campaign']==1))
                                 {
                                  
                                   $delete_yes_no = SmartTrafficConfig::where('campaign_id','=',$id_camps)->delete();
                                   if($delete_yes_no)
                                   {
                                  $update = array('title' => $data4->name,'click_url' => $data4->url,'id_advertiser'=>$id_camps);
                                  $delete_yes_no = ads::where('id_ad','=',$opcurrentArr[0])->update($update);
                                  $update = array('campaign_id' => $id_camps);
                                  $upt1 = SmartTrafficConfig::where('id','=',$smart_ccas_arr[0])->update($update);
                                   }
                                 }
                                else{
                                  
                                $find_yes_no = SmartTrafficConfig::where('campaign_id','=',$id_camps)->get();
				$find_yes_no2 = SmartTrafficConfig::where('id','=',$smart_ccas_arr[0])->get();	
                                 if(isset($find_yes_no[0]['is_primary_campaign']) && ($find_yes_no[0]['is_primary_campaign']==1))
                                 {
                                // $update = array('campaign_id' => $id_camps,'status' => '1');
                                // $upt1 = SmartTrafficConfig::where('id','=',$smart_ccas_arr[0])->update($update); 
                                   $delete_yes_no = SmartTrafficConfig::where('campaign_id','=',$id_camps)->delete();
                                   if($delete_yes_no)
                                   {
                                     $update = array('title' => $data4->name,'click_url' => $data4->url,'id_advertiser'=>$id_camps);
                                  $delete_yes_no = ads::where('id_ad','=',$opcurrentArr[0])->update($update);
                                  $update = array('campaign_id' => $id_camp);
                                  $upt1 = SmartTrafficConfig::where('id','=',$smart_ccas_arr[0])->update($update); 
                                     }
                                  } 
				elseif($find_yes_no[0]['id'] && $find_yes_no2[0]['id'] && $find_yes_no2[0]['campaign_id']==$campid){
						
							
					$find_yes_no = SmartTrafficConfig::where('campaign_id','=',$campid)->delete();
					$update = array('status' => '1');
                                        $upt1 = SmartTrafficConfig::where('campaign_id','=',$id_camps)->update($update);
					}


                                  else{
                         		
					//$find_yes_no = SmartTrafficConfig::where('campaign_id','=',$id_camps)->get();
					    
				     	
                                  $update = array('campaign_id' => $id_camps);
                                	$upt1 = SmartTrafficConfig::where('id','=',$smart_ccas_arr[0])->update($update); 
                                
                                  }

                               }
                               
                            }
                            $url_tracking->save();
                        }        
                        if($upt1 || $result){
                           $status = array('status'=>1);   
                        }else{
                           $status = array('status'=>2,'message'=>'There is something went wrong'); 
                        }
                    }else{
                         $status = array('status'=>2,'message'=>'You are not authorised to replace url');
                    }
                }catch(\Exception $e){
                    $status = array('status'=>2,'message'=>$e->getMessage());
                }
                return json_encode($status); 
          }

    public function editUrl(Request $req){
          $campaigns = DB::select("select id,name,url from advertiser_campaigns where status = '1' AND is_smart = 'CPA'");
           return view('ad.edit-url-management',compact('campaigns'));
    }

    public function editSmartUrl(Request $req){
           $campaigns = DB::select("select id,name,url from advertiser_campaigns where status = '1' AND is_smart = 'CPA'");
           return view('ad.edit-smarturl-management',compact('campaigns'));
    }



 function getUrlDataSmart(Request $request){
      $id_ad = $request->input('id_ad');
      $is_smart = $request->input('is_smart');
      $campaign_id = $request->input('campaign_id');
      $advertisers = [];
      if($id_ad){
      $adsData = Ad::where('id_ad',$id_ad)->get();

          if($adsData[0]->blocked_status == 1 && $adsData[0]->blocked_ids && $adsData[0]->parent_id){
              $sql = DB::Select("select * from advertiser_campaigns ac , ads where ac.id=ads.id_ad and  ads.blocked_status = 1 and ac.status = 1 and ac.id_op=".$adsData[0]->cco." and ac.id NOT IN(".$adsData[0]->blocked_ids.") order by ac.name");
          }
          else if($adsData[0]->blocked_status==1 && $adsData[0]->blocked_ids && $adsData[0]->parent_id)
          {
              $parent_id = $adsData[0]->parent_id;
              $blocked_status= $adsData[0]->blocked_status;
              $block_id_ad_val= $cco = array();
              $ads_parent_data = DB::Select("select booked_ids,cco from ads where ads.parent_id='$parent_id' and ads.blocked_status='$blocked_status'");
                foreach($ads_parent_data as $ad ){
                 $block_id_ad_val[]= $ad->blocked_ids;
                 $cco[] = $ad->cco;
                }
                $str = implode(",",$block_id_ad_val);
                $cco =  implode(",", $cco);
                if($str!=''){
                  $sql= DB::Select("select id,name from advertiser_campaigns ac , ads where ac.id=ads.id_ad and  ads.blocked_status=1 and ac.status=1 and ads.status=1 and ac.id_op IN(".$cco.") and ac.id NOT IN(".$str.")  order by ac.name");
                }
          }
          elseif($is_smart){
              $sql = DB::Select("select id,name from advertiser_campaigns where status=1 and is_smart='".$is_smart."' order by name");
          }
          else{
              $sql = DB::Select("select id,name from advertiser_campaigns where status=1 and id_op=".$adsData[0]->cco." order by name");
              if($sql){
            $i=0;
            foreach($sql as $fetch_url){     
              $advertisers[$i]['id'] = $fetch_url->id;
              $advertisers[$i]['name'] = $fetch_url->name;
              // $advertisers[$i][$fetch_url->id] = $fetch_url->url;
              $i++;
            }
          }else{
            $advertisers[0]['id']=0;
            $advertisers[0]['name']="Campaign does not exists";
          }


               $Smarttraffic_data= new \App\Smarttrfcconfig();
                  $select = [ 
                    'smart_trfc_config.id',
                    'smart_trfc_config.cca',
                    'smart_trfc_config.campaign_id',
                    'smart_trfc_config.hold_percentage',
                    'smart_trfc_config.status',
                    'smart_trfc_config.is_primary_campaign',
                    'ads.id_ad',
                    'ads.id_zone',
                    'ads.url_change',
                    'ads.country_code',
                    'ads.network_name',
                    'ads.operator_name',
                    'ads.cco',
                    'advertiser_campaigns.name as campaign_name',
	                  'advertiser_campaigns.url as click_url',		
                    'advertiser_campaigns.id_op',
                ];         
                 $smrttrfc_result = $Smarttraffic_data->select($select)
                            ->leftJoin("ads","ads.id_ad","=","smart_trfc_config.cca")
                            ->leftJoin("advertiser_campaigns","advertiser_campaigns.id","=","smart_trfc_config.campaign_id")
                            ->where("advertiser_campaigns.id","=",$campaign_id)
                            ->where("smart_trfc_config.cca","=",$id_ad)
                            ->orderBy('smart_trfc_config.cca','desc')
                            ->orderBy('smart_trfc_config.is_primary_campaign','desc')
                            ->get();
             }
           
            
            
            $data = [];
            $data['id_ad'] = $id_ad;
            if(count($advertisers) > 0 && isset($smrttrfc_result[0])){
            $smrttrfc_result[0]->campaign_name;
            $data['status'] = 1;
		        $data['smarttrfc_id'] = $smrttrfc_result[0]->id;  
            $data['advertiser_id'] = $smrttrfc_result[0]->campaign_id;
            $data['etitle'] = $smrttrfc_result[0]->campaign_name;
            $data['network_name'] = $adsData[0]->network_name;
            $data['traffic_type'] = $adsData[0]->traffic_type;
            $data['operator_name'] = $adsData[0]->operator_name;
            $data['click_url'] = $smrttrfc_result[0]->click_url;
            $data['url_change'] = $smrttrfc_result[0]->url_change;
            $data['is_primary_campaign'] = $smrttrfc_result[0]->is_primary_campaign;
            $data['advertiser_campaign_name'] = $advertisers;
            }else{
              $data['status'] = 2;
            }
            $data = Response::json($data);
            return $data;
          }  
        }   

    public function manageUrlPage($id_ad){
      $select = "operator.id, operator.name, country.iso as cc";
        $data = DB::table('operator')
        ->where('id_ad',$id_ad)
        ->selectRaw(DB::raw($select))
        ->leftjoin("country","operator.country_code","=","country_code.iso")
        ->first();
        return view('Ad.edit-url-management',compact('data'));
    }

    public function urlEditAll(Request $request,$id_ad,$idAdvertiser=false,$type="all",$postUrl="editUrlPost"){
      $clickUrl = "";
      if($request->isSubmit == "yes"){
          $campaign_id = $request->camp_data; 
          $id_ad = $request->id_ad;
          $adsQuery= DB::select( DB::raw("UPDATE ads  as ads,advertiser_campaigns as advertiser 
                            SET ads.title=advertiser.name,
                            ads.id_advertiser=advertiser.id,
                            ads.click_url=advertiser.url
                            where ads.id_ad=".$id_ad." and advertiser.id=".$idAdvertiser.""));
        return  redirect('urls');   ;
        }else{
        if($idAdvertiser){
            $clickUrldata = DB::table("advertiser_campaigns")->where("id","=",$idAdvertiser)->get();

           $clickUrl = $clickUrldata[0]->url;
        }
      }
      $data = Ad::where('id_ad',$id_ad)->get();
       if($clickUrl == ""){
        $clickUrl = $data[0]->click_url;
       }
       if(!$idAdvertiser){
            $idAdvertiser=$data[0]->id_advertiser;
       }
       if($data[0]->blocked_status==1 && !empty($data[0]->blocked_ids) && empty($data[0]->parent_id)){
            $select = "*";
            $data1 = DB::table('advertiser_campaigns')
            ->join("ads")
            ->selectRaw(DB::raw($select))
            ->where('advertiser_campaigns.id', '=',"ads.id_ad")
            ->where('advertiser_campaigns.status','=','1')
             ->where('advertiser_campaigns.id_op','=',$data[0]->cco)
            ->where('ads.blocked_status','=','1')
             ->whereNotIn('advertiser_campaigns.id',$data[0]->blocked_ids)
            ->orderby('advertiser_campaigns.name')
            ->get();
        }else if($data[0]->blocked_status==1 && !empty($data[0]->blocked_ids) && !empty($data[0]->parent_id))
        {
            
           $parent_id= $data[0]->parent_id;
            $dataMain = Ad::where('parent_id',$parent_id)->get();
            $select = "*";
            $data1 = DB::table('advertiser_campaigns')
            ->join("ads")
            ->selectRaw(DB::raw($select))
            ->where('advertiser_campaigns.id', '=',"ads.id_ad")
             ->where('ads.id_ad', '=',$dataMain[0]->id_ad)
            ->where('advertiser_campaigns.status','=','1')
             ->where('advertiser_campaigns.id_op','=',$dataMain[0]->cco)
            ->where('ads.blocked_status','=','1')
            ->where('ads.parent_id','=',$dataMain[0]->parent_id)
             ->whereNotIn('advertiser_campaigns.id',$dataMain[0]->blocked_ids)
            ->orderby('advertiser_campaigns.name')
            ->get();
        }else if($request->is_smart){
          $select = "*";
            $data1 = DB::table('advertiser_campaigns')
            ->selectRaw(DB::raw($select))
            ->where('is_smart', '=',$data[0]->cco)
            ->where('status','=','1')
            ->orderby('name')
            ->get();
        }else{
          $select = "*";
            $data1 = DB::table('advertiser_campaigns')
            ->selectRaw(DB::raw($select))
            ->where('id_op', '=',$data[0]->cco)
            ->where('status','=','1')
            ->orderby('name')
            ->get();
        }
        $advertiserArray=array();
        foreach($data1 as $key => $value){     
          $key=$value->id;
          $advertiserArray[$key]=$value;
        } 
        $is_smart  = $request->is_smart ?? "";
        return view('ad.editAllUrl',compact('is_smart','clickUrl','advertiserArray','data','idAdvertiser','id_ad','type','postUrl'));
    }


    public function urlEditAllCPA(Request $request,$id_ad,$idAdvertiser=false){

        return $this->urlEditAll($request,$id_ad,$idAdvertiser=false,"CPA","editUrlCPAPost");
    }
     public function urlEditAllCPI(Request $request,$id_ad,$idAdvertiser=false){

        return $this->urlEditAll($request,$id_ad,$idAdvertiser=false,"CPI","editUrlCPIPost");
    }
     public function urlEditAllCPS(Request $request,$id_ad,$idAdvertiser=false){

        return $this->urlEditAll($request,$id_ad,$idAdvertiser=false,"CPS","editUrlCPSPost");
    }
    public function urlEditAllCPICPA(Request $request,$id_ad,$idAdvertiser=false){

    return $this->urlEditAll($request,$id_ad,$idAdvertiser=false,"CPICPA","editUrlCPICPAPost");
    }
    
    public function update(Request $request,$type =""){
        
        $select = [
        "id_ad",
        "operator_name",
        "network_name","title","status","click_url","id_advertiser",
        "traffic_type"
        ];
        $condtion = [];
        $net_id="";
        $op_id ="";
        if($request->net_id && $request->net_id != ""){
          array_push($condtion,['network_name','=',$request->net_id] );
          $net_id = $request->net_id;
        }
        if($request->op_id && $request->op_id != ""){
          array_push($condtion,['cco','=',$request->op_id] );
          $op_id = $request->op_id;
        }
        if($type != ""){
            array_push($condtion,['type','=',$type]);
        }
        $appends = [];
        $total = $request->total ? $request->total:50;
        $appends['net_id']=$request->net_id;
        $appends['cco']=$request->cco;
        $appends['total']=$request->total;
       
 
        $data = Ad::where($condtion)
            ->select($select)
            ->orderby('id_ad','ASC');
        $update = array('advetiser_id' => $request->advertiser,'operator_id' => $request->operator,'reverse_cca_id' => $request->reverse_cca);

           $url = reverse_setting::where(['reverse_id' =>  $request->ereverse])->update($update);
          return redirect()->route('reverseAdvertiserShowGet');
  }

    public function cronmanage(Request $request,$type="",$page_name="CRON MANAGEMENT")
    {
        $select = [
        "id_ad",
        "operator_name",
        "network_name","title","status","click_url","id_advertiser",
        "traffic_type"
        ];
        //dd($request->all());
          
        $condtion = [];
        $net_id="";
        $op_id ="";
        if($request->net_id && $request->net_id != ""){
          array_push($condtion,['network_name','=',$request->net_id] );
          $net_id = $request->net_id;
        }
        if($request->op_id && $request->op_id != ""){
          array_push($condtion,['cco','=',$request->op_id] );
          $op_id = $request->op_id;
        }
        if($type != ""){
            array_push($condtion,['type','=',$type] );
        }
 
        $data = Ad::where($condtion)
            ->select($select)
            ->orderby('id_ad','ASC')
            ->paginate(20);
      return view('ad.ad-url',compact(['data','net_id','op_id','page_name']));

    }

    
    /* Get the data for Pop Up Model */ 
    function getUrlData(Request $request){
      $id_ad = $request->input('id_ad');
      $is_smart = $request->input('is_smart');
      $advertisers = [];
      if($id_ad){
      $adsData = Ad::where('id_ad',$id_ad)->get();   
          if($adsData[0]->blocked_status == 1 && $adsData[0]->blocked_ids && $adsData[0]->parent_id){
              $sql = DB::Select("select * from advertiser_campaigns ac , ads where ac.id=ads.id_ad and  ads.blocked_status = 1 and ac.status = 1 and ac.id_op=".$adsData[0]->cco." and ac.id NOT IN(".$adsData[0]->blocked_ids.") order by ac.name");
          }
          else if($adsData[0]->blocked_status==1 && $adsData[0]->blocked_ids && $adsData[0]->parent_id)
          {
              $parent_id = $adsData[0]->parent_id;
              $blocked_status= $adsData[0]->blocked_status;
              $block_id_ad_val= $cco = array();
              $ads_parent_data = DB::Select("select booked_ids,cco from ads where ads.parent_id='$parent_id' and ads.blocked_status='$blocked_status'");
                foreach($ads_parent_data as $ad ){
                 $block_id_ad_val[]= $ad->blocked_ids;
                 $cco[] = $ad->cco;
                }
                $str = implode(",",$block_id_ad_val);
                $cco =  implode(",", $cco);
                if($str!=''){
                  $sql= DB::Select("select id,name from advertiser_campaigns ac , ads where ac.id=ads.id_ad and  ads.blocked_status=1 and ac.status=1 and ads.status=1 and ac.id_op IN(".$cco.") and ac.id NOT IN(".$str.")  order by ac.name");
                }
          }
          elseif($is_smart){
              $sql = DB::Select("select id,name as name from advertiser_campaigns where status=1 and is_smart='".$is_smart."' order by name");
          }
          else{
              $sql = DB::Select("select id,name as name from advertiser_campaigns where status=1 and id_op=".$adsData[0]->cco." order by name");
          }
            $i=0;
            foreach($sql as $fetch_url){     
              $advertisers[$i]['id'] = $fetch_url->id;
              $advertisers[$i]['name'] = $fetch_url->name;
              // $advertisers[$i][$fetch_url->id] = $fetch_url->url;
              $i++;
            }
            $data = [];
            $data['id_ad'] = $id_ad;
            if(count($advertisers) > 0){
            $data['status'] = 1;
            $data['id_ad'] = $id_ad;
            $data['advertiser_id'] = $adsData[0]->id_advertiser;
            $data['etitle'] = $adsData[0]->title;
            $data['network_name'] = $adsData[0]->network_name;
            $data['traffic_type'] = $adsData[0]->traffic_type;
            $data['operator_name'] = $adsData[0]->operator_name;
            $data['click_url'] = $adsData[0]->click_url;
            $data['url_change'] = $adsData[0]->url_change;
            $data['advertiser_campaign_name'] = $advertisers;
            }else{
              $data['status'] = 2;
            }
            $data = Response::json($data);
            return $data;
          }  
        }

        /* to Show data in dropdown in model */  
        function getCpiCpa(Request $request){
           $is_smart = $request->input('is_smart');
           $id_advertiser = $request->input('op_id'); 
           $advertisers = []; 
           /* on click on radio box in model to return advertiser data*/
           if($is_smart){
               $select = "id,name,url";
               $data = DB::table('advertiser_campaigns')
                ->selectRaw(DB::raw($select))
                ->where('is_smart', '=',$is_smart)
                ->where('status','=','1')
                ->orderby('name')
                ->get();
                $i=0;
                foreach($data as $fetch_url){     
                   $advertisers[$i]['id'] = $fetch_url->id;
                   $advertisers[$i]['name'] = '('.$fetch_url->id.')'.$fetch_url->name;
                  $i++;
                }
              $data = Response::json($advertisers);
              $data  =  array('status'=>1,'advertiser_campaign'=>$advertisers);
           }else if($id_advertiser){ //  /* on change of dropdown in model*/
           $select = 'url';
           $data = DB::table('advertiser_campaigns')
            ->selectRaw(DB::raw($select))
            ->where('id', '=',$id_advertiser)
            ->get();
            $data['url'] = $data[0]->url;
            $data['status'] = 1;
            $data = Response::json($data);
          }
          return $data;  
        }


        /* Update URL in */
        function UpdateUrl(Request $request){
            $data = $request->session()->all();

            $user_name = $data['roles']['name'];
            $id_ad = $request->id_ad;
            $id_advertiser = $request->id_advertiser;
            $url = $request->url;
            $value = Cookie::get('LARAVELMAC');
            // $ads =  Ad::where('id_ad','=',$id_ad)->get();print_r($ads);die;
            if(!empty($value))
            { 
              if($id_ad && $id_advertiser)
                {
                   $ads = Ad::where('id_ad','=',$id_ad)->get();
                   $alreadyExistedCampaign_id = $ads[0]->id_advertiser;
                   if($ads){
                      $campaign_id =  $id_advertiser;
                      if($campaign_id){
                       $trfccondition = [];
                       array_push($trfccondition,['campaign_id','=',$campaign_id]);
                       array_push($trfccondition,['cca','=',$id_ad]);
                       $smart = SmartTrafficConfig::where($trfccondition)->get();
                       // print"<pre>";print_r($smart);print"</pre>";
                       if(isset($smart) && !empty($smart)){
                        $existOnTrfc = isset($smart[0]->id) ? $smart[0]->id:'';
                        if($existOnTrfc){
                          $status = array('status'=>4);
                          return $status;
                        }
                       }
                      }
                    }
                    $adsQuery = DB::statement("UPDATE ads,advertiser_campaigns as advertiser SET ads.title = advertiser.name,
                             ads.id_advertiser = advertiser.id,
                             ads.click_url ='".$url."'            
                             where ads.id_ad=".$id_ad." and advertiser.id=".$id_advertiser); 
                                                        
                  if($adsQuery)
                    {
					$updateSmartTrfc = DB::statement("UPDATE smart_trfc_config SET campaign_id = '".$id_advertiser."'
                                  where campaign_id = '".$alreadyExistedCampaign_id."' and cca='".$id_ad."' and is_primary_campaign='1'");


                        $url_tracking = $this->CreateUrlTracking($request);
                        if($url_tracking['status'] == 1)
                        {
                            $data = array('status'=>1,'message'=>'Successful');
                            
                        }else{
                            $data = array('status'=>2,'message'=>'No Successful');
                        }    
                    }
                    else
                    {
                       $data = array('status'=>0,'message'=>'No Successful');  
                    }
                }
            }else{
                $data = array('status'=>3,'message'=>'You are not authorised to change the Url');
            }
            $data = Response::json($data);
            return $data;
                      
        }


         function CreateUrlTracking($request){
          $status = array('status'=>2);
          $data = $request->session()->all();
          $user_name = $data['roles']['name'];
          $id_ad = $request->id_ad;
          $id_advertiser = $request->id_advertiser;
          $url = $request->url;
          $value = Cookie::get('LARAVELMAC');
            $url_tracking = new UrlTracking();
            $url_tracking->user_name = $user_name;
            $url_tracking->id_ad = $id_ad;
            $url_tracking->id_advertiser = $id_advertiser;
            $url_tracking->click_url = $url;
            $url_tracking->mac_address = $value;
            $url_tracking->save();
            if($url_tracking){
             $status = array('status'=>1); 
            }
            return $status;
        }


        function getCampaign(Request $request){
          $action = $request->input('action');
          $data = $smart_cca = '';
          $total_smart_ccas = 0;
          if (!empty($action)) {
          switch ($action){
              case "op";
                $op_id = $request->input('op_id');
                $advertiser_campaigns = DB::select("select id,id_advertiser,name,url from advertiser_campaigns 
                  where id_op='$op_id' AND status=1 order by name");
                $data = '<option value="">Select Campaign</option>';
                foreach($advertiser_campaigns as  $ad_camp){
                  $data .='<option value="' . $ad_camp->id . '" id="cad_' . $ad_camp->id . '"  data-title="' . $ad_camp->url . '">' . $ad_camp->name . '(' . $ad_camp->id . ')</option>';
                }
                break;
                case "adscmp";
                  $op_id = $request->input('op_id');
                  $ads = DB::select("select id_ad,title from ads where cco='$op_id'");
                  $data = '<option value="">Select </option>';
                  foreach($ads as $ad_camp){
                    $data .='<option value="' . $ad_camp->id_ad . '" >' . $ad_camp->id_ad . '(' . $ad_camp->title . ')</option>';
                  }
                  break;
                  case "livecca";
                    $op_id = $request->input('op_id');
                    $camp_id = $request->input('camp_id');
                    $sql = "select id_ad,url_change,network_name,traffic_type from ads where id_advertiser='$camp_id'";
                    if(is_numeric($op_id)){
                      $sql  .="and cco='$op_id'";
                    }
                    $ads = DB::Select($sql);
                    if(count($ads) > 0){
                      $data = $ads;
                    }
                    if($request->type == 'smart'){
                      $status = $this->SmartTrafficData($camp_id);
                      if($status['status'] == 1){
                         if(count($status['data']) > 0){
                            $smart_cca = $status['data'];
                            $total_smart_ccas = $status['total'];
                         }
                      }
                    } 
                    break;
                  }
                }
                $status = array('status'=>1,'data'=>$data,'smart_cca'=>$smart_cca,'total_smart_ccas'=>$total_smart_ccas);
                $status = Response::json($status);
                return $status;
              }

            /* to get Smart TRFC accotfing to campaign_id*/
            function SmartTrafficData($camp_id){
              $condition = [];
              try{
                if($camp_id){
                    array_push($condition,['smart_trfc_config.campaign_id','=',$camp_id]);
                }
                // array_push($condition,['smart_trfc_config.is_primary_campaign','=',0]);
                $select = [ 
                      'smart_trfc_config.id', 
                      'smart_trfc_config.cca',
                      'smart_trfc_config.campaign_id',
                      'smart_trfc_config.hold_percentage',
                      'smart_trfc_config.status',
                      'ads.network_name',
                      'ads.traffic_type'
                    ];
                    $data = SmartTrafficConfig::where($condition)
                            ->leftJoin("ads","ads.id_ad","=","smart_trfc_config.cca")
                            ->select($select)->get();
                    $total_smart_ccas = count($data);
                    $status = array('status'=>1, 'data'=>$data,'total'=>$total_smart_ccas); 
                }catch(\Exception $e){
                   $message = 'There is some exception'; 
                   $status = array('status'=>2, 'data'=>'','message'=>$message); 
                }
                return $status;
            }
        
          function get_network(Request $req){ 
             $status =  array('status'=>0,'data'=>'');
             if($req->network_id){
                $dataMain = Ad::where('id_zone',$req->network_id)->select(['title','id_ad'])->get();
                $dataMain = $dataMain->toArray(); 
                  if(sizeof($dataMain)>0){
                    $status = array('status'=>1,'data'=>$dataMain);
                  }
             }
             $status = Response::json($status);
             return $status;  
          }


          
          public function edit_ads($id_ad){
          try{
            $data = Ad::where('id_ad',$id_ad)->get()->toArray();
            $networkData = $this->getNetworks();
            $operatorData = $this->getOperators(); 
            return view('ad.edit-ads',['data'=>$data,'network'=>$networkData,'operator'=>$operatorData]);
            }catch(\Exception $e){
              echo 'Caught exception: ',  $e->getMessage(), "\n";die;
            }
          } 


          public function update_ads(Request $request){
          // print"<pre>";print_r($request->input());print"</pre>";die;
          try{
            //Find the user object from model if it exists
            $value = Cookie::get('LARAVELMAC');
            if($value){
            $network_name  = $request->network_name;
            $network = explode('?',$network_name);
            $operator_name  = $request->operator_name;
            $operator = explode('?',$operator_name);  
            $update = array(
              'id_ad' => $request->id_ad,
              'id_advertiser' => $request->id_advertiser,
              'title' => $request->title,
              'click_url' => $request->click_url1.'?'.$request->click_url2,
              'cco' => $operator[0],
              'operator_name' => $operator[1],
              'type' => $request->type,
              'traffic_type' => $request->traffic_type,
              'network_cpa' => $request->network_cpa,
              'network_name' => $network[1],
              'description' => $request->description,
              'outward_status' => $request->outward_status,
              'wifi_status' => $request->wifi_status,
              'payout_currency' => $request->payout_currency,
              'id_zone' => $network[0],
              'parent_id' => $request->parent_id,
              'country_code' => $request->country_code,
              'id_ad_type' => $request->id_ad_type,
              'is_smart_cca' => $request->is_smart_cca,
              'url_change' => $request->url_change,
              'company_name' => $request->company_name,
              'app_server' => $request->app_server,
            );
            $upt1 = ads::where('id_ad','=',$request->id_ad)->update($update);
            $request->url =  $request->click_url1.'?'.$request->click_url2;
            $this->CreateUrlTracking($request);
            Session::flash('message', 'Successfully updated ads!');
            return redirect('ads');
            //return view('myform.index')->with('user', $user);
            }else{
              Session::flash('message', 'You are not authorised to edit it!');
              return redirect('ads/edit/'.$request->id_ad);
            }
          }
          catch(Exception $err){
              //Show error page
          }
        }

        /* Update column according to ajax request*/
        public function partialUpdate(Request $request){
          $action = $request->action;
          $status = array('status'=>2); 
           switch ($action){
              case "id_ad_type";
                $id_ad = $request->input('id_ad');
                $id_ad_type = $request->input('id_ad_type');
                if($id_ad_type == 1){
                  $id_ad_type = 0;
                  $msg = 'Disable';
                }else{
                  $id_ad_type = 1;
                  $msg = 'Enable';
                }
                $update = array('id_ad_type'=>$id_ad_type);
                $QueryResult = ads::where('id_ad','=',$id_ad)->update($update);
                $status = array('status'=>1,'data'=>$id_ad_type,'msg'=>$msg);
                break;
              }
              return $status;     
        }
 
          public function adsmanagement(Request $request,$type="",$page_name="Ads Management"){
            
            $select = [
                'advertiser_campaigns.id',
                'advertiser_campaigns.id_advertiser',
                'advertiser_campaigns.name as advCampname',
                'advertiser_campaigns.url',
                'advertiser_campaigns.country_code',
                'advertiser_campaigns.type',
                'advertiser_campaigns.cpa',
                'advertiser_campaigns.create_time',
                'advertiser_campaigns.id_op',
                'advertiser_campaigns.is_moi',
                'advertiser_campaigns.is_smart',
                'advertiser_campaigns.payout_type',
                'advertiser_campaigns.payout_currency',
                "advertiser_campaigns.incent_type",
                "advertiser_campaigns.os_type",
                'advertiser_campaigns.cr_goal',
                'advertiser_campaigns.status',
                'advertiser_campaigns.is_live',
                'advertiser_campaigns.ads_cat as cname',
                'advertiser_campaigns.auto_select_for_pub',
                'advertiser.id as advtId',
                'advertiser.name as aname',
                'country.name as cntry',
                'operator.name as opname'];

        $data = DB::table('advertiser_campaigns')
              ->join('advertiser', 'advertiser_campaigns.id_advertiser','=','advertiser.id')
              ->leftJoin('country', 'advertiser_campaigns.country_code','=', 'country.iso')
               ->leftJoin('operator', 'advertiser_campaigns.id_op','=', 'operator.id')
              ->select($select)
              ->orderby('advertiser_campaigns.id', 'desc')
              ->get();
            $data1 = [];
            //$index = 0;
             foreach ($data as $fetch_url) {
                $array = [];
               // $index++;
              if ($fetch_url->is_live==1)   $a="Active";  else   $a="Inactive";

              if ($fetch_url->auto_select_for_pub==1)   $c="Active";  else   $c="Inactive";

              if ($fetch_url->is_moi==1)   $moiStat="Active";  else   $moiStat="Inactive";
              if($fetch_url->status==1){
                      $val = 1;
                      $checked = "checked=checked";
                        $k="Active";
                    }else{
                      $val = 0;
                      $checked = "";
                      $k="Inactive";

                    }

                array_push($array,
                    $fetch_url->id??"",
                    '<span title="'.$fetch_url->aname.'">'.$fetch_url->aname.'</span>',
                    '<a href="/cca/update-campaigns-edit/'.$fetch_url->id.'" class="fa fa-edit"></a>',
                    '<span title="'.$fetch_url->advCampname.'">'.$fetch_url->advCampname??"".'</span>',
                    $fetch_url->cname??"",
                    $fetch_url ->cpa??"",
                    $fetch_url ->payout_type??"",
                    $fetch_url ->payout_currency??"",
                    $fetch_url ->country_code."(".$fetch_url->cntry.")",
                    $fetch_url->type??"",
                    $fetch_url->opname??"",
                    '<input name="stat" type="checkbox" id="'.$fetch_url->id.'" value="'.$val.'" '.$checked.'/><span id="message_'.$fetch_url->id.'">'.$k.'</span>',

                    '<span title="'.$fetch_url->url.'">'.$fetch_url->url.'</span>',
                    $fetch_url->create_time??"",
                    $fetch_url->os_type??"",
                    $fetch_url->incent_type??"",
                    '<span title="'.$moiStat.'">'.$moiStat.'</span>',
                    $fetch_url->is_smart??""

              );
            array_push($data1, $array);

       
          }
          

      return view('ad.ads_management',compact(['data1','page_name']));


  }



    public function getAdData(Request $request)
     {
   
           $keyword = $request->keyword;

           $metaData = Ad::where('network_name', 'like', ''.$keyword['term'] .'%')
           ->get(['network_name as text', 'id_zone as id']);
           $returnRes['results'] = $metaData;
           return $returnRes;
      
     }         
        
         /* function Created date 2018-04-06 
          * function use in new camapign index page 
          * create y :Sonu
          */
  
  public function new_campain_index(Request $request){

            $network_name = AdNetwork::select('name','ccz','id')->orderby('name','ASC')->get();
            $server_list =array(
              'App2'=>'107.170.154.51',
              'App3'=>'162.243.254.216',
              'App6'=>'107.170.173.141',
              'App8'=>'162.243.221.193',
              'App12'=>'162.243.73.231',
              'App10'=>'162.243.80.250',
              'App13'=>'162.243.74.32',
              'App15'=>'192.241.191.139',
              'App16'=>'192.241.188.214',
              'App17'=>'162.243.199.134',
              'App18'=>'162.243.200.63',
              'App20'=>'162.243.83.66',
              'App21'=>'162.243.112.118',
              'App22'=>'192.241.166.247',
              'App25'=>'192.241.242.242',
              'App26'=>'192.241.242.234',
              'App27'=>'192.241.174.146',
              'App28'=>'192.241.180.55',
              'App29'=>'192.241.181.88',
              'App30'=>'192.241.254.170',
              'App38'=>'192.241.249.228',
              'App39'=>'192.241.251.97',
              'App40'=>'192.241.178.46',
              'App41'=>'192.241.162.245',
              'App44'=>'192.241.184.246',
              'App45'=>'162.243.18.13',
              'App48'=>'162.243.25.229' 
              );     
          $view_page='NewCampaignUrl.index';
          
          return view($view_page,['serverlist'=>$server_list,'network_list'=>$network_name]);

  }


// New ads smart ulrs interface --

  //Ads edit smart new logic and functions start
     public function editsmartnewUrl(Request $req){
           $campaigns = DB::select("select id,name,url from advertiser_campaigns where status = '1' AND is_smart = 'CPA'");
           return view('ad.edit-smarturl-management-new',compact('campaigns'));
    }


//Ads edit smart new logic and functions end
    public function updateSmartnewUrls(Request $request){
            $campaigns = DB::select("select id,name,url from advertiser_campaigns where status = '1' AND is_smart = 'CPA'");
               try{
                   $id_camps = $request->id_camps;
                    $data = $request->session()->all();
                    $user_name = $data['roles']['name'];
                    $opcurrentArr = $request->input('option');
                    $smart_ccas_arr = $request->input('smart_ccas');
                    $value = Cookie::get('LARAVELMAC');   
                   if(!empty($value) && ($smart_ccas_arr || $opcurrentArr))
                    {
                        $upt1 = $result= '';
                        $opids = $request->input('op_data');
                        $campid = $request->input('camp_data');
                        $campaign_option = $request->input('campaign_option');
                            if($campaign_option == 2){ 
                              $campid = $request->input('campaign');
                            }
                        $select="advertiser_campaigns.name as name,advertiser_campaigns.url as url ";
                        $data4=DB::table('advertiser_campaigns')->selectRaw($select)->where('advertiser_campaigns.id','=',$id_camps)
                            ->get()->first();
                
                        if($opcurrentArr){
                              $update = array('title' => $data4->name,'click_url' => $data4->url,'id_advertiser'=>$id_camps);
                                $url_tracking = new UrlTracking();
                                $url_tracking->user_name = $user_name;
                                $url_tracking->id_advertiser = $campid;
                                $url_tracking->click_url = $data4->url;
                                $url_tracking->mac_address = $value;
                              if(count($opcurrentArr) > 1){
                                  $parent_ccas = implode("','",$opcurrentArr);
                                  $url_tracking->id_ad = 0;
                                  $url_tracking->multiple_id_ad = $parent_ccas;
                                  $sql = "update ads set title ='".$data4->name."',click_url ='".$data4->url."',id_advertiser ='".$id_camps."' where id_ad IN ('".$parent_ccas."')";
                             
                                   $result = DB::update($sql);
                              }else{ 
                                  $upt1 = ads::where('id_ad','=',$opcurrentArr[0])->update($update);
                                  $url_tracking->id_ad = $opcurrentArr[0];
                              }
                              $url_tracking->save();
                        }

                        if($smart_ccas_arr){
                                $url_tracking = new UrlTracking();
                                $url_tracking->user_name = $user_name;
                                $url_tracking->id_advertiser = $campid;
                                $url_tracking->click_url = $data4->url;
                                $url_tracking->mac_address = $value;
                            if(count($smart_ccas_arr) > 1){
                                  $smart_ccas = implode("','",$smart_ccas_arr);
                                  $url_tracking->id_ad = 0;
                                  $url_tracking->multiple_id_ad = $smart_ccas;
                                
                            for($i=0; $i<count($smart_ccas_arr); $i++){

                             $find_yes_no = SmartTrafficConfig::where('id','=',$smart_ccas_arr[$i])->get(); 

                         
                             $find_yes_no2= SmartTrafficConfig::where('campaign_id','=',$id_camps)->where('cca','=',$find_yes_no[0]['cca'])->get(); 

  
                              if(isset($find_yes_no[0]['is_primary_campaign']) && ($find_yes_no[0]['is_primary_campaign']==0) && !isset($find_yes_no2[0]['campaign_id']) ){
                                  $update = array('campaign_id' => $id_camps);
                                  $result = SmartTrafficConfig::where('id','=',$smart_ccas_arr[$i])->update($update); 
                                  
                                }
                                elseif(isset($find_yes_no2[0]['is_primary_campaign']) && ($find_yes_no2[0]['is_primary_campaign']==1) && isset($find_yes_no[0]['campaign_id'])){
                                     
                              $hold_percentage =  $find_yes_no2[0]['hold_percentage'];
                              $update_trfc = array('hold_percentage'=>$hold_percentage,'is_primary_campaign'=>1,'status'=>1);
                              $result = SmartTrafficConfig::where('id','=',$find_yes_no[0]['id'])->update($update_trfc);
                              $delete_yes_no = SmartTrafficConfig::where('id','=',$find_yes_no2[0]['id'])->delete();  
                                 
                              }
                             elseif(isset($find_yes_no[0]['is_primary_campaign']) && ($find_yes_no[0]['is_primary_campaign']==0) && isset($find_yes_no2[0]['campaign_id'])){
                                      // $upt1 = SmartTrafficConfig::where('id','=',$find_yes_no[0]['id'])->delete();

                                     
                              $hold_percentage = ($find_yes_no2[0]['is_primary_campaign']==1) ? $find_yes_no2[0]['hold_percentage'] : $find_yes_no[0]['hold_percentage']; 
                              $update_trfc = array('campaign_id' => $find_yes_no2[0]['campaign_id'],'hold_percentage'=>$hold_percentage);
                              $result = SmartTrafficConfig::where('id','=',$find_yes_no2[0]['id'])->update($update_trfc);
                              $delete_yes_no = SmartTrafficConfig::where('id','=',$find_yes_no[0]['id'])->delete();   
                                 
                              }elseif(isset($find_yes_no[0]['is_primary_campaign']) && ($find_yes_no[0]['is_primary_campaign']==1) && !isset($find_yes_no2[0]['campaign_id'])){
                                  $update = array('title' => $data4->name,'click_url' => $data4->url,'id_advertiser'=>$id_camps);
                                  $update_ads = ads::where('id_ad','=',$find_yes_no[0]['cca'])->update($update);
                                  $update = array('campaign_id' => $id_camps);
                                  $result = SmartTrafficConfig::where('id','=',$find_yes_no[0]['id'])->update($update);                                 
                              } 
                              elseif(isset($find_yes_no[0]['is_primary_campaign']) && ($find_yes_no[0]['is_primary_campaign']==1) && isset($find_yes_no2[0]['campaign_id']) ){

                                     $update = array('title' => $data4->name,'click_url' => $data4->url,'id_advertiser'=>$id_camps);
                                     $update_ads = ads::where('id_ad','=',$find_yes_no[0]['cca'])->update($update);
                                     $hold_percentage = ($find_yes_no2[0]['is_primary_campaign']==1) ? $find_yes_no2[0]['hold_percentage'] : $find_yes_no[0]['hold_percentage'];
                                     $update_trfc = array('is_primary_campaign'=>1,'status'=>1,'campaign_id' => $id_camps,'hold_percentage'=>$hold_percentage);
                                     $result = SmartTrafficConfig::where('id','=',$find_yes_no2[0]['id'])->update($update_trfc);
                                     $delete_yes_no = SmartTrafficConfig::where('id','=',$find_yes_no[0]['id'])->delete();    

                                   } 

                                 }

                            }else{ 
                             
                             $find_yes_no = SmartTrafficConfig::where('id','=',$smart_ccas_arr[0])->get(); 

                         
                             $find_yes_no2= SmartTrafficConfig::where('campaign_id','=',$id_camps)->where('cca','=',$find_yes_no[0]['cca'])->get(); 

  
                              if(isset($find_yes_no[0]['is_primary_campaign']) && ($find_yes_no[0]['is_primary_campaign']==0) && !isset($find_yes_no2[0]['campaign_id']) ){
                                  $update = array('campaign_id' => $id_camps);
                                  $upt1 = SmartTrafficConfig::where('id','=',$smart_ccas_arr[0])->update($update); 
                                  
                                }
                                elseif(isset($find_yes_no2[0]['is_primary_campaign']) && ($find_yes_no2[0]['is_primary_campaign']==1) && isset($find_yes_no[0]['campaign_id'])){
                                     
                              $hold_percentage =  $find_yes_no2[0]['hold_percentage'];
                              $update_trfc = array('hold_percentage'=>$hold_percentage,'is_primary_campaign'=>1,'status'=>1);
                              $upt1 = SmartTrafficConfig::where('id','=',$find_yes_no[0]['id'])->update($update_trfc);
                              $delete_yes_no = SmartTrafficConfig::where('id','=',$find_yes_no2[0]['id'])->delete();  
                                 
                              }
                             elseif(isset($find_yes_no[0]['is_primary_campaign']) && ($find_yes_no[0]['is_primary_campaign']==0) && isset($find_yes_no2[0]['campaign_id'])){
                                      // $upt1 = SmartTrafficConfig::where('id','=',$find_yes_no[0]['id'])->delete();

                                     
                              $hold_percentage = ($find_yes_no2[0]['is_primary_campaign']==1) ? $find_yes_no2[0]['hold_percentage'] : $find_yes_no[0]['hold_percentage']; 
                              $update_trfc = array('campaign_id' => $find_yes_no2[0]['campaign_id'],'hold_percentage'=>$hold_percentage);
                              $upt1 = SmartTrafficConfig::where('id','=',$find_yes_no2[0]['id'])->update($update_trfc);
                              $delete_yes_no = SmartTrafficConfig::where('id','=',$find_yes_no[0]['id'])->delete();   
                                 
                              }elseif(isset($find_yes_no[0]['is_primary_campaign']) && ($find_yes_no[0]['is_primary_campaign']==1) && !isset($find_yes_no2[0]['campaign_id'])){
                                  $update = array('title' => $data4->name,'click_url' => $data4->url,'id_advertiser'=>$id_camps);
                                  $update_ads = ads::where('id_ad','=',$find_yes_no[0]['cca'])->update($update);
                                  $update = array('campaign_id' => $id_camps);
                                  $upt1 = SmartTrafficConfig::where('id','=',$find_yes_no[0]['id'])->update($update);                                 
                              } 
                              elseif(isset($find_yes_no[0]['is_primary_campaign']) && ($find_yes_no[0]['is_primary_campaign']==1) && isset($find_yes_no2[0]['campaign_id']) ){

                                     $update = array('title' => $data4->name,'click_url' => $data4->url,'id_advertiser'=>$id_camps);
                                     $update_ads = ads::where('id_ad','=',$find_yes_no[0]['cca'])->update($update);
                                     $hold_percentage = ($find_yes_no2[0]['is_primary_campaign']==1) ? $find_yes_no2[0]['hold_percentage'] : $find_yes_no[0]['hold_percentage'];
                                     $update_trfc = array('is_primary_campaign'=>1,'status'=>1,'campaign_id' => $id_camps,'hold_percentage'=>$hold_percentage);
                                     $upt1 = SmartTrafficConfig::where('id','=',$find_yes_no2[0]['id'])->update($update_trfc);
                                     $delete_yes_no = SmartTrafficConfig::where('id','=',$find_yes_no[0]['id'])->delete();    

                                   }
                                  
                            }
                            $url_tracking->save();
                        }        
                        if($upt1 || $result){
                           $status = array('status'=>1);   
                        }else{
                           $status = array('status'=>2,'message'=>'There is something went wrong'); 
                        }
                    }else{
                         $status = array('status'=>2,'message'=>'You are not authorised to replace url');
                    }
                }catch(\Exception $e){
                    $status = array('status'=>2,'message'=>$e->getMessage());
                }
                return json_encode($status); 
          }


           function getsmartCampaign(Request $request){
          $action = $request->input('action');
          $data = $smart_cca = '';
          $total_smart_ccas = 0;
          if (!empty($action)) {
          switch ($action){
              case "op";
                $op_id = $request->input('op_id');
                $advertiser_campaigns = DB::select("select id,id_advertiser,name,url from advertiser_campaigns 
                  where id_op='$op_id' AND status=1 order by name");
                $data = '<option value="">Select Campaign</option>';
                foreach($advertiser_campaigns as  $ad_camp){
                  $data .='<option value="' . $ad_camp->id . '" id="cad_' . $ad_camp->id . '"  data-title="' . $ad_camp->url . '">' . $ad_camp->name . '(' . $ad_camp->id . ')</option>';
                }



                break;
                case "adscmp";
                  $op_id = $request->input('op_id');
                  $ads = DB::select("select id_ad,title from ads where cco='$op_id'");
                  $data = '<option value="">Select </option>';
                  foreach($ads as $ad_camp){
                    $data .='<option value="' . $ad_camp->id_ad . '" >' . $ad_camp->id_ad . '(' . $ad_camp->title . ')</option>';
                  }
                  break;
                  case "livecca";
                    $op_id = $request->input('op_id');
                    $camp_id = $request->input('camp_id');
                    $sql = "select id_ad,url_change,network_name,traffic_type from ads where id_advertiser='$camp_id'";
                    if(is_numeric($op_id)){
                      $sql  .="and cco='$op_id'";
                    }
                    $ads = DB::Select($sql);
                    if(count($ads) > 0){
                      $data = $ads;
                    }
                    if($request->type == 'smart'){
                      $status = $this->SmartTrafficData($camp_id);
                      if($status['status'] == 1){
                         if(count($status['data']) > 0){
                            $smart_cca = $status['data'];
                            $total_smart_ccas = $status['total'];
                         }
                      }
                    } 
                    // if(isset($request->second_type) && $request->second_type=='smartlink')
                    // {
                    //     $smartlink = $this->SmartlinkData($camp_id);

                    //      if(count($status['data']) > 0){
                    //         $smart_cca = $status['data'];
                    //         $total_smart_ccas = $status['total'];
                    //      }
                    
                    // }
                    break;
                  }
                }
                $status = array('status'=>1,'data'=>$data,'smart_cca'=>$smart_cca,'total_smart_ccas'=>$total_smart_ccas);
                $status = Response::json($status);
                return $status;
              }




          function SmartlinkData($camp_id){
              $condition = [];
              try{
                if($camp_id){
                    array_push($condition,['smart_rotator_campaigns_operators.campaign_id','=',$camp_id]);
                }
                $select = [ 
                      'smart_rotator_campaigns_operators.id', 
                      'smart_rotator_campaigns_operators.campaign_id',
                      'smart_rotator_campaigns_operators.op_id',
                      'smart_rotator_campaigns_operators.id_zone',
                      'smart_rotator_campaigns_operators.country_code',
                      'smart_rotator_campaigns_operators.smart_live',
                      'smart_rotator_campaigns_operators.ads_cat'
                    ];
                    $data = DB::table('smart_rotator_campaigns_operators')->where($condition)
                            ->leftJoin("operator","operator.op_id","=","smart_rotator_campaigns_operators.op_id")
                            ->select($select)->get();
                    $total_smart_ccas = count($data);
                    $status = array('status'=>1, 'data'=>$data,'total'=>$total_smart_ccas); 
                }catch(\Exception $e){
                   $message = 'There is some exception'; 
                   $status = array('status'=>2, 'data'=>'','message'=>$message); 
                }
                return $status;
            }
		

         /* to get all the campaign with percentage*/
    public function getPercentageOnCampaignsByCca(Request $request){
        $condition = [];
        $alreadyExistedCampaigns = [];
        $advertiser_campaigns = '';
        if($request->cca){
            array_push($condition,['smart_trfc_config.cca','=',$request->cca]);
        }
        $select = [ 
                    'smart_trfc_config.id', 
                    'smart_trfc_config.cca',
                    'smart_trfc_config.campaign_id',
                    'smart_trfc_config.hold_percentage',
                    'smart_trfc_config.status',
                    'ads.id_zone',
                    'ads.network_name',
                    'ads.operator_name',
                    'advertiser_campaigns.url as url',
                    'advertiser_campaigns.name as campaign_name'
	                  ];

		try{
            if($request->cco || ($request->cco==0)){
                $ad_condition = [];
                array_push($ad_condition,['id_op','=',$request->cco]);
                array_push($ad_condition,['status','=','1']);
                $ad_select = ['name','id','url'];
                $advertiser_campaigns = DB::table('advertiser_campaigns')->where($ad_condition)
                                        ->select($ad_select)->orderby('name')->get();
            }
            $status = array('status'=>1,'advertiser_campaigns'=>$advertiser_campaigns);    
         }catch(\Illuminate\Database\QueryException $ex){ 
          $status = array('status'=>2,'data'=>'','message'=>$ex->getMessage(),'advertiser_campaigns'=>''); 
        }
       	
	        $data = Response::json($status);
        return $data;
    }


     /* to Show data in dropdown in model */  
        function getCpiCpa_smarturl(Request $request){
           $is_smart = $request->input('is_smart');
           $id_advertiser = $request->op_data; 
           $advertisers = []; 
           /* on click on radio box in model to return advertiser data*/
           if($is_smart){
               $select = "id,name,url";
               $data = DB::table('advertiser_campaigns')
                ->selectRaw(DB::raw($select))
                ->where('is_smart', '=',$is_smart)
                ->where('status','=','1')
                ->orderby('name')
                ->get();
                $i=0;
                foreach($data as $fetch_url){     
                   $advertisers[$i]['id'] = $fetch_url->id;
                   $advertisers[$i]['url'] = $fetch_url->url;
                   $advertisers[$i]['name'] = '('.$fetch_url->id.')'.$fetch_url->name;
                  $i++;
                }
              $data = Response::json($advertisers);
              $data  =  array('status'=>1,'advertiser_campaign'=>$advertisers);
           }else if($id_advertiser){ //  /* on change of dropdown in model*/
           $select = 'url';
           $data = DB::table('advertiser_campaigns')
            ->selectRaw(DB::raw($select))
            ->where('id', '=',$id_advertiser)
            ->get();
            $data['url'] = $data[0]->url;
            $data['status'] = 1;
            $data = Response::json($data);
          }
          return $data;  
        }

    //Ads edit smart new logic and functions start
     public function editsmartlinknewUrl(Request $req){
           $campaigns = DB::select("select id,name,url from advertiser_campaigns where status = '1' AND is_smart = 'CPA'");
           return view('ad.edit-smartlinkurl-management-new',compact('campaigns'));
    }


    //Ads edit smartlink new logic and functions end
    public function updateSmartlinknewUrls(Request $request){
            $campaigns = DB::select("select id,name,url from advertiser_campaigns where status = '1' AND is_smart = 'CPA'");
               try{
                   $id_camps = $request->id_camps;
                    $data = $request->session()->all();
                    $user_name = $data['roles']['name'];
                    $opcurrentArr = $request->input('option');
                    $smart_ccas_arr = $request->input('smart_ccas');
                    $smart_link_cca_array = $request->input('smart_links');
                    $value = Cookie::get('LARAVELMAC');   
                   if(!empty($value) && ($smart_ccas_arr || $opcurrentArr || $smart_link_cca_array))
                    {
                        $upt1 = $result= '';
                        $opids = $request->input('op_data');
                        $campid = $request->input('camp_data');
                        $campaign_option = $request->input('campaign_option');
                            if($campaign_option == 2){ 
                              $campid = $request->input('campaign');
                            }
                        $select="advertiser_campaigns.name as name,advertiser_campaigns.url as url ";
                        $data4=DB::table('advertiser_campaigns')->selectRaw($select)->where('advertiser_campaigns.id','=',$id_camps)
                            ->get()->first();
                
                        if($opcurrentArr){
                              $update = array('title' => $data4->name,'click_url' => $data4->url,'id_advertiser'=>$id_camps);
                                $url_tracking = new UrlTracking();
                                $url_tracking->user_name = $user_name;
                                $url_tracking->id_advertiser = $campid;
                                $url_tracking->click_url = $data4->url;
                                $url_tracking->mac_address = $value;
                              if(count($opcurrentArr) > 1){
                                  $parent_ccas = implode("','",$opcurrentArr);
                                  $url_tracking->id_ad = 0;
                                  $url_tracking->multiple_id_ad = $parent_ccas;
                                  $sql = "update ads set title ='".$data4->name."',click_url ='".$data4->url."',id_advertiser ='".$id_camps."' where id_ad IN ('".$parent_ccas."')";
                             
                                   $result = DB::update($sql);
                              }else{ 
                                  $upt1 = ads::where('id_ad','=',$opcurrentArr[0])->update($update);
                                  $url_tracking->id_ad = $opcurrentArr[0];
                              }
                              $url_tracking->save();
                        }
                        
                        if($smart_link_cca_array){
                                 $url_tracking = new UrlTracking();
                                 $url_tracking->user_name = $user_name;
                                 $url_tracking->id_advertiser = $campid;
                                 $url_tracking->click_url = $data4->url;
                                 $url_tracking->mac_address = $value;
                            if(count($smart_link_cca_array) > 1){
                                  $smart_links_ccas = implode("','",$smart_link_cca_array);
                                  $url_tracking->id_ad = 0;
                                  $url_tracking->multiple_id_ad = $smart_links_ccas;
                                  for($i=0; $i<count($smart_link_cca_array); $i++){
                                $find_yes_no = SmartRotatorCampaignsOpeators::where('id','=',$smart_link_cca_array[$i])->get(); 

                                $find_yes_no2= SmartRotatorCampaignsOpeators::where('campaign_id','=',$id_camps)->where('op_id','=',$find_yes_no[$i]['op_id'])->get(); 

                                if(isset($find_yes_no[$i]['campaign_id']) && !isset($find_yes_no2[$i]['campaign_id'])){
                                    $update = array('campaign_id' => $id_camps);
                                    $result = SmartRotatorCampaignsOpeators::where('id','=',$smart_link_cca_array[$i])->update($update); 
                                }elseif(isset($find_yes_no[$i]['campaign_id']) && isset($find_yes_no2[$i]['campaign_id']) && $find_yes_no[$i]['campaign_id']==$find_yes_no2[$i]['campaign_id']){

                                     $update = array('campaign_id' => $id_camps,'smart_status'=>$find_yes_no[$i]['smart_status']);
                                     $result = SmartRotatorCampaignsOpeators::where('id','=',$find_yes_no2[$i]['campaign_id'])->update($update);  
                                     $delete_yes_no = SmartRotatorCampaignsOpeators::where('id','=',$find_yes_no[$i]['id'])->delete();    

                                }
                                  } 
                                
                            }else{
                                $find_yes_no = SmartRotatorCampaignsOpeators::where('id','=',$smart_link_cca_array[0])->get(); 

                                $find_yes_no2= SmartRotatorCampaignsOpeators::where('campaign_id','=',$id_camps)->where('op_id','=',$find_yes_no[0]['op_id'])->where('ads_cat','=',"'".$find_yes_no[0]['ads_cat']."'")->get(); 

                                if(isset($find_yes_no[0]['campaign_id']) && !isset($find_yes_no2[0]['campaign_id'])){
                                    $update = array('campaign_id' => $id_camps);
                                    $upt1 = SmartRotatorCampaignsOpeators::where('id','=',$smart_link_cca_array[0])->update($update); 
                                }elseif(isset($find_yes_no) && isset($find_yes_no2) && $find_yes_no[0]['campaign_id']==$find_yes_no2[0]['campaign_id']){

                                     $update = array('campaign_id' => $id_camps,'smart_status'=>$find_yes_no[0]['smart_status']);
                                     $upt1 = SmartRotatorCampaignsOpeators::where('id','=',$find_yes_no2[0]['campaign_id'])->update($update);  
                                     $delete_yes_no = SmartRotatorCampaignsOpeators::where('id','=',$find_yes_no[0]['id'])->delete();    

                                }

                            }

                            $url_tracking->save();

                        }


                        if($smart_ccas_arr){
                                $url_tracking = new UrlTracking();
                                $url_tracking->user_name = $user_name;
                                $url_tracking->id_advertiser = $campid;
                                $url_tracking->click_url = $data4->url;
                                $url_tracking->mac_address = $value;
                            if(count($smart_ccas_arr) > 1){
                                  $smart_ccas = implode("','",$smart_ccas_arr);
                                  $url_tracking->id_ad = 0;
                                  $url_tracking->multiple_id_ad = $smart_ccas;
                                
                            for($i=0; $i<count($smart_ccas_arr); $i++){

                             $find_yes_no = SmartTrafficConfig::where('id','=',$smart_ccas_arr[$i])->get(); 

                         
                             $find_yes_no2= SmartTrafficConfig::where('campaign_id','=',$id_camps)->where('cca','=',$find_yes_no[0]['cca'])->get(); 

  
                              if(isset($find_yes_no[0]['is_primary_campaign']) && ($find_yes_no[0]['is_primary_campaign']==0) && !isset($find_yes_no2[0]['campaign_id']) ){
                                  $update = array('campaign_id' => $id_camps);
                                  $result = SmartTrafficConfig::where('id','=',$smart_ccas_arr[$i])->update($update); 
                                  
                                }
                                elseif(isset($find_yes_no2[0]['is_primary_campaign']) && ($find_yes_no2[0]['is_primary_campaign']==1) && isset($find_yes_no[0]['campaign_id'])){
                                     
                              $hold_percentage =  $find_yes_no2[0]['hold_percentage'];
                              $update_trfc = array('hold_percentage'=>$hold_percentage,'is_primary_campaign'=>1,'status'=>1);
                              $result = SmartTrafficConfig::where('id','=',$find_yes_no[0]['id'])->update($update_trfc);
                              $delete_yes_no = SmartTrafficConfig::where('id','=',$find_yes_no2[0]['id'])->delete();  
                                 
                              }
                             elseif(isset($find_yes_no[0]['is_primary_campaign']) && ($find_yes_no[0]['is_primary_campaign']==0) && isset($find_yes_no2[0]['campaign_id'])){
                                      // $upt1 = SmartTrafficConfig::where('id','=',$find_yes_no[0]['id'])->delete();

                                     
                              $hold_percentage = ($find_yes_no2[0]['is_primary_campaign']==1) ? $find_yes_no2[0]['hold_percentage'] : $find_yes_no[0]['hold_percentage']; 
                              $update_trfc = array('campaign_id' => $find_yes_no2[0]['campaign_id'],'hold_percentage'=>$hold_percentage);
                              $result = SmartTrafficConfig::where('id','=',$find_yes_no2[0]['id'])->update($update_trfc);
                              $delete_yes_no = SmartTrafficConfig::where('id','=',$find_yes_no[0]['id'])->delete();   
                                 
                              }elseif(isset($find_yes_no[0]['is_primary_campaign']) && ($find_yes_no[0]['is_primary_campaign']==1) && !isset($find_yes_no2[0]['campaign_id'])){
                                  $update = array('title' => $data4->name,'click_url' => $data4->url,'id_advertiser'=>$id_camps);
                                  $update_ads = ads::where('id_ad','=',$find_yes_no[0]['cca'])->update($update);
                                  $update = array('campaign_id' => $id_camps);
                                  $result = SmartTrafficConfig::where('id','=',$find_yes_no[0]['id'])->update($update);                                 
                              } 
                              elseif(isset($find_yes_no[0]['is_primary_campaign']) && ($find_yes_no[0]['is_primary_campaign']==1) && isset($find_yes_no2[0]['campaign_id']) ){

                                     $update = array('title' => $data4->name,'click_url' => $data4->url,'id_advertiser'=>$id_camps);
                                     $update_ads = ads::where('id_ad','=',$find_yes_no[0]['cca'])->update($update);
                                     $hold_percentage = ($find_yes_no2[0]['is_primary_campaign']==1) ? $find_yes_no2[0]['hold_percentage'] : $find_yes_no[0]['hold_percentage'];
                                     $update_trfc = array('is_primary_campaign'=>1,'status'=>1,'campaign_id' => $id_camps,'hold_percentage'=>$hold_percentage);
                                     $result = SmartTrafficConfig::where('id','=',$find_yes_no2[0]['id'])->update($update_trfc);
                                     $delete_yes_no = SmartTrafficConfig::where('id','=',$find_yes_no[0]['id'])->delete();    

                                   } 

                                 }

                            }else{ 
                             
                             $find_yes_no = SmartTrafficConfig::where('id','=',$smart_ccas_arr[0])->get(); 
                             $find_yes_no2= SmartTrafficConfig::where('campaign_id','=',$id_camps)->where('cca','=',$find_yes_no[0]['cca'])->get(); 

  
                              if(isset($find_yes_no[0]['is_primary_campaign']) && ($find_yes_no[0]['is_primary_campaign']==0) && !isset($find_yes_no2[0]['campaign_id']) ){
                                  $update = array('campaign_id' => $id_camps);
                                  $upt1 = SmartTrafficConfig::where('id','=',$smart_ccas_arr[0])->update($update); 
                                  
                                }
                                elseif(isset($find_yes_no2[0]['is_primary_campaign']) && ($find_yes_no2[0]['is_primary_campaign']==1) && isset($find_yes_no[0]['campaign_id'])){
                                     
                              $hold_percentage =  $find_yes_no2[0]['hold_percentage'];
                              $update_trfc = array('hold_percentage'=>$hold_percentage,'is_primary_campaign'=>1,'status'=>1);
                              $upt1 = SmartTrafficConfig::where('id','=',$find_yes_no[0]['id'])->update($update_trfc);
                              $delete_yes_no = SmartTrafficConfig::where('id','=',$find_yes_no2[0]['id'])->delete();  
                                 
                              }
                             elseif(isset($find_yes_no[0]['is_primary_campaign']) && ($find_yes_no[0]['is_primary_campaign']==0) && isset($find_yes_no2[0]['campaign_id'])){
                                      // $upt1 = SmartTrafficConfig::where('id','=',$find_yes_no[0]['id'])->delete();

                                     
                              $hold_percentage = ($find_yes_no2[0]['is_primary_campaign']==1) ? $find_yes_no2[0]['hold_percentage'] : $find_yes_no[0]['hold_percentage']; 
                              $update_trfc = array('campaign_id' => $find_yes_no2[0]['campaign_id'],'hold_percentage'=>$hold_percentage);
                              $upt1 = SmartTrafficConfig::where('id','=',$find_yes_no2[0]['id'])->update($update_trfc);
                              $delete_yes_no = SmartTrafficConfig::where('id','=',$find_yes_no[0]['id'])->delete();   
                                 
                              }elseif(isset($find_yes_no[0]['is_primary_campaign']) && ($find_yes_no[0]['is_primary_campaign']==1) && !isset($find_yes_no2[0]['campaign_id'])){
                                  $update = array('title' => $data4->name,'click_url' => $data4->url,'id_advertiser'=>$id_camps);
                                  $update_ads = ads::where('id_ad','=',$find_yes_no[0]['cca'])->update($update);
                                  $update = array('campaign_id' => $id_camps);
                                  $upt1 = SmartTrafficConfig::where('id','=',$find_yes_no[0]['id'])->update($update);                                 
                              } 
                              elseif(isset($find_yes_no[0]['is_primary_campaign']) && ($find_yes_no[0]['is_primary_campaign']==1) && isset($find_yes_no2[0]['campaign_id']) ){

                                     $update = array('title' => $data4->name,'click_url' => $data4->url,'id_advertiser'=>$id_camps);
                                     $update_ads = ads::where('id_ad','=',$find_yes_no[0]['cca'])->update($update);
                                     $hold_percentage = ($find_yes_no2[0]['is_primary_campaign']==1) ? $find_yes_no2[0]['hold_percentage'] : $find_yes_no[0]['hold_percentage'];
                                     $update_trfc = array('is_primary_campaign'=>1,'status'=>1,'campaign_id' => $id_camps,'hold_percentage'=>$hold_percentage);
                                     $upt1 = SmartTrafficConfig::where('id','=',$find_yes_no2[0]['id'])->update($update_trfc);
                                     $delete_yes_no = SmartTrafficConfig::where('id','=',$find_yes_no[0]['id'])->delete();    

                                   }
                                  
                            }
                            $url_tracking->save();
                        } 
                       
                        if($upt1 || $result){
                           $status = array('status'=>1);   
                        }else{
                           $status = array('status'=>2,'message'=>'There is something went wrong'); 
                        }
                    }else{
                         $status = array('status'=>2,'message'=>'You are not authorised to replace url');
                    }
                }catch(\Exception $e){
                    $status = array('status'=>2,'message'=>$e->getMessage());
                }
                return json_encode($status); 
          }




}
