<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\AdNetwork;
use App\Users;

class InternationRotator extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

   public function index(Request $request){
        
                $data=explode(",",$request->traffic_type);
                $country_dropdown =  \App\Country::groupBY('name')->orderBy('name', 'ASC')->get();
           
     return view('international.test')->with(['country_list' => $country_dropdown,'header'=>'Smartlink Diversion Management','routename'=>'abc']);
    }
    
   public function internationalrotatormgnt_operator(Request $request)
    {
      $operator_name =  \App\Operators::where('country_code', $request->country_name)->orderBy('name','ASC')->get();
      echo $operator_name;
    }

    public function update_status(Request $request){
            
         $dtvalue2 = date('Y-m-d');
         $check_value=$request->check_value;
         $id_ad=$request->id_ad;
         
         $data_list = DB::statement("update trfc_config set status=$check_value where id='$id_ad'");
         if($data_list) { 
                $mess='Update Successful ! Please Check percentage value must be 100 ';
             }  else {
                $mess="Some Error";    
             }
             
            echo json_encode($mess);
            
    }

    public function getDataForTable(Request $request){
           $data=explode(",",$request->traffic_type);
                       
                       $trffic_type= "'" . implode("','", $data) . "'";
                       
                       $country_dropdown =  \App\Country ::groupBY('name')->orderBy('name', 'ASC')->get();
                       

                       $data_list = DB::Select("select distinct adnet.ccz,adnet.name,ads.title as campaign_name,"
                               . "net.id_zone,net.id,net.is_child,net.parent_cca,net.id_ad,"
                               . "net.hold_percentage,net.status, ads.cco,ads.operator_name,con.nicename,ads.country_code,ads.id_advertiser "
                               . " from trfc_config as net left join ads on ads.id_ad=net.id_ad "
                               . "left join ad_network adnet on adnet.ccz = net.id_zone "
                               . "left join country con ON con.iso = ads.country_code "
                               . " where  ads.cco='$request->operator_name' and ads.traffic_type IN ($trffic_type)"
                               . " and ads.country_code='$request->country_name'  and net.is_international='1' "
                               . " order by adnet.name,net.parent_cca DESC,net.id_ad asc");
                        if($data_list)
                        {
                         echo json_encode($data_list);  
                        }
         else {
             echo json_encode( array( 'error' => 'No data Found' ) );
         }        
    }

     function internationalrotatormgnt_country(Request $request){
              
              $country_dropdown =  \App\Country ::groupBY('name')->orderBy('name', 'ASC')->get();
              return view('international.internationalrotaormgntadd',['country_list' => $country_dropdown] );
       
    }
    public function internationalrotatormgnt_cca(Request $request)
    {

        $data=explode(",",$request->traffic_type);
        
        $trffic_type= "'" . implode("','", $data) . "'";
     
        $dtvalue2 = date('Y-m-d');
       $cca = DB::Select("select advertiser_campaigns.cpa,advertiser_campaigns.name as adv_name,"
                . "crc.conversion_count_unique as unique_conversion_count,ads.id_ad as id_ad,"
                . "ads.network_name,ads.id_zone,ads.cco,ads.title,ads.click_url,ads.parent_id,"
                . "ads.country_code,ads.operator_name,ads.traffic_type,crc.cost_dollar as total_cost,crc.op_name,"
                . "country.name as cntry,sum(crc.clickcount) as clickcount, sum(crc.conversion_count) as conversion_count,"
                . "ads.network_cpa,sum(crc.clicks_active_count) as clicks_active_count ,"
                . "concat(ads.cr_goal,'%') as cr_goal,"
                . "concat(cr_received,'%') as cr_received,"
                . "concat(cr_given,'%') as cr_given,"
                . "crc.create_time,ads.id_advertiser "
                . "FROM ads "
                . "left join advertiser_campaigns on ads.id_advertiser=advertiser_campaigns.id "
                . "left join country on ads.country_code=country.iso "
                . "left JOIN crc_records_new AS crc ON crc.id_ad=ads.id_ad "
                . "WHERE ads.description='default' AND ads.traffic_type "
                . "IN($trffic_type) AND ads.country_code='$request->country_name' "
                . "AND ads.cco='$request->operator_name' "
                ." and  DATE(crc.create_time) BETWEEN DATE('".$dtvalue2."') AND DATE('".$dtvalue2."') "
               . "ORDER BY ads.id_ad ASC"
         );
      
       if($cca[0]->parent_id != 0)
       {
  $cca = DB::Select("select advertiser_campaigns.cpa,"
                   . "advertiser_campaigns.name as adv_name,"
                   . "crc.conversion_count_unique as unique_conversion_count,"
                   . "ads.id_ad as id_ad,ads.network_name,"
                   . "ads.id_zone,ads.cco,"
                   . "ads.title,ads.click_url,"
                   . "ads.parent_id,ads.country_code,"
                   . "ads.operator_name,ads.traffic_type,"
                   . "crc.total_cost,crc.op_name,"
                   . "country.name as cntry,sum('0') as clickcount, "
                   . "sum('0') as conversion_count,"
                   . "ads.network_cpa,sum('0') as clicks_active_count,"
                   . "concat(ads.cr_goal,'%') as cr_goal,"
                   . "concat(cr_received,'%') as cr_received,"
                   . "concat(cr_given,'%') as cr_given,"
                   . "crc.create_time,"
                   . "ads.id_advertiser "
                   . "FROM ads left join advertiser_campaigns on ads.id_advertiser=advertiser_campaigns.id "
                   . "left join country on ads.country_code=country.iso "
                   . "left JOIN crc_records_new AS crc ON crc.id_ad=ads.id_ad "
                   . "WHERE ads.description='default' "
                   . "AND ads.parent_id = 0 AND ads.traffic_type IN($trffic_type) AND ads.country_code='$request->country_name' "
                   . "AND ads.cco='$request->operator_name' ORDER BY ads.id_ad ASC"
         );
            $cca = array_map(function ($cca) {
         return (array)$cca;
             }, $cca);
       echo $cca = json_encode($cca);
       }else{
       $cca = array_map(function ($cca) {
         return (array)$cca;
             }, $cca);
          echo $cca = json_encode($cca);    
       }      
    }


    public  function internationalrotator_addnew(Request $request)
    {

        $sql_url_s= DB::Select("select id as id_ad ,id as id_advertiser,name as title,url from advertiser_campaigns where id_op='$request->operator_name' AND status='1' and `country_code`='$request->country_name'  order by `name` asc");

      $ret = array();
        foreach($sql_url_s as $link) {
            if($link->title!="")
            {
           // $ret[$link->id_ad] = $link->title.' ('.$link->id_advertiser.')';
                $ret[]= array(
                    'id_ad'=> $link->id_ad,
                    'url'=> $link->title.' ('.$link->id_advertiser.')'
                    
                    );
            }
        }
     
        $dbSigning_array =   array('url_list'=> $ret);
        echo json_encode($dbSigning_array);
        
    }


  }


