<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;  

use App\Http\Requests;
use DB;
use App\Crc;
use Response;
use File;
use Illuminate\Support\Facades\Redis;
use Cache;
// use Advertiser;

class ConversionController extends Controller
{
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
   
    public function index(Request $request){
      $hour = date("H",time());
//      $items = json_decode($this->getConversionData());
      $items = $this->getConversionData();
      $lastUpdated = $this->lastUpdated();
      $dataN =  view('Conversion.index')->with($items);
      return $dataN;
//      return view('Conversion.index',compact('items','hour','lastUpdated'));
    }

    /**
     * To Show the data on landing page for current day Only
     *
     * @return \Illuminate\Http\Response
     */
    public function getConversionData(){
        $redis = Redis::connection();
        $date = date('Y-m-d');
        $date2 = date('Ymd');
        $dtvalue = date('Y-m-d');
        $enddate = date('Y-m-d');
//        $enddate = date('Y-m-d',strtotime("+1 days"));
        $table = "conversions_$date2 as con1";
        $key  =  "conversion_$date";
        try {
          if(!$redis->exists($key)){
             $items = $this->getcoversion(); 
             Redis::set($key, $items);
             $redis->expire($key,600);
            }else{
            $items = Redis::get($key);
         }
      } catch (\Exception $e) {
          $items = $this->getconversion();  
          
      }
      $allData = '';
        if(count($items['data']) > 0){
            $allData = $items['data'];
        }
        $opdata =  DB::table("operator");
        $opdata = $opdata->selectRaw("id,name,country_code")->get();
        
        $osdata =  DB::table("$table");
        $osdata = $osdata->selectRaw("distinct os")
                ->where("os","!=","")
                ->get();
        
        $networkdata =  DB::table("ad_network");
        $networkdata = $networkdata->selectRaw("distinct(ad_network.id),ad_network.name")
                ->rightJoin("conversions_$date2 as con1","ad_network.id","con1.id_zone")
                ->orderby("ad_network.name")
                ->get();
//        select distinct advertiser_campaigns.id_advertiser from advertiser_campaigns right join conversions_20181025 as con1 on con1.id_advertiser=advertiser_campaigns.id
        $advInnerdata =  DB::table("advertiser_campaigns");
        $advInnerdata = $advInnerdata->selectRaw("distinct advertiser_campaigns.id_advertiser")
                ->rightJoin("conversions_$date2 as con1","con1.id_advertiser","advertiser_campaigns.id")
//                ->orderby("ad_network.name")
                ->get();
        $string = array();
        $i = 0;
        
        foreach($advInnerdata as $value)
        {
            $string[$i] = $value->id_advertiser;
            $i++;
        }
        
        $advInnerdata = json_decode($advInnerdata);
        
        $advertiserdata =  DB::table("advertiser");
        $advertiserdata = $advertiserdata->selectRaw("id,name")
                ->whereIn('id',$string)
//                ->leftJoin("advertiser","con1.id_advertiser","advertiser.id")
                ->orderby("name")
                ->get();
        
        
        
        $campaigndata =  DB::table("conversions_$date2 as con1");
        $campaigndata = $campaigndata->selectRaw("distinct(con1.id_advertiser),advertiser_campaigns.name")
                ->leftJoin("advertiser_campaigns","con1.id_advertiser","advertiser_campaigns.id")
                ->orderby("advertiser_campaigns.name")
                ->get();
        
        $countrydata =  DB::table("country");
        $countrydata = $countrydata->selectRaw("distinct(country.iso),country.name")
                ->rightJoin("conversions_$date2 as con1","country.iso","con1.country")
                ->orderby("country.name")
                ->get();
//        $$opdata = json_decode($opdata);
//        echo "<pre>";
//        print_r($opdata);
//        echo "</pre>";
        $lastUpdated = $this->lastUpdated();
        $result  = array(
                          'data' => $items, 
                          'data1' => $allData,
                          'oparray' => $opdata,
                          'osarray' => $osdata,
                          'networkarray' => $networkdata,
                          'countryarray' => $countrydata,
                          'advertiserarray' => $advertiserdata,
                          'campaignarray' => $campaigndata,
                          'lastUpdated' => $lastUpdated,
//                          "routename"=>$routename,
//                          'header'=>$header,
                          'dtvalue' => $date,
                          'dtvalue2' => $enddate,
//                          'dtvalue2' => $enddate,
//                          'ddData' => $ddData,
//                          'id_channel'=>$request->id_channel,
//                          'operator_id'=>$request->operator_id,
//                          'traffic_type' => $request->traffic_type,
//                          'country'=> $request->country,
//                          'total'=>$request->total,
                          'lastRow'=>$items['lastRow']
//                          'is_smart'=>$is_smart,
//                          'update_time'=> $items['update_time']
                    );
        return $result;
    }

    public function getconversion(){
       $date = date('Ymd');
       $hour = date("H");
       $condtion = [];
       $table_name = "conversions_$date as con1";
       $select = [
                "con1.click_hour",
                "con1.id_ad",
                "con1.id_zone",         
                "con1.datetime",        
                "con1.id_advertiser",
                "(select advertiser.name from advertiser left join advertiser_campaigns on advertiser_campaigns.id_advertiser=advertiser.id where advertiser_campaigns.id=con1.id_advertiser) as advert_name",
//                "advertiser.name as advert_name",   
                "ad_network.name as net_name",   
                "con1.parent_cca",      
                "con1.from_server",     
                "con1.siteid",          
                "con1.country",         
                "con1.dollar_price",
                "con1.cc_token",
                "con1.network_token",
                "con1.os",
                "con1.client_ip",
                "con1.is_duplicate",
                "con1.googleid",
                "ads.traffic_type",
                "con1.status",
                "con1.price",
                'con1.pubid',
                'sum(IF(con1.sale = "1",1,0)) as sale',
           "CASE WHEN ads.traffic_type in('SM','SG','WM','WG') THEN (SELECT operator.name FROM operator where con1.id_ad=operator.id) WHEN con1.traffic_type not in('SM','SG','WM','WG') THEN (SELECT ads.operator_name from ads where con1.id_ad=ads.id_ad) ELSE 'HELLO' END as operator_name",
                "count(1) as conversion"
      ];
//        $fields = implode(",", $field);
        $select = implode(",",$select);
        $data =  DB::table($table_name)->where($condtion);
        $data = $data->selectRaw($select)
                ->leftJoin("advertiser","con1.id_advertiser","advertiser.id")
                ->leftJoin("ad_network","con1.id_zone","ad_network.id")
                ->leftJoin("ads","con1.parent_cca","ads.id_ad")
                ->groupby('click_hour')
                ->orderby('click_hour','DESC');
        $data =  $data->get();
        $data1 = [];
        $total_price = $total_dollar_price = $total_conversion = $total_sale = 0; 
        
        if(count($data))
        {
            foreach ($data as $fetch_records) {
                $array = [];
                array_push($array,
                          $fetch_records->click_hour,
                          $fetch_records->from_server,
                          $fetch_records->operator_name,
                          $fetch_records->country,
                          $fetch_records->parent_cca,
                          $fetch_records->siteid,
                          $fetch_records->conversion,
                          $fetch_records->sale,
                          $fetch_records->id_ad,
                          $fetch_records->net_name,
                          $fetch_records->datetime,
                          $fetch_records->advert_name,
                          $fetch_records->id_advertiser,
                          $fetch_records->traffic_type,
                          $fetch_records->price,
                          $fetch_records->dollar_price,
                          $fetch_records->network_token,
                          $fetch_records->cc_token,
                          $fetch_records->pubid,
                          $fetch_records->os,
                          $fetch_records->client_ip,
                          $fetch_records->is_duplicate,
                          $fetch_records->googleid,
                          $fetch_records->status
                        );
                       
                        array_push($data1, $array);
                        $total_dollor_price = $total_dollar_price + $fetch_records->dollar_price;
                        $total_price = $total_price + $fetch_records->price;
                        $total_conversion = $total_conversion + $fetch_records->conversion;
                        $total_sale = $total_sale + $fetch_records->sale;
            }
        }
        $lastRow = ["Total",
                    "",
                    "",
                    "",
                    "",
                    "",
                    $total_conversion,
                    $total_sale,
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    round($total_price,2),
                    round($total_dollor_price,2),
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    ""
                    ];
        
        $status = array("status"=>"1",'data'=>$data1,'lastRow'=>$lastRow); 
        return $status;
    }

  
    public function filterData(Request $request){
	    $redis = Redis::connection();
     	$current_url = $request->fullUrl();
      $current_url = explode("?",$current_url);
      if(count($current_url) > 1){
         $allParameters = $current_url[1];
         $key = "Smartdata_$allParameters";
      }
      try{
          if(!$redis->exists($key)){
              $item = $this->getFilterQuery($request);
              Redis::set($key, $item);
              $redis->expire($key,500);
              }else{
               $item = $this->getFilterQuery($request);
              }
      } catch(\Exception $e){
         $item = $this->getFilterQuery($request);
      } 
       return $item;
	 }

   function getFilterQuery(Request $request){
       $date = date('Ymd');
       $hour = date("H");
//       $condtion = [];
       $id_zone_arr = $click_hour_arr = $from_server_arr = $country_arr = $traffic_type_arr = $os_arr = $id_advertiser_arr = $group_by_arr = [];
       $table_name = "conversions_$date as con1";
      $condition = [];
      $groupCondition = [];
      $checkedCond = [];
      $extra_fields = '';
//      $date = explode(" - ",$request->date);
//      if(count($date) > 1){
//        $startDate = date('Ymd',strtotime($date[0]));
//        $endDate = date('Ymd',strtotime($date[1]));
//	    }
//      if($request->exists('group_by') && $request->group_by){
//          $group_by = implode("','",$request->group_by);
//      }
        if($request->parent_cca){
//            $condition .= " AND con1.parent_cca IN ('".$request->parent_cca."')";
            array_push($condition,['con1.parent_cca','=',$request->parent_cca]);
        }
        if($request->id_ad){
//            $condition .= " AND id_ad IN ('".$request->id_ad."')";
            array_push($condition,['con1.id_ad','=',$request->id_ad]);
        }
        if($request->id_zone && $request->id_zone != 0)
        {
            if(count($request->id_zone) > 1 )
            {
                $id_zone_arr = $request->id_zone;
            }
            else
            {
                array_push($condition,['con1.id_zone','=',$request->id_zone[0]]);
            }              
        }
        if($request->from_server && $request->from_server != '')
        {
            if(count($request->from_server) > 1 )
            {
                $from_server_arr = $request->from_server;
            }
            else
            {
                array_push($condition,['con1.from_server','=',$request->from_server[0]]);   
            }              
        }
        if($request->country && $request->country != '')
        {
            if(count($request->country) > 1 )
            {
                $country_arr = $request->country;
            }
            else
            {
                array_push($condition,['con1.country','=',$request->country[0]]);   
            }              
        }
        if($request->traffic_type && $request->traffic_type != '')
        {
            if(count($request->traffic_type) > 1 )
            {
                $traffic_type_arr = $request->traffic_type;
            }
            else
            {
                array_push($condition,['ads.traffic_type','=',$request->traffic_type[0]]);   
            }              
        }
        if($request->os && $request->os != '')
        {
            if(count($request->os) > 1 )
            {
                $os_arr = $request->os;
            }
            else
            {
                array_push($condition,['con1.os','=',$request->os[0]]);   
            }              
        }
        if($request->id_advertiser && $request->id_advertiser != '')
        {
            if(count($request->id_advertiser) > 1 )
            {
                $id_advertiser_arr = $request->id_advertiser;
            }
            else
            {
                array_push($condition,['con1.id_advertiser','=',$request->id_advertiser[0]]);   
            }              
        }
        if($request->click_hour && $request->click_hour != '')
        {
            if(count($request->click_hour) > 1 )
            {
                $click_hour_arr = $request->click_hour;
            }
            else
            {
                array_push($condition,['con1.click_hour','=',$request->click_hour[0]]);   
            }              
        }
        if($request->siteid)
        {
            array_push($condition,['con1.siteid','=',$request->siteid]);
        }
        if($request->network_token)
        {
            array_push($condition,['con1.network_token','=',$request->network_token]);
        }
        if($request->cc_token)
        {
            array_push($condition,['con1.cc_token','=',$request->cc_token]);
        }
        if($request->pubid)
        {
            array_push($condition,['con1.pubid','=',$request->pubid]);
        }
        if($request->group_by && $request->group_by != '')
        {
            $group_by_arr = $request->group_by;
            if(count($request->group_by) > 1 )
            {
                
                $groupCondition = $request->group_by;
            }
            else
            {
                array_push($groupCondition,$request->group_by[0]);   
//                $groupCondition .= "'".$request->group_by[0]."'";
            }              
        }
        else
        {
            array_push($groupCondition,['click_hour']);
        }

      $field = [
                "con1.click_hour",
                "con1.id_ad",
                "con1.id_zone",         
                "con1.datetime",        
                "con1.id_advertiser",
                "(select advertiser.name from advertiser left join advertiser_campaigns on advertiser_campaigns.id_advertiser=advertiser.id where advertiser_campaigns.id=con1.id_advertiser) as advert_name",
//                "advertiser.name as advert_name",   
                "ad_network.name as net_name",   
                "con1.parent_cca",      
                "con1.from_server",     
                "con1.siteid",          
                "con1.country",         
                "con1.dollar_price",
                "con1.cc_token",
                "con1.network_token",
                "con1.os",
                "con1.client_ip",
                "con1.is_duplicate",
                "con1.googleid",
                "ads.traffic_type",
                "con1.status",
                "con1.price",
                'con1.pubid',
                'sum(IF(con1.sale = "1",1,0)) as sale',
           "CASE WHEN ads.traffic_type in('SM','SG','WM','WG') THEN (SELECT operator.name FROM operator where con1.id_ad=operator.id) WHEN con1.traffic_type not in('SM','SG','WM','WG') THEN (SELECT ads.operator_name from ads where con1.id_ad=ads.id_ad) ELSE 'HELLO' END as operator_name",
                "count(1) as conversion"
      ];
      
        

        $fields = implode(",", $field); 
        $data =  DB::table($table_name)->where($condition);
      
        if($id_zone_arr)
        {
            $data = $data->whereIn('con1.id_zone',$id_zone_arr);
        }
        if($click_hour_arr)
        {
            $data = $data->whereIn('con1.click_hour',$click_hour_arr);
        }
        if($from_server_arr)
        {
            $data = $data->whereIn('con1.from_server',$from_server_arr);
        }
        if($country_arr)
        {
            $data = $data->whereIn('con1.country',$country_arr);
        }
        if($traffic_type_arr)
        {
            $data = $data->whereIn('ads.traffic_type',$traffic_type_arr);
        }
        if($os_arr)
        {
            $data = $data->whereIn('con1.os',$os_arr);
        }
        if($id_advertiser_arr)
        {
            $data = $data->whereIn('con1.id_advertiser',$id_advertiser_arr);
        }
        if($group_by_arr)
        {
            if(!in_array('client_ip',$group_by_arr))
            {
                array_push($checkedCond,'20');
            }
            if(!in_array('is_duplicate',$group_by_arr))
            {
                array_push($checkedCond,'21');
            }
            if(!in_array('googleid',$group_by_arr))
            {
                array_push($checkedCond,'22');
            }
//            foreach ($group_by_arr as $value) {
//                $groupCondition .= "'".$value."',";
//            }
//            rtrim($groupCondition,',');
//            rtrim($groupCondition,"'");
//            ltrim($groupCondition,"'");
//            $groupCondition = $group_by_arr;
//            $data = $data->whereIn('con1.id_advertiser',$id_advertiser_arr);
        }
      
      
        $data = $data->selectRaw($fields)
                ->leftJoin("advertiser","con1.id_advertiser","advertiser.id")
                ->leftJoin("ad_network","con1.id_zone","ad_network.id")
                ->leftJoin("ads","con1.parent_cca","ads.id_ad")
                ->groupby($groupCondition)
                ->orderby('click_hour','DESC');
        $data =  $data->get();
        $data1 = [];
        $total_price = $total_dollar_price = $total_conversion = $total_sale = 0; 
        
        if(count($data))
        {
            foreach ($data as $fetch_records) {
                $array = [];
                array_push($array,
                          $fetch_records->click_hour,
                          $fetch_records->from_server,
                          $fetch_records->operator_name,
                          $fetch_records->country,
                          $fetch_records->parent_cca,
                          $fetch_records->siteid,
                          $fetch_records->conversion,
                          $fetch_records->sale,
                          $fetch_records->id_ad,
                          $fetch_records->net_name,
                          $fetch_records->datetime,
                          $fetch_records->advert_name,
                          $fetch_records->id_advertiser,
                          $fetch_records->traffic_type,
                          $fetch_records->price,
                          $fetch_records->dollar_price,
                          $fetch_records->network_token,
                          $fetch_records->cc_token,
                          $fetch_records->pubid,
                          $fetch_records->os,
                          $fetch_records->client_ip,
                          $fetch_records->is_duplicate,
                          $fetch_records->googleid,
                          $fetch_records->status
                        );
                       
                        array_push($data1, $array);
                        $total_dollor_price = $total_dollar_price + $fetch_records->dollar_price;
                        $total_price = $total_price + $fetch_records->price;
                        $total_conversion = $total_conversion + $fetch_records->conversion;
                        $total_sale = $total_sale + $fetch_records->sale;
            }
        }
        $lastRow = ["Total",
                    "",
                    "",
                    "",
                    "",
                    "",
                    $total_conversion,
                    $total_sale,
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    round($total_price,2),
                    round($total_dollor_price,2),
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    ""
                    ];
        
        $status = array("status"=>"1",'data'=>$data1,'lastRow'=>$lastRow,'checkedCond'=>$checkedCond); 
        return $status;
      
//      $total_record = count($data);
//      $status = array("status"=>"1",'data'=>$data1,'lastRow'=>$lastRow); 
//        return $status;
//      return view('Conversion.filterData',compact('items','flag','total_record')); 
    }


    function lastUpdated(){
        $date = date('Ymd');
        $table_name = "conversions_$date";
        $lastUpdated = DB::select("SELECT max(click_date_time) as click_date_time from $table_name limit 1");
        $lastUpdated_count = count($lastUpdated);
        if($lastUpdated_count > 0)
          if($lastUpdated[0]->click_date_time){
          return $lastUpdated[0]->click_date_time;  
        }
        return "No Update time";  
      }

  }

