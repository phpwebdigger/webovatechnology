<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\AdNetwork;
use App\Users;

class SmartLinkController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */




    public function index(Request $request,$type="",$routename = "smartNetworkfilter",$header="Network CR WG")
    {


            $condtion = [];
            $ddCondition = [];
            $dtvalue = $request->start;
            $dtvalue2 = $request->end;
            
            
            if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                    $dtvalue2 = date('Y-m-d');
                    $enddate = date('Y-m-d',strtotime("+1 days"));
            }else{
                //$dtvalue2 = date('Y-m-d',strtotime("+1 days"));
               $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));

            }
            
            array_push($condtion,['crc_records_new.create_time','>=',"'".$dtvalue."'"] );
            
            array_push($condtion,['crc_records_new.create_time','<=',"'".$enddate."'"] );
            
            array_push($ddCondition,['crc_records_new.create_time','>=',$dtvalue] );
            
            array_push($ddCondition,['crc_records_new.create_time','<=',$enddate] );

            if($type != "" && $type != "CPS"){
                array_push($condtion,['ads.type','=',strtoupper($type)] );
            }
            $adData = [];
            $adDataArray = "";
           

            // array_push($condtion,['ads.id_zone','=',1168] );
            if($request->id_channel && $request->id_channel != 0){
                //dd($request->id_channel);   
                
                //array_push($condtion,['ads.id_zone','=',1168] );
                array_push($condtion,['ads.id_zone','=',$request->id_channel] );
            }
            else{
                if($type=="organizr"){
                  array_push($condtion,['ads.id_zone','=','538'] );
                }
            }
            if($request->operator_id){
                array_push($condtion,['ads.cco','=',$request->operator_id] );
               // dd($condtion);
            }
            if($request->traffic_type){
              // dd($condtion);
                array_push($condtion,['ads.traffic_type','=',$request->traffic_type] );


            }
            if($request->traffic_type){
                
            }
            
            if($request->country && $request->country !== 0){
             
                array_push($condtion,['ads.country_code','=',$request->country] );

            }
            
            array_push($condtion,["ads.description","=","'default'"] );
            //array_push($condtion,["ads.description","=","default"] );
            array_push($ddCondition,["ads.description","=","'default'"] );

            $request->total = $request->total ? $request->total:50;

          $ddData = $this->createDD($request,$type,$ddCondition);
          //dd($ddData);
           //print_r($ddData); die; 
          

          $select =  "crc_records_new.id,"
                    ."crc_records_new.op_name,"
                    ."crc_records_new.create_time as dte,"
                    ."crc_records_new.id_ad,"
                    ."crc_records_new.cr_received,"
                    ."crc_records_new.cr_given,"
                    ."crc_records_new.conversion_count_unique,"
                    ."crc_records_new.total_cost,"
                    ."advertiser_campaigns.cpa,"
                    ."crc_records_new.parent_cca,"
                    ."CONCAT(advertiser_campaigns.name,'(',crc_records_new.id_advertiser_campaign,')') as adv_name,"
                    ."ads.network_name,"
                    ."crc_records_new.advertiser_name,"
                    ."crc_records_new.clickcount_fraud as fraud,"
                    ."sum(crc_records_new.clickcount) as clickcount,"
                    ."ads.traffic_type,"
                    ."sum(crc_records_new.clicks_active_count) as clicks_active_count,"
                    ."sum(crc_records_new.conversion_count) as conversion_count,"
                    ."crc_records_new.network_cpa,"
                    ."round(sum(crc_records_new.cost_dollar), 2) as cost_dollar,"
                    ."crc_records_new.id_advertiser_campaign,"
                    ."ads.country_code,"
                    ."round(sum(crc_records_new.conversion_count_unique),2) as unique_conversion_count,"
                    ."round(sum(crc_records_new.revenue_dollar), 2) as revenue_dollar";


                         $start = microtime(true);
        
        $appends = [];

        // array_push($condtion,["ads.id_advertiser","=","advertiser_campaigns.id"] );
        // array_push($condtion,["crc_records_new.id_ad","=","ads.id_ad"] );
    

        //dd($condtion);
         $data =  DB::table("ads")
                  ->whereIn('ads.traffic_type', ["'WG'"])
                  ->whereNotIn('ads.cco',["'-1'","'33'"])
                  ->where($condtion) 
                  ->selectRaw(DB::raw($select))
                  ->join("advertiser_campaigns","ads.id_advertiser","=","advertiser_campaigns.id")
                  ->join("crc_records_new","crc_records_new.id_ad","=","ads.id_ad")
                  ->groupby("crc_records_new.id_ad")
                  ->groupby("ads.cco")
                  ->orderby("ads.country_code","ASC")
                  ->orderby("ads.operator_name","ASC");
       


          $data = $data->get();
                


                $data1 = [];
                $clickcount = 0;
                $conversion_count = 0;
                $clicks_active_count = 0;
                $conversion_count_unique = 0;$conversion_count_unique = 0;
                $sourcost = 0;
                $cc_revenueDller_ecpm=0;
                $convCount = 0;
                $revenue_dollarX = 0;
                $profit = 0;
                $clickcount_fraud=0;

                if(sizeof($data) !== 0)
                {
                    //$update_time =  $data[sizeof($data)-1]->create_time;
                     $update_time =  $data[sizeof($data)-1]->dte;
                }else{
                    $update_time = "";
                }
    
                foreach ($data as $fetch_records) {
                $array = [];
                
                array_push($array,
                    $fetch_records->id_ad,
                    '<a title="'.$fetch_records->network_name.'"href="/network-cr-update-single-network/'.$fetch_records->id_ad.'?start='.$dtvalue.'&end='.$dtvalue2.'">'.$fetch_records->network_name.'</a>',
                                            $fetch_records->network_cpa,
                                            $fetch_records->op_name,
                                            $fetch_records->traffic_type,
                                            // '<span title="'.$fetch_records->adv_name.'('.$fetch_records->adv_ids.')">'.$fetch_records->adv_name.'('.$fetch_records->adv_ids.')</span>',

                                          '<span title="'.$fetch_records->adv_name.'">'.$fetch_records->adv_name.'</span>',
                                          

                                            array_key_exists($fetch_records->country_code,$ddData['country_dropdown'])?$ddData['country_dropdown'][$fetch_records->country_code]:"",
                                            $fetch_records->clickcount,
                                            $fetch_records->clickcount-$fetch_records->fraud,
                                            $fetch_records->conversion_count,
                                            $fetch_records->clicks_active_count,
                                            $fetch_records->cr_received, 
                                            $fetch_records->cr_given,
                                            $fetch_records->conversion_count_unique,
                                           
                                             round($fetch_records->total_cost,2)."/".round($fetch_records->total_cost * 65, 2),
                                            round($fetch_records->revenue_dollar,2)."/".round($fetch_records->revenue_dollar * 65, 2),
                                            round($fetch_records->revenue_dollar/1000,2)."/".round($fetch_records->revenue_dollar/1000,2)*65,
                                             // $fetch_records->cpa * $fetch_records->conversion_count,
                                            round(($fetch_records->revenue_dollar - $fetch_records->total_cost),2)."/". round(($fetch_records->revenue_dollar - $fetch_records->total_cost),2)*65,
                                            '<input class="remark" myID="'.$fetch_records->id_ad.'" type="text" value="'.""/*$fetch_records->remark*/.'" id="example-text-input">');
                                         
                array_push($data1, $array);
                                            $clickcount += $fetch_records->clickcount;
                                            $clickcount_fraud += $fetch_records->fraud;
                                            $conversion_count += $fetch_records->conversion_count;
                                            $clicks_active_count += $fetch_records->clicks_active_count;
                                          
                                           
                                            
                                             $conversion_count_unique += $fetch_records->conversion_count_unique;
                                          
                                            $sourcost +=  round($fetch_records->total_cost,2);
                                            $revenue_dollarX +=  round($fetch_records->revenue_dollar,2);
                                            $cc_revenueDller_ecpm +=  round($fetch_records->revenue_dollar/1000,2);
                                            $convCount += $fetch_records->cpa * $fetch_records->conversion_count;
                                            $profit += ($fetch_records->revenue_dollar - $fetch_records->total_cost);
               // data1.push( [$id,$link,$title,$traffic_type,$network_name,$operator_name,$id_advertiser,$click_url]);

        }

        $lastRow =[$clickcount,$clickcount-$clickcount_fraud,$conversion_count,$clicks_active_count,$conversion_count_unique,$sourcost."/".round($sourcost*65,2),$revenue_dollarX."/".round($revenue_dollarX*65,2),$cc_revenueDller_ecpm."/".round($cc_revenueDller_ecpm*65,2),round($profit,2)."/".round($profit*65,2)];



         // if($request->total == "all"){
         //       $data =  $data->get();

         //    }else{
         //       $data =  $data->paginate($request->total)->appends($appends);
         
         //    }
        
             //$time_elapsed_secs = microtime(true) - $start;
             //print_r("Time Taken");
             //print_r($time_elapsed_secs);
        
         $result  = array('data1' => $data1,
            "routename"=>$routename,
            'header'=>$header,
            'dtvalue' => $dtvalue,
            'dtvalue2' => $dtvalue2,
            'ddData' => $ddData,
            'id_channel'=>$request->id_channel,
            'operator_id'=>$request->operator_id,
            'traffic_type' => $request->traffic_type,
            'country'=> $request->country,
            'total'=>$request->total,
            'lastRow'=>$lastRow,
            'update_time'=>$update_time
          );
         //dd($result);
        

        
         if(sizeof($adData)>0){
              $viewPage = "network.network_smart_cr_update_cps";
         }else{
               $viewPage = "network.network_smart_cr_update";
             }
         
       // dd("aa");
         $dataN =  view($viewPage)->with($result);
         $time_elapsed_secs = microtime(true) - $start;
            
        return $dataN;

    //     FROM ads "
    //     , "left join advertiser_campaigns as advertiser_campaigns  on ads.id_advertiser=advertiser_campaigns.id "
    //     . "left join country on ads.country_code=country.iso "
    //     . "right JOIN crc_records_new AS crc ON crc.parent_cca=ads.id_ad "
    //     . "WHERE DATE(crc.create_time)  BETWEEN DATE('" . $dtvalue . "') AND  DATE('" . $dtvalue2 . "')  "
    //     . "AND  ads.description!='default' $channel_cond $country_cond $teco_cond $traffic_type ORDER BY network_name,operator_name ASC ";

    // }
     }

     
    public function smartLinkWG_index(Request $request,$type="",$routename = "smartLinkWG",$header="Smart Link WG")
    {

        $condtion = [];
            $ddCondition = [];
            $dtvalue = $request->start;
            $dtvalue2 = $request->end;
            
            
            if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                    $dtvalue2 = date('Y-m-d');
                    $enddate = date('Y-m-d',strtotime("+1 days"));
            }else{
               $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));
            }
            
            array_push($condtion,['crc_records_new.create_time','>=',$dtvalue] );
            array_push($condtion,['crc_records_new.create_time','<=',$enddate] );

            array_push($condtion,["ads.description","=","default"] );
            
            array_push($ddCondition,['crc_network_campaign_new.create_time','>=',$dtvalue] );
            array_push($ddCondition,['crc_network_campaign_new.create_time','<=',$enddate] );
            array_push($ddCondition,['ads.description','=','default'] );
            
            if($request->id_channel && $request->id_channel != 0){
                array_push($condtion,['ads.id_zone','=',$request->id_channel] );
            }

            if($request->operator_id){
                array_push($condtion,['ads.cco','=',$request->operator_id] );
            }
            if($request->traffic_type){
                array_push($condtion,['ads.traffic_type','=',$request->traffic_type] );
            }

            
            if($request->country && $request->country !== 0){
             
                array_push($condtion,['ads.country_code','=',$request->country] );

            }


            $request->total = $request->total ? $request->total:50;

          $ddData = $this->createDDWG($request,$type,$ddCondition);
          

          $select = 
              "crc_records_new.id,"
            ."crc_records_new.op_name,"
            ."crc_records_new.create_time as dte,"
            ."crc_records_new.id_ad,"
            ."advertiser_campaigns.cpa,"
            ."crc_records_new.parent_cca,"
            ."advertiser_campaigns.name as adv_name,"
            ."crc_records_new.id_advertiser_campaign as advrt_id,"
            ."ads.network_name,"
            ."crc_records_new.advertiser_name,"
            ."crc_records_new.id_advertiser_campaign,"
            ."crc_records_new.clickcount_fraud as fraud,"
            ."ads.traffic_type,"
            ."sum(crc_records_new.clickcount) as clickcount,"
            ."sum(crc_records_new.clicks_active_count) as clicks_active_count,"
            ."sum(crc_records_new.conversion_count) as conversion_count,"
            ."crc_records_new.network_cpa,"
            ."round(sum(crc_records_new.cost_dollar), 2) as cost_dollar,"
            ."crc_records_new.id_advertiser_campaign,"
            ."ads.country_code,"
            ."sum(crc_records_new.conversion_count_unique) as unique_conversion_count,"
            ."round(sum(crc_records_new.revenue_dollar), 2) as revenue_dollar";


                         $start = microtime(true);
        
         $data =  DB::table("crc_records_new")
                ->whereIn('ads.traffic_type', ['WG'])
                ->whereNotIn('ads.cco', ['-1','33'])
                ->where($condtion) 
                ->selectRaw(DB::raw($select))
//                ->select($select)
                ->leftJoin("ads","ads.id_ad","=","crc_records_new.id_ad")
                ->leftJoin("advertiser_campaigns","advertiser_campaigns.id","=","ads.id_advertiser")                
                ->groupby("crc_records_new.id_ad")
                ->groupby("ads.cco")
                ->orderby("ads.country_code","ASC")
                ->orderby("ads.operator_name","ASC")
//                 ->limit(10)
//                ->paginate($request->total)
                 ->get();

//         dd($data);

                $data1 = [];
                $clickcount = 0;
                $conversion_count = 0;
                $clicks_active_count = 0;
                $conversion_count_unique = 0;
                $sourcost = 0;
                $cc_revenueDller_ecpm=0;
                $convCount = 0;
                $revenue_dollarX = 0;
                $profit = 0;
                $clickcount_fraud=0;

    
                foreach ($data as $fetch_records) {
                    
                    $val1=$fetch_records->conversion_count;
                        $val2=$fetch_records->clickcount;
                        $val3=($val1/$val2)*100;
                        $var4 = number_format($val3, 2)."%";
                    
                        $val4=$fetch_records->clicks_active_count;
                            $val5=$fetch_records->clickcount;
                            $val6=($val4/$val5)*100;
                            $var5 = number_format($val6, 2)."%";
                        
                   $array = [];
                
                array_push($array,
                    $fetch_records->id_ad,
                    '<a title="'.$fetch_records->network_name.'"href="/smart-link-wg-single/'.$fetch_records->id_ad.'?start='.$dtvalue.'&end='.$dtvalue2.'&op_name='.$fetch_records->op_name.'&traffic_type='.$fetch_records->traffic_type.'">'.$fetch_records->network_name.'</a>',
                    $fetch_records->network_cpa,
                    $fetch_records->op_name,
                    $fetch_records->traffic_type,
                    '<span title="'.$fetch_records->adv_name.'('.$fetch_records->id_advertiser_campaign.')">'.$fetch_records->adv_name.'</span>',
                    $fetch_records->country_code,
                   
                    $fetch_records->clickcount,
                    $fetch_records->clickcount-$fetch_records->fraud,
                    $fetch_records->unique_conversion_count,                        
                    $fetch_records->clicks_active_count,
                        $var4,
                        $var5,
                    $fetch_records->conversion_count,
                    round($fetch_records->revenue_dollar,2)."/".round($fetch_records->revenue_dollar * 65, 2),
                    round($fetch_records->cost_dollar,2)."/".round($fetch_records->cost_dollar * 65, 2),                    
                    round(($fetch_records->revenue_dollar - $fetch_records->cost_dollar),2)."/". round(($fetch_records->revenue_dollar - $fetch_records->cost_dollar),2)*65,
                    '<input class="remark" myID="'.$fetch_records->id_ad.'" type="text" value="'.""/*$fetch_records->remark*/.'" id="example-text-input">');
                                         
                array_push($data1, $array);
                    $clickcount += $fetch_records->clickcount;
                    $clickcount_fraud += $fetch_records->fraud;
                    $conversion_count += $fetch_records->conversion_count;
                    $clicks_active_count += $fetch_records->clicks_active_count;
                     $conversion_count_unique += $fetch_records->unique_conversion_count;

                    $sourcost +=  round($fetch_records->cost_dollar,2);
                    $revenue_dollarX +=  round($fetch_records->revenue_dollar,2);
                    $cc_revenueDller_ecpm +=  round($fetch_records->revenue_dollar/1000,2);
                    $convCount += $fetch_records->cpa * $fetch_records->conversion_count;
                    $profit += ($fetch_records->revenue_dollar - $fetch_records->cost_dollar);
                    
                
        }

        $lastRow =[$clickcount,$clickcount-$clickcount_fraud,$conversion_count,$clicks_active_count,$conversion_count_unique,$sourcost."/".round($sourcost*65,2),$revenue_dollarX."/".round($revenue_dollarX*65,2),$cc_revenueDller_ecpm."/".round($cc_revenueDller_ecpm*65,2),round($profit,2)."/".round($profit*65,2)];
        
         $result  = array('data1' => $data1,
            "routename"=>$routename,
            'header'=>$header,
            'dtvalue' => $dtvalue,
            'dtvalue2' => $dtvalue2,
            'ddData' => $ddData,
            'id_channel'=>$request->id_channel,
            'operator_id'=>$request->operator_id,
            'traffic_type' => $request->traffic_type,
            'country'=> $request->country,
            'total'=>$request->total,
            'lastRow'=>$lastRow
          );
         //dd($result);

               $viewPage = "smartlink.smrt_link_wg";
         
       // dd("aa");
         $dataN =  view($viewPage)->with($result);
        return $dataN;
            
    }
    public function smartLinkWGWifi_index(Request $request,$type="",$routename = "smartLinkWifiWG",$header="Smart Link WIFI WG")
    {
        

        $condtion = [];
            $ddCondition = [];
            $dtvalue = $request->start;
            $dtvalue2 = $request->end;
            
            
            if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                    $dtvalue2 = date('Y-m-d');
                    $enddate = date('Y-m-d',strtotime("+1 days"));
            }else{
               $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));
            }
            
            array_push($condtion,['crc_records_new.create_time','>=',$dtvalue] );
            array_push($condtion,['crc_records_new.create_time','<=',$enddate] );
            array_push($condtion,["ads.description","=","default"] );
            array_push($condtion,["crc_records_new.op_id","=","33"] );
            array_push($condtion,["ads.cco","=","33"] );
            
            array_push($ddCondition,['crc_network_campaign_new.create_time','>=',$dtvalue] );
            array_push($ddCondition,['crc_network_campaign_new.create_time','<=',$enddate] );
            array_push($ddCondition,['ads.description','=','default'] );
            array_push($ddCondition,["ads.cco","=","33"] );

            
            if($request->id_channel && $request->id_channel != 0){
                array_push($condtion,['ads.id_zone','=',$request->id_channel] );
            }

            if($request->operator_id){
                array_push($condtion,['ads.cco','=',$request->operator_id] );
            }
            if($request->traffic_type){
                array_push($condtion,['ads.traffic_type','=',$request->traffic_type] );
            }

            if($request->country && $request->country !== 0){
             
                array_push($condtion,['ads.country_code','=',$request->country] );

            }
            $request->total = $request->total ? $request->total:50;

          $ddData = $this->createDDWGWIFI($request,$type,$ddCondition);          

          $select = 
              "crc_records_new.id,"
            ."crc_records_new.op_name,"
            ."crc_records_new.create_time as dte,"
            ."crc_records_new.id_ad,"
            ."advertiser_campaigns.cpa,"
            ."crc_records_new.parent_cca,"
            ."advertiser_campaigns.name as adv_name,"
            ."crc_records_new.id_advertiser_campaign as advrt_id,"
            ."ads.network_name,"
            ."crc_records_new.advertiser_name,"
            ."crc_records_new.id_advertiser_campaign,"
            ."crc_records_new.clickcount_fraud as fraud,"
            ."ads.traffic_type,"
            ."sum(crc_records_new.clickcount) as clickcount,"
            ."sum(crc_records_new.clicks_active_count) as clicks_active_count,"
            ."sum(crc_records_new.conversion_count) as conversion_count,"
            ."crc_records_new.network_cpa,"
            ."round(sum(crc_records_new.cost_dollar), 2) as cost_dollar,"
            ."crc_records_new.id_advertiser_campaign,"
            ."ads.country_code,"
            ."sum(crc_records_new.conversion_count_unique) as unique_conversion_count,"
            ."round(sum(crc_records_new.revenue_dollar), 2) as revenue_dollar";


                         $start = microtime(true);
        
         $data =  DB::table("crc_records_new")
                ->whereIn('ads.traffic_type', ['WG'])
//                ->whereNotIn('ads.cco',"=", "33")
                ->where($condtion) 
                ->selectRaw(DB::raw($select))
//                ->select($select)
                ->leftJoin("ads","ads.id_ad","=","crc_records_new.id_ad")
                ->leftJoin("advertiser_campaigns","advertiser_campaigns.id","=","ads.id_advertiser")                
                ->groupby("crc_records_new.id_ad")
                ->groupby("ads.cco")
                ->orderby("ads.country_code","ASC")
                ->orderby("ads.operator_name","ASC")
//                 ->limit(10)
//                ->paginate($request->total)
                 ->get();

                $data1 = [];
                $clickcount = 0;
                $conversion_count = 0;
                $clicks_active_count = 0;
                $conversion_count_unique = 0;
                $sourcost = 0;
                $cc_revenueDller_ecpm=0;
                $convCount = 0;
                $revenue_dollarX = 0;
                $profit = 0;
                $clickcount_fraud=0;

    
                foreach ($data as $fetch_records) {
                    
                    $val1=$fetch_records->conversion_count;
                        $val2=$fetch_records->clickcount;
                        $val3=($val1/$val2)*100;
                        $var4 = number_format($val3, 2)."%";
                    
                        $val4=$fetch_records->clicks_active_count;
                            $val5=$fetch_records->clickcount;
                            $val6=($val4/$val5)*100;
                            $var5 = number_format($val6, 2)."%";
                        
                   $array = [];
                
                array_push($array,
                    $fetch_records->id_ad,
                    '<a title="'.$fetch_records->network_name.'"href="/smart-link-wifi-single/'.$fetch_records->id_ad.'?start='.$dtvalue.'&end='.$dtvalue2.'&op_name='.$fetch_records->op_name.'&traffic_type='.$fetch_records->traffic_type.'">'.$fetch_records->network_name.'</a>',
                    $fetch_records->network_cpa,
                    $fetch_records->op_name,
                    $fetch_records->traffic_type,
                    '<span title="'.$fetch_records->adv_name.'('.$fetch_records->id_advertiser_campaign.')">'.$fetch_records->adv_name.'</span>',
//                    array_key_exists($fetch_records->country_code,$ddData['country_dropdown'])?$ddData['country_dropdown'][$fetch_records->country_code]:"",
                    $fetch_records->country_code,
                   
                    $fetch_records->clickcount,
                    $fetch_records->clickcount-$fetch_records->fraud,
                     $fetch_records->conversion_count,                      
                    $fetch_records->clicks_active_count,                      
                    
                         $var4,
                        $var5,
                        $fetch_records->unique_conversion_count, 
                        round($fetch_records->cost_dollar,2)."/".round($fetch_records->cost_dollar * 65, 2),    
                    round($fetch_records->revenue_dollar,2)."/".round($fetch_records->revenue_dollar * 65, 2),                                    
                    round(($fetch_records->revenue_dollar - $fetch_records->cost_dollar),2)."/". round(($fetch_records->revenue_dollar - $fetch_records->cost_dollar),2)*65,
                    '<input class="remark" myID="'.$fetch_records->id_ad.'" type="text" value="'.""/*$fetch_records->remark*/.'" id="example-text-input">');
                                           
                array_push($data1, $array);
                    $clickcount += $fetch_records->clickcount;
                    $clickcount_fraud += $fetch_records->fraud;
                    $conversion_count += $fetch_records->conversion_count;
                    $clicks_active_count += $fetch_records->clicks_active_count;



                     $conversion_count_unique += $fetch_records->unique_conversion_count;

                    $sourcost +=  round($fetch_records->cost_dollar,2);
                    $revenue_dollarX +=  round($fetch_records->revenue_dollar,2);
                    $cc_revenueDller_ecpm +=  round($fetch_records->revenue_dollar/1000,2);
                    $convCount += $fetch_records->cpa * $fetch_records->conversion_count;
                    $profit += ($fetch_records->revenue_dollar - $fetch_records->cost_dollar);
                    
                
        }
        $lastRow =[$clickcount,$clickcount-$clickcount_fraud,$conversion_count,$clicks_active_count,$conversion_count_unique,$sourcost."/".round($sourcost*65,2),$revenue_dollarX."/".round($revenue_dollarX*65,2),$cc_revenueDller_ecpm."/".round($cc_revenueDller_ecpm*65,2),round($profit,2)."/".round($profit*65,2)];
        
         $result  = array('data1' => $data1,
            "routename"=>$routename,
            'header'=>$header,
            'dtvalue' => $dtvalue,
            'dtvalue2' => $dtvalue2,
            'ddData' => $ddData,
            'id_channel'=>$request->id_channel,
            'operator_id'=>$request->operator_id,
            'traffic_type' => $request->traffic_type,
            'country'=> $request->country,
            'total'=>$request->total,
            'lastRow'=>$lastRow
          );
         //dd($result);

               $viewPage = "smartlink.smrt_link_wifi_wg";
       // dd("aa");
         $dataN =  view($viewPage)->with($result);
            
        return $dataN;
            
    }
    public function smartLinkWM_index(Request $request,$type="",$routename = "smartLinkWM",$header="Smart Link WM")
    {
        

        $condtion = [];
            $ddCondition = [];
            $dtvalue = $request->start;
            $dtvalue2 = $request->end;
            
            
            if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                    $dtvalue2 = date('Y-m-d');
                    $enddate = date('Y-m-d',strtotime("+1 days"));
            }else{
               $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));
            }
            
            array_push($condtion,['crc_records_new.create_time','>=',$dtvalue] );
            array_push($condtion,['crc_records_new.create_time','<=',$enddate] );

            array_push($condtion,["ads.description","=","default"] );
            
            array_push($ddCondition,['crc_network_campaign_new.create_time','>=',$dtvalue] );
            array_push($ddCondition,['crc_network_campaign_new.create_time','<=',$enddate] );
            array_push($ddCondition,['ads.description','=','default'] );

            
            if($request->id_channel && $request->id_channel != 0){
                array_push($condtion,['ads.id_zone','=',$request->id_channel] );
            }

            if($request->operator_id){
                array_push($condtion,['ads.cco','=',$request->operator_id] );
            }
            if($request->traffic_type){
                array_push($condtion,['ads.traffic_type','=',$request->traffic_type] );
            }

            if($request->country && $request->country !== 0){
             
                array_push($condtion,['ads.country_code','=',$request->country] );

            }
            $request->total = $request->total ? $request->total:50;

          $ddData = $this->createDDWM($request,$type,$ddCondition);
          

          $select = 
              "crc_records_new.id,"
            ."crc_records_new.op_name,"
            ."crc_records_new.create_time as dte,"
            ."crc_records_new.id_ad,"
            ."advertiser_campaigns.cpa,"
            ."crc_records_new.parent_cca,"
            ."advertiser_campaigns.name as adv_name,"
            ."crc_records_new.id_advertiser_campaign as advrt_id,"
            ."ads.network_name,"
            ."crc_records_new.advertiser_name,"
            ."crc_records_new.id_advertiser_campaign,"
            ."crc_records_new.clickcount_fraud as fraud," 
            ."ads.traffic_type,"
            ."sum(crc_records_new.clickcount) as clickcount,"
            ."sum(crc_records_new.clicks_active_count) as clicks_active_count,"
            ."sum(crc_records_new.conversion_count) as conversion_count,"
            ."crc_records_new.network_cpa,"
            ."round(sum(crc_records_new.cost_dollar), 2) as cost_dollar,"
            ."crc_records_new.id_advertiser_campaign,"
            ."ads.country_code,"
            ."sum(crc_records_new.conversion_count_unique) as unique_conversion_count,"
            ."round(sum(crc_records_new.revenue_dollar), 2) as revenue_dollar";


                         $start = microtime(true);
        
         $data =  DB::table("crc_records_new")
                ->whereIn('ads.traffic_type', ['WM'])
                ->whereNotIn('ads.cco', ['-1','33'])
                ->where($condtion) 
                ->selectRaw(DB::raw($select))
//                ->select($select)
                ->leftJoin("ads","ads.id_ad","=","crc_records_new.id_ad")
                ->leftJoin("advertiser_campaigns","advertiser_campaigns.id","=","ads.id_advertiser")                
                ->groupby("crc_records_new.id_ad")
                ->groupby("ads.cco")
                ->orderby("ads.country_code","ASC")
                ->orderby("ads.operator_name","ASC")
//                 ->limit(10)
//                ->paginate($request->total)
                 ->get();

                $data1 = [];
                $clickcount = 0;
                $conversion_count = 0;
                $clicks_active_count = 0;
                $conversion_count_unique = 0;
                $sourcost = 0;
                $cc_revenueDller_ecpm=0;
                $convCount = 0;
                $revenue_dollarX = 0;
                $profit = 0;
                $clickcount_fraud=0;

    
                foreach ($data as $fetch_records) {
                    
                    $val1=$fetch_records->conversion_count;
                        $val2=$fetch_records->clickcount;
                        $val3=($val1/$val2)*100;
                        $var4 = number_format($val3, 2)."%";
                    
                        $val4=$fetch_records->clicks_active_count;
                            $val5=$fetch_records->clickcount;
                            $val6=($val4/$val5)*100;
                            $var5 = number_format($val6, 2)."%";
                        
                   $array = [];
                
                array_push($array,
                   $fetch_records->id_ad,
                    '<a title="'.$fetch_records->network_name.'"href="/smart-link-wm-single/'.$fetch_records->id_ad.'?start='.$dtvalue.'&end='.$dtvalue2.'&op_name='.$fetch_records->op_name.'&traffic_type='.$fetch_records->traffic_type.'">'.$fetch_records->network_name.'</a>',
                    $fetch_records->network_cpa,
                    $fetch_records->op_name,
                    $fetch_records->traffic_type,
                    '<span title="'.$fetch_records->adv_name.'('.$fetch_records->id_advertiser_campaign.')">'.$fetch_records->adv_name.'</span>',
//                    array_key_exists($fetch_records->country_code,$ddData['country_dropdown'])?$ddData['country_dropdown'][$fetch_records->country_code]:"",
                    $fetch_records->country_code,
                   
                    $fetch_records->clickcount,
                    $fetch_records->clickcount-$fetch_records->fraud,
                    $fetch_records->unique_conversion_count,                        
                    $fetch_records->clicks_active_count,
                        $var4,
                        $var5,
                    $fetch_records->conversion_count,
                    round($fetch_records->revenue_dollar,2)."/".round($fetch_records->revenue_dollar * 65, 2),
                    round($fetch_records->cost_dollar,2)."/".round($fetch_records->cost_dollar * 65, 2),                    
                    round(($fetch_records->revenue_dollar - $fetch_records->cost_dollar),2)."/". round(($fetch_records->revenue_dollar - $fetch_records->cost_dollar),2)*65,
                    '<input class="remark" myID="'.$fetch_records->id_ad.'" type="text" value="'.""/*$fetch_records->remark*/.'" id="example-text-input">');
                          
                array_push($data1, $array);
                    $clickcount += $fetch_records->clickcount;
                    $clickcount_fraud += $fetch_records->fraud;
                    $conversion_count += $fetch_records->conversion_count;
                    $clicks_active_count += $fetch_records->clicks_active_count;



                     $conversion_count_unique += $fetch_records->unique_conversion_count;

                    $sourcost +=  round($fetch_records->cost_dollar,2);
                    $revenue_dollarX +=  round($fetch_records->revenue_dollar,2);
                    $cc_revenueDller_ecpm +=  round($fetch_records->revenue_dollar/1000,2);
                    $convCount += $fetch_records->cpa * $fetch_records->conversion_count;
                    $profit += ($fetch_records->revenue_dollar - $fetch_records->cost_dollar);
                    
                
        }
        $lastRow =[$clickcount,$clickcount-$clickcount_fraud,$conversion_count,$clicks_active_count,$conversion_count_unique,$sourcost."/".round($sourcost*65,2),$revenue_dollarX."/".round($revenue_dollarX*65,2),$cc_revenueDller_ecpm."/".round($cc_revenueDller_ecpm*65,2),round($profit,2)."/".round($profit*65,2)];
       
         $result  = array('data1' => $data1,
            "routename"=>$routename,
            'header'=>$header,
            'dtvalue' => $dtvalue,
            'dtvalue2' => $dtvalue2,
            'ddData' => $ddData,
            'id_channel'=>$request->id_channel,
            'operator_id'=>$request->operator_id,
            'traffic_type' => $request->traffic_type,
            'country'=> $request->country,
            'total'=>$request->total,
            'lastRow'=>$lastRow
          );
         //dd($result);

        $viewPage = "smartlink.smrt_link_wm";             
        $dataN =  view($viewPage)->with($result);
            
        return $dataN;
            
    }
    public function smartLinkWMWifi_index(Request $request,$type="",$routename = "smartLinkWifiWM",$header="Smart Link WIFI WM")
    {

        $condtion = [];
            $ddCondition = [];
            $dtvalue = $request->start;
            $dtvalue2 = $request->end;
            
            
            if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                    $dtvalue2 = date('Y-m-d');
                    $enddate = date('Y-m-d',strtotime("+1 days"));
            }else{
               $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));
            }
            
            array_push($condtion,['crc_records_new.create_time','>=',$dtvalue] );
            array_push($condtion,['crc_records_new.create_time','<=',$enddate] );
            array_push($condtion,["ads.description","=","default"] );
            array_push($condtion,["crc_records_new.op_id","=","33"] );
            array_push($condtion,["ads.cco","=","33"] );
            
            array_push($ddCondition,['crc_network_campaign_new.create_time','>=',$dtvalue] );
            array_push($ddCondition,['crc_network_campaign_new.create_time','<=',$enddate] );
            array_push($ddCondition,['ads.description','=','default'] );
            array_push($ddCondition,["ads.cco","=","33"] );

            
            if($request->id_channel && $request->id_channel != 0){
                array_push($condtion,['ads.id_zone','=',$request->id_channel] );
            }

            if($request->operator_id){
                array_push($condtion,['ads.cco','=',$request->operator_id] );
            }
            if($request->traffic_type){
                array_push($condtion,['ads.traffic_type','=',$request->traffic_type] );
            }

            
            if($request->country && $request->country !== 0){
             
                array_push($condtion,['ads.country_code','=',$request->country] );

            }


            $request->total = $request->total ? $request->total:50;

          $ddData = $this->createDDWMWIFI($request,$type,$ddCondition);
          

          $select = 
              "crc_records_new.id,"
            ."crc_records_new.op_name,"
            ."crc_records_new.create_time as dte,"
            ."crc_records_new.id_ad,"
            ."advertiser_campaigns.cpa,"
            ."crc_records_new.parent_cca,"
            ."advertiser_campaigns.name as adv_name,"
            ."crc_records_new.id_advertiser_campaign as advrt_id,"
            ."ads.network_name,"
            ."crc_records_new.advertiser_name,"
            ."crc_records_new.id_advertiser_campaign,"                  
            ."crc_records_new.clickcount_fraud as fraud,"
            ."ads.traffic_type,"
            ."sum(crc_records_new.clickcount) as clickcount,"
            ."sum(crc_records_new.clicks_active_count) as clicks_active_count,"
            ."sum(crc_records_new.conversion_count) as conversion_count,"
            ."crc_records_new.network_cpa,"
            ."round(sum(crc_records_new.cost_dollar), 2) as cost_dollar,"
            ."crc_records_new.id_advertiser_campaign,"
            ."ads.country_code,"
            ."sum(crc_records_new.conversion_count_unique) as unique_conversion_count,"
            ."round(sum(crc_records_new.revenue_dollar), 2) as revenue_dollar";


                         $start = microtime(true);
        
         $data =  DB::table("crc_records_new")
                ->whereIn('ads.traffic_type', ['WM'])
                ->where($condtion) 
                ->selectRaw(DB::raw($select))
//                ->select($select)
                ->leftJoin("ads","ads.id_ad","=","crc_records_new.id_ad")
                ->leftJoin("advertiser_campaigns","advertiser_campaigns.id","=","ads.id_advertiser")                
                ->groupby("crc_records_new.id_ad")
                ->groupby("ads.cco")
                ->orderby("ads.country_code","ASC")
                ->orderby("ads.operator_name","ASC")
//                ->paginate($request->total)
                 ->get();


            $data1 = [];
            $clickcount = 0;
            $conversion_count = 0;
            $clicks_active_count = 0;
            $conversion_count_unique = 0;
            $sourcost = 0;
            $cc_revenueDller_ecpm=0;
            $convCount = 0;
            $revenue_dollarX = 0;
            $profit = 0;
            $clickcount_fraud=0;

    
        foreach ($data as $fetch_records) {
                    
            $val1=$fetch_records->conversion_count;
                $val2=$fetch_records->clickcount;
                $val3=($val1/$val2)*100;
                $var4 = number_format($val3, 2)."%";

                $val4=$fetch_records->clicks_active_count;
                    $val5=$fetch_records->clickcount;
                    $val6=($val4/$val5)*100;
                    $var5 = number_format($val6, 2)."%";

            $array = [];
                
        array_push($array,
            $fetch_records->id_ad,
            '<a title="'.$fetch_records->network_name.'"href="/smart-link-wifi-single/'.$fetch_records->id_ad.'?start='.$dtvalue.'&end='.$dtvalue2.'&op_name='.$fetch_records->op_name.'&traffic_type='.$fetch_records->traffic_type.'">'.$fetch_records->network_name.'</a>',
            $fetch_records->network_cpa,
            $fetch_records->op_name,
            $fetch_records->traffic_type,
            '<span title="'.$fetch_records->adv_name.'('.$fetch_records->id_advertiser_campaign.')">'.$fetch_records->adv_name.'</span>',
//                    array_key_exists($fetch_records->country_code,$ddData['country_dropdown'])?$ddData['country_dropdown'][$fetch_records->country_code]:"",
            $fetch_records->country_code,

            $fetch_records->clickcount,
            $fetch_records->clickcount-$fetch_records->fraud,
            $fetch_records->unique_conversion_count,                        
            $fetch_records->clicks_active_count,
                $var4,
                $var5,
            $fetch_records->conversion_count,
            round($fetch_records->revenue_dollar,2)."/".round($fetch_records->revenue_dollar * 65, 2),
            round($fetch_records->cost_dollar,2)."/".round($fetch_records->cost_dollar * 65, 2),                    
            round(($fetch_records->revenue_dollar - $fetch_records->cost_dollar),2)."/". round(($fetch_records->revenue_dollar - $fetch_records->cost_dollar),2)*65,
            '<input class="remark" myID="'.$fetch_records->id_ad.'" type="text" value="'.""/*$fetch_records->remark*/.'" id="example-text-input">');
                          
        array_push($data1, $array);
            $clickcount += $fetch_records->clickcount;
            $clickcount_fraud += $fetch_records->fraud;
            $conversion_count += $fetch_records->conversion_count;
            $clicks_active_count += $fetch_records->clicks_active_count;



             $conversion_count_unique += $fetch_records->unique_conversion_count;

            $sourcost +=  round($fetch_records->cost_dollar,2);
            $revenue_dollarX +=  round($fetch_records->revenue_dollar,2);
            $cc_revenueDller_ecpm +=  round($fetch_records->revenue_dollar/1000,2);
            $convCount += $fetch_records->cpa * $fetch_records->conversion_count;
            $profit += ($fetch_records->revenue_dollar - $fetch_records->cost_dollar);
                    
        }

        $lastRow =[$clickcount,$clickcount-$clickcount_fraud,$conversion_count,$clicks_active_count,$conversion_count_unique,$sourcost."/".round($sourcost*65,2),$revenue_dollarX."/".round($revenue_dollarX*65,2),$cc_revenueDller_ecpm."/".round($cc_revenueDller_ecpm*65,2),round($profit,2)."/".round($profit*65,2)];

         $result  = array('data1' => $data1,
            "routename"=>$routename,
            'header'=>$header,
            'dtvalue' => $dtvalue,
            'dtvalue2' => $dtvalue2,
            'ddData' => $ddData,
            'id_channel'=>$request->id_channel,
            'operator_id'=>$request->operator_id,
            'traffic_type' => $request->traffic_type,
            'country'=> $request->country,
            'total'=>$request->total,
            'lastRow'=>$lastRow
          );
         //dd($result);

               $viewPage = "smartlink.smrt_link_wifi_wm";
       // dd("aa");
         $dataN =  view($viewPage)->with($result);
           
        return $dataN;
            
    }
    public function index_single(Request $request, $id_ad,$type="CPA" ,$routename = "network-wise-record-filter",$header="CR Update")
    {

            $condtion = [];
            $dtvalue = $request->start;
            $dtvalue2 = $request->end;
            
            
            if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                    $dtvalue2 = date('Y-m-d');
                    $enddate = date('Y-m-d',strtotime("+1 days"));
            }else{
                //$dtvalue2 = date('Y-m-d',strtotime("+1 days"));
               $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));

            }
            array_push($condtion,['crc_records_new.create_time','>=',$dtvalue] );
            array_push($condtion,['crc_records_new.create_time','<=',$enddate] );
           

            if($type != "CPICPA"){
                
                array_push($condtion,['report_type','=',strtoupper($type)] );
            }


            if($id_ad && $id_ad!=0){
                array_push($condtion,['crc_records_new.parent_cca','=',$id_ad] );
            }
            if($request->id_advertiser_campaign){
                array_push($condtion,['crc_records_new.id_advertiser_campaign','=',$request->id_advertiser_campaign] );
               // dd($condtion);
            }
            
$select = ["advertiser_vw.advertiser_campaign_cpa",
            "advertiser_vw.id_advertiser_campaign as curcampid",
            "advertiser_vw.advertiser_campaign_name as name",
            "crc_records_new.network_name",
            "advertiser_vw.operator_name as op_name",
            "crc_records_new.id_advertiser_campaign",
            "crc_records_new.total_cost",
            "crc_records_new.id_ad",
            "crc_records_new.id_channel",
            "crc_records_new.clickcount",
            "crc_records_new.conversion_count",
            "crc_records_new.clicks_active_count",
            "crc_records_new.cr_goal AS cr_goal",
            "crc_records_new.cr_received AS cr_received",
            "crc_records_new.cr_given AS cr_given",
            "crc_records_new.create_time"]; 

     $data =  DB::table("crc_records_new")
                ->where($condtion) 
                ->select($select)
                ->leftJoin("advertiser_vw","advertiser_vw.id_advertiser_campaign","=","crc_records_new.id_advertiser_campaign")
                ->orderby("crc_records_new.id_ad","ASC")->get();

         $result  = array('data' => $data,
            "routename"=>$routename,
            'header'=>$header,
            'dtvalue' => $dtvalue,
            'id'=>$id_ad,
            'dtvalue2' => $dtvalue2
          );

        
         return view('network.network_cr_update_single')->with($result);

     }

     private function createDD(Request $request,$type,$condition){

        $select = ["crc_records_new.parent_cca as id_ad"
                    ,"ads.network_name"
                    ,"country.name as cntry"
                    ,"crc_records_new.conversion_count_unique as unique_conversion_count"
                    ,"ads.id_zone"
                    ,"ads.traffic_type"
                    ,"ads.country_code"
                    ,"ads.cco"
                    ,"ads.operator_name"
                    ,"crc_records_new.total_cost"
                    ,"crc_records_new.op_name"
                    ,"crc_records_new.clickcount"
                    ,"crc_records_new.conversion_count"
                    ,"ads.network_cpa"
                    ,"crc_records_new.clicks_active_count"
                    ,"ads.cr_goal as cr_goal"
                    ,"cr_received"
                    ,"cr_given"
                    ,"crc_records_new.create_time"];

          $data =  DB::table("ads")
          ->where($condition) 
         ->select($select)
         ->rightJoin("crc_records_new","crc_records_new.parent_cca","=","ads.id_ad")
         ->leftJoin("country","ads.country_code","=","country.iso")
         ->orderby("network_name","ASC")
         ->orderby("operator_name","ASC")->get();
        
        
         $ddDataResult  = array(
                'network_dropdown' => [],
                'country_dropdown' => [],
                'operator_dropdown' => [],
                'idad_dropdown' => [],
                'traffictype_dropdown' => []
            );
         foreach ($data as $dropdown) {

            if ($dropdown->id_zone){
                $ddDataResult['network_dropdown'][$dropdown->id_zone] = $dropdown->network_name;
            }
            if ($dropdown->country_code){
                 $ddDataResult['country_dropdown'][$dropdown->country_code] = $dropdown->country_code."(".$dropdown->cntry.")";
             }
            if ($dropdown->cco && $dropdown->operator_name){
                  $ddDataResult['operator_dropdown'][$dropdown->cco] = $dropdown->operator_name."(".$dropdown->country_code.")";
            }
            if ($dropdown->id_ad){
                   $ddDataResult['idad_dropdown'][$dropdown->id_ad] = $dropdown->id_ad;
            }
            if($dropdown->traffic_type){
               $ddDataResult['traffictype_dropdown'][$dropdown->traffic_type] = $dropdown->traffic_type;
            }
          }
          
        return $ddDataResult;
     }
     private function createDDWG(Request $request,$type,$condition){

        $select = ["crc_network_campaign_new.parent_cca as id_ad"
                    ,"ads.network_name"
                    ,"ads.id_zone"
                    ,"ads.traffic_type"
                    ,"ads.country_code"
                    ,"ads.cco"
                    ,"ads.operator_name"
                    ,"crc_network_campaign_new.create_time"];

          $data =  DB::table("ads")
         ->whereIn('ads.traffic_type', ['WG'])
         ->whereNotIn('ads.cco', ['-1','33'])
         ->where($condition) 
         ->select($select)
         ->rightJoin("crc_network_campaign_new","crc_network_campaign_new.parent_cca","=","ads.id_ad")
         ->orderby("network_name","ASC")
         ->orderby("country_code","ASC")
         ->orderby("operator_name","ASC")->get();
        
        
         $ddDataResult  = array(
                'network_dropdown' => [],
                'country_dropdown' => [],
                'operator_dropdown' => [],
                'idad_dropdown' => [],
                'traffictype_dropdown' => []
            );
         foreach ($data as $dropdown) {

            if ($dropdown->id_zone){
                $ddDataResult['network_dropdown'][$dropdown->id_zone] = $dropdown->network_name;
            }
            if ($dropdown->country_code){
                 $ddDataResult['country_dropdown'][$dropdown->country_code] = $dropdown->country_code;
             }
            if ($dropdown->cco && $dropdown->operator_name){
//                  $ddDataResult['operator_dropdown'][$dropdown->cco] = $dropdown->operator_name."(".$dropdown->country_code.")";
                  $ddDataResult['operator_dropdown'][$dropdown->cco] = $dropdown->operator_name;
            }
            if ($dropdown->id_ad){
                   $ddDataResult['idad_dropdown'][$dropdown->id_ad] = $dropdown->id_ad;
            }
            if($dropdown->traffic_type){
               $ddDataResult['traffictype_dropdown'][$dropdown->traffic_type] = $dropdown->traffic_type;
            }
          }
          
        return $ddDataResult;
     }
     private function createDDWGWIFI(Request $request,$type,$condition){

        $select = ["crc_network_campaign_new.parent_cca as id_ad"
                    ,"ads.network_name"
                    ,"ads.id_zone"
                    ,"ads.traffic_type"
                    ,"ads.country_code"
                    ,"ads.cco"
                    ,"ads.operator_name"
                    ,"crc_network_campaign_new.create_time"];

          $data =  DB::table("ads")
         ->whereIn('ads.traffic_type', ['WG'])
         ->where($condition) 
         ->select($select)
         ->rightJoin("crc_network_campaign_new","crc_network_campaign_new.parent_cca","=","ads.id_ad")
         ->orderby("country_code","ASC")
                  ->get();
        
        
         $ddDataResult  = array(
                'network_dropdown' => [],
                'country_dropdown' => [],
                'operator_dropdown' => [],
                'idad_dropdown' => [],
                'traffictype_dropdown' => []
            );
         foreach ($data as $dropdown) {

            if ($dropdown->id_zone){
                $ddDataResult['network_dropdown'][$dropdown->id_zone] = $dropdown->network_name;
            }
            if ($dropdown->country_code){
                 $ddDataResult['country_dropdown'][$dropdown->country_code] = $dropdown->country_code;
             }
            if ($dropdown->cco && $dropdown->operator_name){
//                  $ddDataResult['operator_dropdown'][$dropdown->cco] = $dropdown->operator_name."(".$dropdown->country_code.")";
                  $ddDataResult['operator_dropdown'][$dropdown->cco] = $dropdown->operator_name;
            }
            if ($dropdown->id_ad){
                   $ddDataResult['idad_dropdown'][$dropdown->id_ad] = $dropdown->id_ad;
            }
            if($dropdown->traffic_type){
               $ddDataResult['traffictype_dropdown'][$dropdown->traffic_type] = $dropdown->traffic_type;
            }
          }
          
        return $ddDataResult;
     }

     private function createDDWM(Request $request,$type,$condition){

        $select = ["crc_network_campaign_new.parent_cca as id_ad"
                    ,"ads.network_name"
                    ,"ads.id_zone"
                    ,"ads.traffic_type"
                    ,"ads.country_code"
                    ,"ads.cco"
                    ,"ads.operator_name"
                    ,"crc_network_campaign_new.create_time"];

          $data =  DB::table("ads")
         ->whereIn('ads.traffic_type', ['WM'])
         ->whereNotIn('ads.cco', ['-1','33'])
         ->where($condition) 
         ->select($select)
         ->rightJoin("crc_network_campaign_new","crc_network_campaign_new.parent_cca","=","ads.id_ad")
         ->orderby("network_name","ASC")
         ->orderby("country_code","ASC")
         ->orderby("operator_name","ASC")->get();
        
        
         $ddDataResult  = array(
                'network_dropdown' => [],
                'country_dropdown' => [],
                'operator_dropdown' => [],
                'idad_dropdown' => [],
                'traffictype_dropdown' => []
            );
         foreach ($data as $dropdown) {

            if ($dropdown->id_zone){
                $ddDataResult['network_dropdown'][$dropdown->id_zone] = $dropdown->network_name;
            }
            if ($dropdown->country_code){
                 $ddDataResult['country_dropdown'][$dropdown->country_code] = $dropdown->country_code;
             }
            if ($dropdown->cco && $dropdown->operator_name){
//                  $ddDataResult['operator_dropdown'][$dropdown->cco] = $dropdown->operator_name."(".$dropdown->country_code.")";
                  $ddDataResult['operator_dropdown'][$dropdown->cco] = $dropdown->operator_name;
            }
            if ($dropdown->id_ad){
                   $ddDataResult['idad_dropdown'][$dropdown->id_ad] = $dropdown->id_ad;
            }
            if($dropdown->traffic_type){
               $ddDataResult['traffictype_dropdown'][$dropdown->traffic_type] = $dropdown->traffic_type;
            }
          }
          
        return $ddDataResult;
     }
     private function createDDWMWIFI(Request $request,$type,$condition){

        $select = ["crc_network_campaign_new.parent_cca as id_ad"
                    ,"ads.network_name"
                    ,"ads.id_zone"
                    ,"ads.traffic_type"
                    ,"ads.country_code"
                    ,"ads.cco"
                    ,"ads.operator_name"
                    ,"crc_network_campaign_new.create_time"];

          $data =  DB::table("ads")
         ->whereIn('ads.traffic_type', ['WM'])
         ->where($condition) 
         ->select($select)
         ->rightJoin("crc_network_campaign_new","crc_network_campaign_new.parent_cca","=","ads.id_ad")
         ->orderby("country_code","ASC")
                  ->get();
        
        
         $ddDataResult  = array(
                'network_dropdown' => [],
                'country_dropdown' => [],
                'operator_dropdown' => [],
                'idad_dropdown' => [],
                'traffictype_dropdown' => []
            );
         foreach ($data as $dropdown) {

            if ($dropdown->id_zone){
                $ddDataResult['network_dropdown'][$dropdown->id_zone] = $dropdown->network_name;
            }
            if ($dropdown->country_code){
                 $ddDataResult['country_dropdown'][$dropdown->country_code] = $dropdown->country_code;
             }
            if ($dropdown->cco && $dropdown->operator_name){
                  $ddDataResult['operator_dropdown'][$dropdown->cco] = $dropdown->operator_name;
//                  $ddDataResult['operator_dropdown'][$dropdown->cco] = $dropdown->operator_name."(".$dropdown->country_code.")";
            }
            if ($dropdown->id_ad){
                   $ddDataResult['idad_dropdown'][$dropdown->id_ad] = $dropdown->id_ad;
            }
            if($dropdown->traffic_type){
               $ddDataResult['traffictype_dropdown'][$dropdown->traffic_type] = $dropdown->traffic_type;
            }
          }
          
        return $ddDataResult;
     }
     
    public function smartLinkWG_single(Request $request,$id_ad,$type="",$routename = "smartLinkWGSingleFilter",$header="Smart Link WG - Detail")
    {
        
       $condtion = [];
            $dtvalue = $request->start;
            $dtvalue2 = $request->end;
            
            $op_name=$request->op_name;
            $traffic_type=$request->traffic_type;
            
            $data1 = [];
            $clickcount = $conversion_count = $clicks_active_count = $sourcost = $revenue_total = $profit_total = $conversion_count_unique =0;

            $totalClick=0;
            $totalconversion=0;
            $clicks_active_count=0;
  
            if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                    $dtvalue2 = date('Y-m-d');
                    $enddate = date('Y-m-d',strtotime("+1 days"));
            }else{
               $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));

            }
            array_push($condtion,['crc_records_new.create_time','>=',$dtvalue] );
            array_push($condtion,['crc_records_new.create_time','<=',$enddate] );
            array_push($condtion,['ads.description','=','default'] );
            array_push($condtion,['crc_records_new.op_name','=',$op_name]);
            array_push($condtion,['crc_records_new.id_ad','=',$id_ad]);
            
            $select = "crc_records_new.id,"
			."crc_records_new.op_name,"
                        ."crc_records_new.id_advertiser_campaign,"
                        ."crc_records_new.total_cost,"
                        ."crc_records_new.id_ad,"
			."crc_records_new.network_name,"
			."crc_records_new.advertiser_name,"
			."crc_records_new.parent_cca,"
                        ."crc_records_new.id_channel,"
			."crc_records_new.traffic_type,"
                        ."sum(crc_records_new.clickcount) as clickcount,"
                        ."sum(crc_records_new.conversion_count) as conversion_count,"
                        ."sum(crc_records_new.clicks_active_count) as clicks_active_count,"
			."sum(crc_records_new.conversion_count_unique) as conversion_count_unique,"
			."round(sum(crc_records_new.cost_dollar), 2) as cost_dollar,"
                        ."crc_records_new.cr_goal AS cr_goal,"
                        ."crc_records_new.cr_received AS cr_received,"
                        ."crc_records_new.cr_given AS cr_given,"
                        ."round(sum(crc_records_new.revenue_dollar), 2) as revenue_dollar,"
                        ."crc_records_new.create_time,"
			."advertiser_campaigns.name,"
			."ads.country_code"; 

                $data =  DB::table("crc_records_new")
                ->whereIn('ads.traffic_type', ['WG'])
                ->whereNotIn('ads.cco', ['-1','33'])
                ->where($condtion) 
//                ->select($select)
                ->selectRaw(DB::raw($select))
                ->leftJoin("ads","ads.id_ad","=","crc_records_new.id_ad")
                ->leftJoin("advertiser_campaigns","crc_records_new.id_advertiser_campaign","=","advertiser_campaigns.id")
                ->groupby("advertiser_campaigns.id")
                ->orderby("advertiser_campaigns.id","ASC")->get();

                foreach ($data as $fetch_records){
                    $cr_in = $cr_out = 0;
                    if($fetch_records->conversion_count != 0 && $val2=$fetch_records->clickcount != 0)
                    {
                        $val1=$fetch_records->conversion_count; 
                        $val2=$fetch_records->clickcount;
                        $val3=($val1/$val2)*100;
                        $cr_in =  round($val3, 2)."%";

                        $val4=$fetch_records->clicks_active_count;
                        $val5=$fetch_records->clickcount;
                        $val6=($val4/$val5)*100;
                        $cr_out = round($val6, 2)."%";
                    }

                    $click_sum = 0;                
                    $array = [];                
                    array_push($array,
                        $fetch_records->id_ad,
                         '<span title="'.$fetch_records->name.'('.$fetch_records->id_advertiser_campaign.')"><a href="/smart-link-single-parent/'.$fetch_records->id_ad.'?adv='.$fetch_records->id_advertiser_campaign.'&start='.$dtvalue.'&end='.$dtvalue2.'">'.$fetch_records->name.'</a></span>',
                          $click_sum += $fetch_records->clickcount,
                          $fetch_records->conversion_count,
                          $fetch_records->clicks_active_count,
                          $cr_in,
                          $cr_out,                            
                          $fetch_records->conversion_count_unique,
                          $fetch_records->cost_dollar.'/'.round($fetch_records->cost_dollar * 65, 2),
                          $profit = number_format($fetch_records->revenue_dollar, 2).'/'. round($fetch_records->revenue_dollar * 65, 2)
                          );
                          array_push($data1, $array);
                        $clickcount += $fetch_records->clickcount;
                        $conversion_count += $fetch_records->conversion_count;
                        $clicks_active_count += $fetch_records->clicks_active_count;
                        $conversion_count_unique += $fetch_records->conversion_count_unique;
                        $revenue_total += $fetch_records->revenue_dollar;
                        $sourcost += $fetch_records->cost_dollar;
                }
                  $revenue_total = round($revenue_total, 2)."/".round($revenue_total * 65, 2);
                  $sourcost = round($sourcost, 2)."/".round($sourcost * 65, 2);
                $lastRow =[$clickcount,$conversion_count,$clicks_active_count,$conversion_count_unique,$revenue_total,$sourcost];

        $result  = array('data1' => $data1,
            "routename"=>$routename,
            'header'=>$header,
            'dtvalue' => $dtvalue,
            'id'=>$id_ad,
            'dtvalue2' => $dtvalue2,
            'lastRow' => $lastRow,
             'opr_name'=>$op_name,
             'traffic_type'=>$traffic_type
        );
            $viewPage = "smartlink.smrt_link_wg_detail";
       // dd("aa");
         $dataN =  view($viewPage)->with($result);            
        return $dataN;
            
    }
    
    public function smartLinkWG_single_parent(Request $request,$id_ad,$type="",$routename = "smartLinkSingleFilterParent",$header="Smart Link - Details Parent")
    {

       $condtion = [];
            $dtvalue = $request->start;
            $dtvalue2 = $request->end;
            $adv=$request->adv;

            $data1 = [];
            $clickcount = $conversion_count = $clicks_active_count = $sourcost = $revenue_total = $profit_total = $conversion_count_unique = 0;
            
            $totalClick=0;
            $totalconversion=0;
            $clicks_active_count=0;
  
            if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                    $dtvalue2 = date('Y-m-d');
                    $enddate = date('Y-m-d',strtotime("+1 days"));
            }else{
               $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));

            }
                array_push($condtion,['crc_records_new.create_time','>=',$dtvalue] );
                array_push($condtion,['crc_records_new.create_time','<=',$enddate] );
                array_push($condtion,['crc_records_new.report_type','=','CPA'] );
                array_push($condtion,['crc_records_new.id_advertiser_campaign','=',$adv]);
                array_push($condtion,['crc_records_new.id_ad','=',$id_ad]);
                
                $select = "crc_records_new.id_channel,"
			."crc_records_new.network_name,"			
			."advertiser_vw.advertiser_campaign_cpa,"
			."advertiser_vw.advertiser_campaign_name as name,"
                        ."crc_records_new.id_advertiser_campaign,"
			."crc_records_new.parent_cca,"
                        ."crc_records_new.id_ad,"
			."sum(crc_records_new.total_cost) as total_cost,"                        
                        ."sum(crc_records_new.clickcount) as clickcount,"
                        ."sum(crc_records_new.conversion_count) as conversion_count,"
                        ."sum(crc_records_new.clicks_active_count) as clicks_active_count,"
			."sum(crc_records_new.conversion_count_unique) as conversion_count_unique,"			
                        ."CONCAT(AVG(crc_records_new.cr_goal),'%') AS cr_goal,"
                        ."CONCAT(AVG(crc_records_new.cr_received),'%') AS cr_received,"
                        ."CONCAT(AVG(crc_records_new.cr_given),'%') AS cr_given,"
                        ."crc_records_new.create_time"; 


                $data =  DB::table("crc_records_new")
                ->where($condtion) 
//                ->select($select)
                ->selectRaw(DB::raw($select))
                ->leftJoin("advertiser_vw","crc_records_new.id_advertiser_campaign","=","advertiser_vw.id_advertiser_campaign")

                ->groupby("crc_records_new.parent_cca")
                ->orderby("crc_records_new.id_channel","ASC")->get();
//                 dd($data);
                foreach ($data as $fetch_records){

                    $click_sum = 0;                
                    $array = [];
                    
                    array_push($array,
                        $fetch_records->id_ad,
                        $fetch_records->parent_cca,
        //                           '<a href="/network-cr-update-single-chanel?id_channel='.$fetch_records->id_channel.'&start='.$dtvalue.'&end='.$dtvalue2.'">'.$fetch_records->id_channel.'</a>',
                          '<span title="'.$fetch_records->name.'</span>',
                          $fetch_records->network_name,
                          $click_sum += $fetch_records->clickcount,
                          $fetch_records->conversion_count,
                          $fetch_records->clicks_active_count,
                          $fetch_records->cr_received,
                          $fetch_records->cr_given,                            
                          $fetch_records->cr_goal,
                          $fetch_records->total_cost,
                          $profit = $fetch_records->advertiser_campaign_cpa * $fetch_records->conversion_count

                          );
                          array_push($data1, $array);
                    $clickcount += $fetch_records->clickcount;
                    $conversion_count += $fetch_records->conversion_count;
                    $conversion_count_unique += $fetch_records->conversion_count_unique;
                    $profit_total += $profit;
                  }
                $lastRow =[$clickcount,$conversion_count,$conversion_count_unique,$profit_total];


         $result  = array('data1' => $data1,
            "routename"=>$routename,
            'header'=>$header,
            'dtvalue' => $dtvalue,
            'id'=>$id_ad,
            'dtvalue2' => $dtvalue2,
            'lastRow' => $lastRow,
             'adv'=>$adv
          );
               $viewPage = "smartlink.smrt_link_wg_detail_parent";
        $dataN =  view($viewPage)->with($result);
        return $dataN;
            
    }
    
    public function smartLinkWM_single(Request $request,$id_ad,$type="",$routename = "smartLinkWMSingleFilter",$header="Smart Link WM - Detail")
    {
            
       $condtion = [];
            $dtvalue = $request->start;
            $dtvalue2 = $request->end;
            
            $op_name=$request->op_name;
            $traffic_type=$request->traffic_type;
            
            $data1 = [];
            $clickcount = $conversion_count = $clicks_active_count = $sourcost = $revenue_total = $profit_total = $conversion_count_unique =0;
            
            $totalClick=0;
            $totalconversion=0;
            $clicks_active_count=0;
  
            if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                    $dtvalue2 = date('Y-m-d');
                    $enddate = date('Y-m-d',strtotime("+1 days"));
            }else{
               $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));

            }
            array_push($condtion,['crc_records_new.create_time','>=',$dtvalue] );
            array_push($condtion,['crc_records_new.create_time','<=',$enddate] );
            array_push($condtion,['ads.description','=','default'] );
            array_push($condtion,['crc_records_new.op_name','=',$op_name]);
            array_push($condtion,['crc_records_new.id_ad','=',$id_ad]);
            
            $select = 
              "crc_records_new.id,"
            ."crc_records_new.op_name,"
            ."crc_records_new.create_time as dte,"
            ."crc_records_new.id_ad,"
            ."advertiser_campaigns.cpa,"
            ."crc_records_new.parent_cca,"
            ."advertiser_campaigns.name as adv_name,"
            ."crc_records_new.id_advertiser_campaign as advrt_id,"
            ."ads.network_name,"
            ."crc_records_new.advertiser_name,"
            ."crc_records_new.id_advertiser_campaign,"
            ."crc_records_new.clickcount_fraud as fraud," 
            ."ads.traffic_type,"
            ."sum(crc_records_new.clickcount) as clickcount,"
            ."sum(crc_records_new.clicks_active_count) as clicks_active_count,"
            ."sum(crc_records_new.conversion_count) as conversion_count,"
            ."crc_records_new.network_cpa,"
            ."round(sum(crc_records_new.cost_dollar), 2) as cost_dollar,"
            ."crc_records_new.id_advertiser_campaign,"
            ."ads.country_code,"
            ."sum(crc_records_new.conversion_count_unique) as unique_conversion_count,"
            ."round(sum(crc_records_new.revenue_dollar), 2) as revenue_dollar";

         $data =  DB::table("crc_records_new")
                ->whereIn('ads.traffic_type', ['WM'])
                ->whereNotIn('ads.cco', ['-1','33'])
                ->where($condtion) 
                ->selectRaw(DB::raw($select))
//                ->select($select)
                ->leftJoin("ads","ads.id_ad","=","crc_records_new.id_ad")
                ->leftJoin("advertiser_campaigns","advertiser_campaigns.id","=","ads.id_advertiser")                
                ->groupby("crc_records_new.id_advertiser_campaign")
                ->groupby("crc_records_new.parent_cca")
                ->groupby("ads.id_ad")
                ->orderby("crc_records_new.id_ad","ASC")
                ->orderby("crc_records_new.parent_cca","ASC")
//                 ->limit(10)
//                ->paginate($request->total)
                 ->get();

                foreach ($data as $fetch_records){
                    $cr_in = $cr_out = 0;
                    if($fetch_records->conversion_count != 0 && $val2=$fetch_records->clickcount != 0)
                    {
                        $val1=$fetch_records->conversion_count; 
                        $val2=$fetch_records->clickcount;
                        $val3=($val1/$val2)*100;
                        $cr_in =  round($val3, 2)."%";

                        $val4=$fetch_records->clicks_active_count;
                        $val5=$fetch_records->clickcount;
                        $val6=($val4/$val5)*100;
                        $cr_out = round($val6, 2)."%";
                    }
                    $click_sum = 0;                
                    $array = [];                
                    array_push($array,
                        $fetch_records->id_ad,
                         '<span title="'.$fetch_records->adv_name.'('.$fetch_records->id_advertiser_campaign.')"><a href="/smart-link-single-parent/'.$fetch_records->id_ad.'?adv='.$fetch_records->id_advertiser_campaign.'&start='.$dtvalue.'&end='.$dtvalue2.'">'.$fetch_records->adv_name.'</a></span>',
    //                            '<span title="'.$fetch_records->adv_name.'('.$fetch_records->id_advertiser_campaign.')">'.$fetch_records->adv_name.'</span>',
                          $click_sum += $fetch_records->clickcount,
                          $fetch_records->conversion_count,
                          $fetch_records->clicks_active_count,
                          $cr_in,
                          $cr_out,                            
                          $fetch_records->unique_conversion_count,
                          $fetch_records->cost_dollar.'/'.round($fetch_records->cost_dollar * 65, 2),
                          $profit = number_format($fetch_records->revenue_dollar, 2).'/'. round($fetch_records->revenue_dollar * 65, 2)
                          );
                    array_push($data1, $array);
                    $clickcount += $fetch_records->clickcount;
                    $conversion_count += $fetch_records->conversion_count;
                    $clicks_active_count += $fetch_records->clicks_active_count;
                    $conversion_count_unique += $fetch_records->unique_conversion_count;
                    $revenue_total += $fetch_records->revenue_dollar;
                    $sourcost += $fetch_records->cost_dollar;
                  }
                $revenue_total = round($revenue_total, 2)."/".round($revenue_total * 65, 2);
                $sourcost = round($sourcost, 2)."/".round($sourcost * 65, 2);
                $lastRow =[$clickcount,$conversion_count,$clicks_active_count,$conversion_count_unique,$revenue_total,$sourcost];
         $result  = array('data1' => $data1,
            "routename"=>$routename,
            'header'=>$header,
            'dtvalue' => $dtvalue,
            'id'=>$id_ad,
            'dtvalue2' => $dtvalue2,
            'lastRow' => $lastRow,
             'opr_name'=>$op_name,
             'traffic_type'=>$traffic_type
            
          );
            $viewPage = "smartlink.smrt_link_wm_detail";     
        $dataN =  view($viewPage)->with($result);
            
        return $dataN;
            
    }
    
    public function smartLinkWGWIFI_single(Request $request,$id_ad,$type="",$routename = "smartLinkWGSingleFilter",$header="Smart Link WG - Detail")
    {

        $condtion = [];
            $dtvalue = $request->start;
            $dtvalue2 = $request->end;
            
            $op_name=$request->op_name;
            $traffic_type=$request->traffic_type;
            
            
            
            
            $data1 = [];

            $clickcount = $conversion_count = $clicks_active_count = $sourcost = $revenue_total = $profit_total = $conversion_count_unique =0;
            
            
            $totalClick=0;
            $totalconversion=0;
            $clicks_active_count=0;
  
            if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                    $dtvalue2 = date('Y-m-d');
                    $enddate = date('Y-m-d',strtotime("+1 days"));
            }else{
               $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));

            }
            array_push($condtion,['crc_records_new.create_time','>=',$dtvalue] );
            array_push($condtion,['crc_records_new.create_time','<=',$enddate] );
            array_push($condtion,["ads.description","=","default"] );
            array_push($condtion,["crc_records_new.op_id","=","33"] );
            array_push($condtion,["ads.cco","=","33"] );
            array_push($condtion,["crc_records_new.op_name","=",$op_name] );
            
            $select = "crc_records_new.id,"
                    ."crc_records_new.op_name,"
                    ."crc_records_new.create_time as dte,"
                    ."crc_records_new.id_ad,"
                    ."advertiser_campaigns.cpa,"
                    ."crc_records_new.parent_cca,"
                    ."advertiser_campaigns.name as adv_name,"
                    ."crc_records_new.id_advertiser_campaign as advrt_id,"
                    ."crc_records_new.network_name,"
                    ."crc_records_new.advertiser_name,"
                    ."crc_records_new.id_advertiser_campaign,"
                    ."crc_records_new.clickcount_fraud as fraud,"
                    ."ads.traffic_type,"
                    ."sum(crc_records_new.clickcount) as clickcount,"
                    ."sum(crc_records_new.clicks_active_count) as clicks_active_count,"
                    ."sum(crc_records_new.conversion_count) as conversion_count,"
                    ."crc_records_new.network_cpa,"
                    ."round(sum(crc_records_new.cost_dollar), 2) as cost_dollar,"
                    ."crc_records_new.id_advertiser_campaign,"
                    ."ads.country_code,"
                    ."sum(crc_records_new.conversion_count_unique) as unique_conversion_count,"
                    ."round(sum(crc_records_new.revenue_dollar), 2) as revenue_dollar"; 

                $data =  DB::table("crc_records_new")
                ->whereIn('ads.traffic_type', ['WG'])
                ->where($condtion) 
                ->selectRaw(DB::raw($select))
//                ->select($select)
                ->leftJoin("ads","ads.id_ad","=","crc_records_new.id_ad")
                ->leftJoin("advertiser_campaigns","advertiser_campaigns.id","=","ads.id_advertiser")                
                ->groupby("crc_records_new.parent_cca")
                ->orderby("crc_records_new.parent_cca","ASC")
//                ->paginate($request->total)
                 ->get();

                foreach ($data as $fetch_records){
                        $cr_in = $cr_out = 0;
                    if($fetch_records->conversion_count != 0 && $val2=$fetch_records->clickcount != 0)
                    {
                        $val1=$fetch_records->conversion_count; 
                        $val2=$fetch_records->clickcount;
                        $val3=($val1/$val2)*100;
                        $cr_in =  round($val3, 2)."%";

                        $val4=$fetch_records->clicks_active_count;
                        $val5=$fetch_records->clickcount;
                        $val6=($val4/$val5)*100;
                        $cr_out = round($val6, 2)."%";
                    }

                    $click_sum = 0;                
                    $array = [];                
                    array_push($array,
                        $fetch_records->id_ad,
                        '<span title="'.$fetch_records->adv_name.'('.$fetch_records->id_advertiser_campaign.')"><a href="/smart-link-single-parent/'.$id_ad.'?adv='.$fetch_records->id_advertiser_campaign.'&start='.$dtvalue.'&end='.$dtvalue2.'">'.$fetch_records->adv_name.'</a></span>',
//                        <span title="'.$fetch_records->name.'('.$fetch_records->id_advertiser_campaign.')">'.$fetch_records->name.'</span>',
                       $click_sum += $fetch_records->clickcount,
                       $fetch_records->conversion_count,
                       $fetch_records->clicks_active_count,
                       $cr_in,
                       $cr_out,                            
                       $fetch_records->unique_conversion_count,
                       $fetch_records->cost_dollar.'/'.round($fetch_records->cost_dollar * 65, 2),
                       $profit = number_format($fetch_records->revenue_dollar, 2).'/'. round($fetch_records->revenue_dollar * 65, 2)
                       );
                            array_push($data1, $array);
                    $clickcount += $fetch_records->clickcount;
                    $conversion_count += $fetch_records->conversion_count;
                    $clicks_active_count += $fetch_records->clicks_active_count;
                    $conversion_count_unique += $fetch_records->unique_conversion_count;
                    $revenue_total += $fetch_records->revenue_dollar;
                    $sourcost += $fetch_records->cost_dollar;
                  }
                  $revenue_total = round($revenue_total, 2)."/".round($revenue_total * 65, 2);
                  $sourcost = round($sourcost, 2)."/".round($sourcost * 65, 2);
                $lastRow =[$clickcount,$conversion_count,$clicks_active_count,$conversion_count_unique,$revenue_total,$sourcost];
         $result  = array('data1' => $data1,
            "routename"=>$routename,
            'header'=>$header,
            'dtvalue' => $dtvalue,
            'id'=>$id_ad,
            'dtvalue2' => $dtvalue2,
            'lastRow' => $lastRow,
             'opr_name'=>$op_name,
             'traffic_type'=>$traffic_type
            );
        

               $viewPage = "smartlink.smrt_link_wg_wifi_detail";
        
        $dataN =  view($viewPage)->with($result);
           
        return $dataN;
            
    }
    public function smartLinkWMWIFI_single(Request $request,$id_ad,$type="",$routename = "smartLinkWMSingleFilter",$header="Smart Link WM - Detail")
    {
        
        $condtion = [];
            $dtvalue = $request->start;
            $dtvalue2 = $request->end;            
            $op_name=$request->op_name;
            $traffic_type=$request->traffic_type;
            
            $data1 = [];
            $clickcount = $conversion_count = $clicks_active_count = $sourcost = $revenue_total = $profit_total = $conversion_count_unique =0;
            
            $totalClick=0;
            $totalconversion=0;
            $clicks_active_count=0;
  
            if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                    $dtvalue2 = date('Y-m-d');
                    $enddate = date('Y-m-d',strtotime("+1 days"));
            }else{
               $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));

            }                
            array_push($condtion,['crc_records_new.create_time','>=',$dtvalue] );
            array_push($condtion,['crc_records_new.create_time','<=',$enddate] );
            array_push($condtion,['ads.description','=','default'] );
            array_push($condtion,['crc_records_new.op_name','=',$op_name]);
            array_push($condtion,['crc_records_new.id_ad','=',$id_ad]);
            
            $select = "crc_records_new.id,"
            ."crc_records_new.op_name,"
            ."crc_records_new.create_time as dte,"
            ."crc_records_new.id_ad,"
		."crc_records_new.parent_cca,"
            ."advertiser_campaigns.cpa,"
            ."crc_records_new.parent_cca,"
            ."advertiser_campaigns.name as adv_name,"
            ."crc_records_new.id_advertiser_campaign as advrt_id,"
            ."crc_records_new.network_name,"
            ."crc_records_new.advertiser_name,"
            ."crc_records_new.id_advertiser_campaign,"                  
            ."crc_records_new.clickcount_fraud as fraud,"
            ."crc_records_new.traffic_type,"
            ."sum(crc_records_new.clickcount) as clickcount,"
            ."sum(crc_records_new.clicks_active_count) as clicks_active_count,"
            ."sum(crc_records_new.conversion_count) as conversion_count,"
            ."crc_records_new.network_cpa,"
            ."round(sum(crc_records_new.cost_dollar), 2) as cost_dollar,"
            ."crc_records_new.id_advertiser_campaign,"
            ."ads.country_code,"
            ."sum(crc_records_new.conversion_count_unique) as unique_conversion_count,"
            ."round(sum(crc_records_new.revenue_dollar), 2) as revenue_dollar";

         $data =  DB::table("crc_records_new")
                ->whereIn('ads.traffic_type', ['WM'])
                ->where($condtion) 
                ->selectRaw(DB::raw($select))
//                ->select($select)
                ->leftJoin("ads","ads.id_ad","=","crc_records_new.id_ad")
                ->leftJoin("advertiser_campaigns","advertiser_campaigns.id","=","ads.id_advertiser")                
                ->groupby("advertiser_campaigns.id")
                ->groupby("ads.cco")
                ->orderby("advertiser_campaigns.id","ASC")
                ->orderby("ads.operator_name","ASC")
//                 ->limit(10)
//                ->paginate($request->total)
                 ->get();

                foreach ($data as $fetch_records){
                    $cr_in = $cr_out = 0;
                    if($fetch_records->conversion_count != 0 && $val2=$fetch_records->clickcount != 0)
                    {
                        $val1=$fetch_records->conversion_count; 
                        $val2=$fetch_records->clickcount;
                        $val3=($val1/$val2)*100;
                        $cr_in =  round($val3, 2)."%";

                        $val4=$fetch_records->clicks_active_count;
                        $val5=$fetch_records->clickcount;
                        $val6=($val4/$val5)*100;
                        $cr_out = round($val6, 2)."%";
                    }
                    $click_sum = 0;                
                    $array = [];                
                    array_push($array,
                        $fetch_records->id_ad,
                         '<span title="'.$fetch_records->adv_name.'('.$fetch_records->id_advertiser_campaign.')"><a href="/smart-link-single-parent/'.$fetch_records->id_ad.'?adv='.$fetch_records->id_advertiser_campaign.'&start='.$dtvalue.'&end='.$dtvalue2.'">'.$fetch_records->adv_name.'</a></span>',
        //                            '<span title="'.$fetch_records->adv_name.'('.$fetch_records->id_advertiser_campaign.')">'.$fetch_records->adv_name.'</span>',
                          $click_sum += $fetch_records->clickcount,
                          $fetch_records->conversion_count,
                          $fetch_records->clicks_active_count,
                          $cr_in,
                          $cr_out,                            
                          $fetch_records->unique_conversion_count,
                          $fetch_records->cost_dollar.'/'.round($fetch_records->cost_dollar * 65, 2),
                          $profit = number_format($fetch_records->revenue_dollar, 2).'/'. round($fetch_records->revenue_dollar * 65, 2)
                          );
                    array_push($data1, $array);
                        $clickcount += $fetch_records->clickcount;
                        $conversion_count += $fetch_records->conversion_count;
                        $clicks_active_count += $fetch_records->clicks_active_count;
                        $conversion_count_unique += $fetch_records->unique_conversion_count;
                        $revenue_total += $fetch_records->revenue_dollar;
                        $sourcost += $fetch_records->cost_dollar;
                  }
                  $revenue_total = round($revenue_total, 2)."/".round($revenue_total * 65, 2);
                  $sourcost = round($sourcost, 2)."/".round($sourcost * 65, 2);
                $lastRow =[$clickcount,$conversion_count,$clicks_active_count,$conversion_count_unique,$revenue_total,$sourcost];

         $result  = array('data1' => $data1,
            "routename"=>$routename,
            'header'=>$header,
            'dtvalue' => $dtvalue,
            'id'=>$id_ad,
            'dtvalue2' => $dtvalue2,
            'lastRow' => $lastRow,
             'opr_name'=>$op_name,
             'traffic_type'=>$traffic_type
          );
        $viewPage = "smartlink.smrt_link_wm_detail";
        
        $dataN =  view($viewPage)->with($result);
        return $dataN;
            
    }
    
    public function smartLinkWIFI_single(Request $request,$id_ad,$type="",$routename = "smartLinkWifiSingle",$header="Smart Link WIFI - Detail")
    {
        
       $condtion = [];
            $dtvalue = $request->start;
            $dtvalue2 = $request->end;
            
            $op_name=$request->op_name;
            $traffic_type=$request->traffic_type;
            
            $data1 = [];

            $clickcount = $conversion_count = $clicks_active_count = $sourcost = $revenue_total = $profit_total = $conversion_count_unique =0;
            $totalClick=0;
            $totalconversion=0;
            $clicks_active_count=0;
  
            if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                    $dtvalue2 = date('Y-m-d');
                    $enddate = date('Y-m-d',strtotime("+1 days"));
            }else{
               $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));

            }                
            array_push($condtion,['crc_records_new.create_time','>=',$dtvalue] );
            array_push($condtion,['crc_records_new.create_time','<=',$enddate] );
            array_push($condtion,['ads.description','=','default'] );
            array_push($condtion,['ads.cco','=','33']);
            array_push($condtion,['crc_records_new.op_id','=','33']);
            array_push($condtion,['crc_records_new.op_name','=',$op_name]);
            array_push($condtion,['crc_records_new.id_ad','=',$id_ad]);           
//            array_push($condtion,['crc_records_new.id_ad','=',$id_ad]);           
//            array_push($condtion,['crc_records_new.id_ad','=',$id_ad]);           

            $select = "crc_records_new.id,"
            ."crc_records_new.op_name,"
            ."crc_records_new.create_time as dte,"
            ."crc_records_new.id_ad,"
		."crc_records_new.parent_cca,"
            ."advertiser_campaigns.cpa,"
            ."crc_records_new.parent_cca,"
            ."advertiser_campaigns.name as adv_name,"
            ."crc_records_new.id_advertiser_campaign as advrt_id,"
            ."crc_records_new.network_name,"
            ."crc_records_new.advertiser_name,"
            ."crc_records_new.id_advertiser_campaign,"                  
            ."crc_records_new.clickcount_fraud as fraud,"
            ."crc_records_new.traffic_type,"
            ."sum(crc_records_new.clickcount) as clickcount,"
            ."sum(crc_records_new.clicks_active_count) as clicks_active_count,"
            ."sum(crc_records_new.conversion_count) as conversion_count,"
            ."crc_records_new.network_cpa,"
            ."round(sum(crc_records_new.cost_dollar), 2) as cost_dollar,"
            ."crc_records_new.id_advertiser_campaign,"
            ."ads.country_code,"
            ."sum(crc_records_new.conversion_count_unique) as unique_conversion_count,"
            ."round(sum(crc_records_new.revenue_dollar), 2) as revenue_dollar";

         $data =  DB::table("crc_records_new")
                ->whereIn('ads.traffic_type', [$request->traffic_type])
                ->where($condtion) 
                ->selectRaw(DB::raw($select))
//                ->select($select)
                ->leftJoin("ads","ads.id_ad","=","crc_records_new.id_ad")
                ->leftJoin("advertiser_campaigns","advertiser_campaigns.id","=","ads.id_advertiser")                
                ->groupby("crc_records_new.parent_cca")
                ->orderby("crc_records_new.parent_cca","ASC")
                 ->get();

                foreach ($data as $fetch_records){
                    $cr_in = $cr_out = 0;
                    if($fetch_records->conversion_count != 0 && $val2=$fetch_records->clickcount != 0)
                    {
                        $val1=$fetch_records->conversion_count; 
                        $val2=$fetch_records->clickcount;
                        $val3=($val1/$val2)*100;
                        $cr_in =  round($val3, 2)."%";

                        $val4=$fetch_records->clicks_active_count;
                        $val5=$fetch_records->clickcount;
                        $val6=($val4/$val5)*100;
                        $cr_out = round($val6, 2)."%";
                    }

                    $click_sum = 0;

                    $array = [];

                    array_push($array,
                        $fetch_records->id_ad,
                         '<span title="'.$fetch_records->adv_name.'('.$fetch_records->id_advertiser_campaign.')"><a href="/smart-link-single-parent/'.$fetch_records->id_ad.'?adv='.$fetch_records->id_advertiser_campaign.'&start='.$dtvalue.'&end='.$dtvalue2.'">'.$fetch_records->adv_name.'</a></span>',
        //                            '<span title="'.$fetch_records->adv_name.'('.$fetch_records->id_advertiser_campaign.')">'.$fetch_records->adv_name.'</span>',
                          $click_sum += $fetch_records->clickcount,
                          $fetch_records->conversion_count,
                          $fetch_records->clicks_active_count,
                          $cr_in,
                          $cr_out,                            
                          $fetch_records->unique_conversion_count,
                          $fetch_records->cost_dollar.'/'.round($fetch_records->cost_dollar * 65, 2),
                          $profit = number_format($fetch_records->revenue_dollar, 2).'/'. round($fetch_records->revenue_dollar * 65, 2)
                          );
                    array_push($data1, $array);
                        $clickcount += $fetch_records->clickcount;
                        $conversion_count += $fetch_records->conversion_count;
                        $clicks_active_count += $fetch_records->clicks_active_count;
                        $conversion_count_unique += $fetch_records->unique_conversion_count;
                        $revenue_total += $fetch_records->revenue_dollar;
                        $sourcost += $fetch_records->cost_dollar;
                }
                $revenue_total = round($revenue_total, 2)."/".round($revenue_total * 65, 2);
                $sourcost = round($sourcost, 2)."/".round($sourcost * 65, 2);
                $lastRow =[$clickcount,$conversion_count,$clicks_active_count,$conversion_count_unique,$revenue_total,$sourcost];

         $result  = array('data1' => $data1,
            "routename"=>$routename,
            'header'=>$header,
            'dtvalue' => $dtvalue,
            'id'=>$id_ad,
            'dtvalue2' => $dtvalue2,
            'lastRow' => $lastRow,
             'opr_name'=>$op_name,
             'traffic_type'=>$traffic_type
           
          );
            $viewPage = "smartlink.smrt_link_wifi_detail";
        $dataN =  view($viewPage)->with($result);
        return $dataN;
            
    }
    
}


