<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Campaign;
use App\Ad;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Auth;
use App\CampaignStopCron;
use App\AdvertiserCampaigns;

class CampaignController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index() {
      return view('cca.list');
    }
    
    public function UpdateCampaigns(Request $req){


        if($req->advt){

          $get_id     =   $req->uid;
          $cname      =   trim($req->cname);
          $advt_name  =   trim($req->advt);
          $url        =   trim($req->url);
          $cpa        =   trim($req->cpa);
          $cntry      =   trim($req->country);
          $typ        =   trim($req->type);
          $id_op      =   trim($req->id_op);
          $cr_goal    =   trim($req->cr_goal);
          $status     =   trim($req->status);
          $payout_type=   trim($req->payout_typ);
          $payout_currency =   trim($req->payout_cur);
          $moi        =   trim($req->moi);
          $ads_cat    =   trim($req->ads_cat);

          $incent_type    =   trim($req->incent_type);
          $os_type    =   trim($req->os_type);
          $is_smart    =   trim($req->is_smart);


          $adsCampaign = new AdvertiserCampaigns();
          $adsCampaign->id_advertiser = $advt_name;
          $adsCampaign->name = $cname;
          $adsCampaign->url = $url;
          $adsCampaign->cpa = $cpa;
          $adsCampaign->country_code = $cntry;
          $adsCampaign->type = $typ;
          $adsCampaign->create_time = Date('Y-m-d H:i:s');
          $adsCampaign->id_op = $id_op;
          $adsCampaign->cr_goal = $cr_goal;
          $adsCampaign->status = $status;
          $adsCampaign->is_moi =$moi ;
          $adsCampaign->payout_type = $payout_type;
          $adsCampaign->payout_currency = $payout_currency;
          $adsCampaign->ads_cat = $ads_cat;
          $adsCampaign->incent_type = $incent_type;
          $adsCampaign->os_type = $os_type;
          $adsCampaign->is_smart = $is_smart;
          $adsCampaign->save();

          return redirect()->back()->with('addcampaign', 'Campaigns Added Successfully');
          //dd("saved write a code to redirect to listing page");
          //dd($adsCampaign);
        }

        //get operator code
        $select = ["operator.id","operator.name","country.iso"];

         $dataOP = DB::table("operator")
                      ->leftJoin("country","operator.country_code","=","country.iso")
                      ->select($select)
                      ->where("operator.status","=",1)
                      ->orderby("operator.name","ASC")
                      ->get();

        //get advertiser dropdown
          $select = ["id","name"];
          $dataAdv =  DB::table("advertiser")->select($select)->groupby("id")->orderby("name","ASC")->get();

        return view('cca.UpdateCampaigns',compact(['dataOP','dataAdv']));

    }


        public function UpdateCampaignsSingle(Request $req){
      
           //echo $request->id;die;
          $data = \App\AdvertiserCampaigns::findorfail($req->id)->toarray();
          //print_r($data); die;

        if($req->advt){

          $get_id     =   $req->uid;
          $cname      =   trim($req->cname);
          $advt_name  =   trim($req->advt);
          $url        =   trim($req->url);
          $cpa        =   trim($req->cpa);
          $cntry      =   trim($req->country);
          $typ        =   trim($req->type);
          $id_op      =   trim($req->id_op);
          $cr_goal    =   trim($req->cr_goal);
          $status     =   trim($req->status);
          $payout_type=   trim($req->payout_typ);
          $payout_currency =   trim($req->payout_cur);
          $moi        =   trim($req->moi);
          $ads_cat    =   trim($req->ads_cat);

          $incent_type    =   trim($req->incent_type);
          $os_type    =   trim($req->os_type);
          $is_smart    =   trim($req->is_smart);


            $adsCampaign = AdvertiserCampaigns::find($req->id);
            $adsCampaign->id_advertiser = $advt_name;
            $adsCampaign->name = $cname;
            $adsCampaign->url = $url;
            $adsCampaign->cpa = $cpa;
            $adsCampaign->country_code = $cntry;
            $adsCampaign->type = $typ;
            $adsCampaign->create_time = Date('Y-m-d H:i:s');
            $adsCampaign->id_op = $id_op;
            $adsCampaign->cr_goal = $cr_goal;
            $adsCampaign->status = $status;
            $adsCampaign->is_moi =$moi ;
            $adsCampaign->payout_type = $payout_type;
            $adsCampaign->payout_currency = $payout_currency;
            $adsCampaign->ads_cat = $ads_cat;
            $adsCampaign->incent_type = $incent_type;
            $adsCampaign->os_type = $os_type;
            $adsCampaign->is_smart = $is_smart;
            $adsCampaign->save();

          return redirect()->back()->with('addcampaign', 'Campaigns updated Successfully');
          //dd("saved write a code to redirect to listing page");
          //dd($adsCampaign);
        }

        //get operator code
        $select = ["operator.id","operator.name","country.iso"];

         $dataOP = DB::table("operator")
                      ->leftJoin("country","operator.country_code","=","country.iso")
                      ->select($select)
                      ->where("operator.status","=",1)
                      ->orderby("operator.name","ASC")
                      ->get();

        //get advertiser dropdown
          $select = ["id","name"];
          $dataAdv =  DB::table("advertiser")->select($select)->groupby("id")->orderby("name","ASC")->get();

        return view('cca.UpdateCampaignsSingle',compact(['dataOP','dataAdv', 'data']));

    }

    public function createCampaignList (Request $request,$type="",$page_name="CCA URL LIST")
    {
          $condtion = [];
          array_push($condtion,['display_url','!=',""] );
          $data = Ad::where($condtion)
            ->orderby('id_ad','DESC')
            ->paginate(1000);
            $data1 = [];
            $index = 0;
             foreach ($data as $fetch_url) {
                $array = [];
                $index++;
                array_push($array,
                   '<span id="edit_cca_list_'.$fetch_url->id.'">'.$fetch_url->id_ad.'</span><a  href="/cca/edit-cca-list/'.$fetch_url->id_ad.'"  class="pad5"><i id="edit_cca_list1_'.$fetch_url->id.'" class="fa fa-edit"></i> </a>',
                    $fetch_url->display_url
                   
              );
            array_push($data1, $array);
          }
         return view('ad.campaignlist',compact(['data1','page_name','data']));
    }


public function findCampaignList (Request $request,$type="")
    {
          $condtion = [];
          array_push($condtion,['display_url','!=',""] );
          array_push($condtion,['id_ad','=',$request->id_ad] );
          $data = Ad::where($condtion)

            ->orderby('id_ad','desc')
            ->get();
            $data1 = [];
            $index = 0;
             foreach ($data as $fetch_url) {
                $array = [];
                $index++;
                array_push($array,
                    // "<a href=/cca/edit-cca-list/".$fetch_url->id_ad."><i id='edit_cca_list_'".$fetch_url->id."' class='fa fa-edit'></i>".$fetch_url->id_ad."<a>",
                   '<span id="edit_cca_list_'.$fetch_url->id.'">'.$fetch_url->id_ad.'</span><a  href="/cca/edit-cca-list/'.$fetch_url->id_ad.'"  class="pad5"><i id="edit_cca_list1_'.$fetch_url->id.'" class="fa fa-edit"></i> </a>',
                    $fetch_url->display_url
                   
              );
            array_push($data1, $array);
          }
           $status = array("status"=>1, "data"=>$data,'data1'=>$data1);
         return $status;
    }


public function edit_cca_list(Request $request){
 
 $id_ad = $request->id_ad;
 
 $condtion = $condtions=[];
 
 array_push($condtion,['id_ad','=',$id_ad] );
 $url_id= Ad::where($condtion)->orderby('id_ad','ASC')->get();
 
 array_push($condtions,['display_url','!=','']);
 $data_found = Ad::select('id_ad','display_url')->where($condtions)->orderby('id_ad','ASC')->get();

  $data2=[];
  foreach ($data_found as $key => $value) {
    $data2[$value->id_ad] = $value->display_url;
  }
          

    $result  = array(
      'id_ad' => $url_id[0]->id_ad,
      'display_url' => $url_id[0]->display_url,
      'complete_url' =>$data2
    );

    $viewPage = "cca.edit_ccalist";
    $dataN =  view($viewPage)->with($result);
    return $dataN;
}

public function update_cca_list(Request $request){

 $id_ad = $request->id_ad;
 $display_url = $request->display_url;
 
 $condtion = $condtions=[];
 
 // array_push($condtion,['id_ad','=',$request->display_url]);

 // $url_id= Ad::where($condtion)->orderby('id_ad','ASC')->get();
 
 // $display_url= $url_id[0]->display_url;
 
 $url_id = Ad::where('id_ad', '=', $id_ad)->update(['sdisplay_url' => $display_url]); 
  if($url_id){
    $status = array("status"=>1,'message'=>'Updated Successfully');   
    }else{
    $status = array("status"=>2,'message'=>'Not Updated Successfully');
    }
 return json_encode($status);
 
 }


    public function add(Request $req)
    {
    	$name = $req->cname;
    	$Campaign = new Campaign;
      $Campaign->name = $name;
    	try{
    		
			    	$Campaign->save();

            return redirect()->route('createCampaign')->with('message', 'Campaign Created');
    	}
    	catch(\Illuminate\Database\QueryException $ex){ 
  					dd($ex->getMessage()); 
 					 
		}


        
    }
    public function getAccess(Request $request)
    {
           
           return view('queryaccess', compact('QueryAccess'));
    }

    public function getcampaign(Request $request)
    {
        $select = ["campaign_stop_cron.id as id",                      
                "campaign_stop_cron.id_advertiser_campaign as id_advertiser_campaign",  
                "campaign_stop_cron.parent_cca as parent_cca",
                "campaign_stop_cron.clicks_limit as clicks_limit",
                "campaign_stop_cron.conversions_limit as conversions_limit",
                "campaign_stop_cron.time as time","campaign_stop_cron.to_time as to_time",
                "campaign_stop_cron.cron_date as cron_date",
                "campaign_stop_cron.replace_with_campaign_id as replace_with_campaign_id",
                "advertiser_campaigns.name as name",
                "advCamp.name as advCampName",
                "campaign_stop_cron.status as status",
                "campaign_stop_cron.create_time as create_time"];


        $data =   CampaignStopCron::select($select);
        $data = $data->leftJoin("advertiser_campaigns","advertiser_campaigns.id","=","campaign_stop_cron.id_advertiser_campaign");
        $data = $data->leftJoin("advertiser_campaigns as advCamp","advCamp.id","=","campaign_stop_cron.replace_with_campaign_id");
        if($request->colorder){
           $data = $data->orderby($request->colorder,$request->order);
           $appends["colorder"]=$request->colorder;
           $appends["order"]=$request->order;
        }else{
            $data = $data->orderby("id","DESC");
        }
       

        $appends['total']=$request->total;   
          
         $data =  $data->paginate($request->total)->appends($appends);

          $result  = array('data' => $data,
           
            'total'=>$request->total?$request->total:50
          );
          

      return view('cca.autocampaign')->with($result);
    }
    public function getautoadd()
    {         
      return view('cca.autocampaign_add');
    }
    public function autocampaignadd(Request $request)
    {
      CampaignStopCron::create([
                    'id_advertiser_campaign' => $request->id_advertiser,
                    'parent_cca' =>implode($request->parentcca,","),
                    'clicks_limit' => $request->clicks_limit,
                    'conversions_limit'=> $request->conversions_limit,
                    'time' => $request->time,
                    'to_time' => $request->to_time,
                    'cron_date' => $request->cron_date,
                    'replace_with_campaign_id' => $request->new_campaign_id,
                  ]);
        return redirect('/cca/auto-campaign');
    
    }
    public function ajaxdataopt(Request $req)
    {
      $idop=$req->idoperator;
      $idAdvertiser=$req->id_cam;
      if(!empty($idop))
      {
              $select = "advertiser_campaigns.id_advertiser as idadv,advertiser_campaigns.name as idname";
              $data1 = DB::table('advertiser_campaigns')
                ->selectRaw(DB::raw($select))
                ->where([["advertiser_campaigns.id_op","=",$idop]] )
                ->where([["advertiser_campaigns.status","=","1"]])
                ->groupby("advertiser_campaigns.id")
                ->orderby("advertiser_campaigns.id","DESC")
                ->get()
                ->toArray();


            $res1 = "<option value=''>--select--</option>";

            foreach ($data1 as $key => $val)
            {
              $res1 .= "<option value ='".$val->idadv."'>".'['.$val->idadv.']'.' '.$val->idname."</option>";
          
            }
            return $res1;
        }
           
      elseif(!empty($idAdvertiser))
      {
              $select = "ads.id_ad as idad";
              $data2 = DB::table('ads')
                ->selectRaw(DB::raw($select))
                ->where([["ads.id_advertiser","=",$idAdvertiser]])
                ->get()
                ->toArray();

              
            $res2="";
            
            foreach ($data2 as $key => $val)
            {
              $res2 .= "<option value ='".$val->idad."'>".$val->idad."</option>";          
            }
            return $res2;

      }
  }

  public function edit($id)
      {


          $camp=CampaignStopCron::find($id);
          
          
          return view('cca.autocampaign_edit',compact('camp'));
      
      }
  public function update(Request $request)
      {
       
        $camp=CampaignStopCron::find($request->id);
        $camp->id_advertiser_campaign = $request->id_advertiser;
        $camp->parent_cca = implode($request->parentcca,",");
        $camp->clicks_limit = $request->clicks_limit;
        $camp->conversions_limit = $request->conversions_limit;
        $camp->time = $request->time;
        $camp->to_time = $request->to_time;
        $camp->cron_date = $request->cron_date;
        $camp->replace_with_campaign_id= $request->new_campaign_id;
        $camp->status = $request->status;
        $camp->save();

        return redirect('/cca/auto-campaign');
        
      }

  public function addCamp(Request $req){
    $campaign = $req->campaign;
    $Operator = $req->Operator;
    $camp_type = $req->camp_type;
    $country_code = $req->country_code;
    $Networks = $req->Networks;
    $Networks_id = $req->Networks_id;
    $clickid_parameter = $req->clcik_id_parm;
    $ad_category = $req->ad_category;
    $Operator_name = $req->Operator_name;
    $network_postback_source = $req->network_postback_source;
    $operators = $req->operators;
    $parent_id = $req->parent_id;
    $incent_type = $req->incent_type;
    $wifi_stat = $req->wifi_stat;
    $pay_cur = $req->pay_cur;
    $os_type = $req->os_type;
    $payout_value = $req->payout_value;
    if ($clickid_parameter) {
        $clickid_parameter = $clickid_parameter;
    }else{
        $clickid_parameter = "";
    }
    $query_operas = "select id , name from operator where status ='1' Order by name,id DESC";
    $data1 = DB::table('operator')
                ->select(["id","name"])
                ->where([["status","=",'1']])
                ->orderby("name","DESC")
                ->orderby("id","DESC")
                ->get()
                ->toArray();
     $operatorsArray = array();
        foreach ($data1 as $key => $value) {
          $operatorsArray[$value ->id] = $value ->name;
        }
      
      $ads = new Ad;
      $ads->campaignid = $campaign;
      $ads->cco = $Operator;
      $ads->operator_name = $Operator_name;
      $ads->type = $camp_type;
      $ads->network_name = $Networks;
      $ads->traffic_type = $ad_category;
      $ads->id_zone = $Networks_id;
      $ads->network_postback_source = $network_postback_source;
      $ads->parent_id = $parent_id;
      $ads->network_cpa = $payout_value;
      $ads->country_code = $country_code;
      $ads->os_type = $os_type;
      $ads->incent_type = $incent_type;
      $ads->wifi_status = $wifi_stat;
      $ads->payout_currency = $pay_cur;
      $ads->save();
      $id = $ads->id;
    if (!empty($operators)) {
        $childrenArray = array();
        $childrenArray1 = array();
        $selectedOperatorArray = explode(",", $operators);
        foreach ($selectedOperatorArray as $op_id) {

            $ads2 = new Ad;
            $ads2->campaignid = $campaign;
            $ads2->cco = $op_id;
            $ads2->operator_name = $operatorsArray[$op_id];
            $ads2->type = $camp_type;
            $ads2->id_zone = $Networks_id;
            $ads2->network_name = $Networks;
            $ads2->country_code = $country_code;
            $ads2->os_type = $os_type;
            $ads2->incent_type = $incent_type;
            $ads2->wifi_status = $wifi_stat;
            $ads2->payout_currency = $pay_cur;
            $ads2->traffic_type = $ad_category;
            $ads2->network_postback_source = $network_postback_source;
            $ads2->save();
            $lastId = $ads2->id;
                $childrenArray1[$op_id] = $lastId;
                $childrenArray[$lastId] = $operatorsArray[$op_id] . "(" . $op_id . ")";

        }
    }
    if($ads->id) {
        $data = array();
        if (!empty($clickid_parameter)) {
            //$data['clickid']=$clickid_parameter;
            $data1 = "cca=" . $id . "&ccz=" . $Networks_id . '&' . $clickid_parameter . '=';
        } else {
            //$data['clickid']="";
            $data1 = "cca=" . $id . "&ccz=" . $Networks_id;
        }

        $data['ccadata'] = $data1;
        //$data['ccz'] = intval($Networks_id);
        $data['children'] = [];
        return $data;
        //echo json_encode($data);
       // insert_tracvar($campaign);
       
    } else {
        ?>
        <div class="showbox"> <?php echo "Sorry ! values could not inserted"; ?> </div>

        <?php
        header("location : edit_campaign.php");
        exit;
    }
  }




  public function addUrls(Request $req){
    $id_ad =$req->ad_id;
    $ccz =$req->ccz;
    $arrayName = array('display_url' => $req->url.'&ccz='.$ccz );
    $active = 1;
    Ad::where(['id_ad' =>  $id_ad])->update($arrayName);
    
    // $curl = curl_init();
    // curl_setopt($curl, CURLOPT_URL, "http://162.243.33.148/cpabuffer/text.php");
    // curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    // $result = curl_exec($curl);
    // curl_close($curl);
    // print $result;

    return "updated";
  }
}