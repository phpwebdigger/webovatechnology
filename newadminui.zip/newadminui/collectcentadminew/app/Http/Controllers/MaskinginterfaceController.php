<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Users;
use App\Advertisermasking;
use App\Advertiser;
use App\AdvertiserCampaigns;
use App\ads;

class MaskinginterfaceController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

//carbun8-64601 ->1639  Carbun8

    //claymotion-74777  ->1391  Claymotion
    // insert into advertiser_maskings(id,advertiser_id,advertiser_name,display_name,type,description,created_date,status) values (NULL,'1639','Carbun8','AAAB','advertiser','',NOW(),1)

	public function index(Request $request,$type="",$routename = "maskinginterface",$header="Masking Advertiser")
    {	
    	    $adDataArray='';
            $adDataArray = Advertisermasking::where("status","1")->get();    
	    	$data1=[];
	    	foreach($adDataArray as $key => $value) {
	    		$array=[];

	    		array_push($array,
	    			$value->id,
	    			$value->advertiser_name,
	    			$value->display_name,
	    			$value->created_date);

				array_push($data1, $array);

	    	}
				
	    	 $data1  = array('data1' => $data1);

	    	return view('Masking.advertiserlist')->with($data1);
    }



    function random_strings($length_of_string) 
{ 
  
    // String of all alphanumeric character 
    $str_result = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'; 
  
    // Shufle the $str_result and returns substring 
    // of specified length 
    return substr(str_shuffle($str_result),0, $length_of_string); 
} 

    // make logic for replace the real advertiser name with masking value ,first change with Ascenso( id is 33 in advertiser table) Advertiser 

    protected function changeadvertisername(Request $request){
    		
        $adDataArray = Advertisermasking::select('advertiser_id','advertiser_name','display_name')->where("status","1")->where('type','advertiser')->whereIN('advertiser_id',['1639','1391'])->get();
             foreach ($adDataArray as $key => $value) {
              
              $update_advertiser=DB::table('advertiser')->where('status', 1)->where('id', $value->advertiser_id)->update(['name' => $value->display_name]);
                  if($update_advertiser) {
                 $this->find_replace($value->advertiser_id,$value->advertiser_name,$value->display_name);
                 }             

            }
    }



               public  function find_replace($advertiser_id ,$name_like ,$replace_with){
                //select id,id_advertiser, name from advertiser_campaigns where id_advertiser=33 limit 10000
                $find_yes_no = Advertiser::select('advertiser.id as advertiser_id','advertiser.name as advertiser_name','advertiser.create_time as advertiser_create_time','advertiser_campaigns.id as advertiser_campaigns_id','advertiser_campaigns.name as advertiser_campaigns_name','advertiser_campaigns.create_time as advertiser_campaigns_create_timesss')
                  ->leftjoin('advertiser_campaigns','advertiser_campaigns.id_advertiser','=','advertiser.id')
                  ->where('advertiser_campaigns.id_advertiser',$advertiser_id)
                  ->where('advertiser.status','1')->orderby('advertiser_campaigns_name')->get();   
                    $data=[];

                    foreach ($find_yes_no as $key => $value) {  
                    $replacewith_campain_name= str_replace($name_like,$replace_with, $value->advertiser_campaigns_name);
                         
    echo  $results = DB::update("UPDATE advertiser_campaigns SET name = REPLACE(name, '".trim($value->advertiser_campaigns_name)."', '".trim($replacewith_campain_name)."') WHERE id='".$value->advertiser_campaigns_id."' and  id_advertiser='".$value->advertiser_id."' and name like '%".trim($name_like)."%';");


                    }


        }




        public function changeadvertisernameafterweek(Request $req){

            $adDataArray = Advertisermasking::select(DB::raw('date(created_date) as created_date,advertiser_name,display_name,description,created_date,status') )->where("status","1")->where('type','advertiser')->whereRaw('DATE(created_dates) < DATE_SUB(CURDATE(), INTERVAL 7 DAY)')->get(); 

                echo "<pre>";
                print_r($adDataArray);
                echo "</pre>";

            foreach($adDataArray as $key => $value) {
                echo $key."=====".$this->random_generator(4);
            }
            


            //  $datetime1= $adDataArray[0]->created_date;
            // // $datetime2=date('Y-m-d');
            //     $now = time(); // or your date as well
            // $interval = strtotime($datetime1)-$now;
            //     $days = floor($interval / 86400); // 1 day
            //     // if($days <= 7) {
            //         // echo 'less' .$days;
            //         echo "</br>";
            //         echo $this->random_generator(4);
            //             // $this->changeadvertisername($req);


            //     // }


        }



         function update_insert_new(){


                $inert_Advertisermasking = new Advertisermasking;
                $inert_Advertisermasking->advertiser_id = $value->id;
                $inert_Advertisermasking->advertiser_name = $value->name;
                // $inert_Advertisermasking->display_name =$this->random_generator(4);
                $inert_Advertisermasking->display_name = now();
                if($inert_Advertisermasking->save())
                {
                        $status_update=1;
                }else{
                        $status_update=0;
                }


         }   



         function random_generator($digits){
                    srand ((double) microtime() * 10000000);
                    $input = array ("A", "B", "C", "D", "E","F","G","H","I","J","K","L","M","N","O","P","Q",
                    "R","S","T","U","V","W","X","Y","Z");

                    $random_generator="";
                    for($i=1;$i<$digits+1;$i++){ 
                    $rand_index = array_rand($input);
                    $random_generator .=$input[$rand_index];
                    } // end of for loop 


                    return $random_generator;
                    } // end of function




     function changeadvertisernametables(){
            foreach(range('A','Z') as $i) {
            foreach(range('A','Z') as $j) { 
            foreach(range('A','Z') as $k) { 
            echo "$i$j$k<br />";
            }
            }
            }
        
        
        }
        /*Masking Logic start for publisher networkname*/
        public function publisher_changes(Request $req){
            /* Masking Logic start for publisher (networkname)
            * Effected table -
            * select * from advertiser_vw  where advertiser_name like '%penta%'
            * select * from ads  where network_name ='pentamob'
            * select * from advertiser_campaigns where name like "%pentamob%"
            *
            */
            $pubnamelist=Advertisermasking::select('advertiser_id','advertiser_name','display_name')->where("status","1")->where('type','publisher')->get(); 
            
            foreach ($pubnamelist as $key => $value) {
           
                $update_advertiser=DB::table('ad_network')->where('status', 1)
                          ->where('ccz', $value->advertiser_id)
                          ->where('name', $value->advertiser_name)
                          ->limit(1)
                        ->update(['name' => $value->display_name]);
                        $update_advertiser=1;
                          if($update_advertiser) {
                   
                echo $this->find_replace_publisher($value->advertiser_id,$value->advertiser_name,$value->display_name);

              } 

            } // End foreach loop

        } //End here publisher_changes function


            public  function find_replace_publisher($publisher_id ,$publisher_name,$name_like){
                //select * from ads  where network_name ='pentamob'
           

             $find_yes_no = ads::select('ads.network_name','ads.id_ad','ads.id_zone','ad_network.ccz')->leftjoin('ad_network','ads.id_zone','=','ad_network.ccz')->where('ad_network.ccz',$publisher_id)->orderby('ads.network_name')->get();   
                    $data=[];

                    foreach ($find_yes_no as $key => $value) {  
                    
                    // echo $key ."UPDATE adsssssss SET network_namessss='".$name_like."' where ads.id_zone='".$value->id_zone."' and ads.network_name='".$publisher_name."'";          
                echo  $results = DB::update("UPDATE ads SET network_name='".$name_like."' where ads.id_zone='".$value->id_zone."' and ads.network_name='".$publisher_name."'");


                    }


        }

}    



