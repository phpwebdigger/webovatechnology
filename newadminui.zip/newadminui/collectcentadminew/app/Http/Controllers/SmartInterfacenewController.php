<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\SmartRotatorCampaignsOpeators;
use App\UrlTracking;

class SmartInterfacenewController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request,$is_offer_direct=0)
    { 
        ini_set('memory_limit','-1');
            // echo '<pre>';
            // print_r($request->all());
            // echo '</pre>';

        $advertiser_data = $smartData = $matched_data = [];
        $cap_count_click =  0; $selected_operator_id='';
        $smart_live_vale="";
        $perm_stat_vale="";
         
        $select =  [
           "advertiser_campaigns.id as adv_cmp_id",
            "advertiser_campaigns.id_advertiser",
            "advertiser_campaigns.name",
            "advertiser_campaigns.url",
            "advertiser_campaigns.id_op",
            "SR.cap_count_click",
            "SR.cap_count_conversions",
            "SR.start_date",
            "SR.end_date",
            "SR.is_desktop",
            "advertiser_campaigns.status",
            "advertiser_campaigns.is_fraud",
            "advertiser.name as adv_name", 
            "operator.name as opr_name",
            "advertiser.id",
            "SR.id as smartoperator_id",
            "SR.smart_live",
            'SR.campaign_id',
            "SR.waitage_percentage",
            "SR.waitage_type",
            "SR.waitage_time",
            "SR.id_zone",
            'SR.op_id',
            'SR.smart_status',
            "SR.country_code",
            "SR.ads_cat", 
            "SR.includes",
            "SR.excludes", 
            "advertiser_campaigns.permanent_status", 
          ];
        $fields = [];
        $condtion = [];
        if($is_offer_direct > 0){
          array_push($condtion,["SR.is_offer_direct",">",0]);
          array_push($condtion,["SR.id_zone","!=",0]);
          array_push($select,'ad_network.name as network_name');
          $title = 'Offerwall';
        }else{
          $title = 'Smart Interface';
          array_push($condtion,["SR.is_offer_direct","=",$is_offer_direct]);
        }

        if(isset($request->campaign_id) && !empty($request->campaign_id))
        {
             array_push($condtion,["SR.campaign_id","=",$request->campaign_id]);
             $campaign_id=$request->campaign_id;
        }else{
             $campaign_id='';
        }
        
        if(isset($request->id_channel) && !empty($request->id_channel))
        {
             array_push($condtion,["SR.id_zone","=",$request->id_channel]);
          $id_channel=$request->id_channel;
        }else{
             $id_channel='';
        }
        
        if(isset($request->advert) && !empty($request->advert))
        {
             array_push($condtion,["advertiser_campaigns.id_advertiser","=",$request->advert]);
          $advert=$request->advert;
        }else{
             $advert='';
        }


       if($request->operator_id !="")
        {
        array_push($condtion,["SR.op_id","=",$request->operator_id]);
        $selected_operator_id=$request->operator_id;
        }


       if(isset($request->traffic_type) && !empty($request->traffic_type))
        {
             array_push($condtion,["SR.ads_cat","=",$request->traffic_type]);
         $traffic_type=$request->traffic_type;
        }else{
             $traffic_type='';
        }

        if(isset($request->country) && !empty($request->country))
        {
             array_push($condtion,["SR.country_code","=",$request->country]);
      $country=$request->country;
        }else{
             $country='';
        }

      if(($request->smart_live!="") && ($request->smart_live==0) || ($request->smart_live ==1)){
         array_push($condtion,["SR.smart_live","=",$request->smart_live]);   
        $smart_live_vale=$request->smart_live;
        }else{
          $smart_live_vale="";
        }
        
      if(($request->permanent_status!="") && ($request->permanent_status==0) || ($request->permanent_status ==1)){
         array_push($condtion,["advertiser_campaigns.permanent_status","=",$request->permanent_status]);   
        $perm_stat_vale=$request->smart_live;
        }else{
          $perm_stat_vale="";
        }

      if(isset($request->smart_status) && !empty($request->smart_status)){
         array_push($condtion,["SR.smart_status","=",$request->smart_status]);   
         $smart_status=$request->smart_status;
        }else{
             $smart_status='';
        }

         if($request->offer_url){
         // array_push($condtion,["SR.offer_url","like",'"%'.$request->offer_url.'%"']);   
         array_push($condtion,["SR.offer_url","like",'"%'.$request->offer_url.'%"']);   
       $offer_url=$request->offer_url;
        }else{
             $offer_url='';
        }
//	ini_set('memory_limit', -1);

        $data =  DB::table("smart_rotator_campaigns_operators as SR")
        ->select($select)
        ->where($condtion)
        ->leftJoin("advertiser_campaigns","SR.campaign_id","=","advertiser_campaigns.id")
        ->leftJoin("advertiser","advertiser.id","=","advertiser_campaigns.id_advertiser")
        ->leftJoin("operator","operator.id","=","SR.op_id");
        if($is_offer_direct > 0){
              $data  =  $data->leftJoin("ad_network","ad_network.ccz","=","SR.id_zone");
        }  
        //$data  =  $data->get();
	$data  =  $data->paginate(1000);
         

         // dd(count($data));
         // $data =  SmartRotatorCampaignsOpeators::with(['AdvertiserCampaign','AdvertiserCampaign.Advertiser','Operator'])->limit(10)->get();
         
         $isDeskTop_st = $isLive_st =  $smart_st = "";
         $data1= [];
         $count = 0;
	if(count($data)>0){		
          foreach ($data as $result) {
                $array = [];
                $includes = $result->includes;
                $includes = json_decode($includes);
                $include_network = isset($includes->network)? $includes->network : '';
                $include_site_id = isset($includes->site_id)? $includes->site_id : '';
                $include_browser = isset($includes->browser)? $includes->browser : '';
                $include_os = isset($includes->os)? $includes->os : '';
                $include_referrer = isset($includes->referrer)? $includes->referrer : '';
                $excludes = $result->excludes;
                $excludes = json_decode($excludes);
                $exclude_network = isset($excludes->network)? $excludes->network : '';
                $exclude_site_id = isset($excludes->site_id)? $excludes->site_id : '';
                $exclude_browser = isset($excludes->browser)? $excludes->browser : '';
                $exclude_os = isset($excludes->os)? $excludes->os : '';
                $exclude_referrer = isset($excludes->referrer)? $excludes->referrer : '';
                $is_fraud = 'False';
                $live_color = $fraud_color ="color:#F05355";
                $isLive_st = 'NotLive';
                if($result->smart_status == 1){
                    $smart_st = 'Remove';
                }
                if($result->is_fraud==1){
                    $is_fraud = 'True';
                    $fraud_color = "color:#32CEA7";  
                }
                $isFraud_st_temp = '<span id="is_fraud_'.$result->adv_cmp_id.'">'.$is_fraud.'</span> | <a  href="javascript:void(0);" onclick="EditFraud('.$result->adv_cmp_id.','.$result->is_fraud.')" <i id="is_fraud_temp_'.$result->adv_cmp_id.'" class="fa fa-square" style="'.$fraud_color.'"></i> </a>';
                if($result->smart_live == 1){
                    $isLive_st = 'Live';
                    $live_color = "color:#32CEA7"; 
                }
                $isLive = '<span id="smart_live_'.$result->smartoperator_id.'">'.$isLive_st.'</span> | <a  href="javascript:void(0);" onclick="EditStatus('.$result->smartoperator_id.','.$result->adv_cmp_id.','.$result->smart_live.')" <i id="smart_live_temp_'.$result->smartoperator_id.'" class="fa fa-square" style="'.$live_color.'"></i> </a>';
                $desktop_value = 0;
                $isDeskTop_st = 'Mobile';
                if($result->is_desktop == 1){
                    $isDeskTop_st = 'Desktop'; 
                    $desktop_value = 1;
                }else if($result->is_desktop == 0){
                    $isDeskTop_st = 'Mobile';
                    $desktop_value = 0;
                }else if($result->is_desktop == 2){
                    $isDeskTop_st = 'Both';
                    $desktop_value = 2;
                }
                if($result->cap_count_click){
                    $cap_count_click = $result->cap_count_click;
                }
                $w_type = "'$result->waitage_type'";
                $count++;
                $network_names = "";
                if(isset($result->network_name) && $result->network_name){
                 $network_names  = "(".$result->network_name.")";
                }
              
                array_push($array,
                            $result->smartoperator_id,
                            '<span id="adv_cmp_id_'.trim($result->smartoperator_id).'">'.$result->adv_cmp_id.'</span>',
                            '<a href="/smart-interface/edit/'.$result->smartoperator_id.'?is_offer='.$is_offer_direct.'"><button type="button" class="btn btn-success btn-circle "><i class="fa fa-edit"></i> </button></a>',
                              '<a href="/smart-interface-add-new/'.$result->smartoperator_id.'?is_offer='.$is_offer_direct.'"><button type="button" class="btn btn-success btn-circle "><i class="fa fa-plus"></i> </button></a>',
//                              '<span id="smart_status_'.$result->smartoperator_id.'">'.$smart_st.'</span> | <a  href="javascript:void(0);" onclick="RemoveCamp('.$result->smartoperator_id.','.$result->smart_status.')"<i class="glyphicon glyphicon-trash"></i> </a>',
                            // $result->id_advertiser,
                            // $result->adv_name,
                            '<span id="name_id_'.trim($result->smartoperator_id).'" title="'.$result->name.'">'.$result->name.'('. $result->adv_cmp_id.')'.'</span><span id="id_ad-'.trim($result->smartoperator_id).'" class="change-campaign" data-value="'.$result->smartoperator_id.'" data-smart_id="'.$result->smartoperator_id.'-'.$result->ads_cat.'-'.$result->country_code.'-'.$result->op_id.'">&nbsp;<i class="fa fa-edit"></i></span>',

                            '<span id="waiting_percentage_'.trim(isset($result->smartoperator_id)).'">'.$result->waitage_percentage.'</span><a  href="javascript:void(0);" onclick="EditPercent('.$result->smartoperator_id.','.$result->adv_cmp_id.','.$result->waitage_percentage.')" class="pad5"><i id="waiting_percentage_temp1_'.$result->smartoperator_id.'" class="fa fa-edit"></i> </a>',
                            $result->ads_cat,
                            $result->country_code,
                            $result->opr_name,
                            '<span id="url_id_'.$result->smartoperator_id.'" title="'.$result->url.'">'.$result->url.'</span>',
                            '<span id="waitage_type_'.$result->smartoperator_id.'">'.$result->waitage_type.'</span> | <a  href="javascript:void(0);" onclick="EditWaitage('.$result->smartoperator_id.','.$w_type.')" <i class="fa fa-edit"></i></a>',
                            '<span id="waitage_time_'.$result->smartoperator_id.'">'.$result->waitage_time.'</span>',
                            '<span id="cap_count_click_'.$result->smartoperator_id.'">'.$result->cap_count_click.'</span><a  href="javascript:void(0);" onclick="EditClick('.$result->smartoperator_id.','.$cap_count_click.')"> <i id="cap_count_click_temp1_'.$result->smartoperator_id.'" class="fa fa-edit"></i> </a>',
                            '<span id="cap_count_conversions_'.isset($result->smartoperator_id).'">'.$result->cap_count_conversions.'</span> | <a  href="javascript:void(0);" onclick="EditConversion('.$result->smartoperator_id.','.$result->cap_count_conversions.')" <i id="cap_count_conversions_temp1_'.$result->smartoperator_id.'" class="fa fa-edit"></i> </a>',
                            $isLive,
                            $result->start_date,
                            $result->end_date,
                            $exclude_network,
                            $include_network,
                            $exclude_site_id,
                            $include_site_id,
                            $exclude_browser,
                            $include_browser,
                            $exclude_os,
                            $include_os,
                            $exclude_referrer,
                            $include_referrer,
                            '<span id="is_desktop_status_'.$result->smartoperator_id.'">'.$isDeskTop_st.'</span> | <a  href="javascript:void(0);" onclick="EditDesktop('.$result->smartoperator_id.','.$desktop_value.')" <i class="fa fa-edit"></i> </a>',
                            
                            $isFraud_st_temp,
                            "<span id='".isset($result->permanent_status)."'>".$result->permanent_status."</span>"
                            ); 
                array_push($data1, $array);
            }
	}
      $netData1 =  DB::table("ad_network")->selectRaw(DB::raw("distinct ccz,name"))->where("name", "NOT LIKE",'%...%')->where("name","NOT LIKE", '%abc%')->where('ccz',"!=",'0')->orderby("name","ASC")->get();

        $netData=array();
        foreach($netData1 as $fetch_dt)
        { 
            $netData[$fetch_dt->ccz] = $fetch_dt->name;
            
        }
            $opdata=array();
             $opdata_list =  DB::table("operator")
             ->leftJoin("country","operator.country_code","=","country.iso")
             ->selectRaw(DB::raw("operator.id as id, operator.name as name,country.iso as cc"))
             ->orderby("operator.name","ASC")->get(); 
             foreach($opdata_list as $fetch_dt)
            { 
            $opdata[$fetch_dt->id] = $fetch_dt->name.'('.$fetch_dt->cc.')';
            }

            $countrydata=array();
             $countrydata_list =  DB::table("country")
            ->select('iso','nicename')
             ->orderby("nicename","ASC")->get(); 
             foreach($countrydata_list as $fetch_dt)
            { 
            $countrydata[$fetch_dt->iso] = $fetch_dt->nicename.'('.$fetch_dt->iso.')';
            }

            $advertiserdata=array();
             $advertiserdata_list =  DB::table("advertiser")
            ->select('id','name')
             ->orderby("name","ASC")->get(); 
             foreach($advertiserdata_list as $fetch_dt)
            { 
            $advertiserdata[$fetch_dt->id] = $fetch_dt->name.'('.$fetch_dt->id.')';
            }

            $campaigndata=array();
             $campaigndata_list =  DB::table("smart_rotator_campaigns_operators as SR")
            ->select('SR.campaign_id','advertiser_campaigns.name as adv_camp_name')
            ->leftJoin("advertiser_campaigns","SR.campaign_id","=","advertiser_campaigns.id")
             ->orderby("advertiser_campaigns.name","ASC")->get(); 
             foreach($campaigndata_list as $fetch_dt)
            { 
            $campaigndata[$fetch_dt->campaign_id] = $fetch_dt->adv_camp_name.'('.$fetch_dt->campaign_id.')';
            }

//	$netData=$opdata=$advert=$countrydata=$campaigndata=$advertiserdata='';
            $view = 'smart_new.smart_interface_view';
            if($is_offer_direct){
              $view = 'smart.offerwall';
            }
        
        return view($view,compact('data','data1','title','netData','opdata','advert','countrydata','campaigndata','advertiserdata','offer_url','smart_status','perm_stat_vale','smart_live_vale','country','traffic_type','selected_operator_id','id_channel','campaign_id'));
    }

    public function filterSmartinterfacenewcData(Request $request){
       $cap_count_click =  0; $selected_operator_id='';
        $smart_live_vale="";
        $perm_stat_vale="";
          $is_offer_direct=0;
        $select =  [
           "advertiser_campaigns.id as adv_cmp_id",
            "advertiser_campaigns.id_advertiser",
            "advertiser_campaigns.name",
            "advertiser_campaigns.url",
            "advertiser_campaigns.id_op",
            "SR.cap_count_click",
            "SR.cap_count_conversions",
            "SR.start_date",
            "SR.end_date",
            "SR.is_desktop",
            "advertiser_campaigns.status",
            "advertiser_campaigns.is_fraud",
            "advertiser.name as adv_name", 
            "operator.name as opr_name",
            "advertiser.id",
            "SR.id as smartoperator_id",
            "SR.smart_live",
            'SR.campaign_id',
            "SR.waitage_percentage",
            "SR.waitage_type",
            "SR.waitage_time",
            "SR.id_zone",
            'SR.op_id',
            'SR.smart_status',
            "SR.country_code",
            "SR.ads_cat", 
            "SR.includes",
            "SR.excludes", 
            "advertiser_campaigns.permanent_status", 
          ];
        $fields = [];
        $condtion = [];
      
        if(isset($request->campaign_id) && !empty($request->campaign_id) && $request->campaign_id !='' && $request->campaign_id !='null')
        {
             array_push($condtion,["SR.campaign_id","=",$request->campaign_id]);
             $campaign_id=$request->campaign_id;
        }else{
             $campaign_id='';
        }
        
        if(isset($request->id_channel) && !empty($request->id_channel))
        {
             array_push($condtion,["SR.id_zone","=",$request->id_channel]);
          $id_channel=$request->id_channel;
        }else{
             $id_channel='';
        }
        if(isset($request->advert) && !empty($request->advert))
        {
             array_push($condtion,["advertiser_campaigns.id_advertiser","=",$request->advert]);
          $advert=$request->advert;
        }else{
             $advert='';
        }


       if($request->operator_id !="")
        {
        array_push($condtion,["SR.op_id","=",$request->operator_id]);
        $selected_operator_id=$request->operator_id;
        }


       if(isset($request->traffic_type) && !empty($request->traffic_type))
        {
             array_push($condtion,["SR.ads_cat","=",$request->traffic_type]);
         $traffic_type=$request->traffic_type;
        }else{
             $traffic_type='';
        }

        if(isset($request->country) && !empty($request->country))
        {
             array_push($condtion,["SR.country_code","=",$request->country]);
      $country=$request->country;
        }else{
             $country='';
        }

      if(($request->smart_live!="") && ($request->smart_live==0) || ($request->smart_live ==1)){
         array_push($condtion,["SR.smart_live","=",$request->smart_live]);   
        $smart_live_vale=$request->smart_live;
        }else{
          $smart_live_vale="";
        }
        
      if(($request->permanent_status!="") && ($request->permanent_status=='Inactive') || ($request->permanent_status =='Active')){
         array_push($condtion,["advertiser_campaigns.permanent_status","=",$request->permanent_status]);   
        $perm_stat_vale=$request->permanent_status;
        }else{
          $perm_stat_vale="";
        }

      if(isset($request->smart_status) && !empty($request->smart_status)){
         array_push($condtion,["SR.smart_status","=",$request->smart_status]);   
         $smart_status=$request->smart_status;
        }else{
             $smart_status='';
        }

         if($request->offer_url){
         // array_push($condtion,["SR.offer_url","like",'"%'.$request->offer_url.'%"']);   
         array_push($condtion,["SR.offer_url","like",'"%'.$request->offer_url.'%"']);   
       $offer_url=$request->offer_url;
        }else{
             $offer_url='';
        }

        $data =  DB::table("smart_rotator_campaigns_operators as SR")
        ->select($select)
        ->where($condtion)
        ->leftJoin("advertiser_campaigns","SR.campaign_id","=","advertiser_campaigns.id")
        ->leftJoin("advertiser","advertiser.id","=","advertiser_campaigns.id_advertiser")
        ->leftJoin("operator","operator.id","=","SR.op_id");
        if($is_offer_direct > 0){
              $data  =  $data->leftJoin("ad_network","ad_network.ccz","=","SR.id_zone");
        }  
        $data  =  $data->get();
         

         // dd(count($data));
         // $data =  SmartRotatorCampaignsOpeators::with(['AdvertiserCampaign','AdvertiserCampaign.Advertiser','Operator'])->limit(10)->get();
         
         $isDeskTop_st = $isLive_st =  $smart_st = "";
         $data1= [];
         $count = 0;
          foreach ($data as $result) {
                $array = [];
                $includes = $result->includes;
                $includes = json_decode($includes);
                $include_network = isset($includes->network)? $includes->network : '';
                $include_site_id = isset($includes->site_id)? $includes->site_id : '';
                $include_browser = isset($includes->browser)? $includes->browser : '';
                $include_os = isset($includes->os)? $includes->os : '';
                $include_referrer = isset($includes->referrer)? $includes->referrer : '';
                $excludes = $result->excludes;
                $excludes = json_decode($excludes);
                $exclude_network = isset($excludes->network)? $excludes->network : '';
                $exclude_site_id = isset($excludes->site_id)? $excludes->site_id : '';
                $exclude_browser = isset($excludes->browser)? $excludes->browser : '';
                $exclude_os = isset($excludes->os)? $excludes->os : '';
                $exclude_referrer = isset($excludes->referrer)? $excludes->referrer : '';
                $is_fraud = 'False';
                $live_color = $fraud_color ="color:#F05355";
                $isLive_st = 'NotLive';
                if($result->smart_status == 1){
                    $smart_st = 'Remove';
                }
                if($result->is_fraud==1){
                    $is_fraud = 'True';
                    $fraud_color = "color:#32CEA7";  
                }
                $isFraud_st_temp = '<span id="is_fraud_'.$result->adv_cmp_id.'">'.$is_fraud.'</span> | <a  href="javascript:void(0);" onclick="EditFraud('.$result->adv_cmp_id.','.$result->is_fraud.')" <i id="is_fraud_temp_'.$result->adv_cmp_id.'" class="fa fa-square" style="'.$fraud_color.'"></i> </a>';
                if($result->smart_live == 1){
                    $isLive_st = 'Live';
                    $live_color = "color:#32CEA7"; 
                }
                $isLive = '<span id="smart_live_'.$result->smartoperator_id.'">'.$isLive_st.'</span> | <a  href="javascript:void(0);" onclick="EditStatus('.$result->smartoperator_id.','.$result->adv_cmp_id.','.$result->smart_live.')" <i id="smart_live_temp_'.$result->smartoperator_id.'" class="fa fa-square" style="'.$live_color.'"></i> </a>';
                $desktop_value = 0;
                $isDeskTop_st = 'Mobile';
                if($result->is_desktop == 1){
                    $isDeskTop_st = 'Desktop'; 
                    $desktop_value = 1;
                }else if($result->is_desktop == 0){
                    $isDeskTop_st = 'Mobile';
                    $desktop_value = 0;
                }else if($result->is_desktop == 2){
                    $isDeskTop_st = 'Both';
                    $desktop_value = 2;
                }
                if($result->cap_count_click){
                    $cap_count_click = $result->cap_count_click;
                }
                $w_type = "'$result->waitage_type'";
                $count++;
                $network_names = "";
                if(isset($result->network_name) && $result->network_name){
                 $network_names  = "(".$result->network_name.")";
                }
              
                array_push($array,
                            $result->smartoperator_id,
                            '<span id="adv_cmp_id_'.trim($result->smartoperator_id).'">'.$result->adv_cmp_id.'</span>',
                            '<a href="/smart-interface/edit/'.$result->smartoperator_id.'?is_offer='.$is_offer_direct.'"><button type="button" class="btn btn-success btn-circle "><i class="fa fa-edit"></i> </button></a>',
                              '<a href="/smart-interface-add-new/'.$result->smartoperator_id.'?is_offer='.$is_offer_direct.'"><button type="button" class="btn btn-success btn-circle "><i class="fa fa-plus"></i> </button></a>',
//                              '<span id="smart_status_'.$result->smartoperator_id.'">'.$smart_st.'</span> | <a  href="javascript:void(0);" onclick="RemoveCamp('.$result->smartoperator_id.','.$result->smart_status.')"<i class="glyphicon glyphicon-trash"></i> </a>',
                            // $result->id_advertiser,
                            // $result->adv_name,
                            '<span id="name_id_'.trim($result->smartoperator_id).'" title="'.$result->name.'">'.$result->name.'('. $result->adv_cmp_id.')'.'</span><span id="id_ad-"'.trim($result->smartoperator_id).'" class="change-campaign" data-value="'.$result->smartoperator_id.'" data-smart_id="'.$result->smartoperator_id.'">&nbsp;<i class="fa fa-edit"></i></span>',

                            '<span id="waiting_percentage_'.trim($result->smartoperator_id).'">'.$result->waitage_percentage.'</span><a  href="javascript:void(0);" onclick="EditPercent('.$result->smartoperator_id.','.$result->adv_cmp_id.','.$result->waitage_percentage.')" class="pad5"><i id="waiting_percentage_temp1_'.$result->smartoperator_id.'" class="fa fa-edit"></i> </a>',
                            $result->ads_cat,
                            $result->country_code,
                            $result->opr_name,
                            '<span id="url_id_'.$result->smartoperator_id.'" title="'.$result->url.'">'.$result->url.'</span>',
                            '<span id="waitage_type_'.$result->smartoperator_id.'">'.$result->waitage_type.'</span> | <a  href="javascript:void(0);" onclick="EditWaitage('.$result->smartoperator_id.','.$w_type.')" <i class="fa fa-edit"></i></a>',
                            '<span id="waitage_time_'.$result->smartoperator_id.'">'.$result->waitage_time.'</span>',
                            '<span id="cap_count_click_'.$result->smartoperator_id.'">'.$result->cap_count_click.'</span><a  href="javascript:void(0);" onclick="EditClick('.$result->smartoperator_id.','.$cap_count_click.')"> <i id="cap_count_click_temp1_'.$result->smartoperator_id.'" class="fa fa-edit"></i> </a>',
                            '<span id="cap_count_conversions_'.$result->smartoperator_id.'">'.$result->cap_count_conversions.'</span> | <a  href="javascript:void(0);" onclick="EditConversion('.$result->smartoperator_id.','.$result->cap_count_conversions.')" <i id="cap_count_conversions_temp1_'.$result->smartoperator_id.'" class="fa fa-edit"></i> </a>',
                            $isLive,
                            $result->start_date,
                            $result->end_date,
                            $exclude_network,
                            $include_network,
                            $exclude_site_id,
                            $include_site_id,
                            $exclude_browser,
                            $include_browser,
                            $exclude_os,
                            $include_os,
                            $exclude_referrer,
                            $include_referrer,
                            '<span id="is_desktop_status_'.$result->smartoperator_id.'">'.$isDeskTop_st.'</span> | <a  href="javascript:void(0);" onclick="EditDesktop('.$result->smartoperator_id.','.$desktop_value.')" <i class="fa fa-edit"></i> </a>',
                            
                            $isFraud_st_temp,
                            "<span id='".$result->permanent_status."'>".$result->permanent_status."</span>"
                            );
                array_push($data1, $array);
            }
            if($data){
          $Rstatus = array('status'=>'1','data'=>$data1);
        }
      else{
          $Rstatus = array('status'=>'2','data'=>$data1);
      }
      echo json_encode($Rstatus);
      exit;

    }



    public function campaigns(Request $request,$is_offer_direct=0){
        $advertiser_data = $smartData = $matched_data = $data1= $condition = [];
        $cap_count_click = $count = 0;
        $isDeskTop_st = $isLive_st =  $smart_st = "";
          $select =  [
            "smart_rotator_campaigns_operators.id",
            "smart_rotator_campaigns_operators.smart_live",
            'smart_rotator_campaigns_operators.campaign_id',
            "smart_rotator_campaigns_operators.waitage_percentage",
            "smart_rotator_campaigns_operators.waitage_type",
            "smart_rotator_campaigns_operators.waitage_time",
            "smart_rotator_campaigns_operators.id_zone",
            'smart_rotator_campaigns_operators.op_id',
            'smart_rotator_campaigns_operators.smart_status',
            "smart_rotator_campaigns_operators.country_code",
            "smart_rotator_campaigns_operators.ads_cat",
            "smart_rotator_campaigns_operators.cap_count_click",
            "smart_rotator_campaigns_operators.cap_count_conversions",
            "smart_rotator_campaigns_operators.start_date",
            "smart_rotator_campaigns_operators.end_date", 
          ];

        if($is_offer_direct > 0){
          array_push($condition,["is_offer_direct",">",0]);
          array_push($condition,["id_zone","!=",0]);
          $title = 'Offerwall';
          $data =  SmartRotatorCampaignsOpeators::with(['AdvertiserCampaign','AdvertiserCampaign.Advertiser','Operator','Network'])->where($condition)->get();
        }else{
          array_push($condition,["id_zone","=",0]);  
          $title = 'Smart Interface';
          $data =  SmartRotatorCampaignsOpeators::with(['AdvertiserCampaign'=>function($query){
             $query->select("id",
                            "id_advertiser",
                            "name",
                            "url",
                            "id_op",
                            "country_code",
                            "status",
                            "is_fraud" 
                            );
          },'AdvertiserCampaign.Advertiser'=>function($query){
              $query->select("name","id");
          },'Operator'=>function($qu){
               $qu->select("name",'id');
          }])->where($condition)->select($select)->get();
        }
        
        foreach ($data as $result) {
                $array = [];
                $is_fraud = 'False';
                $live_color = $fraud_color ="color:#F05355";
                $isLive_st = 'NotLive';
                $includes = $result->includes;
                $includes = json_decode($includes);
                $include_network = isset($includes->network)? $includes->network : '';
                $include_site_id = isset($includes->site_id)? $includes->site_id : '';
                $include_browser = isset($includes->browser)? $includes->browser : '';
                $include_os = isset($includes->os)? $includes->os : '';
                $include_referrer = isset($includes->referrer)? $includes->referrer : '';
                $excludes = $result->excludes;
                $excludes = json_decode($excludes);
                $exclude_network = isset($excludes->network)? $excludes->network : '';
                $exclude_site_id = isset($excludes->site_id)? $excludes->site_id : '';
                $exclude_browser = isset($excludes->browser)? $excludes->browser : '';
                $exclude_os = isset($excludes->os)? $excludes->os : '';
                $exclude_referrer = isset($excludes->referrer)? $excludes->referrer : '';
                if($result->smart_status == 1){
                    $smart_st = 'Remove';
                }
                if($result->is_fraud == 1){
                    $is_fraud = 'True';
                    $fraud_color = "color:#32CEA7";  
                }
                $isFraud_st_temp = '<span id="is_fraud_'.$result->AdvertiserCampaign['id'].'">'.$is_fraud.'</span> | <a  href="javascript:void(0);" onclick="EditFraud('.$result->AdvertiserCampaign->id.','.$result->is_fraud.')" <i id="is_fraud_temp_'.$result->AdvertiserCampaign->id.'" class="fa fa-square" style="'.$fraud_color.'"></i> </a>';
                if($result->smart_live == 1){
                    $isLive_st = 'Live';
                    $live_color = "color:#32CEA7"; 
                }
                $isLive = '<span id="smart_live_'.$result->id.'">'.$isLive_st.'</span> | <a  href="javascript:void(0);" onclick="EditStatus('.$result->id.','.$result->AdvertiserCampaign->id.','.$result->smart_live.')" <i id="smart_live_temp_'.$result->id.'" class="fa fa-square" style="'.$live_color.'"></i> </a>';
                $desktop_value = 0;
                $isDeskTop_st = 'Mobile';
                if($result->is_desktop == 1){
                    $isDeskTop_st = 'Desktop'; 
                    $desktop_value = 1;
                }else if($result->is_desktop == 0){
                    $isDeskTop_st = 'Mobile';
                    $desktop_value = 0;
                }else if($result->is_desktop == 2){
                    $isDeskTop_st = 'Both';
                    $desktop_value = 2;
                }
                if($result->cap_count_click){
                    $cap_count_click = $result->cap_count_click;
                } 
                $w_type = "'$result->waitage_type'";
                $count++;
                $network_name = "";
                if(isset($result->Network['name']) && $result->Network['name']){
                 $network_name  = "(".$result->Network['name'].")";
                }
                array_push($array,
                            $result->id_zone.$network_name,
                            $result->AdvertiserCampaign['id']."(".$result->id.")",
                            '<a href="/smart-interface/edit/'.$result->id.'"><button type="button" class="btn btn-success btn-circle "><i class="fa fa-edit"></i> </button></a>',
                            $result->AdvertiserCampaign['id_advertiser'],
                            $result->AdvertiserCampaign->Advertiser['name'],
                            '<span title="'.$result->name.'">'.$result->AdvertiserCampaign['name'].'</span>',
                            '<span id="waiting_percentage_'.$result->id.'">'.$result->waitage_percentage.'</span><a  href="javascript:void(0);" onclick="EditPercent('.$result->id.','.$result->AdvertiserCampaign['id'].','.$result->waitage_percentage.')" class="pad5"><i id="waiting_percentage_temp1_'.$result->id.'" class="fa fa-edit"></i> </a>',
                            $result->ads_cat,
                            $result->AdvertiserCampaign['country_code'],
                            $result->Operator['name'],
                            '<span id="waitage_type_'.$result->id.'">'.$result->waitage_type.'</span> | <a  href="javascript:void(0);" onclick="EditWaitage('.$result->id.','.$w_type.')" <i class="fa fa-edit"></i></a>',
                            '<span id="waitage_time_'.$result->id.'">'.$result->waitage_time.'</span>',
                            '<span id="cap_count_click_'.$result->id.'">'.$result->cap_count_click.'</span><a  href="javascript:void(0);" onclick="EditClick('.$result->id.','.$cap_count_click.')"> <i id="cap_count_click_temp1_'.$result->id.'" class="fa fa-edit"></i> </a>',
                            '<span id="cap_count_conversions_'.$result->id.'">'.$result->cap_count_conversions.'</span> | <a  href="javascript:void(0);" onclick="EditConversion('.$result->id.','.$result->cap_count_conversions.')" <i id="cap_count_conversions_temp1_'.$result->id.'" class="fa fa-edit"></i> </a>',
                            $isLive,
                            $result->start_date,
                            $result->end_date,
                            $exclude_network,
                            $include_network,
                            $exclude_site_id,
                            $include_site_id,
                            $exclude_browser,
                            $include_browser,
                            $exclude_os,
                            $include_os,
                            $exclude_referrer,
                            $include_referrer,
                            '<span id="is_desktop_status_'.$result->AdvertiserCampaign['id'].'">'.$isDeskTop_st.'</span> | <a  href="javascript:void(0);" onclick="EditDesktop('.$result->AdvertiserCampaign['id'].','.$desktop_value.')" <i class="fa fa-edit"></i> </a>',
                            '<span id="smart_status_'.$result->id.'">'.$smart_st.'</span> | <a  href="javascript:void(0);" onclick="RemoveCamp('.$result->id.','.$result->smart_status.')" <i class="glyphicon glyphicon-trash"></i> </a>',
                            $isFraud_st_temp,
                            '<span title="'.$result->AdvertiserCampaign['url'].'">'.$result->AdvertiserCampaign['url'].'</span>'
                            );
                array_push($data1, $array);
            }
            $view = 'smart.campaigns';
            if($is_offer_direct){
              $view = 'smart.offerwall';
            }
        return view($view,compact('data1','title'));
    }

    public function campaignsPaginate(Request $request,$is_offer_direct=0){
        $advertiser_data = $smartData = $matched_data = $data1= $condition = [];
        $cap_count_click = $count = 0;
        $isDeskTop_st = $isLive_st =  $smart_st = "";
        if($is_offer_direct > 0){
          array_push($condition,["is_offer_direct",">",0]);
          array_push($condition,["id_zone","!=",0]);
          $title = 'Offerwall';
          $data =  SmartRotatorCampaignsOpeators::with(['AdvertiserCampaign','AdvertiserCampaign.Advertiser','Operator','Network'])->where($condition)->paginate();
        }else{
          $title = 'Smart Interface';
          array_push($condition,["is_offer_direct","=",$is_offer_direct]);
          $data =  SmartRotatorCampaignsOpeators::with(['AdvertiserCampaign','AdvertiserCampaign.Advertiser','Operator'])->paginate();
        }
        $view = 'smart.campaignPaginate';
        return view($view,compact('data','title'));
    }    



    public function offerwall(Request $request){
       $is_offer_direct = 1;
       return $this->index($request,$is_offer_direct);
    }
    
    public function index_adv(Request $request,$advertiser_id=null,$operator_id=null,$parent_cca=null,$viewPage = "smart.smart_advertiser_view",$type=null,$cat = array('SM','SG')){
   
        $condtion = $data1= [];
        $total_sale_count = $count = $totalClick = $actualcount = $totalconversion = $clicks_active_count = $unique_conversion = $totalCostDollar = $totalRevenueDollar = $totalprofit = $finalprofit_ECPM =  0;
        $dtvalue = $request->start;
        $dtvalue2 = $request->end;
        $id_channel =  $request->id_channel;
        if(is_null($dtvalue)){
            $dtvalue = date('Y-m-d');
        }
        if(is_null($dtvalue2)){
                $dtvalue2 = date('Y-m-d');
                $enddate = date('Y-m-d',strtotime("+1 days"));
        }else{
           if($dtvalue == $dtvalue2){ 
              $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));
           }else{
            $enddate = date('Y-m-d',strtotime($dtvalue2));
           }
        }

        // array_push($condtion,["SR.smart_status","=",'1'] );
        array_push($condtion,['crc_records_new.create_time','>=',$dtvalue] );
        array_push($condtion,['crc_records_new.create_time','<=',$enddate] );
        $select =  "advertiser_campaigns.id,"
                    ."advertiser_campaigns.id_advertiser,"
                    ."advertiser_campaigns.name,"
                    ."advertiser_campaigns.url,"
                   // ."SR.smart_status,"
                    ."advertiser_campaigns.payout_type,"
                    ."advertiser_campaigns.type,"
                    ."advertiser_campaigns.vertical,"
                    ."advertiser_campaigns.os_type,"
                    ."operator.country_code,"
                    ."advertiser_campaigns.cpa as ac_cpa,"
                    ."advertiser_campaigns.id_op as id_op,"
                    ."crc_records_new.op_id,"
                    ."crc_records_new.id_channel,"
                    ."crc_records_new.id_advertiser_campaign,"
                    // ."crc_records_new.total_cost,"
                    ."crc_records_new.clickcount_fraud as fraud,"
                    ."crc_records_new.id_ad as id_ad,"
                    ."sum(crc_records_new.clickcount) AS clickcount,"
                    ."sum(crc_records_new.conversion_count) AS conversion_count,"
                    ."sum(crc_records_new.clicks_active_count) as clicks_active_count,"
                    ."sum(crc_records_new.conversion_count_unique) as conversion_count_unique,"
                    ."sum(crc_records_new.revenue_dollar) as revenue_dollar,"
                    ."sum(crc_records_new.cost_dollar) as cost_dollar,"
                    ."CONCAT(crc_records_new.cr_goal,'%') AS cr_goal,"
                    ."CONCAT(crc_records_new.cr_received,'%') AS cr_received,"
                    ."CONCAT(crc_records_new.cr_given,'%') AS cr_given,"
                    ."crc_records_new.create_time,"
                    ."crc_records_new.traffic_type,"
                    ."sum(crc_records_new.sale_count) as sale_count,"
                    ."crc_records_new.parent_cca,"
                    ."crc_records_new.network_name as network_names,"
		            ."ad_network.name as network_name,"
                    ."operator.name as operator_name,"
                    ."advertiser.id as advtr_id,"
                    ."advertiser.name  as adv_name";

                if($request->id_channel){
                    array_push($condtion,['crc_records_new.id_channel','=',$id_channel]);  
                }
                if($advertiser_id){
                  array_push($condtion,['crc_records_new.id_advertiser_campaign','=',$advertiser_id] );
                  //  if($operator_id >= 0){  
                     //  array_push($condtion,['crc_records_new.op_id','=',$operator_id]);
                  // }
                }

                if($parent_cca > 0){
                   array_push($condtion,['crc_records_new.parent_cca','=',$parent_cca]);
                } 
                 // print"<pre>";print_r($condtion);print"</pre>";      
                 if($type == 'network'){
                    $data = DB::table("crc_records_new as crc_records_new")
                    ->selectRaw(DB::raw($select))
                    ->whereIn('crc_records_new.traffic_type',$cat)
                     ->where($condtion)
                      // ->Join("smart_rotator_campaigns_operators as SR","SR.campaign_id","=","crc_records_new.id_advertiser_campaign")
                      ->leftJoin("ad_network","crc_records_new.id_channel","=","ad_network.ccz")
                      ->leftJoin("advertiser_campaigns","advertiser_campaigns.id","=","crc_records_new.parent_cca")
                     // ->leftJoin("ads","ads.id_ad","=","crc_records_new.id_ad")
		                  
                     ->leftJoin("advertiser","advertiser.id","=","advertiser_campaigns.id_advertiser")
                     ->leftJoin("operator","operator.id","=","advertiser_campaigns.id_op")
                      ->groupby("crc_records_new.id_channel","crc_records_new.parent_cca")
                      //  ->groupby("crc_records_new.id_channel")
                     ->get();
                 
                }else if($type == 'advertiserByParentcca' || $type == 'advertiser'){
                  $data = DB::table("crc_records_new as crc_records_new")
                    ->selectRaw(DB::raw($select))
                    ->whereIn('crc_records_new.traffic_type',$cat)
                     ->where($condtion)
                     ->leftJoin("advertiser_campaigns","advertiser_campaigns.id","=","crc_records_new.parent_cca")
                     ->leftJoin("ad_network","ad_network.ccz","=","crc_records_new.id_channel")
                     ->leftJoin("advertiser","advertiser.id","=","advertiser_campaigns.id_advertiser")
                     ->leftJoin("operator","operator.id","=","advertiser_campaigns.id_op")
                     ->groupby("crc_records_new.id_advertiser_campaign")
                     ->get();
                      
                }else if($type == 'offerccabyadvertiser'){
                    $data =  DB::table("crc_records_new as crc_records_new")
                    ->selectRaw(DB::raw($select))
                    ->whereIn('crc_records_new.traffic_type',$cat)
                     ->where($condtion)
                    // ->Join("smart_rotator_campaigns_operators as SR","SR.campaign_id","=","crc_records_new.id_advertiser_campaign")
                     ->leftJoin("advertiser_campaigns","advertiser_campaigns.id","=","crc_records_new.id_advertiser_campaign")
                     // ->leftJoin("ads","ads.id_ad","=","crc_records_new.id_ad")
                     ->leftJoin("ad_network","ad_network.ccz","=","crc_records_new.id_channel")
                     ->leftJoin("advertiser","advertiser.id","=","advertiser_campaigns.id_advertiser")
                     ->leftJoin("operator","operator.id","=","crc_records_new.op_id")
                     ->groupby("crc_records_new.id_advertiser_campaign","crc_records_new.parent_cca","crc_records_new.id_channel")
                     ->get();
                      
                }else{
                   $data =  DB::table("crc_records_new as crc_records_new")
                    ->selectRaw(DB::raw($select))
                    ->whereIn('crc_records_new.traffic_type',$cat)
                     ->where($condtion)
                    // ->Join("smart_rotator_campaigns_operators as SR","SR.campaign_id","=","crc_records_new.id_advertiser_campaign")
                     ->leftJoin("advertiser_campaigns","advertiser_campaigns.id","=","crc_records_new.id_advertiser_campaign")
                     // ->leftJoin("ads","ads.id_ad","=","crc_records_new.id_ad")
                     ->leftJoin("ad_network","ad_network.ccz","=","crc_records_new.id_channel")
                     ->leftJoin("advertiser","advertiser.id","=","advertiser_campaigns.id_advertiser")
                     ->leftJoin("operator","operator.id","=","crc_records_new.op_id")
                     ->groupby("crc_records_new.id_advertiser_campaign","crc_records_new.op_id","crc_records_new.parent_cca")
                     ->get();
                } 
                     foreach ($data as $result) {
                            $array = $data = $rtotal = [];
                            $count++;
                            $totalCostDollar = round($totalCostDollar + ($result->cost_dollar));  
                            $totalRevenueDollar = round($totalRevenueDollar + ($result->revenue_dollar)); 
                            $profit_dollar = $result->revenue_dollar - $result->cost_dollar;
                            $profit = $profit_dollar * 65; 
                            $profit_both = "<span class=dollar>$profit_dollar</span><span class=rupees>$profit</span>";
                            $totalprofit = $totalprofit + $profit;
                            $actualClick = $result->clickcount - $result->fraud;
                            $cost_dollar = round($result->cost_dollar,2);
                            $cost_dollar_ruppes = round($result->cost_dollar*65);
                            $revenue_dollar = round($result->revenue_dollar,2);
                            $revenue_dollar_ruppes = round($result->revenue_dollar * 65);
                            $first_field = "<a href=/smart-cca-by-advertiser/$result->id/$result->op_id/?start=$dtvalue&end=$enddate>$result->id_advertiser_campaign<a>";
                            if($advertiser_id){
                                $first_field = "$result->parent_cca";
                            }else if($type == 'network'){
                               $first_field = "$result->id_channel";
                            } else if ($type == 'advertiser'){
                            $first_field = "<a href=/offer-cca-by-advertiser/$result->id/$result->op_id/?start=$dtvalue&end=$enddate>$result->id_advertiser_campaign<a>";  
                            }
                            
                            if($type == 'advertiserByParentcca'){
                              $array[] =  $result->parent_cca;
                              $first_field = $result->id_advertiser_campaign;
                            }
                              $array[] =  $first_field;
                              $array[] =  $result->network_name;
                              if($type == 'network'){
                                 $array[] = "<a href=/offer-by-parentcca/$result->parent_cca/?id_channel=$result->id_channel&start=$dtvalue&end=$enddate>$result->parent_cca</a>";  
                                 // $array[] = "$result->id";
                              }
                              $array[] =  $result->adv_name;
                              $array[] =  $result->operator_name."(".$result->country_code.")(".$result->op_id.")";
                              $array[] =  $result->traffic_type;                            
                              $array[] =  $result->payout_type;                            
                              $array[] =  '<span title="'.$result->name.'">'.$result->name.'('.$result->id.')</span>';
                              $array[] =   $result->country_code;
                              $array[] =   $result->type;
                              $array[] =   $result->vertical;
                              $array[] =   $result->os_type;
                              $array[] =   $result->sale_count;
                              $array[] =   $result->clickcount;
                              $array[] =   $actualClick;
                              $array[] =   $result->conversion_count;
                              $array[] =   $result->clicks_active_count;
                              $array[] =   $result->cr_received;
                              $array[] =   $result->cr_given;
                              $array[] =   $result->conversion_count_unique;
                              $array[] =   $result->cr_goal;
                              $array[] =   "<span class=dollar>".$cost_dollar."</span><span class=rupees>".$cost_dollar_ruppes."</span>";
                              $array[] =   "<span class=dollar>$revenue_dollar</span><span class=rupees>$revenue_dollar_ruppes</span>";
                              $array[] =   "<span class=dollar>$cost_dollar</span><span class=rupees>$cost_dollar_ruppes</span>";
                              $array[] =   $profit_both;
                        
                            array_push($data1, $array);
                                $total_sale_count = $total_sale_count + $result->sale_count; 
                                $totalClick = $totalClick + $result->clickcount;
                                $actualcount = $actualcount + $actualClick;
                                $totalconversion = $totalconversion + $result->conversion_count;
                                $clicks_active_count = $clicks_active_count + $result->clicks_active_count;
                                $unique_conversion = $unique_conversion + $result->conversion_count_unique;
                        }

                        

                        $lastRow =[$totalClick,$actualcount,$totalconversion,$clicks_active_count,$unique_conversion,$totalCostDollar,$totalRevenueDollar,$totalprofit,$total_sale_count];

                      $result  = array('data1' => $data1,            
                        'dtvalue' => $dtvalue,
                        'dtvalue2' => $dtvalue2,
                        'lastRow'=>$lastRow
                      );
                    
                    $dataN =  view($viewPage)->with($result);
                    return $dataN;
                }

        /* show cca by advertiser*/
    public function getccabyadvertiser(Request $request,$advertiser_id,$operator_id){
        $template_name =  'smart.ccaByAdvertiser';
        $type = '';
        $cat = ['SM','SG'];
        $parent_cca = ""; 
        return $this->index_adv($request,$advertiser_id,$operator_id,$parent_cca,$template_name,$type,$cat);
    }

    
    public function getOfferAdveriserbyParentcca(Request $request,$parent_cca){
        $template_name =  'smart.advertiserByParentcca';
        $type = 'advertiserByParentcca';
        $cat = ['OM','OG'];
        $advertiser_id = $operator_id = '';
        return $this->index_adv($request,$advertiser_id,$operator_id,$parent_cca,$template_name,$type,$cat);
    }

    /* To show network wise smart record */
    public function offer_networkwise(Request $request){
        $advertiser_id = $operator_id = $parent_cca = "";
        $type = "network";
        $template_name = "smart.networkwise";
        $cat = ['OM','OG'];
        return $this->index_adv($request,$advertiser_id,$operator_id,$parent_cca,$template_name,$type,$cat);   
    }

    /* To show advertiser wise data for OM OG category */
    public function offer_advertiser(Request $request){
        $advertiser_id = $operator_id = $parent_cca = "";
        $type = "advertiser";
        $template_name = "smart.smart_advertiser_view";
        $cat = ['OM','OG'];
        return $this->index_adv($request,$advertiser_id,$operator_id,$parent_cca,$template_name,$type,$cat);   
    }

         /* show cca by advertiser*/
    public function getofferccabyadvertiser(Request $request,$advertiser_id,$operator_id){
        $template_name =  'smart.offerccaByAdvertiser';
        $type = 'offerccabyadvertiser';
        $cat = ['OM','OG'];
        $parent_cca = ""; 
        return $this->index_adv($request,$advertiser_id,$operator_id,$parent_cca,$template_name,$type,$cat);
    }


    public function geturlSmart(Request $request){
        $condition = $operator_condition = [];
        $is_offer  = $request->is_offer;
        $id=$request->id;
        if($id){
            array_push($condition,["SR.id","=",$id] );
        }
        $select_camp =  [
            "AC.name",
            "AC.id_advertiser",
            "AC.cpa",
            "AC.url",
            "SR.includes",
            "SR.excludes", 
            "SR.campaign_id",
            "SR.waitage_percentage",
            "SR.waitage_type",
            "SR.waitage_time",
            "SR.id",
            "SR.op_id",
            "SR.cap_count_click",
            "SR.cap_count_conversions",
            "SR.start_date",
            "SR.end_date",
            "SR.ads_cat",
            "SR.country_code",
            "SR.smart_live",
            "SR.smart_status",
            "SR.is_desktop"
          ];
          $advertiser_campaigns="";
        $camp_data =  DB::table("smart_rotator_campaigns_operators as SR")
         ->where($condition)
         ->leftJoin("advertiser_campaigns as AC","SR.campaign_id","=","AC.id")
         ->select($select_camp)
         ->limit(1)
         ->get();   
            if($camp_data[0]->op_id !="")
            {
           $advertiser_campaigns = DB::table("advertiser_campaigns")->select('name','id','id_advertiser')->whereIN('id_op',[$camp_data[0]->op_id])->where('status','=','1')->get();
            }
         $condtion = [];
        $select_adv =  ["id","name"];
        $advertier_data =  DB::table("advertiser")->select($select_adv)->get();
            $select_opr =  ["opr.id","opr.name","opr.country_code as iso"];
        $oprdata =  DB::table("operator as opr")->select($select_opr)->leftjoin('country as count', 'count.iso', '=', 'opr.country_code')->get();

        $operator_name_list = DB::table("operator")->select('id','name')->get();
         $operator_name_list =json_decode(json_encode($operator_name_list),true);
         $oprdata =[];
        foreach ($operator_name_list as $key => $value) {
         $oprdata[$value['id']]=$value['name'];
        }

        $select_country =  ["id","iso","nicename"];
        $country_datas =  DB::table("country")->select($select_country)->get();
        $country_data =json_decode(json_encode($country_datas),true);
        $country =[];
        foreach ($country_data as $key => $value) {
         $country[$value['iso']]=$value['nicename'];
        }
        
        $country_name= ($camp_data[0]->country_code!='') ? $camp_data[0]->country_code:'';
        
        $opertor_name= ($camp_data[0]->op_id!='') ? $camp_data[0]->op_id:'';

        $categories_name= ($camp_data[0]->ads_cat!='') ? $camp_data[0]->ads_cat:'';
            $result  = array(
            'operator' => $oprdata,
            'country' => $country[$country_name],
            'advertiser'=> $advertier_data,
            'country_name'=>$country_name,
            'Category'=>$camp_data[0]->ads_cat,
            'op_id'=>(!empty($opertor_name) && $opertor_name!="" )?$oprdata[$opertor_name]:'',
            'waitage_percentage'=>$camp_data[0]->waitage_percentage,
            'category'=>$categories_name,
            'Advertiser_Campaign_name'=>$camp_data[0]->name,
            'advertiser_campaigns'=>$advertiser_campaigns,
            'url_offer'=>($camp_data[0]->url !="")?$camp_data[0]->url:'',

        );

                return json_encode($result);


    }
 

    public function editurlSmart(Request $request){
            $smart_rotator_id=$request->id;
            $country=$request->country;
            $operator=$request->operator;
            $category=$request->category;
            $adv_camp=$request->adv_camp;
            
            $opr = '"'.$operator.'"';
            $cntry = '"'.$country.'"';
//            $op_id = '';

             $id_advertiser = $request->id_advertiser;
            $url = "'".$request->url."'";
            $condtion=[];
             $select_op =  [
            "id",
            "name"];
            
            $op_data =  DB::table("operator")
            ->where("name","=",$operator)
            ->where("country_code","=",$country)
            ->select($select_op)
            ->limit(1)
            ->get();
                
            
            
//            echo "<pre>"; print_r($op_data); die;
//            $op_data =json_decode(json_encode($op_data),true);
            
    foreach ($op_data as $value) {
        $op_id = $value->id;
    }
            
//    foreach ($op_data as $op_key => $op_value)
//    {
//        $op_id = $op_value['id'];
//        
//    }
            
//            $op_id = $op_data[0]->id;
            
            array_push($condtion,["id","=",$smart_rotator_id]);
            
            $camp_data =  DB::table("smart_rotator_campaigns_operators as SR")
            ->where("SR.country_code","=",$country)
            ->where("SR.op_id","=",$op_id)
            ->where("SR.ads_cat","=",$category)
            ->where("SR.campaign_id","=",$adv_camp)
            ->leftJoin("advertiser_campaigns as AC","SR.campaign_id","=","AC.id")
            ->select("SR.campaign_id")
            ->limit(1)
            ->get();   
            
            foreach ($camp_data as $value)
            {
                $camp_id = $value->campaign_id;
            }
            
//            echo "<pre>"; print_r($camp_data); die;
            
            if(empty($camp_id))
            {
                $update = DB::statement("UPDATE smart_rotator_campaigns_operators SET campaign_id='".$id_advertiser."',
                                 offer_url='".$request->url."'  
                                 where id='".$smart_rotator_id."' limit 1");
            }
            
                // $update = DB::table('smart_rotator_campaigns_operators')
                //       ->where($condtion)
                //       ->update(array('campaign_ids' => $id_advertiser,'offer_url'=>$url)); 
              
            if(empty($camp_id))
            {
            if($update){ 
                  $select=DB::table('smart_rotator_campaigns_operators as Sr')->select('Sr.id','Sr.campaign_id','Sr.offer_url','advertiser_campaigns.name')
                       ->leftJoin("advertiser_campaigns","Sr.campaign_id","=","advertiser_campaigns.id")
                      ->where('Sr.id', $smart_rotator_id)->get();
                      if($select){
                      $return_id=$select[0]->id;
                      $return_campaign_id=$select[0]->campaign_id;
                      $return_offer_url=$select[0]->offer_url;
                      $return_name=$select[0]->name;
                    
                            $data = array('status'=>1,'message'=>'Successful','return_id'=>$return_id,'return_campaign_id'=>$return_campaign_id,'return_offer_url'=>$return_offer_url,'return_name'=>$return_name);
                            
                        }else{
                            $data = array('status'=>2,'message'=>'No Successful','data'=>'');
                        }    
            }else{
                 $data = array('status'=>0,'message'=>'No Successful','data'=>''); 
            }
            }
            else 
            {
                $data = array('status'=>0,'message'=>'Campaign Already Exists Select Different Campaign','data'=>'');
            }
             $data = json_encode($data);
            return $data;
    }   

    public function get_camp(Request $request,$id){

        $condition = $operator_condition = [];
        $is_offer  = $request->is_offer;
        if($id){
            array_push($condition,["SR.id","=",$id] );
        }
        $select_camp =  [
            "AC.name",
            "AC.id_advertiser",
            "AC.cpa",
            "AC.url",
            "SR.includes",
            "SR.excludes", 
            "SR.campaign_id",
            "SR.waitage_percentage",
            "SR.waitage_type",
            "SR.waitage_time",
            "SR.id",
            "SR.op_id",
            "SR.cap_count_click",
            "SR.cap_count_conversions",
            "SR.start_date",
            "SR.end_date",
            "SR.ads_cat",
            "SR.country_code",
            "SR.smart_live",
            "SR.smart_status",
            "SR.offer_url",
            "SR.is_desktop"
          ];
        
        $camp_data =  DB::table("smart_rotator_campaigns_operators as SR")
         ->where($condition)
         ->leftJoin("advertiser_campaigns as AC","SR.campaign_id","=","AC.id")
         ->select($select_camp)
         ->limit(1)
         ->get();   
            if($camp_data[0]->op_id !="")
            {
           $advertiser_campaigns = DB::table("advertiser_campaigns")->select('name','id','id_advertiser')->whereIN('id_op',[$camp_data[0]->op_id])->where('status','=','1')->get();
       }

        $condtion = [];
        $select_adv =  ["id","name"];
        $advertier_data =  DB::table("advertiser")->select($select_adv)->get();
		    $select_opr =  ["opr.id","opr.name","opr.country_code as iso"];
        $oprdata =  DB::table("operator as opr")->select($select_opr)->leftjoin('country as count', 'count.iso', '=', 'opr.country_code')->get();
        $select_country =  ["id","iso","nicename"];
        $country_datas =  DB::table("country")->select($select_country)->get();
        $country_data =json_decode(json_encode($country_datas),true);
        $country =[];
        foreach ($country_data as $key => $value) {
         $country[$value['iso']]=$value['nicename'];
        }
        
        $country_name= ($camp_data[0]->country_code!='') ? $camp_data[0]->country_code:'';
        
        $opertor_name= ($camp_data[0]->op_id!='') ? $camp_data[0]->op_id:'';

        $categories_name= ($camp_data[0]->ads_cat!='') ? $camp_data[0]->ads_cat:'';




		    $result  = array(
            'operator' => $oprdata,
            'country' => $country_datas,
            'advertiser'=> $advertier_data,
            'country_name'=>$country_name,
            'op_id'=>$opertor_name,
            'category'=>$categories_name,
            'advertiser_campaigns'=>$advertiser_campaigns

        );
            
        $viewPage = "smart_new.smart_interface_add";
        $dataN =  view($viewPage)->with($result);
        return $dataN;
    }
    
    
    public function percent_update(Request $request){
        $id = $request->id;
        $waitage_percent = $request->waitage_percent;
        if($id && ($waitage_percent || $request->exists('waitage_percent'))){
            $update = DB::table('smart_rotator_campaigns_operators')
                      ->where('id', $id)
                      ->limit(1)  // optional - to ensure only one record is updated.
                      ->update(array('waitage_percentage' => $waitage_percent)); 
            if($update){ 
                $status =  array('status'=>1);
            }else{
                $status =  array('status'=>2);
            }
        }else{
            $status =  array('status'=>3);
        }
        return json_encode($status);
    }

    /* To update waitage_type in advertiser_campaigns */
    public function waitagetype_update(Request $request){
        $id = $request->id;
        $waitage_type = $request->waitage_type;
        $waitage_time = $request->waitage_time;
        if(!empty($id) && !empty($waitage_type)){
        $update = DB::table('smart_rotator_campaigns_operators')
            ->where('id', $id)
             ->limit(1)  // optional - to ensure only one record is updated.
            ->update(array('waitage_type' => $waitage_type,'waitage_time' => $waitage_time)); 
            if($update){
               $status =  array('status'=>1,'message'=>'Successfully Fraud status updated!');
            }else{
               $status =  array('status'=>2,'message'=>'Sorry please try again!');
            }
        }else{
           $status =  array('status'=>3,'message'=>'Oops, something went wrong!');
        }
        return $status;
    }

    public function click_update(Request $request){
        $id = $request->id;
        $cap_count_click = $request->click_count;
        if(!empty($id) && !empty($cap_count_click)){
          $update = DB::table('smart_rotator_campaigns_operators')
            ->where('id', $id)
            ->limit(1)  // optional - to ensure only one record is updated.
            ->update(array('cap_count_click' => $cap_count_click)); 
            if($update){
               echo 1;
                exit();
            }else {
                echo 2;
                exit();
            }
        }else{
            echo 3;
            exit();
        }
    }

    public function conversion_update(Request $request){
        $id = $request->id;
        $conversion_count = $request->conversion_count;
        if(!empty($id) && !empty($conversion_count)){
            $update = DB::table('smart_rotator_campaigns_operators')
            ->where('id', $id)
            ->limit(1)  // optional - to ensure only one record is updated.
            ->update(array('cap_count_conversions' => $conversion_count)); 
            if($update){
               echo 1;
                exit();
            }else {
                echo 2;
                exit();
            }
        }else{
            echo 3;
            exit();
        }
    }

    public function fraud_update(Request $request){
        $id = $request->id;
        $status = $request->status;
        if(!empty($id) && $status != ''){
            if($status=='1'){
                $statuss = '0';
            }else{
                $statuss = '1';
            }
            $update = DB::table('advertiser_campaigns')
            ->where('id', $id)
            ->limit(1)  // optional - to ensure only one record is updated.
            ->update(array('is_fraud' => $statuss)); 
            if($update){
               $status =  array('status'=>1,'message'=>'Successfully Fraud status updated!');
            }else{
               $status =  array('status'=>2,'message'=>'Sorry please try again!');
            }
        }else{
           $status =  array('status'=>3,'message'=>'Oops, something went wrong!');
        }
        return $status;
    }
    
    /* To change the smart_live status of Campaign*/
    public function livestatus_update(Request $request){
       $smartoperator_id = $request->id; #smart_campaign_id
       $campaign_id = $request->campaign_id; #smart_campaign_id
       $is_live = $request->is_live;  #1 live,0 nt live 
       $update_smart = '';
       if($campaign_id){
         $checkCampaign = DB::Select("select status from advertiser_campaigns where id=$campaign_id");
         if($checkCampaign){ 
            if($checkCampaign[0]->status == 0 && $is_live == 1){
              $status =  array('status'=>2,'message'=>'Please activate the campaign  first!');
              return $status;
            }
         }     
         if($smartoperator_id){
              $update = DB::table('smart_rotator_campaigns_operators')->where('id',$smartoperator_id)->update(array('smart_live' => $is_live));
             if($update){
                 $status =  array('status'=>1,'message'=>'Successfully Status updated!');
              }else{
                 $status =  array('status'=>2,'message'=>'Sorry please try again!');
              }
          }else{
              $status =  array('status'=>3,'message'=>'Oops, something went wrong!');
          }
        }
        return $status;
    }

    /*  To remove the campaign from the smart_rotator_campaigns_operators table*/
    public function smartStatus_update(Request $request){
        $smartoperator_id = $request->smartoperator_id;
        if($smartoperator_id){
             $update = DB::table('smart_rotator_campaigns_operators')
            ->where('id', $smartoperator_id)
            ->limit(1)  // optional - to ensure only one record is updated.
            ->delete();
            if($update){
                $status = array('status'=>'1','message'=>'This campiagn is removed');
            }else{
                $status = array('status'=>'2','message'=>'This campiagn is not removed');
            }
        }else{
            $status = array('status'=>'3','message'=>'Oops something went wrong');
        }    
        return json_encode($status);
    }

    

    public function smartDesktop_update(Request $request){
       $id = $request->id;
       $option_type = $request->option_type;
       if(!empty($id) && $option_type != ''){
        $update = DB::table('smart_rotator_campaigns_operators')
            ->where('id', $id)
            ->limit(1)  // optional - to ensure only one record is updated.
            ->update(array('is_desktop' => $option_type)); 
            if($update){
            echo 1;exit();
            }else{
            echo 2;exit();
            }
        }else{
            echo 3;
            exit();
        }
    }
    
    /* TO save and update smart campaign */
    public function store(Request $request){
        $operator_country = $datawgwm = [];
        $adv_camp_id = $request->adv_camp_id;
        $adv_camp_ids = explode(',',$request->adv_camp_id); 
        $operator_id = explode(',',$request->opr_list);
        $country_iso = $request->country_id;
        $cat_list = "'".$request->cat_list."'";  
        $adv_list = explode(',', $request->adv_list);
        $operator_name = $request->operator_name;
        $offer_url = "'".$request->offer_url."'";
        $operator_name_arr = explode("(",$operator_name);
        $cat_data = ['WM','WG'];
        $waitage_percentage = "'".$request->waitage_percentage."'";
        $waitage_type = "'".$request->waitage_type."'";
        $waitage_time = $request->waitage_time;
        $smart_status = $request->smart_status;
        $dataOP = DB::select("select `operator`.`country_code`,`operator`.`id` from `operator` where `operator`.`status` = 1 "
                 . "and `operator`.`id` in ($request->opr_list) order by `operator`.`name` asc");
        foreach($dataOP as $op_co_name){
            if($op_co_name->id == 33){
              $operator_country[] = $country_iso;  
            }else{
              $operator_country[] = $op_co_name->country_code;
            }
        }
       
        if($request->exists('opr_list') && $request->adv_camp_id){
           $sql_insertroute = "Insert into smart_rotator_campaigns_operators(`campaign_id`,`op_id`,`smart_status`,`country_code`,`ads_cat`,`waitage_percentage`,`waitage_type`,`waitage_time`,`offer_url`) values ";
            $n = count($operator_id);
            $vals = array();
            for($i=0;$i<$n;$i++){
                $campaign_id = $adv_camp_id;
                $op_id = isset($operator_id[$i]) ? "'".$operator_id[$i]."'" : "NULL";
                $country_code = isset($country_iso) ? "'".$country_iso."'" : "NULL";
                $operator_name = isset($operator_name_arr[$i]) ? "'".$operator_name_arr[$i]."'" : "no operator";
                $campaign_exist = $this->checkCampaign($campaign_id,$cat_list,$op_id,$country_code);
                array_push($vals, "($campaign_id, $op_id,$smart_status,$country_code,$cat_list,$waitage_percentage,$waitage_type,$waitage_time,$offer_url)");
                if($campaign_exist)
                { 
                    break;
                }
            }
            /* To check campaign exist in smart operator*/
            if($campaign_exist){
            $status =  array('status'=>3, 'message'=>"$campaign_exist exist for operator $operator_name)"); 
            }else{
                $sql_insertroute .= implode(', ', $vals);
                $sqlResult = DB::insert($sql_insertroute);
                if($sqlResult){
                $status =  array('status'=>1, 'message'=>"campaign inserted ");
                }
                else{
                $status =  array('status'=>2, 'message'=>"Not inserted");
                }
            }    
        }
        return json_encode($status);
      }

    
    public function Smartcamapignlist(Request $request){
        $op_id=$request->op_id;
        $advertiser_campaigns = DB::table("advertiser_campaigns")->select('name','id','id_advertiser')->whereIN('id_op',[$op_id])->where('status','=','1') ->orderby('name')->get();

        return $advertiser_campaigns;


    }

    /* To check Campaign */ 
    public function checkCampaign($campaign_id,$cat_list,$op_id,$country_code){
       if($campaign_id && $op_id){
         $country_condition = " AND 1=1"; 
         if($country_code){
          $country_condition = " AND country_code = $country_code";
         }         
         $sql = "Select count(1) as campaignCount from smart_rotator_campaigns_operators where campaign_id = $campaign_id AND ads_cat = $cat_list AND op_id = $op_id $country_condition  limit 1";
         $result = DB::select($sql);
         if($result[0]->campaignCount > 0){
            return $campaign_id;
         }
       }
       return false;
    }    

    // AJAX call for get campign
    public function get_campaign(Request $request){   
        $data = $ddDataResult1  = [];
        $country = $request->country;
        $opr_list = $request->opr_list;
        $cat_list = $request->cat_list;
        $adv_list = $request->adv_list;
        $cc = $operator = "";
        $category_condition = ""; 
        $condition = "1=1";
        
        if($adv_list){
           $condition .= " AND id_advertiser = '".$adv_list."'";
           $category_condition .= " AND id_advertiser = '".$adv_list."'";
           $category_condition .= " AND status = '1'";
        }
        
        if(($cat_list != 'WM' || $cat_list != 'WG') && $cat_list){
            $condition .= " AND ads_cat = '".$cat_list."'";
        }

        if($opr_list !=""){
            $operator = "$opr_list";
            if(is_array($opr_list)){
                $opr = explode(",", $opr_list);
                $operator = "'" . implode("','", $opr) . "'";
            }
            $condition .= " AND id_op IN ($operator)";
        }
        if($country){
            $condition .= " AND country_code = '".$country."'";
        }
        $condition  .= " AND status = '1'";
        $data = DB::select("select id,name,ads_cat from advertiser_campaigns Where $condition UNION select id,name,ads_cat from advertiser_campaigns where ads_cat IN ('WG','WM') $category_condition");
        foreach ($data as $dropdown){            
            $ddDataResult1[$dropdown->id]['name'] = $dropdown->name." (".$dropdown->id.")(".$dropdown->ads_cat.")";
            $ddDataResult1[$dropdown->id]['cat_id'] = $dropdown->ads_cat;
        }
        if($ddDataResult1){
            $status = array('status'=>1,'data'=>$ddDataResult1);
        }else{
            $status = array('status'=>2,'data'=>$ddDataResult1);  
        }
        return json_encode($status);
    }

    /* Edit Smart Campaign data*/
    public function edit(Request $request,$id){
        $condition = $operator_condition = [];
        $is_offer  = $request->is_offer;
        if($id){
            array_push($condition,["SR.id","=",$id] );
        }
        $select_camp =  [
            "AC.name",
            "AC.id_advertiser",
            "AC.cpa",
            "AC.url",
            "SR.includes",
            "SR.excludes", 
            "SR.campaign_id",
            "SR.waitage_percentage",
            "SR.waitage_type",
            "SR.waitage_time",
            "SR.id",
            "SR.op_id",
            "SR.cap_count_click",
            "SR.cap_count_conversions",
            "SR.start_date",
            "SR.end_date",
            "SR.ads_cat",
            "SR.country_code",
            "SR.smart_live",
            "SR.smart_status",
            "SR.is_desktop"
          ];
        
        $camp_data =  DB::table("smart_rotator_campaigns_operators as SR")
         ->where($condition)
         ->leftJoin("advertiser_campaigns as AC","SR.campaign_id","=","AC.id")
         ->select($select_camp)
         ->limit(1)
         ->get();
        
        $decode_data = json_decode($camp_data, true);
        $includes =  json_decode($decode_data[0]['includes']);
        $excludes =  json_decode($decode_data[0]['excludes']);
        
        $select_country =  ["iso","name"];
        $country_data =  DB::table("country")->select($select_country)->get();
        $select_opr =  ["id","name","country_code"];

        array_push($operator_condition,["country_code","=",$decode_data[0]['country_code']]);
        
        $operator_data =  DB::table("operator")
         ->where($operator_condition) 
         ->select($select_opr)
         ->get();
        echo $is_offer;
        $result  = array(
            'data' => $decode_data[0],
            'country_data' => $country_data,
            'operator_data' => $operator_data,
            'includes' => $includes,
            'excludes' => $excludes,
            'is_offer' => $is_offer
          );
        $viewPage = "smart_new.smart_interface_edit";
        $dataN =  view($viewPage)->with($result);
        return $dataN;
    }

    
    /* Update smart campaign data*/ 
    public function update(Request $request){
        $smartOperator_id = $request->id;
        $campaign_id = $request->campaign_id;
        $country_code = $request->country;
        $operator_code = $request->operator;
        $category = $request->category;
        $waitage_percentage = $request->waitage_percentage;
        $waitage_type = $request->waitage_type;
        $waitage_time = $request->waitage_time;
        $conversion_count = $request->cap_count_conversions;
        $click_count = $request->cap_count_click;
        $start_datetime = $request->start_datetime;
        $end_datetime = $request->end_datetime;
        
        /* Includes */
       
        $includes['network'] = $include_network = $request->include_network;
        $includes['referrer'] = $include_referrer = $request->include_referrer;
        $includes['site_id'] = $include_siteid = $request->include_siteid;
        $includes['os'] = $include_os = $request->include_os;
        $includes['browser'] = $include_browser = $request->include_browser;
       
        /* Excludes */
        $excludes['network'] = $exclude_network = $request->exclude_network;
        $excludes['referrer'] = $exclude_referrer = $request->exclude_referrer;
        $excludes['site_id'] = $exclude_siteid = $request->exclude_siteid;
        $excludes['os'] = $exclude_os = $request->exclude_os;
        $excludes['browser'] = $exclude_browser = $request->exclude_browser;
        $includes_all = json_encode($includes);
        $excludes_all = json_encode($excludes);
        $smart_status = $request->smart_status;
        $is_offer = $request->is_offer;
        if($smartOperator_id && $country_code && $category){
            $SmartRotator = SmartRotatorCampaignsOpeators::find($smartOperator_id);
            $SmartRotator->country_code =  $country_code;
            $SmartRotator->op_id =  $operator_code;
            $SmartRotator->ads_cat =  $category;
            $SmartRotator->smart_status =  $smart_status;
            $SmartRotator->waitage_percentage =  $waitage_percentage;
            $SmartRotator->waitage_type = $waitage_type;
            $SmartRotator->waitage_time = $waitage_time;
            $SmartRotator->cap_count_conversions =  $conversion_count;
            $SmartRotator->cap_count_click =  $click_count;
            $SmartRotator->start_date = $start_datetime;
            $SmartRotator->end_date =  $end_datetime;
            $SmartRotator->includes =  $includes_all;
            $SmartRotator->excludes =  $excludes_all;
            $SmartRotator->is_desktop =  $request->is_desktop;
            $SmartRotator->save();
            if($SmartRotator){
                $status = array("status"=>1,'message'=>'Updated Successfully');   
            }else{
                $status = array("status"=>2,'message'=>'Not Updated Successfully');
            }
        }else{
             $status = array("status"=>3,'message'=>'Some thing went wrong');           
        }
        return json_encode($status);
    }


    public function select_country_ops(Request $req){

        $country= $req->country_value;
        $country_array=[];
         $select_opr =  ["id","name","country_code"];

        array_push($country_array,["country_code","=",$country]);
        $operator_data =  DB::table("operator")
         ->where($country_array) 
         ->orwhere("id","=","33") 
         ->select($select_opr)
         ->get();

        return  json_decode(json_encode($operator_data,true));

    }

}
