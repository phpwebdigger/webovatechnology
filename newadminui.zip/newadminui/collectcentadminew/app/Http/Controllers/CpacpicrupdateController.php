<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Response;
use App\Ad;
use App\AdvertiserCampaigns;
use App\Advertiser;

class CpacpicrupdateController extends Controller
{

   //
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */


    

    public function index(Request $request)
    {

        $result=[];

        $viewPage = "Cpacpiupdate.index";

        $dataN =  view($viewPage)->with($result);
        return $dataN;
        
   }

   
   private function getNetworks(){
        $redis = Redis::connection();
        $key  =  "networks";
        try {
          if(!$redis->exists($key)){
             $items = $this->getNetworkQuery(); 
             $hourlydata = Redis::set($key,$items);
             $redis->expire($key,5000);
            }else{
            $items = Redis::get($key);
         }
        } catch (\Exception $e) {
            // echo $e->getMessage();
          $items = $this->getNetworkQuery();  
        }
        return json_decode($items);
    }



  function getNetworkQuery(){
      $network_dropdown = [];
      $networksResult = DB::select("select id,ccz,name from ad_network order by name ASC");
      foreach ($networksResult as $dropdown) {
        if ($dropdown->id && $dropdown->name){
            $network_dropdown[$dropdown->id]['networkWithCCZ'] = $dropdown->name."(".$dropdown->ccz.")";
            $network_dropdown[$dropdown->id]['id'] = $dropdown->id;
            $network_dropdown[$dropdown->id]['network'] = $dropdown->name;
            $network_dropdown[$dropdown->id]['ccz'] = $dropdown->ccz;
          }
        }
        $items = json_encode($network_dropdown);
        return $items;
    }



  public function Siteidwisefileter(Request $req){

    $parent_cca = isset($req->Parent_CCA) ? $req->Parent_CCA:'';
    $id_zone = isset($req->id_zone) ? $req->id_zone:'';
    $status='';
  $listdata =  Siteidwisediversion::where('parent_cca',$parent_cca)->orWhere('id_zone',$id_zone)->get();
      $data=[];
        foreach ($listdata as $key => $value) {
          $rst=$this->getpulisher_name($value->id_zone,$value->plateform);

          $rata = $this->getadvertiser_campaigns_name($value->camapignid);

          
          $arrays=[];
          // echo $value->siteids;
          array_push($arrays,
            $value->parent_cca,
            $rst[$value->id_zone],
            $value->plateform,
            $value->siteids,
            // '<a href="#" name="edit_siteid" id="edit_siteid" onClick="editsiteid('.$value->id.','.$value->parent_cca.','.$value->id_zone.','.$value->siteids.','.$value->camapignid.')"> Edit</a>',
            // $value->camapignid,
            $rata[$value->camapignid],
            '<a href="#" name="edit_campaign" id="edit_campaign" onClick="editcampainname('.$value->id.','.$value->parent_cca.','.$value->id_zone.','.$value->siteids.','.$value->camapignid.')"> Edit</a>',
              $value->reason,
            $value->Type,
            $value->status,
            '<a href="#" name="delete_List" id="delete_list" onClick="deleterow('.$value->id.')">Delete</a>'
          );
           array_push($data, $arrays);
  
        }
        if($data){
          $status = array('status'=>'1','data'=>$data);
        }else{
          $status = array('status'=>'2','data'=>'No Vaue');
        }

        $result  = json_encode($status);
       return $result;
  }


  public function Siteidwiseparentccadetails(Request $req){
      $parent_cca =isset($req->parent_cca) ? $req->parent_cca:'';
      $input_parent_cca =isset($req->parent_cca) ? $req->parent_cca:'';
      $parent_cca_ads = $id_zone ='';
      if($parent_cca == trim($parent_cca) && strpos($parent_cca, '_') !== false) {
        $parent_cca_dt = explode('_',$parent_cca);
        $parent_cca = isset($parent_cca_dt[0]) ? $parent_cca_dt[0] :0;
        $id_zone  = isset($parent_cca_dt[1]) ? $parent_cca_dt[1] :0;
      }else{
      $parent_cca_ads =$parent_cca;
      }


      if(isset($parent_cca) && isset($id_zone)  && !empty($parent_cca) && !empty($id_zone)){
          $pub_name='';
            $metaData = AdvertiserCampaigns::where('id',$parent_cca)
        
             ->get(['advertiser_campaigns.id as id_ad', 'advertiser_campaigns.id_op as operator_name','advertiser_campaigns.id_op as cco','advertiser_campaigns.country_code','advertiser_campaigns.os_type','advertiser_campaigns.id as id_advertiser']);

             $publisherData =  $dataMain= DB::table("ad_network")->where('ccz',$id_zone)->get();
           
              $pub_name=$publisherData[0]->name.'('.$publisherData[0]->ccz.')';
             $plateform_value='Offerwall'; 

            // $pub_line=$parent_cca;
        
      }else{
          
      $metaData = Ad::where('id_ad',$parent_cca)
      ->get(['id_ad', 'operator_name','cco','country_code','os_type','network_name','id_zone','id_advertiser']);
            $plateform_value='S2S'; 
        }
  

      $result_data='';



       if(!empty($metaData) && count($metaData)>0)
        {
           
          $result_data .='<form method="get" action="" name="insert_siteidwise" id="insert_siteidwise">';
          $result_data .='<span id="error"></span>';
          $result_data .='<span class="preloader_porcessing"></span>';
            $result_data .= '<table class="table table-bordered" id="item_addmore">';

                $result_data .= '<thead>';
                    $result_data .= '<th>';
                        $result_data .= 'Publisher Name';                
                    $result_data .= '</th>';
                    $result_data .= '<th>';
                        $result_data .= 'Insert Site Id';                
                    $result_data .= '</th>';
                      $result_data .= '<th>';
                        $result_data .= 'Select Camapign Name';                
                    $result_data .= '</th>';
                      $result_data .= '<th>';
                        $result_data .= 'Is Smart';                
                    $result_data .= '</th>';
                    $result_data .= '<th>';
                        $result_data .= 'Action';                
                    $result_data .= '</th>';
                      $result_data .= '<th>';
                        $result_data .= 'Reason';                
                    $result_data .= '</th>';
              $result_data .= '<th>';
                        $result_data .= 'Add New';                
                    $result_data .= '</th>';
                $result_data .= '</thead>';

                foreach ($metaData as $key => $value) 
                {
                  $fecth_data = $this->getCampaignNameofferlist($value->country_code,$value->os_type);
                $id_zone= isset($value->id_zone) ? $value->id_zone : $id_zone;
                    $result_data .= '<tr>';

                      $result_data .= '<input type="hidden" id="parent_cca_test" name="parent_cca_test" value="'.$value->id_advertiser.'"/>';

              $result_data .= '<input type="hidden" id="parent_cca_value" name="parent_cca_value" value="'.$value->id_ad.'"/>';
              $result_data .= '<input type="hidden" name="id_zone_value" value="'.$id_zone.'"/>';
              $result_data .= '<input type="hidden" name="plateform_value" value="'.$plateform_value.'"/>';

               $result_data .= '<input type="hidden" name="op_id" id=name="op_id" value="'.$value->cco.'"/>';
                if(isset($value->network_name) && !empty($value->network_name)){
                    $result_data .= '<td>'.$value->network_name.'('. $id_zone.')'.'</td>';
                  }else{
                    $result_data .= '<td>'.$pub_name.'</td>';
                  }
                  

                    $result_data .= '<td><textarea  class="form-control" id="siteid_value" name="siteid_value[]" required rows="6" cols="6"></textarea></td>';

                    $result_data .= '<td><select name="selected_camapign[]" id="selected_camapign_1"  required class="form-control" data-live-search="true" data-actions-box="true" data-selected-text-format="count > 3" data-size="10" data-style="btn-danger">
                    <option value="">Select</option>';
                    foreach ($fecth_data as $key => $values) {
                      $result_data .='<option value="'.$values->campaign_id.'">'.trim($values->offer_url).'  ('.trim($values->campaign_id).')'.'</option>';
                    }
        $result_data .='</select></td>';
                   $result_data .= '<td><input type="radio" name="is_smart_1" id="default_radio_1" class="radiobox3 " value="DEFAULT" checked="checked">Default &nbsp;&nbsp;
                    <input type="radio" name="is_smart_1" id="is_smart_cpa_1" value="CPA" class="radiobox3">CPA
                    &nbsp;&nbsp;&nbsp;
                    <input type="radio" name="is_smart_1" id="is_smart_cpi_1" value="CPI" class="radiobox3">CPI 
</td>';         
                    /*   $result_data .= '<td><input type="radio" id="running_1" name="status_1" class="radiobox_runing" value="1" checked="checked">Running &nbsp;&nbsp;
                    <input type="radio" id="paused_1" name="status_1" value="0" class="radiobox_paused">Paused</td>'; */

          $result_data .= '<td><select name="status[]" id="status" class="form-control">
                      <option value="1">Running</option>
                      <option value="0">Paused</option>
                    </select></td>';

                    $result_data .= '<td><select name="reason[]" id="reason_1" class="form-control">
                      <option value="include">Include</option>
<option value="exclude">Exclude</option>
<option value="citit">Citit</option> 
<option value="click_flooding">Click Flooding</option>
              </td>';

          $result_data .='<td> <button type="button" name="add_new_row" 
          onclick="javascript:displayaddnew(\''.$input_parent_cca.'\')" class="btn btn-primary align-right">Add New</button></td>';
                    $result_data .= '</tr>';
                }

            $result_data .= '</table></form>';
           // $result_data .='';
        }
        else
        {
            $result_data .= '<table class="table table-bordered">';
                $result_data .= '<tr>';
                    $result_data .= '<th>';
                        $result_data .= 'No Data Found';                
                    $result_data .= '</th>';
                $result_data .= '</tr>';
            $result_data .= '</table>';
        }

           // $returnRes['results'] = $result_data;
           return $result_data;


  }

  public function getCampaignNameofferlist($country_code,$os_type){

               $dataMain= DB::table("advertiser_campaigns")
               ->select('advertiser_campaigns.name as offer_url','advertiser_campaigns.id as campaign_id')
               ->where('advertiser_campaigns.status','=','1')
               ->where('advertiser_campaigns.country_code','=',$country_code)
               ->where('advertiser_campaigns.type','=','CPICPA')
              ->orderby('advertiser_campaigns.name')
        ->get();
        $dataMain=$dataMain->toArray();
        return $dataMain;
    }


  public function Siteidwiseaddmorerow(Request $request){

    $parent_cca_ads = $id_zone =$parent_cca ='';
       $parent_cca =isset($request->parent_cca) ? $request->parent_cca:'';
      if($parent_cca == trim($parent_cca) && strpos($parent_cca, '_') !== false) {
        $parent_cca_dt = explode('_',$parent_cca);
        $parent_cca = isset($parent_cca_dt[0]) ? $parent_cca_dt[0] :0;
        $id_zone  = isset($parent_cca_dt[1]) ? $parent_cca_dt[1] :0;
      }else{
      $parent_cca =$parent_cca;
      }
  if(isset($parent_cca) && isset($id_zone)  && !empty($parent_cca) && !empty($id_zone)){
           $metaData = AdvertiserCampaigns::where('id',$parent_cca)
             ->get(['advertiser_campaigns.id as id_ad', 'advertiser_campaigns.id_op as operator_name','advertiser_campaigns.id_op as cco','advertiser_campaigns.country_code','advertiser_campaigns.os_type','advertiser_campaigns.id as id_advertiser']);

             $publisherData =  $dataMain= DB::table("ad_network")->where('ccz',$id_zone)->get();
              $pub_name=$publisherData[0]->name.'('.$publisherData[0]->ccz.')';
            $plateform_value='Offerwall'; 
        

      }else{
          
      $metaData = Ad::where('id_ad',$parent_cca)
      ->get(['id_ad', 'operator_name','cco','country_code','os_type','network_name','id_zone','id_advertiser']);
             $plateform_value='S2S'; 
        }
  

      $result_data='';
       if(!empty($metaData) && count($metaData)>0)
        {

            

                foreach ($metaData as $key => $value) 
                {
                  $fecth_data = $this->getCampaignNameofferlist($value->country_code,$value->os_type);

                 

               $id_zone= isset($value->id_zone) ? $value->id_zone : $id_zone;
                    $result_data .= '<tr>';
                     
                     if(isset($value->network_name) && !empty($value->network_name)){
                    $result_data .= '<td>'.$value->network_name.'('. $id_zone.')'.'</td>';
                  }else{
                    $result_data .= '<td>'.$pub_name.'</td>';
                  }

                    $result_data .= '<td><textarea  class="form-control" id="siteid_value"  name="siteid_value[]" rows="6" cols="6"></textarea></td>';  


                    $result_data .= '<td><select name="selected_camapign[]" id="selected_camapign_'.$request->count.'" class=" form-control" data-live-search="true" data-actions-box="true" data-selected-text-format="count > 3" data-size="10" data-style="btn-danger"><option value="">Select</option>';
                    foreach ($fecth_data as $key => $values) {
                      $result_data .='<option value="'.$values->campaign_id.'">'.trim($values->offer_url).'  ('.trim($values->campaign_id).')'.'</option>';
                    }
        $result_data .='</select></td>';
                   $result_data .= '<td><input type="radio" name="is_smart_'.$request->count.'" id="default_radio_'.$request->count.'" class="radiobox3 " value="DEFAULT" checked="checked">Default &nbsp;&nbsp;
                    <input type="radio" name="is_smart_'.$request->count.'" id="is_smart_cpa_'.$request->count.'" value="CPA" class="radiobox3">CPA
                    &nbsp;&nbsp;&nbsp;
                    <input type="radio" name="is_smart_'.$request->count.'" id="is_smart_cpi_'.$request->count.'" value="CPI" class="radiobox3">CPI 
</td>';         
                   


          $result_data .= '<td><select name="status[]" class="form-control" id="status_'.$request->count.'">
                      <option value="1">Running</option>
                      <option value="0">Paused</option>
                    </select></td>';

           $result_data .= '<td><select name="reason[]" id="reason_'.$request->count.'" class="form-control">
                      <option value="include">Include</option>
<option value="exclude">Exclude</option>
<option value="citit">Citit</option> 
<option value="click_flooding">Click Flooding</option>
              </td>';                 

          $result_data .='<td><button type="button" name="remove" class="btn btn-danger btn-sm remove"><span class="glyphicon glyphicon-minus"></span></button></td>';
                    $result_data .= '</tr>';
                }

          
           
        }
        else
        {
           
                $result_data .= '<tr>';
                    $result_data .= '<th>';
                        $result_data .= 'No Data Found';                
                    $result_data .= '</th>';
                $result_data .= '</tr>';
           
        }

           // $returnRes['results'] = $result_data;
           return $result_data;

      
  }


  public function Siteidwiseadd_newinsert(Request $req){
    $msg="";
      $parent_cca = isset($req->parent_cca_value)? $req->parent_cca_value :'';
      $id_zone = isset($req->id_zone_value) ? $req->id_zone_value :'';
      $plateform = isset($req->plateform_value) ? $req->plateform_value :'';
      $siteids = isset($req->siteid_value) ? $req->siteid_value:'';
      $camapignid = isset($req->selected_camapign) ? $req->selected_camapign:'';
      $reason = isset($req->reason) ? $req->reason :'';
      $status = isset($req->status) ? $req->status :'';

      $order_details = [];
for($i= 0; $i < count($camapignid); $i++){
    $order_deratils[] = [
        'parent_cca' => $parent_cca,
        'id_zone' => $id_zone,
        'plateform' => $plateform,
        'siteids' => $siteids[$i],
        'camapignid' => $camapignid[$i],
        'reason' => $reason[$i],
        'Type' => 'Manual',
        'status' => $status[$i],
    ];
}
        // echo "<pre>"; print_r($order_deratils); echo '</pre>';
      $new_add= Siteidwisediversion::insert($order_deratils);
      if($new_add){
        $msg="1";
      }else{
        $msg="2";
      } 
      return $msg;

  }


  public function Siteidwisediverisoneditdeatils(Request $request){

      $id =isset($request->id) ? $request->id:'';
      $result_data='';


        $listdata =  Siteidwisediversion::where('id',$id)->get();
        
          foreach ($listdata as $key => $value) {
          
        $plateform=$value->plateform;
          }

      if($plateform=='S2S'){
      $metaData = Ad::leftjoin('siteid_campaign_routing','siteid_campaign_routing.parent_cca','=','ads.id_ad')->where('siteid_campaign_routing.id',$id)->get(['ads.id_ad', 'ads.operator_name','ads.cco','ads.country_code','ads.os_type','ads.network_name','siteid_campaign_routing.id_zone','siteid_campaign_routing.siteids','siteid_campaign_routing.camapignid','siteid_campaign_routing.status','siteid_campaign_routing.id','siteid_campaign_routing.parent_cca as id_advertiser','siteid_campaign_routing.plateform','siteid_campaign_routing.reason']);
  
    }else if($plateform=='Offerwall'){
      $metaData = AdvertiserCampaigns::leftjoin('siteid_campaign_routing','siteid_campaign_routing.parent_cca','=','advertiser_campaigns.id')->where('siteid_campaign_routing.id',$id)->get(['advertiser_campaigns.id as id_ad', 'advertiser_campaigns.id_op as operator_name','advertiser_campaigns.id_op as cco','advertiser_campaigns.country_code as country_code','advertiser_campaigns.os_type','advertiser_campaigns.name as network_name','siteid_campaign_routing.id_zone','siteid_campaign_routing.siteids','siteid_campaign_routing.camapignid','siteid_campaign_routing.status','siteid_campaign_routing.id','siteid_campaign_routing.parent_cca as id_advertiser','siteid_campaign_routing.plateform','siteid_campaign_routing.reason']);
    }
      


       if(!empty($metaData) && count($metaData)>0)
        {
          $result_data .='<form method="get" action="" name="edit_siteidwise" id="edit_siteidwise">';
          $result_data .='<span id="error"></span>';
          $result_data .='<span class="preloader_porcessing"></span>';
            $result_data .= '<table class="table table-bordered" id="edit_item_addmore">';
                $result_data .= '<thead>';
                    $result_data .= '<th>';
                    $result_data .= 'Parent CCA';                
                    $result_data .= '</th>';
                    $result_data .= '<th>';
                        $result_data .= 'Publisher Name';                
                    $result_data .= '</th>';
                    $result_data .= '<th>';
                        $result_data .= 'Insert Site Id';                
                    $result_data .= '</th>';
                      $result_data .= '<th>';
                        $result_data .= 'Select Camapign Name';                
                    $result_data .= '</th>';
                      $result_data .= '<th>';
                        $result_data .= 'Is Smart';                
                    $result_data .= '</th>';
                    $result_data .= '<th>';
                     $result_data .= 'Reason';                
                    $result_data .= '</th>';
                    $result_data .= '<th>';
                        $result_data .= 'Action';                
                    $result_data .= '</th>';
              
                $result_data .= '</thead>';

                foreach ($metaData as $key => $value) 
                {
                  $fecth_data = $this->getCampaignNameofferlist($value->country_code,$value->os_type);

                
                  $rst=$this->getpulisher_name($value->id_zone,$value->plateform);
        
                    $result_data .= '<tr>';

$result_data .= '<input type="hidden" id="parent_cca_test" name="parent_cca_test" value="'.$value->camapignid.'"/>';
                       $result_data .= '<input type="hidden" name="edit_row_id" value="'.$value->id.'"/>';
              $result_data .= '<input type="hidden" name="edit_parent_cca_value" value="'.$value->id_ad.'"/>';

              $result_data .= '<input type="hidden" name="edit_id_zone_value" value="'.$value->id_zone.'"/>';

              $result_data .= '<input type="hidden" name="op_id" id="op_id" value="'.$value->cco.'"/>';
  $result_data .= '<input type="hidden" id="campaign_id_test" name="campaign_id_test" value="'.$value->camapignid.'"/>';

                 $result_data .= '<td>'.$value->id_ad.'</td>';
            $result_data .= '<td>'.$rst[$value->id_zone].'</td>';

                    $result_data .= '<td><textarea  class="form-control" id="edit_siteid_value" name="edit_siteid_value" required rows="3" cols="6">'.$value->siteids.'</textarea></td>'; 
                    $result_data .= '<td><select name="edit_selected_camapign" id="selected_camapign_1"  required class=" form-control" data-live-search="true" data-actions-box="true" data-selected-text-format="count > 3" data-size="10" data-style="btn-danger">
                    <option value="">Select</option>';
                    foreach ($fecth_data as $key => $values) {
                       if(trim($value->camapignid) == trim($values->campaign_id)){
                          $selected = 'selected="selected"';
                       }else{
                          $selected ='';
                       }
                      $result_data .='<option value="'.$values->campaign_id.'" '.$selected.'>'.trim($values->offer_url).'  ('.trim($values->campaign_id).')'.'</option>';
                    }
        $result_data .='</select></td>';
                   $result_data .= '<td><input type="radio" name="is_smart_1" id="default_radio_1" class="radiobox3 " value="DEFAULT" checked="checked">Default &nbsp;&nbsp;
                   <input type="radio" name="is_smart_1" id="is_smart_cpa_1" value="CPA" class="radiobox3">CPA
                    &nbsp;&nbsp;&nbsp;
                    <input type="radio" name="is_smart_1" id="is_smart_cpi_1" value="CPI" class="radiobox3">CPI 
</td>';       
            
                   $result_data .= '<td><select name="edit_reason[]" id="edit_reason_1" class="form-control">';
                   if($value->reason=='include'){
            $result_data .='<option value="include" selected>Include</option>';
          }else{
            $result_data .='<option value="include">Include</option>';
            }
 if($value->reason =='exclude'){
$result_data .='<option value="exclude" selected>Exclude</option>';
}else{
$result_data .='<option value="exclude">Exclude</option>';
}
 if($value->reason=='citit'){
$result_data .='<option value="citit" selected>Citit</option>';
}else{
  $result_data .='<option value="citit">Citit</option>';
}
 if($value->reason=='click_flooding'){
$result_data .='<option value="click_flooding" selected>Click Flooding</option>';
}else{
$result_data .='<option value="click_flooding">Click Flooding</option>';
}
              $result_data .='</td>';

           $result_data .= '<td><select name="edit_status_drop" id="edit_status" class="form-control">';
            if($value->status==1){
                    $result_data .= '<option value="1" selected>Running</option>';
                    $result_data .= '<option value="0">Paused</option>';
                    }else{
                    $result_data .= '<option value="1">Running</option>';     
                    $result_data .= '<option value="0" selected>Paused</option>';
                    }
                    $result_data .= '</select></td></tr>';
                }

            $result_data .= '</table></form>';
           // $result_data .='';
        }
        else
        {
            $result_data .= '<table class="table table-bordered">';
                $result_data .= '<tr>';
                    $result_data .= '<th>';
                        $result_data .= 'No Data Found';                
                    $result_data .= '</th>';
                $result_data .= '</tr>';
            $result_data .= '</table>';
        }

           // $returnRes['results'] = $result_data;
           return $result_data;

  }


  public function Siteidwisediverisoneditsave(Request $request){

    $msg="";



    $edit_row_id= isset($request->edit_row_id) ? $request->edit_row_id:'';
    $edit_siteid_value=isset($request->edit_siteid_value) ? $request->edit_siteid_value:'';
    $edit_selected_camapign=isset($request->edit_selected_camapign) ? $request->edit_selected_camapign:'';
    $edit_status = isset($request->edit_status_drop) ? $request->edit_status_drop : '';
    $parent_cca = isset($request->edit_parent_cca_value) ? $request->edit_parent_cca_value :'';
    $id_zone = isset($request->edit_id_zone_value) ? $request->edit_id_zone_value :'';
      
  $edit_save = Siteidwisediversion::find($edit_row_id);
  $edit_save->parent_cca = $parent_cca;
  $edit_save->id_zone = $id_zone;
    $edit_save->siteids = $edit_siteid_value;
    $edit_save->camapignid = $edit_selected_camapign;
    $edit_save->status = $edit_status;
   
    if($edit_save->save()){
        $msg="1";
      }else{
        $msg="2";
      } 
      return $msg;
  }



  public function selectcampaignofferlist(Request  $request){

            $id = $request->cca;
            $conditon= $request->conditon;

            $is_smart = $request->is_smart;


            $select_fields=['id_op','country_code','os_type'];
            $select = DB::table('advertiser_campaigns')->select($select_fields)->where('id',$id)->get();
            $array = json_decode(json_encode($select), true);

               $op_id = $array[0]['id_op'];     
               $country_code = $array[0]['country_code'];     
               $os_type = $array[0]['os_type'];     
try{
            if($conditon == 'default'){ 
                    $ad_select = ['name','id'];
                    $advertiser_campaigns = DB::table('advertiser_campaigns')->select($ad_select)->where('country_code',$country_code)->where('id_op',$op_id)->where('os_type',$os_type)->orderby('name')->where('status','1')->get();
                     $advertiser_campaigns = json_decode(json_encode($advertiser_campaigns), true);
            }
            else if($is_smart=='CPA') {
                   $ad_select = ['name','id'];
                  $select_fields=['id_op','country_code','os_type','is_smart'];
                  $advertiser_campaigns = DB::table('advertiser_campaigns')->select($ad_select)->where('country_code',$country_code)->where('id_op',$op_id)->where('os_type',$os_type)->where('is_smart','CPA')->orderby('name')->where('status','1')->get();
                  $advertiser_campaigns = json_decode(json_encode($advertiser_campaigns), true);
            } 
            else if($is_smart=='CPI') {
                   $ad_select = ['name','id'];
                   $select_fields=['id_op','country_code','os_type','is_smart'];
                  $advertiser_campaigns = DB::table('advertiser_campaigns')->select($ad_select)
                  //->where('country_codess',$country_code)
                  //->where('id_op',$op_id)->where('os_type',$os_type)
                  ->where('is_smart','CPI')->orderby('name')->where('status','1')->get();
             $advertiser_campaigns = json_decode(json_encode($advertiser_campaigns), true);
            }

             $status = array('status'=>1,'advertiser_campaigns'=>$advertiser_campaigns);    
         }catch(\Illuminate\Database\QueryException $ex){ 
          $status = array('status'=>2,'data'=>'','message'=>$ex->getMessage(),'advertiser_campaigns'=>''); 
        }
        $data =  Response::json($status);
        return $data;
    }

    function getpulisher_name($id_zone,$type){

      $mrslq="";
      if($type=="S2S"){
        $mrslq=Ad::where('id_zone',$id_zone)->get(['network_name as name','id_zone as ccz']);
      }elseif ($type=="Offerwall") {
        $mrslq=DB::table('ad_network')->select('name','ccz as ccz')->where('ccz',$id_zone)->get();
      }
      $new_array=[];
      foreach ($mrslq as $key => $value) {
        $new_array[$value->ccz]= $value->name.'('.$value->ccz.')';    # code...
      }
      return $new_array;

    }

     function getadvertiser_campaigns_name($id){

          
        $metaData = AdvertiserCampaigns::where('id',$id)->get();
        $camp_array=[];
        foreach ($metaData as $key => $value) {
          $camp_array[$value->id] = $value->name.'('.$value->id.')';
        }
        $camp_array = isset($camp_array) ? $camp_array : 0;
      return $camp_array;

     }

     function deletefunction(Request $request){

            $listdata =  Siteidwisediversion::find($id);
            try{
            $listdata->delete();  
            }catch(\Illuminate\Database\QueryException $ex){
               dd($ex->getMessage());
            }
            if($listdata){
        $status = array('status'=>1,'message'=>'Delete');
      }else{
        $status = array('status'=>2,'message'=>'not updated'); 
      }
      return json_encode($status);


     }


      public function updateSiteidwise(Request $request){
      $action = $request->action;
      $fields = $action.'_status';
      $id = $request->id;
      $status = $request->check_value;
      $update='';
      try{
        $info = array('status'=>$status);
       $update =  Siteidwisediversion::where('id',$id)->update($info);
      }catch(\Illuminate\Database\QueryException $ex){
        dd($ex->getMessage());
      }
      if($update){
        $status = array('status'=>1,'message'=>'updated','id_ad'=>$request->id,'check_value'=>$request->check_value);
      }else{
        $status = array('status'=>2,'message'=>'not updated'); 
      }
      return json_encode($status);
    }



}
