<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use DB;
use App\Crc;
use Response;
use SimpleHelper;

class CrcController extends Controller
{
    

   public function __construct()
    {
        $this->middleware('auth');
    }
   
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request){
      $items= array();
      $network = DB::select("select ccz,name from ad_network order by name");
      $advertiser = DB::select("select id,name from advertiser order by name");
      return view('CrcRecord.index',compact('items','network','advertiser'));
	  }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function getdata(Request $request){
       $type = $request->input('type');
       $net_id = $request->input('net_id');
       $advertiser_id = $request->input('advertiser_id');
       $total_network_id = count($net_id);
       $dateR = $dateRange = $request->input('daterange');
       $condition = $this->getdateRangeCondtion($dateRange);
       if($net_id){
        $net_id = implode(",",$net_id);
          $condition .= " AND id_channel IN ($net_id)";
       }
       if($advertiser_id){
        $advertiser_id = implode(",",$advertiser_id);
        $condition .= " AND id_advertiser IN ($advertiser_id)";
       } 
       $dateRange = explode(" ",$dateRange);
       $start_date = $dateRange[0];
       $end_date =   $dateRange[2];
       $diff = strtotime($end_date) - strtotime($start_date);
       $diff = $diff/86400;
       if($diff == 0){
        $diff = $total_network_id * 1;
       }else{
        $diff = $total_network_id * $diff;
       }
       $total_sale = "sum(IF(crc.traffic_type = 'WG' OR crc.traffic_type = 'WM',crc.cost_dollar, crc.total_cost))";
       $fields = [
                      "crc.id", 
                      "crc.op_name", 
                      "crc.`op_id`",
                      "crc.network_name",
                      "crc.id_advertiser",
                      "crc.id_channel", 
                      "sum(crc.clickcount ) AS clickcount", 
                      "sum( crc.conversion_count ) AS conversion_count", 
                      "sum( crc.conversion_count_unique ) AS conversion_count_unique", 
                      "sum( crc.clicks_active_count ) AS clicks_active_count", 
                      "sum(crc.`revenue_dollar` ) AS revenue_dollar", 
                      "$total_sale  as cost_dollar",
                      "(sum(crc.`revenue_dollar`) - $total_sale) AS profit",
                      "date(crc.`create_time`) as create_time",
                      "crc.traffic_type",
                    ];
       $fields = implode(",",$fields); 
       if($type == 'date'){
        $items = DB::select("SELECT $fields 
            FROM crc_records_new AS crc WHERE $condition 
            GROUP BY date(create_time)");
        }else if($type == 'network'){
        $items = DB::select("SELECT $fields
            FROM crc_records_new AS crc 
            WHERE $condition
            GROUP BY crc.id_channel");
        }else if($type == 'advertiser'){
         $items = DB::select("SELECT $fields,advertiser.name as advertiser
            FROM crc_records_new AS crc INNER JOIN advertiser ON crc.id_advertiser = advertiser.id 
            WHERE $condition
            GROUP BY crc.id_advertiser");
        }
         $data = [];
         $totalClick =  $conversion_count = $conversion_count_unique = $clicks_active_count = $TotalEcpc = 
         $cost_dollar = $revenue_dollar = $profit = 0;
         foreach($items as $item){
            $array = [];
            $totalClick += $item->clickcount; 
            $conversion_count += $item->conversion_count;
            $conversion_count_unique += $item->conversion_count_unique;
            $clicks_active_count += $item->clicks_active_count;
            if($item->clickcount){ 
               $ecpc = number_format(($item->revenue_dollar/$item->clickcount),4);   
               $TotalEcpc =  $TotalEcpc + $ecpc;
               $TotalEcpc = number_format($TotalEcpc,4);
            }  
            $cost_dollar +=  $item->cost_dollar;
            $revenue_dollar +=  $item->revenue_dollar;
            $profit += $item->profit; 
            if($type == 'network'){
              $first_field = $item->network_name;
            }elseif($type == 'advertiser'){
              $first_field = $item->advertiser."(".$item->id_advertiser.")";
            }else{
              $first_field = $item->create_time;
            }
            array_push($array,
                            $first_field,
                            $item->clickcount,
                            $item->conversion_count,
                            $item->conversion_count_unique,
                            $item->clicks_active_count,
                            SimpleHelper::getPercentage($item->conversion_count,$item->clickcount),
                            SimpleHelper::getPercentage($item->clicks_active_count,$item->clickcount),
                            $ecpc,
                            SimpleHelper::numFormat($item->cost_dollar),
                            SimpleHelper::numFormat($item->revenue_dollar),
                            SimpleHelper::numFormat($item->profit)
                         ); 
                  array_push($data,$array);                  
            }
          $lastRow = [
                      "",
                      $totalClick, 
                      $conversion_count,
                      $conversion_count_unique,
                      $clicks_active_count,
                      "",
                      "",
                      $TotalEcpc, 
                      SimpleHelper::numFormat($cost_dollar),  
                      SimpleHelper::numFormat($revenue_dollar),
                      SimpleHelper::numFormat($profit),   
                    ]; 

           $status  = array('status'=>1,'items'=>$data,'lastRow'=>$lastRow);
           $status = json_encode($status);
           return $status;
      }


      public function getdataJson(Request $request){
       $type = $request->input('type');
       $net_id = $request->input('net_id');
       $total_network_id = count($net_id);
       $dateR = $dateRange = $request->input('daterange');
       $condition= $this->getdateRangeCondtion($dateRange);
       $net_id = implode(",",$net_id);
       if($net_id){
          $condition .= " AND id_channel IN ($net_id)";
       } 
       $dateRange = explode(" ",$dateRange);
       $start_date = $dateRange[0];
       $end_date =   $dateRange[2];
       $diff = strtotime($end_date) - strtotime($start_date);
       $diff = $diff/86400;
       if($diff == 0){
        $diff = $total_network_id * 1;
       }else{
        $diff = $total_network_id * $diff;
       }
       $total_sale = "sum(IF(traffic_type = 'WG' OR traffic_type = 'WM',crc.cost_dollar, crc.total_cost))";
       $fields = [
                      "crc.id", 
                      "crc.op_name", 
                      "crc.`op_id`",
                      "crc.network_name",
                      "crc.id_channel", 
                      "sum(crc.clickcount ) AS clickcount", 
                      "sum( crc.conversion_count ) AS conversion_count", 
                      "sum( crc.conversion_count_unique ) AS conversion_count_unique", 
                      "sum( crc.clicks_active_count ) AS clicks_active_count", 
                      "sum(crc.`revenue_dollar` ) AS revenue_dollar", 
                      "$total_sale  as cost_dollar",
                      "(sum(crc.`revenue_dollar`) - $total_sale) AS profit",
                      "date(crc.`create_time`) as create_time",
                      "crc.traffic_type",
                    ];
        $fields = implode(",",$fields); 
       if($type == 'Date'){
        $items = DB::select("SELECT $fields 
            FROM crc_records_new AS crc WHERE $condition 
            GROUP BY date(create_time)");
        }else if($type == 'Network'){
        $items = DB::select("SELECT $fields
            FROM crc_records_new AS crc 
            WHERE $condition
            GROUP BY crc.id_channel");
        }
        $lastUpdated = $this->lastUpdated();  
        return view('CrcRecord.getdata',compact('items','type','dateR','lastUpdated'))->with('i', ($request->input('page', 1) - 1) * 5);
      }


    /* main Function used to fetch data for all condition except first one*/
    public function getPublisher(Request $request){
        $id_channel_exist = $request->exists('id_channel');
        $id_channel = $request->input('id_channel');
        $dateRange = $request->input('daterange');
        $condition= $this->getdateRangeCondtion($dateRange);
        if(($id_channel_exist || $id_channel)){
          $total_sale = "sum(IF(traffic_type = 'WG' OR traffic_type = 'WM',crc.cost_dollar, crc.total_cost))";
          $fields = [
                  "op.`country_code`",
                  "crc.`id`, op.`name` as op_name", 
                  "crc.`op_id`",
                  "crc.`network_name`",
                  "crc.`parent_cca`",
                  "crc.`op_id`",
                  "crc.`id_channel`",
                  "crc.`traffic_type`",
                  "sum(crc.`clickcount`) as clickcount" , 
                  "sum(crc.`conversion_count`) as conversion_count", 
                  "sum( crc.`conversion_count_unique`) as conversion_count_unique", 
                  "sum(crc.`clicks_active_count`) AS clicks_active_count", 
                  "sum(crc.`revenue_dollar`) AS revenue_dollar", 
                  "$total_sale as cost_dollar",
                  "(sum(crc.`revenue_dollar`) - $total_sale) AS profit"
                  ]; 
          $fields  = implode(",",$fields);
          $items =  DB::select("SELECT $fields 
            FROM crc_records_new AS crc INNER JOIN operator as op ON crc.op_id = op.id
            WHERE  crc.`id_channel` = '".$id_channel."' and $condition
            GROUP BY crc.parent_cca");
            return view('CrcRecord.publisherAjax',compact('items'))->with('i', ($request->input('page', 1) - 1) * 5);
        }
            $items = Response::json(array('status'=>'OK','records'=>$items));
        return $items;
    }

    public function getdateRangeCondtion($dateRange){
         if(!empty($dateRange)){
           $dateRange = explode(" ",$dateRange);
            $start_date = $dateRange[0];
            $end_date =   $dateRange[2];
            $diff = strtotime($end_date) - strtotime($start_date);
            $diff =  $diff/86400;
            if($start_date == $end_date){
             $condition =  "(date(crc.create_time) = '$start_date')";
            }else if($diff > 0){
             $condition = "(date(crc.create_time) BETWEEN '$start_date' AND '$end_date')";   
            } 
          }else{
          $condition = '1=1';
        }
        return $condition;
    }

    /* To check when crc_records_new was last updated 
     * Developer: Sumit  
     * Date : 19 July 2017 #12.00PM
     */
    function lastUpdated(){
     $lastUpdated = DB::select("SELECT max(create_time) as create_time from crc_records_new limit 1");
	 $lastUpdated_count = count($lastUpdated);
	 if($lastUpdated_count > 0)
	    if($lastUpdated[0]->create_time){
		  return $lastUpdated[0]->create_time;	
		}
      return "No Update time";  
   }

    
    

    
}
