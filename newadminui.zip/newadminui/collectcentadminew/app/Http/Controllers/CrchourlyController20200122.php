<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;  

use App\Http\Requests;
use DB;
use App\Crc;
use Response;
use File;
use Illuminate\Support\Facades\Redis;
use Cache;
// use Advertiser;

class CrchourlyController20200122 extends Controller
{
    
    
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
   
    public function index(Request $request,$template = 'Hourly.index'){
	    
      $path = storage_path() . "/json/country.json";
      if (!File::exists($path)) {
        throw new Exception("Invalid File");
      }
      $country_json = File::get($path);
      $country = json_decode($country_json);
      return view($template,compact('country'));
    }


    public function smartIndex(Request $request){
      $template = 'Hourly.smartIndex';
      return $this->index($request,$template);
    }

    
    /**
     * To Show the data on landing page for current day Only
     *
     * @return \Illuminate\Http\Response
     */
    public function gethourdata(Request $request){
        $redis = Redis::connection();
        $cache = $request->input('cache');
        $date  = date('Y-m-d');
        $key   = "hourlydata_$date";
      try {
          if(!$redis->exists($key)){
             $items = $this->gethourquery(); 
            $hourlydata = Redis::set($key, $items);
             $redis->expire($key,300);
            }else{
            $items = Redis::get($key);
         }
      } catch (\Exception $e) {
            // echo $e->getMessage();
          $items = $this->gethourquery();  
      }
      return $items; 
        
    }

   
    public function gethourquery(){
       $date = date('Y-m-d');
       $fields = [
                  'chr.id',
                  'chr.op_name',
                  'chr.id_ad',
                  'chr.network_name',
                  'chr.advertiser_campain_name',
                  'chr.advertiser_name',
                  'sum(chr.clickcount) as clickcount',
                  'sum(chr.sale_count) as sale_count',
                  'sum(chr.clicks_active_count) as clicks_active_count',
                  'sum(chr.conversion_count) as conversion_count',
                  'sum(chr.conversion_count_unique) as conversion_count_unique', 
                  'chr.network_cpa',
                  "sum(IF(traffic_type = 'WG' OR traffic_type = 'WM',chr.cost_dollar, chr.total_cost)) as total_costv",
                  // "sum(chr.total_cost)+sum(chr.cost_dollar)  as total_costv",
                  'chr.cr_received',
                  'chr.cr_given',
                  'chr.hour',
                  'chr.total_cost',
                  'chr.id_advertiser_campaign',
                  'sum(chr.clickcount_fraud) as clickcount_fraud',
                  'sum(chr.revenue_dollar) as revenue_dollar',
                  'cost_dollar'
                 ];
         $fields = implode(",", $fields);  
         $items['records'] = DB::select("SELECT $fields FROM crc_records_details chr WHERE DATE(chr.date) BETWEEN DATE('".$date."')  AND  DATE('".$date."') group by hour ORDER BY hour DESC");
           $items['status'] = 'OK';
           $items = json_encode($items,JSON_NUMERIC_CHECK);
           $items = json_encode(json_decode($items));
           return $items;
    }

  
    public function filterData(Request $request){
	  // if($request->ajax()){
      $redis = Redis::connection();
     	$current_url = $request->fullUrl();
      $current_url = explode("?",$current_url);
      if(count($current_url) > 1){
         $allParameters = $current_url[1];
         $key = "hourlydatapnet_$allParameters";
      }
      try{
          if(!$redis->exists($key)){
              $item = $this->getFilterQuery($request);
              Redis::set($key, $item);
              $redis->expire($key,300);
              }else{
                // $item = Redis::get($key);
                $item = $this->getFilterQuery($request);
              }
      } catch(\Exception $e){
         $item = $this->getFilterQuery($request);

      } 
       return $item;
	 }

    public function filterSmartData(Request $request){
    // if($request->ajax()){
      $redis = Redis::connection();
      $current_url = $request->fullUrl();
      $current_url = explode("?",$current_url);
      if(count($current_url) > 1){
         $allParameters = $current_url[1];
         $key = "Smarthourlydata_$allParameters";
      }
      $type = 'smart';
      try{
          if(!$redis->exists($key)){
              $item = $this->getFilterQuery($request,$type);
              Redis::set($key, $item);
              $redis->expire($key,300);
              }else{
                // $item = Redis::get($key);
                $item = $this->getFilterQuery($request,$type);
              }
      } catch(\Exception $e){
         $item = $this->getFilterQuery($request,$type);
      } 
       return $item;
   }

    function getFilterQuery(Request $request,$type="hourly")
    {
       
//        echo "<pre>";
//        print_r($request->all());
//        echo "</pre>";
        
        $report_type = $request['report_type'];
        
        
//        echo "REPORT = ".$report_type;
//        
//        die();
         $network_cpa_select = $network_cpa_condition = '';
        $check_dates[] = $date = date('Y-m-d'); // current_date
        $check_dates[] = date('Y-m-d', strtotime($date .' -1 day')); // previous_date
        $condition =  $group_by_condition =  $country_flag = '';
        
        if($request->input('daterange'))
        {
            $dateRange = explode(" ",$request->input('daterange'));
            $dtvalue2 = "'".$dateRange[2]."'"; 
            $dtvalue  = "'".$dateRange[0]."'";
            $condition .= "BETWEEN $dtvalue AND $dtvalue2 ";  
        }
        
        $condition .= $this->queryCondition($request->input());

        if(strpos($request->input('country'),',') !== false )
        {
            $condition .= " AND op.country_code IN ('". str_replace(",", "','", $request->input('country'))."')";
        }
        else if($request->input('country') !="")
        {
            $condition .= " AND op.country_code = '".$request->input('country')."'";
        }

        if(strpos($request->input('vertical'),',') !== false )
        {
            $condition .= " AND advertiser_campaigns.vertical IN ('". str_replace(",", "','", $request->input('vertical'))."')";
        }
        else if($request->input('vertical') !="")
        {
            $condition .= " AND advertiser_campaigns.vertical = '".$request->input('vertical')."'";
        }
        
        if($report_type != 'CPICPA')
        {
            $condition .= " AND chr.traffic_type NOT IN ('OM','OG')";
        }
        
        if($report_type == 'CPICPA' && $request->input('vertical') !="CPL")
        {
            $condition .= " AND advertiser_campaigns.vertical NOT IN ('CPL')";
            // $network_cpa_select = " advertiser_campaigns.os_type,advertiser_campaigns.country_code, advertiser_campaigns.offername as pub_offer_name,"; 
            // // $network_cpa_condition = " LEFT JOIN advertiser_campaigns ON advertiser_campaigns.id = chr.parent_cca";
        }

        if($request->input('groupby'))
        {
            $group_by_arr = explode(',',$request->input('groupby'));
            if(in_array('country',$group_by_arr))
            {
                $country_flag = 1; // to check country is coming
                $group_by_condition .= "op.country_code";
                if(($key = array_search('country', $group_by_arr)) !== false) 
                {
                    unset($group_by_arr[$key]);
                }
                if(count($group_by_arr) > 0)
                {
                    $group_by_options = implode(",",$group_by_arr);
                    $group_by_condition .= ", chr.".$group_by_options; 
                }
                $condition .= ' group by '.$group_by_condition;
            }
            else
            {
                $condition .= ' group by chr.'.$request->input('groupby');
            }
        }
        /* Condition is applied only for Group BY Parent CCA condition to fetch network_cpa field */
       
        if($type == 'hourly' && strpos($request->input('groupby'), 'parent_cca') !== false || $request->input('vertical'))
        {
            $network_cpa_select = " ads.network_cpa, ads.pub_offer_name,ads.country_code, "; 
            $network_cpa_condition = "LEFT JOIN ads ON chr.id_ad = ads.id_ad";
        }
        else if($type == 'smart' && strpos($request->input('groupby'), 'parent_cca') !== false || $request->input('vertical'))
        {
            $network_cpa_select = " ads.network_cpa,ads.is_smart_cca,ads.pub_offer_name, ";
            $network_cpa_condition = "LEFT JOIN ads ON chr.parent_cca = ads.id_ad";
        }
        $fields = [
                "chr.id",
                "chr.op_name",
                "chr.id_ad",
                "chr.id_channel",
                "chr.parent_cca",
                "chr.advertiser_campain_name",
                "chr.network_name",
                "chr.advertiser_name",
                "sum(chr.clickcount) as clickcount",
                "sum(chr.sale_count) as sale_count",
                "sum(chr.clicks_active_count) as clicks_active_count",
                "sum(chr.conversion_count) as conversion_count",
                "sum(chr.conversion_count_unique) as conversion_count_unique",
                "sum(chr.revenue_dollar) as revenue_dollar",
                "chr.network_cpa",
                "sum( IF(chr.traffic_type = 'WG' OR chr.traffic_type = 'WM' OR chr.traffic_type = 'SM' OR chr.traffic_type = 'SG',chr.cost_dollar, chr.total_cost)) as total_costv",
                // "sum(chr.total_cost)+sum(chr.cost_dollar)  as total_costv",
                "chr.cr_received",
                "chr.cr_given",
                "chr.hour",
                "chr.total_cost",
                "chr.id_advertiser_campaign",
                "chr.report_type",
                "chr.traffic_type",
             ];

            $allFields = implode(",", $fields);
            if(in_array($dateRange[0],$check_dates))
            {
                // if($request->input('country') !=""  ||  $country_flag == 1){
                $filterresult = DB::SELECT("SELECT $network_cpa_select $allFields, op.country_code FROM crc_records_details chr LEFT  JOIN operator as op ON chr.op_id = op.id $network_cpa_condition 
                    LEFT JOIN advertiser_campaigns ON advertiser_campaigns.id = chr.id_advertiser_campaign
                  WHERE chr.date $condition ORDER BY chr.hour DESC"); 
              /* }else{
                $filterresult = DB::SELECT("SELECT $network_cpa_select $allFields FROM crc_records_details as chr $network_cpa_condition WHERE date $condition ORDER BY chr.hour DESC");
              }*/  
            }
            else
            {
                if($request->input('country') !="" ||  $country_flag == 1)
                {
                    $filterresult = DB::SELECT("SELECT 
                    chr.id,
                    chr.op_name,
                    op.country_code,
                    chr.id_ad, 
                    chr.parent_cca,
                    chr.network_name,
                    sum(chr.clickcount) as clickcount,
                    sum(chr.sale_count) as sale_count,
                    sum(chr.clicks_active_count) as clicks_active_count,
                    sum(chr.conversion_count) as conversion_count,
                    chr.network_cpa,
                    sum(chr.total_cost) as total_costv,
                    sum(chr.revenue_dollar) as revenue_dollar, 
                    chr.cr_received,
                    chr.cr_given,
                    chr.hour,chr.total_cost,
                    chr.id_advertiser_campaign,
                    chr.report_type,
                    FROM crc_records_details chr Left JOIN operator as op ON chr.op_id = op.id WHERE DATE(chr.create_date) $condition ORDER BY chr.hour DESC");
                }
                else
                {
                  //crc_hourly_records
                    $filterresult = DB::SELECT(
                    "SELECT chr.id,"
                        . "chr.op_name,"
                        . "chr.id_ad,"
                        . "chr.network_name,"
                        . "sum(chr.clickcount) as clickcount ,"
                        . "sum(chr.sale_count) as sale_count ,"
                        . "sum(chr.clicks_active_count) as clicks_active_count,"
                        . "sum(chr.conversion_count) as conversion_count,"
                        . "chr.network_cpa,"
                        . "sum(chr.total_cost) as total_costv,"
                       // . "sum(chr.revenue_dollar) as revenue_dollar,"
                        . "chr.cr_received,"
                        . "chr.cr_given,"
                        . "chr.hour,chr.total_cost,"
                        . "chr.id_advertiser_campaign,"
                        . "chr.report_type"
                        . " FROM "
                        . "crc_records_details chr "
                        . " WHERE  "
                        . " DATE(chr.create_date) $condition ORDER BY chr.hour");
                }
            }
        $lastUpdated = $this->lastUpdated();
        $item  = json_encode(array("status"=>'OK',"item"=>$filterresult, 'lastUpdated'=>$lastUpdated));
        return $item;
    }


      public function queryCondition($request){
      $requestAll = $request;
      $condition = "";
      foreach($requestAll as $key=>$value){
          if($key == 'report_type'){
            $condition .= $this->ConditionInOREqual('report_type',$value);
          }
          if($key=='traffic_type'){
            $condition .= $this->ConditionInOREqual('traffic_type',$value);
          }
          if($key=='operator'){ 
               $condition .= $this->ConditionInOREqual('op_id',$value);
          }
          if($key=='network'){ 
               $condition .= $this->ConditionInOREqual('id_channel',$value);
          }
          if($key=='advertiser'){ 
               $condition .= $this->ConditionInOREqual('id_advertiser',$value);
          }
          if($key == 'hour'){ 
               $condition .= $this->ConditionInOREqual('hour',$value);
          }
          if($key=='id_advt'){ 
              $condition .= $this->ConditionInOREqual('id_advertiser_campaign',$value);
          }
          if($key=='parent_cca'){ 
              $condition .= $this->ConditionInOREqual('parent_cca',$value);
          }
          if ($key=='id_ad') {
			    $condition .= $this->ConditionInOREqual('id_ad',$value);
		  }
        }
        return $condition;

      }   
      
      function ConditionInOREqual($key,$value){
          if($value !=""){
          $cond = " AND chr.$key = '".$value."'";
          if(strpos($value, ',') == true ){
             $cond = " AND chr.$key IN ('". str_replace(",", "','", $value)."')";   
          }
          return $cond;
          }
          return false;
      }


     /* return the operators for Opearator dropdown at hour page */   
    public function getOperators(){
        $redis = Redis::connection();
        $key  =  "operators1";
        try {
          if(!$redis->exists($key)){
             $items = $this->getOperatorQuery(); 
             $hourlydata = Redis::set($key, $items);
             $redis->expire($key,5000);
            }else{
            $items = Redis::get($key);
         }
        } catch (\Exception $e) {
            // echo $e->getMessage();
          $items = $this->getOperatorQuery();  
        }
        return $items;
    }

     function getOperatorQuery(){
      $operator_dropdown = [];
      $operatorsResult = DB::select("select operator.id, operator.name, country.iso as cc from operator LEFT JOIN country on operator.country_code=country.iso order by operator.id");
      foreach ($operatorsResult as $dropdown) {
        if ($dropdown->id && $dropdown->name){
            $operator_dropdown[$dropdown->id]['operator'] = $dropdown->name."(".$dropdown->cc.")";
            $operator_dropdown[$dropdown->id]['id'] = $dropdown->id;
          }
        }
        $items = json_encode($operator_dropdown);
        return $items;
     } 

     /* return the operators for networks dropdown at hour page */  
     public function getNetworks(){
        $redis = Redis::connection();
        $key  =  "networks";
        try {
          if(!$redis->exists($key)){
             $items = $this->getNetworkQuery(); 
             $hourlydata = Redis::set($key,$items);
             $redis->expire($key,5000);
            }else{
            $items = Redis::get($key);
         }
        } catch (\Exception $e) {
            // echo $e->getMessage();
          $items = $this->getNetworkQuery();  
        }
        return $items;
    }


    function getNetworkQuery(){
      $network_dropdown = [];
      $networksResult = DB::select("select id,ccz,name from ad_network order by name ASC");
      foreach ($networksResult as $dropdown) {
        if ($dropdown->id && $dropdown->name){
            $network_dropdown[$dropdown->id]['networkWithCCZ'] = $dropdown->name."(".$dropdown->ccz.")";
            $network_dropdown[$dropdown->id]['id'] = $dropdown->id;
            $network_dropdown[$dropdown->id]['network'] = $dropdown->name;
            $network_dropdown[$dropdown->id]['ccz'] = $dropdown->ccz;
          }
        }
        $items = json_encode($network_dropdown);
        return $items;
    }


     /* return the operators for Opearator dropdown at hour page 
      * Date: 4 July 2017
     */  
      public function getAdvertisers(){
        $redis = Redis::connection();
        $date = date('Y-m-d');
        $key  =  "advertisers";
        try {
          if(!$redis->exists($key)){
             $items = $this->getadvertiserQuery(); 
             $hourlydata = Redis::set($key, $items);
             $redis->expire($key,500);
            }else{
            $items = Redis::get($key);
         }
        } catch (\Exception $e) {
            // echo $e->getMessage();
          $items = $this->getadvertiserQuery();  
        }
        return $items;
      }

      function getadvertiserQuery(){
        $advertiserResult = DB::select("SELECT name as advertiser_name, id as id_advertiser_campaign from advertiser group by name ASC");
        foreach ($advertiserResult as $dropdown) {
        if ($dropdown->id_advertiser_campaign && $dropdown->advertiser_name)
        $advertiser_dropdown[$dropdown->id_advertiser_campaign]['advertiser'] = $dropdown->advertiser_name."(".$dropdown->id_advertiser_campaign.")";
        $advertiser_dropdown[$dropdown->id_advertiser_campaign]['id'] = $dropdown->id_advertiser_campaign;
        }
        $items = json_encode($advertiser_dropdown);
        return $items;
      }


      public function getCampaigns(){
        $redis = Redis::connection();
        $key  =  "campaigns";
        try {
          if(!$redis->exists($key)){
             $items = $this->getcampaignQuery(); 
             $hourlydata = Redis::set($key, $items);
             $redis->expire($key,500);
            }else{
            $items = Redis::get($key);
         }
        } catch (\Exception $e) {
            // echo $e->getMessage();
          $items = $this->getcampaignQuery();  
        }
        return $items;
      }

      function getcampaignQuery(){
        $campaignResult = DB::select("select distinct(ac.id),ac.name from advertiser_campaigns as ac INNER JOIN crc_records_details crd ON ac.id = crd.id_advertiser_campaign");
        foreach($campaignResult as $dropdown) {
        if ($dropdown->id && $dropdown->name)
          $campaign_dropdown[$dropdown->id]['name'] = $dropdown->name."(".$dropdown->id.")";
          $campaign_dropdown[$dropdown->id]['id'] = $dropdown->id;
          $items = json_encode(array("status"=>"1","data"=>$campaign_dropdown));
        }
        return $items;
      }

       function lastUpdated(){
        $lastUpdated = DB::select("SELECT max(create_time) as create_time from crc_records_new limit 1");
        $lastUpdated_count = count($lastUpdated);
        if($lastUpdated_count > 0)
          if($lastUpdated[0]->create_time){
          return $lastUpdated[0]->create_time;  
        }
        return "No Update time";  
      }

  }

