<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Users;
use App\Advertisermasking;
use App\Advertiser;
use App\AdvertiserCampaigns;

class MaskinginterfaceControllerbackups extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }



	public function index(Request $request,$type="",$routename = "maskinginterface",$header="Masking Advertiser")
    {	
    	$adDataArray='';

	 
	    	$adDataArray = Advertisermasking::where("status","1")->get();    
	    	$data1=[];
	    	foreach($adDataArray as $key => $value) {
	    		$array=[];

	    		array_push($array,
	    			$value->id,
	    			$value->advertiser_name,
	    			$value->display_name,
	    			$value->created_date);

				array_push($data1, $array);

	    	}
				
	    	 $data1  = array('data1' => $data1);

	    	return view('Masking.advertiserlist')->with($data1);
    }


    // make logic for replace the real advertiser name with masking value ,first change with Ascenso( id is 33 in advertiser table) Advertiser 

    protected function changeadvertisername(Request $request){
    		$advertiser_name='Ascenso';
            
            // $select_advertiser=DB::table('advertiser')->select('id','name')->where('status','1')->limit(10)->get();
            //     $seladvertiser_id  = $seladvertiser_name= [];
            //     $status_update=1;
            // // if(isset($select_advertiser) && !empty($select_advertiser)){
            // // foreach ($select_advertiser as $key => $value) {
            // //     //Insert randum name in  Advertiser masking tables;
            // //     $inert_Advertisermasking = 1;//new Advertisermasking;
            // //     $inert_Advertisermasking->advertiser_id = $value->id;
            // //     $inert_Advertisermasking->advertiser_name = $value->name;
            // //     $inert_Advertisermasking->display_name =$this->random_generator(4);
            // //     $inert_Advertisermasking->display_name = now();
            // //     if($inert_Advertisermasking->save())
            // //     {
            // //             $status_update=1;
            // //     }else{
            // //             $status_update=0;
            // //     }

            // //     }    
            // //  }else{
            // //         $status_update=0;
            // //  }
    
        if($status_update){
            $update_adv_name=1;
        $adDataArray = Advertisermasking::select('advertiser_id','advertiser_name','display_name')->where("status","1")->get();     foreach ($adDataArray as $key => $value) {
            try {
             /* 
                udpate advertiser table name 

             $update_advertiser=DB::table('advertiser')->where('status', 1)
                            ->where('id', $value->advertiser_id)
                            ->update(['name' => $value->display_name]);*/
                    echo $this->find_replace($value->advertiser_id,$value->advertiser_name,$value->display_name);
                }
                 catch (\Illuminate\Database\QueryException $e) {
                        $update_adv_name=0;
                    }
            }

        }

               }



               public  function find_replace($advertiser_id ,$name_like ,$replace_with){
                //select id,id_advertiser, name from advertiser_campaigns where id_advertiser=33 limit 10000
             $find_yes_no = Advertiser::select('advertiser.id as advertiser_id','advertiser.name as advertiser_name','advertiser.create_time as advertiser_create_time','advertiser_campaigns.id as advertiser_campaigns_id','advertiser_campaigns.name as advertiser_campaigns_name','advertiser_campaigns.create_time as advertiser_campaigns_create_timesss')
                  ->leftjoin('advertiser_campaigns','advertiser_campaigns.id_advertiser','=','advertiser.id')
                  ->where('advertiser_campaigns.id_advertiser',$advertiser_id)->where('advertiser.status','1')->orderby('advertiser_campaigns_name')->get();   
                    $data=[];

                    foreach ($find_yes_no as $key => $value) {

                         $results = DB::select( DB::raw("UPDATE advertiser_campaignssss SET name = REPLACE(name, '".$replace_with."', '".$value->advertiser_campaigns_name."') WHERE id='".$value->advertiser_campaigns_id."' and  id_advertiser='".$value->advertiser_id."' and name like '%".$name_like."%';"));

                    }


        }




        public function changeadvertisernameafterweek(Request $req){

            $adDataArray = Advertisermasking::select(DB::raw('date(created_date) as created_date') )->where("status","1")->get(); 

             $datetime1= $adDataArray[0]->created_date;
            // $datetime2=date('Y-m-d');
                $now = time(); // or your date as well
            $interval = strtotime($datetime1)-$now;
                $days = floor($interval / 86400); // 1 day
                if($days <= 7) {
                    echo 'less' .$days;
                    echo "</br>";
                    echo $this->random_generator(4);
                        // $this->changeadvertisername($req);


                }


        }



         function update_insert_new(){


                $inert_Advertisermasking = new Advertisermasking;
                $inert_Advertisermasking->advertiser_id = $value->id;
                $inert_Advertisermasking->advertiser_name = $value->name;
                $inert_Advertisermasking->display_name =$this->random_generator(4);
                $inert_Advertisermasking->display_name = now();
                if($inert_Advertisermasking->save())
                {
                        $status_update=1;
                }else{
                        $status_update=0;
                }


         }   



         function random_generator($digits){
                    srand ((double) microtime() * 10000000);
                    $input = array ("A", "B", "C", "D", "E","F","G","H","I","J","K","L","M","N","O","P","Q",
                    "R","S","T","U","V","W","X","Y","Z");

                    $random_generator="";
                    for($i=1;$i<$digits+1;$i++){ 
                    $rand_index = array_rand($input);
                    $random_generator .=$input[$rand_index];
                    } // end of for loop 


                    return $random_generator;
                    } // end of function




        public function changeadvertisernametables(Request $req){
            foreach(range('A','Z') as $i) {
            foreach(range('A','Z') as $j) { 
            foreach(range('A','Z') as $k) { 
            echo "$i$j$k<br />";
            }
            }
            }

//             $prints = 10;
// $alphas = array_merge(range('A', 'Z'));

// for ($i = 1; $i <= $prints; $i++) {
//   echo "$i\n";
//   foreach ($alphas as $letter) {
//     echo "{$letter} ";
//   }

//   echo "\n\n";
// }



        }



}    



