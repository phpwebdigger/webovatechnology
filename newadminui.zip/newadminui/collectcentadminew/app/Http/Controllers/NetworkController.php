<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\AdNetwork;
use App\Users;
use App\Users1;
use Auth;
use Hash;
use App\PublisherProfile;

class NetworkController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request,$type="",$routename = "networkfilter",$header="Network CR Update")
    {
            $condtion = [];
            $ddCondition = [];
            $dtvalue = $request->start;
            $dtvalue2 = $request->end;
            if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                    $dtvalue2 = date('Y-m-d');
                    $enddate = date('Y-m-d',strtotime("+1 days"));
            }else{
               $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));
            }
            array_push($condtion,['crc_network_campaign_new.create_time','>=',$dtvalue] );
            array_push($condtion,['crc_network_campaign_new.create_time','<=',$enddate] );
            array_push($ddCondition,['crc_network_campaign_new.create_time','>=',$dtvalue] );
            array_push($ddCondition,['crc_network_campaign_new.create_time','<=',$enddate] );

            if($type != "" && $type != "CPS"){
                array_push($condtion,['ads.type','=',strtoupper($type)] );
            }
            $adData = [];
            $adDataArray = "";
            if($type == "CPS"){
              $adDataArray = AdNetwork::where("account_manager","=","anshul.tyagi@collectcent.com")->get(["name"]);
              foreach($adDataArray as $value){
                  if($value->name && (!in_array($value->name, $adData))){
                      array_push($adData, $value->name);
                  }
              }
            }
            if($request->id_channel && $request->id_channel != 0){
                //array_push($condtion,['ads.id_zone','=',1168] );
                array_push($condtion,['ads.id_zone','=',$request->id_channel] );
            }else{
                if($type=="organizr"){
                  array_push($condtion,['ads.id_zone','=','538'] );
                }
            }
            if($request->operator_id){
                array_push($condtion,['ads.cco','=',$request->operator_id] );
            }
            if($request->traffic_type){
              array_push($condtion,['ads.traffic_type','=',$request->traffic_type] );
            }
            if($request->traffic_type){
                
            }
            if($request->country && $request->country !== 0){
             
                array_push($condtion,['ads.country_code','=',$request->country] );

            }
            
            array_push($condtion,["ads.description","!=","default"] );
            array_push($ddCondition,["ads.description","!=","default"] );

            $request->total = $request->total ? $request->total:50;

          $ddData = $this->createDD($request,$type,$ddCondition);
          

          $select =  ["advertiser_campaigns.cpa",
                        "advertiser_campaigns.name as adv_name",
                        "crc_network_campaign_new.conversion_count_unique as conversion_count_unique",
                        "crc_network_campaign_new.parent_cca as id_ad",
                        "ads.network_name as network_name",
                        "ads.id_zone",
                        "ads.cco",
                        "ads.country_code",
                        "ads.operator_name",
                        "ads.traffic_type as traffic_type",
                        "crc_network_campaign_new.total_cost",
                        "crc_network_campaign_new.op_name",
                         //"country.name  cntry",
                        "crc_network_campaign_new.clickcount",
                        "crc_network_campaign_new.conversion_count",
                        "ads.network_cpa",
                        "crc_network_campaign_new.clicks_active_count",
                        "ads.cr_goal as cr_goal",
                        "cr_received as cr_received",
                        "cr_given as cr_given",
                        "crc_network_campaign_new.create_time"];
        
        $appends = [];
         $data =  DB::table("ads")->where($condtion) ->select($select)
                  ->leftJoin("advertiser_campaigns","ads.id_advertiser","=","advertiser_campaigns.id")
                  ->rightJoin("crc_network_campaign_new","crc_network_campaign_new.parent_cca","=","ads.id_ad");
                   if($request->colorder){
                     $data = $data->orderby($request->colorder,$request->order);
                     $appends["colorder"]=$request->colorder;
                     $appends["order"]=$request->order;
                   }else{
                      $data = $data->orderby("network_name","ASC")->orderby("operator_name","ASC");
                      
                   }
                   if(sizeof($adData)>0){
                    $data =  $data->whereIn('ads.network_name', $adData);
                   }

                  $appends['id_channel']=$request->id_channel;
                  $appends['operator_id']=$request->operator_id;
                  $appends['traffic_type']= $request->traffic_type;
                  $appends['country'] = $request->country;
                  $appends['total']=$request->total;
              if($request->total == "all"){
               $data =  $data->get();
              }else{
               $data =  $data->paginate($request->total)->appends($appends);
              }
          $result  = array('data' => $data,
            "routename"=>$routename,
            'header'=>$header,
            'dtvalue' => $dtvalue,
            'dtvalue2' => $dtvalue2,
            'ddData' => $ddData,
            'id_channel'=>$request->id_channel,
            'operator_id'=>$request->operator_id,
            'traffic_type' => $request->traffic_type,
            'country'=> $request->country,
            'total'=>$request->total
          );
         if(sizeof($adData)>0){
              $viewPage = "network.network_cr_update_cps";
         }else{
               $viewPage = "network.network_cr_update";
         }

         return view($viewPage)->with($result);

    }


      public function index_single(Request $request, $id_ad,$type="CPA" ,$routename = "network-wise-record-filter",$header="CR Update")
      {


            $condtion = [];
            $dtvalue = $request->start;
            $dtvalue2 = $request->end;
            
            
            if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                    $dtvalue2 = date('Y-m-d');
                    $enddate = date('Y-m-d',strtotime("+1 days"));
            }else{
                //$dtvalue2 = date('Y-m-d',strtotime("+1 days"));
               $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));

            }
            
            

            array_push($condtion,['crc_records_new.create_time','>=',$dtvalue] );
            array_push($condtion,['crc_records_new.create_time','<=',$enddate] );
           

            if($type != "CPICPA"){
                
                array_push($condtion,['report_type','=',strtoupper($type)] );
            }


            if($id_ad && $id_ad!=0){
                array_push($condtion,['crc_records_new.parent_cca','=',$id_ad] );
            }
            if($request->id_advertiser_campaign){
                array_push($condtion,['crc_records_new.id_advertiser_campaign','=',$request->id_advertiser_campaign] );
               // dd($condtion);
            }
            
$select = ["advertiser_vw.advertiser_campaign_cpa",
            "advertiser_vw.id_advertiser_campaign as curcampid",
            "advertiser_vw.advertiser_campaign_name as name",
            "crc_records_new.network_name",
            "advertiser_vw.operator_name as op_name",
            "crc_records_new.id_advertiser_campaign",
            "crc_records_new.total_cost",
            "crc_records_new.id_ad",
            "crc_records_new.id_channel",
            "crc_records_new.clickcount",
            "crc_records_new.conversion_count",
            "crc_records_new.clicks_active_count",
            "crc_records_new.cr_goal AS cr_goal",
            "crc_records_new.cr_received AS cr_received",
            "crc_records_new.cr_given AS cr_given",
            "crc_records_new.create_time"]; 


          $data =  DB::table("crc_records_new")
                ->where($condtion) 
                ->select($select)
                ->leftJoin("advertiser_vw","advertiser_vw.id_advertiser_campaign","=","crc_records_new.id_advertiser_campaign")
                ->orderby("crc_records_new.id_ad","ASC")->get();

          $result  = array('data' => $data,
            "routename"=>$routename,
            'header'=>$header,
            'dtvalue' => $dtvalue,
            'id'=>$id_ad,
            'dtvalue2' => $dtvalue2
          );

        return view('network.network_cr_update_single')->with($result);

     }

     private function createDD(Request $request,$type,$condition){

        $select = ["crc_network_campaign_new.parent_cca as id_ad"
                    ,"ads.network_name"
                    ,"country.name as cntry"
                    ,"crc_network_campaign_new.conversion_count_unique as unique_conversion_count"
                    ,"ads.id_zone"
                    ,"ads.traffic_type"
                    ,"ads.country_code"
                    ,"ads.cco"
                    ,"ads.operator_name"
                    ,"crc_network_campaign_new.total_cost"
                    ,"crc_network_campaign_new.op_name"
                    ,"crc_network_campaign_new.clickcount"
                    ,"crc_network_campaign_new.conversion_count"
                    ,"ads.network_cpa"
                    ,"crc_network_campaign_new.clicks_active_count"
                    ,"ads.cr_goal as cr_goal"
                    ,"cr_received"
                    ,"cr_given"
                    ,"crc_network_campaign_new.create_time"];

          $data =  DB::table("ads")
          ->where($condition) 
         ->select($select)
         ->rightJoin("crc_network_campaign_new","crc_network_campaign_new.parent_cca","=","ads.id_ad")
         ->leftJoin("country","ads.country_code","=","country.iso")
         ->orderby("network_name","ASC")
         ->orderby("operator_name","ASC")->get();
        
        
         $ddDataResult  = array(
                'network_dropdown' => [],
                'country_dropdown' => [],
                'operator_dropdown' => [],
                'idad_dropdown' => [],
                'traffictype_dropdown' => []
            );
         foreach ($data as $dropdown) {

            if ($dropdown->id_zone){
                $ddDataResult['network_dropdown'][$dropdown->id_zone] = $dropdown->network_name;
            }
            if ($dropdown->country_code){
                 $ddDataResult['country_dropdown'][$dropdown->country_code] = $dropdown->country_code."(".$dropdown->cntry.")";
             }
            if ($dropdown->cco && $dropdown->operator_name){
                  $ddDataResult['operator_dropdown'][$dropdown->cco] = $dropdown->operator_name."(".$dropdown->country_code.")";
            }
            if ($dropdown->id_ad){
                   $ddDataResult['idad_dropdown'][$dropdown->id_ad] = $dropdown->id_ad;
            }
            if($dropdown->traffic_type){
               $ddDataResult['traffictype_dropdown'][$dropdown->traffic_type] = $dropdown->traffic_type;
            }
          }
          
        return $ddDataResult;
     }

 private function createDDCareer(Request $request,$type,$condition){


     $select = ["crc_network_campaign_new.parent_cca as id_ad",
     "ads.network_name",
     "ads.id_zone"
    ,"ads.traffic_type"
    ,"ads.country_code"
    ,"ads.cco"
    ,"ads.operator_name"
    ,"crc_network_campaign_new.op_name"
    ,"ads.network_cpa"
    ,"country.name as cntry"];

 

if($type == "A"){
            $data =  DB::table("ads")
            ->whereIn('ads.traffic_type', ['A','IG'])
            ->whereNotIn('ads.cco',['-1','33'])
            ->select($select)
            ->rightJoin("crc_network_campaign_new","crc_network_campaign_new.parent_cca","=","ads.id_ad")
            ->leftJoin("country","ads.country_code","=","country.iso")
              ->where($condition) 
            ->orderby("network_name","ASC")
            ->orderby("operator_name","ASC")->get();
        

}
else if($type == "Rotator"){
            $data =  DB::table("ads")
            ->whereIn('ads.traffic_type', ['WM','WG'])
            ->select($select)
            ->rightJoin("crc_network_campaign_new","crc_network_campaign_new.parent_cca","=","ads.id_ad")
            ->leftJoin("country","ads.country_code","=","country.iso")
              ->where($condition) 
            ->orderby("network_name","ASC")
            ->orderby("operator_name","ASC")->get();
        
}
else if($type == "C"){
            $data =  DB::table("ads")
            ->whereIn('ads.traffic_type', ['C','I'])
            ->whereNotIn('ads.cco',['-1','33'])
            ->select($select)
            ->rightJoin("crc_network_campaign_new","crc_network_campaign_new.parent_cca","=","ads.id_ad")
            ->leftJoin("country","ads.country_code","=","country.iso")
              ->where($condition) 
            ->orderby("network_name","ASC")
            ->orderby("operator_name","ASC")->get();
        

}

else if($type == "WIFIA"){
   $data =  DB::table("ads")
            ->whereIn('ads.traffic_type', ['A','IG'])
            ->select($select)
            ->rightJoin("crc_network_campaign_new","crc_network_campaign_new.parent_cca","=","ads.id_ad")
            ->leftJoin("country","ads.country_code","=","country.iso")
              ->where($condition) 
            ->orderby("network_name","ASC")
            ->orderby("operator_name","ASC")->get();

}
else if($type == "WIFIC"){
   $data =  DB::table("ads")
            ->whereIn('ads.traffic_type', ['C','I'])
            ->select($select)
            ->rightJoin("crc_network_campaign_new","crc_network_campaign_new.parent_cca","=","ads.id_ad")
            ->leftJoin("country","ads.country_code","=","country.iso")
              ->where($condition) 
            ->orderby("network_name","ASC")
            ->orderby("operator_name","ASC")->get();

}
else{
             $data =  DB::table("ads")
              ->whereIn('ads.traffic_type', ['C','I'])
              ->select($select)
         ->rightJoin("crc_network_campaign_new","crc_network_campaign_new.parent_cca","=","ads.id_ad")
         ->leftJoin("country","ads.country_code","=","country.iso")
         ->where($condition) 
         ->orderby("network_name","ASC")
         ->orderby("operator_name","ASC")->get();
        

}
         $ddDataResult  = array(
                'network_dropdown' => [],
                'country_dropdown' => [],
                'operator_dropdown' => [],
                'idad_dropdown' => [],
                'traffictype_dropdown' => []
            );

        
         foreach ($data as $dropdown) {

            if ($dropdown->id_zone){
                $ddDataResult['network_dropdown'][$dropdown->id_zone] = $dropdown->network_name;
            }
            if ($dropdown->country_code){
                 $ddDataResult['country_dropdown'][$dropdown->country_code] = $dropdown->country_code."(".$dropdown->cntry.")";
             }
            if ($dropdown->cco && $dropdown->operator_name){
                  $ddDataResult['operator_dropdown'][$dropdown->cco] = $dropdown->operator_name."(".$dropdown->country_code.")";
            }
            if ($dropdown->id_ad){
                   $ddDataResult['idad_dropdown'][$dropdown->id_ad] = $dropdown->id_ad;
            }
            if($dropdown->traffic_type){
               $ddDataResult['traffictype_dropdown'][$dropdown->traffic_type] = $dropdown->traffic_type;
            }
          }
          
        return $ddDataResult;

$query_for_dropdown = mysql_query($query_insert_drop);

while ($dropdown = mysql_fetch_array($query_for_dropdown)) {


    if ($dropdown['id_zone'])
        $network_dropdown[$dropdown['id_zone']] = $dropdown['network_name'];
    if ($dropdown['country_code'])
        $country_dropdown[$dropdown['country_code']] = $dropdown['country_code']."(".$dropdown['cntry'].")";
    if ($dropdown['cco'] && $dropdown['operator_name'])
        $operator_dropdown[$dropdown['cco']] = $dropdown['operator_name']."(".$dropdown['country_code'].")";
    if ($dropdown['id_ad'])
        $idad_dropdown[$dropdown['id_ad']] = $dropdown['id_ad'];
    if ($dropdown['traffic_type'])
        $traffictype_dropdown[$dropdown['traffic_type']] = $dropdown['traffic_type'];
}

}


     public function cpa_cr_update(Request $request){

        return $this->index($request,"CPA","networkfilterCPA","CPA Cr Update");

     }
     public function organizr_cr_update(Request $request){

        return $this->index($request,"organizr","networkfilterOrganizr","Organizr Report");

     }
     public function cps_cr_update(Request $request){

        return $this->index($request,"CPS","networkfilterCPS","CPS Cr Update");

     }
     public function index_back_campaign(Request $request,$routename = "backCompaignFilter",$header="CR Back Update"){

            $condtion = [];
            
            $dtvalue = $request->start;
            $dtvalue2 = $request->end;
            
            
            if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                    $dtvalue2 = date('Y-m-d');
                    $enddate = date('Y-m-d',strtotime("+1 days"));
            }else{
                //$dtvalue2 = date('Y-m-d',strtotime("+1 days"));
               $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));

            }
            
            

            array_push($condtion,['crc_network_campaign_new.create_time','>=',$dtvalue] );
            array_push($condtion,['crc_network_campaign_new.create_time','<=',$enddate] );
            array_push($condtion,['report_type','=',"CPA"] );
            
             $select =  "advertiser_campaigns.cpa"
                        .",advertiser_campaigns.name as adv_name"
                        .",crc_network_campaign_new.conversion_count_unique as conversion_count_unique,"
                        . "ads.network_name,"
                        . "crc_network_campaign_new.parent_cca as id_ad,"
                        . "ads.id_zone,"
                        . "ads.cco,"
                        . "ads.country_code,"
                        . "ads.operator_name,"
                        . "ads.traffic_type,"
                        . "crc_network_campaign_new.total_cost,"
                        . "crc_network_campaign_new.op_name,"
                        . "country.name as cntry,"
                        . "crc_network_campaign_new.clickcount,"
                        . "crc_network_campaign_new.conversion_count,"
                        . "ads.network_cpa,"
                        . "crc_network_campaign_new.clicks_active_count,"
                        . "concat(ads.cr_goal,'%') as cr_goal,"
                        . "concat(cr_received,'%') as cr_received,"
                        . "concat(cr_given,'%') as cr_given,"
                        . "crc_network_campaign_new.create_time";
       
             $data =  DB::table("ads")
              ->whereIn('crc_network_campaign_new.parent_cca', ['4623','4779','4780','4834','4835'])
              ->where($condtion) 
             ->selectRaw(DB::raw($select))
             ->leftJoin("advertiser_campaigns","ads.id_advertiser","=","advertiser_campaigns.id")
             ->leftJoin("country","ads.country_code","=","country.iso")
             ->rightJoin("crc_network_campaign_new","crc_network_campaign_new.parent_cca","=","ads.id_ad")
             ->groupby("crc_network_campaign_new.parent_cca")
             ->orderby("network_name","ASC")
             ->orderby("operator_name","ASC")
             ->paginate(20);
       
        // dd($data);
         $result  = array('data' => $data,
            "routename"=>$routename,
            'header'=>$header,
            'dtvalue' => $dtvalue,
            'dtvalue2' => $dtvalue2
          );

         return view('network.network_cr_update_back')->with($result);


     }


      public function cpi_cr_update(Request $request){

        return $this->index($request,"CPI","networkfilterCPI","CPI Cr Update");

     }
    public function cpicpa_cr_update(Request $request){

        return $this->index($request,"CPICPA","networkfilterCPICPA","CPICPA Cr Update");

     }





     //cariar specific routes
    public function CarrierIndexA(Request $request,$type="A",$routename = "homeCariarFilter",$header="CR Update WG")
    {


            $condtion = [];
            $ddCondition = [];
            $dtvalue = $request->start;
            $dtvalue2 = $request->end;
            
            
            if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                    $dtvalue2 = date('Y-m-d');
                    $enddate = date('Y-m-d',strtotime("+1 days"));
            }else{
                //$dtvalue2 = date('Y-m-d',strtotime("+1 days"));
               $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));

            }
            
            

            array_push($condtion,['crc_records_new.create_time','>=',$dtvalue] );
            array_push($condtion,['crc_records_new.create_time','<=',$enddate] );
            array_push($ddCondition,['create_time','>=',$dtvalue] );
            array_push($ddCondition,['create_time','<=',$enddate] );



            if($request->id_channel){
                array_push($condtion,['ads.id_zone','=',$request->id_channel] );
            }
            if($request->operator_id){
                array_push($condtion,['ads.cco','=',$request->operator_id] );
               
            }
            if($request->traffic_type){
                array_push($condtion,['ads.traffic_type','=',$request->traffic_type] );

            }
        
            array_push($condtion,["ads.description","!=","'default'"] );
            array_push($ddCondition,["ads.description","!=","'default'"] );
            $request->total = $request->total ? $request->total : 50;
            
             $select =  "advertiser_campaigns.cpa"
                        .",advertiser_campaigns.name as adv_name"
                        .",sum(crc_records_new.conversion_count_unique) as conversion_count_unique "
                        .",crc_records_new.id_ad as id_ad"
                        .",ads.network_name"
                        .",ads.id_zone"
                        .",ads.cco"
                        .",ads.country_code"
                        .",ads.operator_name"
                        .",ads.traffic_type"
                        .",sum(crc_records_new.total_cost) as total_cost"
                        .",crc_records_new.op_name"
                        .",sum(crc_records_new.clickcount) as clickcount"
                        .",sum(crc_records_new.conversion_count) as conversion_count"
                        .",ads.network_cpa"
                        .",sum(crc_records_new.revenue_dollar) as revenue_dollar"
                        .",sum(crc_records_new.cost_dollar) as cost_dollar"
                        .",sum(crc_records_new.clicks_active_count) as clicks_active_count"
                        .",concat(ads.cr_goal,'%') as cr_goal"
                        .",concat(round(AVG(cr_received),2),'%') as cr_received"
                        .",concat(round(AVG(cr_given),2),'%') as cr_given"
                        .",crc_records_new.create_time as create_time";
        $appends = [];


        if($type == "A"){
        
              $data =  DB::table("ads")
              ->whereIn('ads.traffic_type', ['A','IG'])
              ->whereNotIn('ads.cco',['-1','33'])
              ->where($condtion) 
             ->selectRaw(DB::raw($select))
             ->leftJoin("advertiser_campaigns","ads.id_advertiser","=","advertiser_campaigns.id")
             ->leftJoin("crc_records_new","crc_records_new.id_ad","=","ads.id_ad")
             ->groupby("crc_records_new.id_ad");
             
              if($request->colorder){
                 $data = $data->orderby($request->colorder,$request->order);
                 $appends["colorder"]=$request->colorder;
                 $appends["order"]=$request->order;
              }else{
                 $data = $data->orderby("ads.network_name","ASC");
                 $data = $data->orderby("ads.operator_name","ASC");
              
               }
            
             if($request->total == "all"){
               $data =  $data->get();
            }else{
               $data =  $data->paginate($request->total)->appends($appends);
         
            }



        }
        else if($type == "Rotator"){
        
              $data =  DB::table("ads")
              ->whereIn('ads.traffic_type', ['WM','WG'])
              ->where($condtion) 
             ->selectRaw(DB::raw($select))
             ->leftJoin("advertiser_campaigns","ads.id_advertiser","=","advertiser_campaigns.id")
             ->leftJoin("crc_records_new","crc_records_new.id_ad","=","ads.id_ad")
             ->groupby("crc_records_new.id_ad");
             
              if($request->colorder){
                 $data = $data->orderby($request->colorder,$request->order);
                 $appends["colorder"]=$request->colorder;
                 $appends["order"]=$request->order;
              }else{
                 $data = $data->orderby("ads.network_name","ASC");
                 $data = $data->orderby("ads.operator_name","ASC");
              
               }
            
            if($request->total == "all"){
               $data =  $data->get();
            }else{
               $data =  $data->paginate($request->total)->appends($appends);
         
            }



        }
        else if($type == "C"){

             $data =  DB::table("ads")
              ->whereIn('ads.traffic_type', ['C','I'])
              ->whereNotIn('ads.cco',['-1','33'])
              ->where($condtion) 
             ->selectRaw(DB::raw($select))
             ->leftJoin("advertiser_campaigns","ads.id_advertiser","=","advertiser_campaigns.id")
             ->leftJoin("crc_records_new","crc_records_new.id_ad","=","ads.id_ad")
             ->groupby("crc_records_new.id_ad");
             
              if($request->colorder){
                 $data = $data->orderby($request->colorder,$request->order);
                 $appends["colorder"]=$request->colorder;
                 $appends["order"]=$request->order;
              }else{
                 $data = $data->orderby("ads.network_name","ASC");
                 $data = $data->orderby("ads.operator_name","ASC");
              
               }
            
              if($request->total == "all"){
                   $data =  $data->get();
                }else{
                   $data =  $data->paginate($request->total)->appends($appends);
             
                }


             //$data = $data->get();
             

    }
    else if($type=="WIFIA"){
            array_push($condtion, ["ads.cco","=","33"]);
            array_push($condtion, ["crc_records_new.op_id","=","33"]);
            array_push($ddCondition, ["ads.cco","=","33"]);


            $data =  DB::table("ads")
              ->where($condtion) 
              ->whereIn('ads.traffic_type', ['A','IG'])
             ->selectRaw(DB::raw($select))
             ->leftJoin("advertiser_campaigns","ads.id_advertiser","=","advertiser_campaigns.id")
             ->leftJoin("crc_records_new","crc_records_new.id_ad","=","ads.id_ad")
             ->groupby("crc_records_new.id_ad");
             
              if($request->colorder){
                 $data = $data->orderby($request->colorder,$request->order);
                 $appends["colorder"]=$request->colorder;
                 $appends["order"]=$request->order;
              }else{
                 $data = $data->orderby("crc_records_new.clickcount","DESC");
                 $data = $data->orderby("ads.network_name","ASC");
                 $data = $data->orderby("ads.operator_name","ASC");
              
               }
            
              if($request->total == "all"){
               $data =  $data->get();
            }else{
               $data =  $data->paginate($request->total)->appends($appends);
         
            }
        }
    else{
          
            array_push($condtion, ["ads.cco","=","33"]);
            array_push($condtion, ["crc_records_new.op_id","=","33"]);
            array_push($ddCondition, ["ads.cco","=","33"]);

            $data =  DB::table("ads")
              ->where($condtion) 
              ->whereIn('ads.traffic_type', ['C','I'])
             ->selectRaw(DB::raw($select))
             ->leftJoin("advertiser_campaigns","ads.id_advertiser","=","advertiser_campaigns.id")
             ->leftJoin("crc_records_new","crc_records_new.id_ad","=","ads.id_ad")
             ->groupby("crc_records_new.id_ad");
             if($request->colorder){
                 $data = $data->orderby($request->colorder,$request->order);
                 $appends["colorder"]=$request->colorder;
                 $appends["order"]=$request->order;
              }else{
                 $data = $data->orderby("crc_records_new.clickcount","DESC");
                 $data = $data->orderby("ads.network_name","ASC");
                 $data = $data->orderby("ads.operator_name","ASC");
              
               }
              if($request->total == "all"){
               $data =  $data->get();
            }else{
               $data =  $data->paginate($request->total)->appends($appends);
         
            }
        }

        $appends['id_channel']=$request->id_channel;
        $appends['operator_id']=$request->operator_id;
        $appends['traffic_type']= $request->traffic_type;
        $appends['country'] = $request->country;
        $appends['total']=$request->total;
        
         $ddData = $this->createDDCareer($request,$type,$ddCondition);
        // dd($data);
         $result  = array('data' => $data,
            "routename"=>$routename,
            'header'=>$header,
            'dtvalue' => $dtvalue,
            'dtvalue2' => $dtvalue2,
            'ddData' => $ddData,
            'id_channel'=>$request->id_channel,
            'operator_id'=>$request->operator_id,
            'traffic_type' => $request->traffic_type,
            'country'=> $request->country,
            'total'=>$request->total
          );

         return view('network.network_cr_update_cariar')->with($result);


     }
      //cariar specific routes
    public function CarrierIndexA_single(Request $request,$id,$type="",$routename = "carrier-specific-network-wise-record-filter",$header="CR Update WG")
    {


            $condtion = [];
            $dtvalue = $request->start;
            $dtvalue2 = $request->end;
            
            
            if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                    $dtvalue2 = date('Y-m-d');
                    $enddate = date('Y-m-d',strtotime("+1 days"));
            }else{
                //$dtvalue2 = date('Y-m-d',strtotime("+1 days"));
               $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));

            }
            
            

            array_push($condtion,['crc_records_new.create_time','>=',$dtvalue] );
            array_push($condtion,['crc_records_new.create_time','<=',$enddate] );
            
            if($id){
                array_push($condtion,['crc_records_new.id_ad','=',$id] );
            }
            if($request->id_advertiser_campaign){
                array_push($condtion,['crc_records.id_advertiser_campaign','=',$request->id_advertiser_campaign] );
               // dd($condtion);
            }
          
           $select = "advertiser_vw.advertiser_campaign_cpa"
                     .",advertiser_vw.advertiser_campaign_name as name"
                     .",crc_records_new.network_name"
                     .",crc_records_new.parent_cca"
                     .",crc_records_new.id_advertiser_campaign"
                     .",sum(crc_records_new.total_cost) as total_cost"
                     .",crc_records_new.id_ad"
                     .",sum(crc_records_new.revenue_dollar) as revenue_dollar"
                     .",sum(crc_records_new.conversion_count_unique) as conversion_count_unique"
                     .",crc_records_new.id_channel"
                     .",sum(crc_records_new.clickcount) as clickcount" 
                 .",sum(crc_records_new.conversion_count) as conversion_count" 
                 .",sum(crc_records_new.clicks_active_count) as clicks_active_count"  
                 .",crc_records_new.create_time";
  
             $data =  DB::table("crc_records_new")
              ->where($condtion) 
             ->selectRaw(DB::raw($select))
             ->leftJoin("advertiser_vw","crc_records_new.id_advertiser_campaign","=","advertiser_vw.id_advertiser_campaign")
             ->groupby("advertiser_vw.id_advertiser_campaign")
             ->orderby("advertiser_vw.advertiser_campaign_name","ASC")
             ->get();
        // dd($data);
         $result  = array('data' => $data,
            "routename"=>$routename,
            'header'=>$header,
            'id'=>$id,
            'dtvalue' => $dtvalue,
            'dtvalue2' => $dtvalue2
          );
        

         return view('network.network_cr_update_cariar_single')->with($result);


     }
     public function CarrierIndexC(Request $request){
        return $this->CarrierIndexA($request,"C","homeCariarFilterC","CR Update WM");
     }
     public function CarrierIndexRotator(Request $request){
        return $this->CarrierIndexA($request,"Rotator","homeCariarFilterRotator","Rotator CR Update");
     }

     public function CarrierIndexWIFIA(Request $request){
        return $this->CarrierIndexA($request,"WIFIA","homeCariarFilterWIFIA","CR Update WG");
     }
     public function CarrierIndexWIFIC(Request $request){
        return $this->CarrierIndexA($request,"WIFIC","homeCariarFilterWIFIC","CR Update WM");
     }

      function getNetworkList(Request $request) 
     {
       $user = Auth::user();
      // print_r($user);

        $select =  ["ad_network.name as network_name",
                        "ad_network.ccz as ccz",
                        "ad_network.token_key as token_key",
                        "ad_network.clickid_parameter as clickid_parameter",
                        "ad_network.create_time as create_time",
                        "ad_network.account_manager as account_manager",
                        "ad_network.create_time as create_time",
                        "ad_network.status as status",
                        "ad_network.id"];
        $data =  AdNetwork::with('User')->select($select);   
           if(!empty($user->role_id) && $user->role_id=='12' ){
            $data->where('ad_network.account_manager',$user->email);
           }

          $data= $data->orderBy('ad_network.id', 'ASC')
           ->get();

        $data1 = [];
        $stat = '';
        foreach ($data as $fetch_records)
        {

            $array = [];
            if($fetch_records->status==1)
            {
                $stat = 'Active';
            }
            else
            {
                $stat = 'Inactive';
            }

            array_push($array,
                $fetch_records->network_name,
                $fetch_records->ccz,
                $fetch_records->token_key,
                $fetch_records->clickid_parameter,
                $fetch_records->account_manager,
                $fetch_records->create_time,
                $stat,
                '<a href="/network/edit/'.$fetch_records->id.'"><button type="button" class="btn btn-danger btn-circle "><i class="fa fa-edit"></i></button></a>'
                );
            array_push($data1, $array);

        }
        $result  = array('data1' => $data1);
         
//        return view('/Resources.NetworkList',['network' => $result]);
        return view('Resources.NetworkList')->with($result);
    }
        function showaddnetworkview()
        {
           $user = Auth::user();
           $role_id = $user->role_id;
           $user_email = $user->email;
            return view ('Resources.addnetwork', ['role_id' =>$role_id,'user_email'=>$user_email]);
        }

        function AddNetwork(Request $request)
        {

            $rst =$this->getlastccz(); 
            $ccz = $rst + 1;
            $data  = array(
                'name' => $request->network_name,
                'clickid_parameter'=> $request->clickid,
                'billing_trafficker'=> $request->billing,
                'account_manager'=> $request->account_manager,
                'ccz'=> $ccz);

            AdNetwork::create($data);
            return redirect('/Resources/list-network');
        }

        function getlastccz(){
        //  $order = AdNetwork::select('max(ccz) as last_ccz')->whereRaw('id = (select max(`id`) from orders)')->get();
          $last_idzone=0;
          $orderby = AdNetwork::selectRaw('max(ccz) as last_ccz')->get();
            
            foreach ($orderby as $user) {
                $last_idzone=$user->last_ccz;//echo $user->name;
            }
          

          return $last_idzone;
        }


    function editNetwork($id)
        {
           $user = Auth::user();
           $role_id = $user->role_id;
           $user_email = $user->email;
          $network=AdNetwork::find($id);
        return view ('Resources.editnetwork',compact('network','role_id','user_email'));
        }
    public function update(Request $request)
    {
    
        $manager = is_array($request->account_manager)?implode(', ', $request->account_manager):$request->account_manager;
//        $manager = "'" . implode ( "', '", $request->account_manager ) . "'";

        
//        echo "MANGER = ".$manager;
//        
//        echo "<pre>";
//        print_r($request->all());
//        echo "</pre>";
//        die();
        
        $network=AdNetwork::find($request->id);
        $network->name = $request->network_name;
        $network->ccz = $request->ccz;
        $network->token_key = $request->token_key;
        $network->clickid_parameter = $request->clickid;
        $network->account_manager = $manager;
        $network->billing_trafficker = $request->billing;
        $network->status = $request->status;
        $network->save();

        return redirect('/Resources/list-network');
        
    }

    public function publisher_cr_index(Request $request){
            
            $condtion = [];
            $dtvalue = $request->start;
            $dtvalue2 = $request->end;
    
            if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                    $dtvalue2 = date('Y-m-d');
                    $enddate = date('Y-m-d',strtotime("+1 days"));
            }else{
                //$dtvalue2 = date('Y-m-d',strtotime("+1 days"));
               $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));

            }
            
            

            array_push($condtion,['create_time','>=',$dtvalue] );
            array_push($condtion,['create_time','<=',$enddate] );
            
            
            array_push($condtion,['report_type','=',"CPA"] );

 
            $select = ["network_name",
                    "total_cost",
                    "op_name",
                    "id_channel",
                    "clickcount",
                    "conversion_count",
                    "network_cpa",
                    "clicks_active_count",
                    "cr_goal AS cr_goal",
                    "cr_received AS cr_receivedrc.cr_given AS cr_given",
                    "create_time"];

            $data =  DB::table("crc_network")
                    ->where($condtion) 
                    ->select($select)
                    ->orderby("network_name","ASC")
                    ->orderby("op_name","ASC")
                    ->get();

        
         $result  = array('data' => $data,
            "routename"=>"publisherCrFilter",
            'header'=>"Publisher CR Update",
            'dtvalue'=>$dtvalue,
            'dtvalue2'=>$dtvalue2
          );

         return view('network.publisher_cr_update')->with($result);

        }
        
    public function publisherlist(Request $request)
    {

        $user = Auth::user();
      // print_r($user);

        $select =  ["ad_network.name as network_name",
                        "ad_network.ccz as ccz",
                        "ad_network.token_key as token_key",
                        "ad_network.clickid_parameter as clickid_parameter",
                        "ad_network.create_time as create_time",
                        "ad_network.account_manager as account_manager",
                        "ad_network.create_time as create_time",
                        "ad_network.status as status",
                        "ad_network.id"];
        $data =  AdNetwork::with('User')->select($select);   
           if(!empty($user->role_id) && $user->role_id=='12' ){
            $data->where('ad_network.account_manager',$user->email);
           }

          $data= $data->orderBy('ad_network.id', 'ASC')
           ->get();

        $data1 = [];
        $stat = '';
        foreach ($data as $fetch_records)
        {

            $array = [];
            if($fetch_records->status==1)
            {
                $stat = 'Active';
            }
            else
            {
                $stat = 'Inactive';
            }

            array_push($array,
                $fetch_records->network_name,
                $fetch_records->ccz,
                $fetch_records->token_key,
                $fetch_records->clickid_parameter,
                $fetch_records->account_manager,
                $fetch_records->create_time,
                $stat,
                '<a href="/edit-publisher/'.$fetch_records->ccz.'"><button type="button" class="btn btn-danger btn-circle "><i class="fa fa-edit"></i></button></a>'
                );
            array_push($data1, $array);

        }
        $result  = array('data1' => $data1);
         
        return view('offers.publisherlist')->with($result);
    }
    
    public function editpublisher(Request $request)
    {

        $user = Auth::user();
      // print_r($user);

//        echo "<pre>";
//        print_r($request->all());
//        echo "</pre>";
        
        $zone = $request->ccz;
        
        
//        die();
        $select =  ["admin_id"];
        $data =  DB::table("publisher_profile")
                    ->where('ccz',$zone) 
                    ->select($select)
                    ->get();
        
        
        
        $admin_id = $data[0]->admin_id;
        
//        $data =  PublisherProfile::select($select)->where('ccz',$zone);
        
//        echo "<pre>";
//        print_r($data);
//        echo "</pre>";
        
        $user_data =  DB::table("users1")
                    ->where('id',$admin_id) 
                    ->select('*')
                    ->get();
//        echo "<pre>";
//        print_r($user_data);
//        echo "</pre>";      
//        die();
        
           
         
        return view('offers.editpublisher')->with(['publisher'=>$user_data[0],'user_id'=>$admin_id, 'id_zone'=>$zone]);
    }
    
    public function dopublisheredit(Request $request)
    {

//        echo "<pre>";
//        print_r($request->all());
//        echo "</pre>";
        
        
//        echo "ID = ".$request->pub_id;
//        die();

        $this->user =  \Auth::user();
          
        $posturl = $request->globalpost;
        $id_zone = $request->id_zone;
        
//        echo "<br>";
//        echo "POSTBACK = ".$posturl;
//        
//        die();
        
        if(strpos($posturl, '__NETWORKTOKEN__') ==false  ) 
        {
            return redirect()->back()->with('posturl', 'Your postback URL :'.$posturl.' does not contians __NETWORKTOKEN__ ');

        }
        else
        {
            $update = DB::table('users1')->where('id', $request->pub_id)->take(1)
                ->update(array('global_postback'=>$request->globalpost));
            
//                DB::table('cron_config')->where('ccz', $id_zone)->update(array('network_callback_url'=>$posturl));
//
//                DB::table('config_delivery')->where('id_zone', $id_zone)->update(array('post_back_url'=>$posturl));

            return redirect()->to('publisherlist')->send()->with('publishersuccess', 'Publisher Updated successfully.');

        }


        

//
//      $checkpubemail = Users1::where(
//        'id', '!=' ,$request->pub_id)->get()->toArray(); 
//
//        if(!empty($checkpubemail))
//        {
//        return redirect()->back()->with('pubemailis', 'This email is already exits use another.');
//
//        }
//
//
//
//       $quickRandom =$this->quickRandom(16);
//
//            $publisher = Users1::take(1)->find($request->pub_id);
//
//            if(empty($request->phone))
//            {
//              $request->phone="123456";
//            }
//
//          $publisher->name=$request->pubname;
//          $publisher->email=$request->email;
//          //$publisher->password=Hash::make($request->password);
//          $publisher->user_type = "publisher";
//          $publisher->msisdn = $request->phone;
//          $publisher->company_name=$request->company;
//          $publisher->skype_id = $request->skype_id;
//          $publisher->status = 'active';
//          $publisher->address=$request->address;
//          $publisher->created_at = date("Y:m:d H:i:s");;
//          $publisher->user_token = "";
//          $publisher->api_name = $request->apiname;
//          if($this->user->email=='fozilmedia@collectcent.com'){
//            $publisher->addedbyofferwall='3';
//             }else{
//                $publisher->addedbyofferwall='1'; 
//             }
//          $publisher->global_postback=$request->globalpost;
//          $publisher->clickid_parameter=$request->clickparameter;
//          $publisher->save();
//          $publisher_id = $publisher->id;
//
//
//            $requestArr['company_name'] = $publisher->company_name;
//            $requestArr['msisdn'] = $publisher->msisdn;
//            $requestArr['skype'] = $publisher->skype_id;
//            $requestArr['address'] = $publisher->address;
//
//        DB::table('publisher_profile')->where('admin_id', $request->pub_id)->take(1)
//        ->update(array('admin_id'=>$request->pub_id, 'auth_key'=>$quickRandom,'name'=>$publisher->name,
//          'email'=>$publisher->email,'mobile'=>($requestArr['msisdn']) ? $requestArr['msisdn'] : "",
//          'skype'=>$request->skype_id, 'company_name'=>$request->company,'website_url'=>"",
//          'address'=>$request->address));
//
//        DB::table('ad_network')->where('ccz', $networkccz)
//        ->where('name', $networknameedit)->take(1)->update(array('name'=>$request->pubname, 
//        'clickid_parameter'=>$request->clickparameter, 'update_time'=>date("Y:m:d H:i:s")
//        ));
//
//
//        






    }
    
    
   public static function quickRandom($length = 16)
    {
      $pool = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

    return substr(str_shuffle(str_repeat($pool, $length)), 0, $length);
    }
        
    public function addpublisher(Request $request)
    {
//        echo "<pre>";
//        print_r($request->all());
//        echo "</pre>";
//        die();
        
            $this->user =  \Auth::user();
            
            $usr = $this->user; 
            $user_email = $usr->email;
            $roles = config('app.dashboard_users');
            
           if($request->addpub)
           {
               
                $posturl = $request->globalpost;
                if(strpos($posturl, '__NETWORKTOKEN__') ==false  ) {

                   return redirect()->back()
                   ->withInput($request->input())
                   ->with('posturl', 'Your postback URL does not contians __NETWORKTOKEN__ ');

                }

             $checkname = \App\Users1::where('name', $request->pubname)->select('name')->first();
               if(!empty($checkname))
               {

                  return redirect()->back()
                  ->withInput($request->input())
                  ->with('pubnameis', 'This Publisher name is already exist use another name.');


               }

             $checkemail = \App\Users1::where('email', $request->email)->select('email')->first();  
               if(!empty($checkemail))
               {
                 return redirect()->back()
                 ->withInput($request->input())
                 ->with('pubemailis', 'This email is already exits use another.');

               } 

               if($request->password!=$request->cpassword)
               {

               return redirect()->back()
               ->withInput($request->input())
               ->with('confirmpass', 'password and confirm password should be same.');
               }

              $checknetwork = \App\AdNetwork::where('name', $request->pubname)->select('name')->first();  
               if(!empty($checknetwork))
               {
                  return redirect()->back()
                  ->withInput($request->input())
                  ->with('pubnameis', 'This Network name is already exist use another name.');
               } 


            $quickRandom =$this->quickRandom(16);

                     $getccz = \App\AdNetwork::max('ccz');
                     if($getccz=="")
                     {
                          $ccz=1;
                     }
                     else
                     {
                       $ccz=$getccz+1;
                     }

                    if(empty($request->phone))
                    {
                      $request->phone="123456";
                    }
        
                $adNetworkObj = new \App\AdNetwork();
                $adNetworkObj->ccz = $ccz;
                $adNetworkObj->name = $request->pubname;
                $adNetworkObj->clickid_parameter = $request->clickparameter;              
                $adNetworkObj->account_manager = $user_email;
                $adNetworkObj->create_time = date("Y:m:d H:i:s");
                $adNetworkObj->save();


               $publisher = new Users1;
               $publisher->name=$request->pubname;
               $publisher->email=$request->email;
               $publisher->password=Hash::make($request->password);
//               $publisher->password=md5($request->password);
               $publisher->user_type = "publisher";
               $publisher->msisdn = $request->phone;
               $publisher->company_name=$request->company;
               $publisher->skype_id = $request->skype_id;
               $publisher->status = 'active';
               $publisher->address=$request->address;
               $publisher->created_at = date("Y:m:d H:i:s");;
               $publisher->user_token = "";
               $publisher->api_name = $request->apiname;

               $publisher->addedbyofferwall=1; 
               
               
            if(in_array($user_email, $roles))
            {
                $publisher->pub_added_by=$user_email; 
            }
            else 
            {
                $publisher->pub_added_by=$usr->email; 
            }
               
            
               
//               echo "======================"."<br>";
//              
//            echo $usr->email;
//            
////            $usr = $this->user;
////            echo "<pre>";
////            print_r($usr);
////            echo "</pre>";
//            die();
               
               $publisher->global_postback=$request->globalpost;
               $publisher->clickid_parameter=$request->clickparameter;
               $publisher->save();
               $publisher_id = $publisher->id;

              $requestArr['company_name'] = $publisher->company_name;
              $requestArr['msisdn'] = $publisher->msisdn;
              $requestArr['skype'] = $publisher->skype_id;
              $requestArr['address'] = $publisher->address;




               $publisherProfile = new \App\PublisherProfile();

               $publisherProfile->admin_id = $publisher_id;
               $publisherProfile->auth_key = $quickRandom;
               $publisherProfile->name = $publisher->name;
               $publisherProfile->ccz = $ccz;

                $publisherProfile->email = $publisher->email;
                $publisherProfile->mobile = ($requestArr['msisdn']) ? $requestArr['msisdn'] : "";
                $publisherProfile->skype = ($requestArr['skype']) ? $requestArr['skype'] : "";
                $publisherProfile->company_name = ($requestArr['company_name']) ? $requestArr['company_name'] : "";
                $publisherProfile->website_url = "";
                $publisherProfile->address = ($requestArr['address']) ? $requestArr['address'] : "";

                
                
                
               $publisherProfile->account_manager='sanjeev@collectcent.com'; 
               
               
               

                $publisherProfile->save();

                $role_user = new \App\RoleUser();
//                $config_roles = config('app.user_roles');
                $role_user->role_id = 5;  
                $role_user->user_id = $publisher_id;
                $role_user->save();

                //below will be  mail code  after register successfully


                return redirect()->back()->with('publishersuccess', 'Publisher Added successfully.');
      
           }


        return view('offers.addpublisher', ['request'=>$request,'active'=>'Publisher']);


     }
        
    public function advertiser_list(Request $request){
                $user = Auth::user();

            $select = ["advertiser.name as advertiser_name",
                    "advertiser.country as country",
                    "advertiser.advertiser_key as advertiser_key",
                    "advertiser.language as language",
                    "advertiser.account_manager as account_manager",
                    "advertiser.create_time as create_time",
                    "advertiser.status as status",
                    "advertiser.id"];
            $data =  \App\Advertiser::with('User')
            ->select($select) ;
          if(!empty($user->role_id) && $user->role_id=='12'){
          $data->where('advertiser.account_manager',$user->email);
          }  
            $data=$data->orderBy('advertiser.id', 'ASC')
            ->get();
            
            $data1 = [];
        $stat = '';
        $i=0;
        foreach ($data as $fetch_records)
        {
            $i++;

            $array = [];
            if($fetch_records->status==1)
            {
                $stat = 'Active';
            }
            else
            {
                $stat = 'Inactive';
            }

            array_push($array,
                    $i,
                $fetch_records->id,
                
                $fetch_records->advertiser_name,
                $fetch_records->country,
                $fetch_records->language,
                $fetch_records->account_manager,
                $fetch_records->advertiser_key,
                $fetch_records->create_time,
                $stat
                );
            array_push($data1, $array);

        }
        
        $result  = array('data1' => $data1);
            
            // dd($data->all());
        return view('offers.advertiser_list')->with($result);


      }
      
      public function addadvertiser(Request $request){

//         echo "ADD ADV";
//         echo "<pre>";
//         print_r($request->all());
//         echo "</pre>";
//         die();
         
         
           if($request->addadv)
           {


             $this->user =  \Auth::user();


             $checkname = \App\Users1::where('name', $request->advname)->where('user_type','advertiser')->select('name')->first();
             $checknameAdv = \App\Advertisers::where('name', $request->advname)->select('name')->first();
               if(!empty($checkname) || !empty($checknameAdv))
               {

                  return redirect()->back()
                  ->withInput($request->input())
                  ->with('advnameis', 'This Advertiser name already exists use another name.');


               }

             $checkemail = \App\Users1::where('email', $request->email)->where('user_type','advertiser')->select('email')->first(); 

             $checkemailAdv = \App\Advertisers::where('name', $request->advname)->select('name')->first();  
               if(!empty($checkemail) || !empty($checkemailAdv))
               {
                 return redirect()->back()
                 ->withInput($request->input())
                 ->with('advemailis', 'This advertiser already exists use another.');

               } 

               if($request->password!=$request->cpassword)
               {

               return redirect()->back()
               ->withInput($request->input())
               ->with('confirmpass', 'password and confirm password should be same.');
               }

                     $getId = \App\Advertisers::max('id');
                     if($getId=="")
                     {
                          $id=1;
                     }
                     else
                     {
                       $id=$getId+1;
                     }

                    if(empty($request->phone))
                    {
                      $request->phone="123456";
                    }
        
                $advertiserObj = new \App\Advertisers();
                $advertiserObj->id = $id;
                $advertiserObj->name = $request->advname;
                $advertiserObj->account_manager = $this->user->email;              
                $advertiserObj->create_time = date("Y:m:d H:i:s");
                $advertiserObj->save();


               $advertiser = new Users1;
               $advertiser->advertiser_id=$id;
               $advertiser->name=$request->advname;
               $advertiser->email=$request->email;
               $advertiser->password=Hash::make($request->password);
//               $publisher->password=md5($request->password);
               $advertiser->user_type = "advertiser";
               $advertiser->msisdn = $request->phone;
               $advertiser->company_name=$request->company;
               $advertiser->skype_id = $request->skype_id;
               $advertiser->status = 'active';
               $advertiser->address=$request->address;
               $advertiser->created_at = date("Y:m:d H:i:s");
               $advertiser->user_token = "";
//               $advertiser->api_name = $request->apiname;
               $advertiser->addedbyofferwall=1; 
               

               $advertiser->save();
               
 

                $role_user = new \App\RoleUser();
//                $config_roles = config('app.user_roles');
                $role_user->role_id = 6;
                $role_user->user_id = $id;
                $role_user->save();

                //below will be  mail code  after register successfully


                return redirect()->back()->with('advertisersuccess', 'Advertiser Added successfully.');


                            
           }


      return view('offers.addadvertiser', ['request'=>$request,'active'=>'Publisher']);


     }
        
  }


