<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;  

use App\Http\Requests;
use DB;
use App\Crc;
use Response;
use File;
use Illuminate\Support\Facades\Redis;
use Cache;
// use Advertiser;

class SiteidwaisehourlyController extends Controller
{
    
    
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
   
    public function index(Request $request,$template = 'SitewiseHourly.index'){
	    
      $path = storage_path() . "/json/country.json";      
      if (!File::exists($path)) {
        throw new Exception("Invalid File");
      }
      $country_json = File::get($path);
      $country = json_decode($country_json);
      return view($template,compact('country'));
    }


    public function smartIndex(Request $request){
      $template = 'SitewiseHourly.smartIndex';
      return $this->index($request,$template);
    }

    
    /**
     * To Show the data on landing page for current day Only
     *
     * @return \Illuminate\Http\Response
     */

    public function gethourdata(Request $request){
      //   $redis = Redis::connection();
      //   $cache = $request->input('cache');
      //   $date  = date('Y-m-d');
      //   $key   = "hourlydata_$date";
      // try {
      //     if(!$redis->exists($key)){
      //        $items = $this->gethourquery(); 
      //       $hourlydata = Redis::set($key, $items);
      //        $redis->expire($key,300);
      //       }else{
      //       $items = Redis::get($key);
        
      //    }
      // } catch (\Exception $e) {
            // echo $e->getMessage();
          $items = $this->gethourquery();  
      // }
      return $items; 
        
    }

   
    public function gethourquery(){
       $date = date('Y-m-d');
       $table_date=date('Ymd');
       $fields = [ 'advertiser_campaigns.name as offername', 
                  'ads.network_name', 
                  'chr.parentcca',
                  'chr.campaignid as id_advertiser',
                  'chr.adid',
                  'chr.networkid',
                  'count(chr.publisherid) as publisherid',
                  'count(chr.siteid) as siteid',
                  'chr.country',
                  'sum(chr.clickcount) as clickcount',
                  'sum(chr.idfa) as idfa',
                  //'sum(chr.inward) as inward',
                  'sum(chr.inward) as conversion_count',
                    "sum(chr.sale) as sale_count",
                  //'sum(chr.outward) as outward',
                  'sum(chr.outward) as clicks_active_count',
                   'chr.os',
                  'chr.hour'
                 ];
         $fields = implode(",", $fields);  
         $items['records'] = DB::select("SELECT $fields FROM offerwal_crc_".$table_date." chr LEFT JOIN ads ON chr.parentcca=ads.id_ad LEFT JOIN advertiser_campaigns ON chr.campaignid = advertiser_campaigns.id LEFT JOIN advertiser ON advertiser.id=advertiser_campaigns.id_advertiser WHERE DATE(chr.date_time
            ) BETWEEN DATE('".$date."')  AND  DATE('".$date."') AND ads.type='CPICPA'  group by hour ORDER BY hour DESC");
           $items['status'] = 'OK';
           $items = json_encode($items,JSON_NUMERIC_CHECK);
           $items = json_encode(json_decode($items));
           return $items;
    }

  
    public function filterData(Request $request){
	  // if($request->ajax()){
      $redis = Redis::connection();
     	$current_url = $request->fullUrl();
      $current_url = explode("?",$current_url);
      if(count($current_url) > 1){
         $allParameters = $current_url[1];
         $key = "hourlydatapnet_$allParameters";
      }
      try{
          if(!$redis->exists($key)){
              $item = $this->getFilterQuery($request);
              Redis::set($key, $item);
              $redis->expire($key,300);
              }else{
                // $item = Redis::get($key);
                $item = $this->getFilterQuery($request);
              }
      } catch(\Exception $e){
         $item = $this->getFilterQuery($request);

      } 
       return $item;
	 }

    public function filterSmartData(Request $request){
    // if($request->ajax()){
      $redis = Redis::connection();
      $current_url = $request->fullUrl();
      $current_url = explode("?",$current_url);
      if(count($current_url) > 1){
         $allParameters = $current_url[1];
         $key = "Siteidhourlydata_$allParameters";
      }
      $type = 'site';
      try{
          if(!$redis->exists($key)){
              $item = $this->getFilterQuery($request,$type);
              Redis::set($key, $item);
              $redis->expire($key,300);
              }else{
                // $item = Redis::get($key);
                $item = $this->getFilterQuery($request,$type);
              }
      } catch(\Exception $e){
         $item = $this->getFilterQuery($request,$type);
      } 
       return $item;
   }

    function getFilterQuery(Request $request,$type="hourly")
    {
        $filterresult='';
        $report_type = $request['report_type'];
        
        if(isset($request->report_type) && $request->report_type == '1' || $request->report_type == '2' || $request->report_type == '3' | $request->report_type == '4'){

           $filterresult = $this->filterbymonthly($request);
        }else{
            $filterresult = $this->filterbyhourly($request);
        }
        $lastUpdated = $this->lastUpdated();
        $item  = json_encode(array("status"=>'OK',"item"=>$filterresult, 'lastUpdated'=>$lastUpdated));
        return $item;
    }


    function filterbyhourly(Request $request){


        $date = date('Y-m-d');
       $check_dates[] = date('Y-m-d'); // current_date
       // echo '</br>';
        $check_dates[] = date('Y-m-d', strtotime($date .' -1 day')); // previous_date

          $filterresult='';
          $TdateRange = explode(" ",$request->input('daterange'));
            $Tdtvalue2 = $TdateRange[2]; 
            $Tdtvalue  = $TdateRange[0];
            if( ($Tdtvalue2 &&  $Tdtvalue) !== $date){
           $table_date = date('Ymd', strtotime($Tdtvalue2));
        
            }else{
               $table_date = date('Ymd');
            }
         

        $condition =  $group_by_condition =  $country_flag = '';
        
        if($request->input('daterange'))
        {
            $dateRange = explode(" ",$request->input('daterange'));
            $dtvalue2 = "'".$dateRange[2]."'"; 
            $dtvalue  = "'".$dateRange[0]."'";
            $condition .= "BETWEEN $dtvalue AND $dtvalue2 ";  
        }
        
        $condition .= $this->queryCondition($request->input());

        if(strpos($request->input('country'),',') !== false )
        {
            $condition .= " AND chr.country IN ('". str_replace(",", "','", $request->input('country'))."')";
        }
        else if($request->input('country') !="")
        {
            $condition .= " AND chr.country = '".$request->input('country')."'";
        }

        if(strpos($request->input('vertical'),',') !== false )
        {
            $condition .= " AND advertiser_campaigns.vertical IN ('". str_replace(",", "','", $request->input('vertical'))."')";
        }
          else if($request->input('vertical') !="")
          {
              $condition .= " AND advertiser_campaigns.vertical = '".$request->input('vertical')."'";
          }


        if(strpos($request->input('operator'),',') !== false )
        {
            $condition .= " AND advertiser_campaigns.id_op IN ('". str_replace(",", "','", $request->input('operator'))."')";
        }
            else if($request->input('operator') !='')
        {
            $condition .= " AND advertiser_campaigns.id_op = '".$request->input('operator')."'";
        }
  
        if(strpos($request->input('traffic_type'),',') !== false )
        {
            $condition .= " AND ads.traffic_type IN ('". str_replace(",", "','", $request->input('traffic_type'))."')";
        }
            else if($request->input('traffic_type') !='')
        {
            $condition .= " AND ads.traffic_type = '".$request->input('traffic_type')."'";
        }


        if($request->input('groupby'))
        {
            $group_by_arr = explode(',',$request->input('groupby'));
            if(in_array('country',$group_by_arr))
            {
                $country_flag = 1; // to check country is coming
                $group_by_condition .= "chr.country";
                if(($key = array_search('country', $group_by_arr)) !== false) 
                {
                    unset($group_by_arr[$key]);
                }
                if(count($group_by_arr) > 0)
                {
                    $group_by_options = implode(",",$group_by_arr);
                    $group_by_condition .= ", chr.".$group_by_options; 
                }
                $condition .= ' group by '.$group_by_condition;
            }
            else if(($key = array_search('op_id', $group_by_arr)) !== false) 
                {
                    $condition .= ' group by advertiser_campaigns.id_op';
                }
            else
            {
                $condition .= ' group by chr.'.$request->input('groupby');
            }
        }
        /* Condition is applied only for Group BY Parent CCA condition to fetch network_cpa field */
        $network_cpa_select = $network_cpa_condition = '';
      
        if(strpos($request->input('groupby'), 'networkid') !== false){
            $network_cpa_select = " adn.name as network_name, "; 
            $network_cpa_condition = "LEFT JOIN ad_network as adn ON chr.networkid = adn.ccz";
        }else{
          $network_cpa_condition = "";
        }

        
           $fields = [
            'advertiser_campaigns.name as offername',
            'ads.id_advertiser as id_advertiser_campaign',
            'ads.operator_name as op_name',
            'advertiser.name as advertiser_name',
                  'chr.parentcca',
                  'chr.campaignid',
                  'chr.adid',
                  'chr.publisherid',
                  'chr.networkid',
                  'chr.siteid',
                  'chr.country as country_code',
                  'sum(chr.idfa) as idfa',
                  "sum(chr.sale) as sale_count",
                  'sum(chr.clickcount) as clickcount',
                  'sum(chr.inward) as conversion_count',
                  'sum(chr.outward) as clicks_active_count',
                  'chr.siteid as siteid',
                  'chr.country as site_country',
                  'chr.os',
                  'chr.hour'
                 ];

            $allFields = implode(",", $fields);
            if(in_array($dateRange[0],$check_dates))
            {
              
            $filterresult = DB::SELECT("SELECT $network_cpa_select $allFields 
              FROM offerwal_crc_".$table_date." chr  
                LEFT JOIN ads ON chr.parentcca=ads.id_ad LEFT JOIN advertiser_campaigns ON chr.campaignid = advertiser_campaigns.id LEFT JOIN advertiser ON advertiser.id=advertiser_campaigns.id_advertiser $network_cpa_condition WHERE date(chr.date_time) $condition ORDER BY chr.hour DESC"); 
              
            }

            return $filterresult;
    }



    function filterbymonthly(Request $request){

      // echo '<pre>';print_r($request->all());
     

        $date = date('Ym').$request->report_type;
    

          $filterresult='';


        $condition =  $group_by_condition =  $country_flag = '';
        
        $condition .= " = $date";  
        
        $condition .= $this->queryCondition($request->input());
      

        if(strpos($request->input('country'),',') !== false )
        {
            $condition .= " AND chr.country IN ('". str_replace(",", "','", $request->input('country'))."')";
        }
        else if($request->input('country') !="")
        {
            $condition .= " AND chr.country = '".$request->input('country')."'";
        }

        if(strpos($request->input('vertical'),',') !== false )
        {
            $condition .= " AND ads.vertical IN ('". str_replace(",", "','", $request->input('vertical'))."')";
        }
        else if($request->input('vertical') !="")
        {
            $condition .= " AND ads.vertical = '".$request->input('vertical')."'";
        }
       
         else if($request->input('operator') !="")
        {
            $condition .= " AND ads.cco = '".$request->input('operator')."'";
        }
      
        if($request->input('groupby'))
        {
            $group_by_arr = explode(',',$request->input('groupby'));
            if(in_array('country',$group_by_arr))
            {
                $country_flag = 1; // to check country is coming
                $group_by_condition .= "chr.country";
                if(($key = array_search('country', $group_by_arr)) !== false) 
                {
                    unset($group_by_arr[$key]);
                }
                if(count($group_by_arr) > 0)
                {
                    $group_by_options = implode(",",$group_by_arr);
                    if($group_by_options='date')
                    {
                    $group_by_condition .= ", chr.record_date";   
                    }
                    
                }


                $condition .= ' group by '.$group_by_condition;
            }
            if($request->input('groupby')=='date'){
               $condition .= ' group by chr.record_date';
            }
            else
            {
                $condition .= ' group by chr.'.$request->input('groupby');
              // $condition .= ' group by chr.record_date';
            }
        }
        
        /* Condition is applied only for Group BY Parent CCA condition to fetch network_cpa field */
        $network_cpa_select = $network_cpa_condition = '';
        $network_cpa_condition = "LEFT JOIN ad_network as adn ON chr.id_channel = adn.ccz";
        // if(strpos($request->input('groupby'), 'networkid') !== false){
        //     $network_cpa_select = " adn.name as network_name, "; 
            
        // }else{
        //   $network_cpa_condition = "";
        // }

        
           $fields = [ 'chr.create_week as hour',
            'advertiser_campaigns.name as offername',
            'ads.id_advertiser as id_advertiser_campaign',
            'ads.operator_name as op_name',
            'advertiser.name as advertiser_name',
                  'chr.parent_cca as parentcca',
                  'chr.id_advertiser_campaign as campaignid',
                  'chr.id_ad as adid',
                  'adn.name as network_name',
                  'chr.id_channel as publisherid',
                  'chr. id_channel as networkid',
                  'sum(chr.clickcount) as clickcount',
                  'sum(chr.conversion_count) as conversion_count',
                  'sum(chr.clicks_active_count) as clicks_active_count',
                  'chr.id as id',
               
                  
                 ];

            $allFields = implode(",", $fields);
          
            $filterresult = DB::SELECT("SELECT $network_cpa_select $allFields 
              FROM crc_records_weekly chr LEFT JOIN ads ON chr.parent_cca=ads.id_ad LEFT JOIN advertiser_campaigns ON chr.id_advertiser_campaign = advertiser_campaigns.id LEFT JOIN advertiser ON advertiser.id=advertiser_campaigns.id_advertiser $network_cpa_condition WHERE chr.create_week $condition  group by  chr.id_advertiser_campaign ORDER BY chr.create_week DESC"); 
              
                      return $filterresult;
    }

      public function queryCondition($request){
      $requestAll = $request;
      $condition = "";
      foreach($requestAll as $key=>$value){
          if($key == 'report_type'){
            $condition .= $this->ConditionInOREqual('report_type',$value);
          }

          // if($key=='traffic_type'){
          //   $condition .= $this->ConditionInOREqual('traffic_type',$value);
          // }
          // if($key=='operator'){ 
          //      $condition .= $this->ConditionInOREqual('op_id',$value);
          // }
          if($key=='advertiser'){ 
               $condition .= $this->ConditionInOREqual('adid',$value);
          }
          if($key == 'hour'){ 
               $condition .= $this->ConditionInOREqual('hour',$value);
          }
          if($key=='id_advt'){ 
              $condition .= $this->ConditionInOREqual('campaignid',$value);
          }
          if($key=='parent_cca'){ 
              $condition .= $this->ConditionInOREqual('parentcca',$value);
          }
          if ($key=='id_ad') {
			    $condition .= $this->ConditionInOREqual('adid',$value);
		     }
          if ($key=='siteid') {
          $condition .= $this->ConditionInOREqual('siteid',$value);
         } 
         if ($key=='pubid') {
          $condition .= $this->ConditionInOREqual('pubid',$value);
         }
        if($key=='publisherid') {
          $condition .= $this->ConditionInOREqual('publisherid',$value);
         }
         if ($key=='network') {
          $condition .= $this->ConditionInOREqual('networkid',$value);
         }
          if ($key=='idfa') {
          $condition .= $this->ConditionInOREqual('idfa',$value);
         }
          if ($key=='report_type') {
          $condition .=$this->ConditionInOREqual('report_type',$value);
         }

        }
        return $condition;

      }   
                  
      function ConditionInOREqual($key,$value){
          if($value !="" && $key!='report_type'){
          $cond = " AND chr.$key = '".$value."'";
          if(strpos($value, ',') == true ){
             $cond = " AND chr.$key IN ('". str_replace(",", "','", $value)."')";   
          }
          return $cond;
          }
          return false;
      }


     /* return the operators for Opearator dropdown at hour page */   
    public function getOperators(){
        $redis = Redis::connection();
        $key  =  "operators1";
        try {
          if(!$redis->exists($key)){
             $items = $this->getOperatorQuery(); 
             $hourlydata = Redis::set($key, $items);
             $redis->expire($key,5000);
            }else{
            $items = Redis::get($key);
         }
        } catch (\Exception $e) {
            // echo $e->getMessage();
          $items = $this->getOperatorQuery();  
        }
        return $items;
    }     




     function getOperatorQuery(){
      $operator_dropdown = [];
      $operatorsResult = DB::select("select operator.id, operator.name, country.iso as cc from operator LEFT JOIN country on operator.country_code=country.iso order by operator.id");
      foreach ($operatorsResult as $dropdown) {
        if ($dropdown->id && $dropdown->name){
            $operator_dropdown[$dropdown->id]['operator'] = $dropdown->name."(".$dropdown->cc.")";
            $operator_dropdown[$dropdown->id]['id'] = $dropdown->id;
          }
        }
        $items = json_encode($operator_dropdown);
        return $items;
     } 

     /* return the operators for networks dropdown at hour page */  
     public function getNetworks(){
        $redis = Redis::connection();
        $key  =  "networks";
        try {
          if(!$redis->exists($key)){
             $items = $this->getNetworkQuery(); 
             $hourlydata = Redis::set($key,$items);
             $redis->expire($key,5000);
            }else{
            $items = Redis::get($key);
         }
        } catch (\Exception $e) {
            // echo $e->getMessage();
          $items = $this->getNetworkQuery();  
        }
        return $items;
    }


    function getNetworkQuery(){
      $network_dropdown = [];
      $networksResult = DB::select("select id,ccz,name from ad_network order by name ASC");
      foreach ($networksResult as $dropdown) {
        if ($dropdown->id && $dropdown->name){
            $network_dropdown[$dropdown->id]['networkWithCCZ'] = $dropdown->name."(".$dropdown->ccz.")";
            $network_dropdown[$dropdown->id]['id'] = $dropdown->id;
            $network_dropdown[$dropdown->id]['network'] = $dropdown->name;
            $network_dropdown[$dropdown->id]['ccz'] = $dropdown->ccz;
          }
        }
        $items = json_encode($network_dropdown);
        return $items;
    }


     /* return the operators for Opearator dropdown at hour page 
      * Date: 4 July 2017
     */  
      public function getAdvertisers(){
        $redis = Redis::connection();
        $date = date('Y-m-d');
        $key  =  "advertisers";
        try {
          if(!$redis->exists($key)){
             $items = $this->getadvertiserQuery(); 
             $hourlydata = Redis::set($key, $items);
             $redis->expire($key,500);
            }else{
            $items = Redis::get($key);
         }
        } catch (\Exception $e) {
            // echo $e->getMessage();
          $items = $this->getadvertiserQuery();  
        }
        return $items;
      }

      function getadvertiserQuery(){
        $advertiserResult = DB::select("SELECT name as advertiser_name, id as id_advertiser_campaign from advertiser group by name ASC");
        foreach ($advertiserResult as $dropdown) {
        if ($dropdown->id_advertiser_campaign && $dropdown->advertiser_name)
        $advertiser_dropdown[$dropdown->id_advertiser_campaign]['advertiser'] = $dropdown->advertiser_name."(".$dropdown->id_advertiser_campaign.")";
        $advertiser_dropdown[$dropdown->id_advertiser_campaign]['id'] = $dropdown->id_advertiser_campaign;
        }
        $items = json_encode($advertiser_dropdown);
        return $items;
      }


      public function getCampaigns(){
        $redis = Redis::connection();
        $key  =  "campaigns";
        try {
          if(!$redis->exists($key)){
             $items = $this->getcampaignQuery(); 
             $hourlydata = Redis::set($key, $items);
             $redis->expire($key,500);
            }else{
            $items = Redis::get($key);
         }
        } catch (\Exception $e) {
            // echo $e->getMessage();
          $items = $this->getcampaignQuery();  
        }
        return $items;
      }

      function getcampaignQuery(){
        $campaignResult = DB::select("select distinct(ac.id),ac.name from advertiser_campaigns as ac INNER JOIN crc_records_details crd ON ac.id = crd.id_advertiser_campaign");
        foreach($campaignResult as $dropdown) {
        if ($dropdown->id && $dropdown->name)
          $campaign_dropdown[$dropdown->id]['name'] = $dropdown->name."(".$dropdown->id.")";
          $campaign_dropdown[$dropdown->id]['id'] = $dropdown->id;
          $items = json_encode(array("status"=>"1","data"=>$campaign_dropdown));
        }
        return $items;
      }

       function lastUpdated(){
        $lastUpdated = DB::select("SELECT max(create_time) as create_time from crc_records_new limit 1");
        $lastUpdated_count = count($lastUpdated);
        if($lastUpdated_count > 0)
          if($lastUpdated[0]->create_time){
          return $lastUpdated[0]->create_time;  
        }
        return "No Update time";  
      }

  }

