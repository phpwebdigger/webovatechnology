<?php

namespace App\Http\Middleware;
use Illuminate\Support\Facades\Route;

use Closure;

class access
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
         $currentName= Route::getFacadeRoot()->current()->getName();
         if(in_array($currentName, \Config::get('role.all'))){

            $permissions = \Session::get('roles')->permission;
             if(\Session::get('roles')->name == "admin"){

             }
             else if(!in_array($currentName, explode(',',$permissions))){
                  return redirect('/forbidden');
             }
         }
         
        return $next($request);
    }
}
