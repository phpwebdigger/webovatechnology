<?php
namespace App\Http\Traits;
use App\Operator;
use App\AdNetwork;
use redis;

trait CommonTrait {
    
    public function getOperators() {
        // Get all the operators from the Operator Table.
        $Operators = Operator::all();
        return $Operators;
    }

    public function getNetworks() {
        // Get all the operators from the Operator Table.
        $AdNetwork = AdNetwork::all();
        return $AdNetwork;
    }
    
    public function getCountries() {
        // Get all the operators from the Operator Table.
        $Country = Country::all();
        return $Country;
    }
}