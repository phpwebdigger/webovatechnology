<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class reverse_setting extends Model
{
  protected $table = 'reverse_setting';
	protected $fillable = ['reverse_id','advetiser_id','operator_id','reverse_cca_id'];
   	public $timestamps = false;

}
