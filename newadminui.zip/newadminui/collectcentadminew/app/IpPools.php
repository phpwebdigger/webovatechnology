<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class IpPools extends Model
{
    //
     protected $fillable = ['ip_pools','name','created'];  
     protected $table = 'ip_pools';

     public $timestamps = false;

     public function CampaignIpPools()
     { 
    	return $this->belongsTo('App\CampaignIpPools');
     }

}
