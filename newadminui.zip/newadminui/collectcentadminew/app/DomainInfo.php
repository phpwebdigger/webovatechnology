<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DomainInfo extends Model
{
    //
     protected $table = 'domainInfo';
     protected $fillable = ["companyName","serverName",'ip','domainName','status'];
     public $timestamps = true;	
    
}
