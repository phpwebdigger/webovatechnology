<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CrcRecordsSmart extends BaseModel
{
    //
    protected $table; 
    public $timestamps = false;
    public function __construct()
    {
       $this->setTable($this->getTable);
    }

    public function getTable()
	{
	 $date = date('Ymd');	
    return "crc_records_smart_$date";
	}
}
