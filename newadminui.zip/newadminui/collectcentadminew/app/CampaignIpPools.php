<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CampaignIpPools extends Model
{
    //
     protected $fillable = ['campaign_id','ip_pool_id','id_ad','status','created'];  
     protected $table = 'campaign_ip_pools';
     public $timestamps = false;

    public function IpPools()
    {
        return $this->belongsTo('App\IpPools','ip_pool_id','id');
    }

    public function AdvertiserCampaign()
    {
        return $this->belongsTo('App\AdvertiserCampaigns','campaign_id','id');
    }

}
