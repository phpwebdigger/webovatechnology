<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\User;

class QueryAccess extends Model
{
    //
     protected $fillable = [
        'user_id', 'query'
    ];

    public function User(){
    	return $this->belongsTo('App\User');
    }
}
