<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Siteidwisediversion extends Model
{
		public $timestamps = false;
	protected $table = 'siteid_campaign_routing';

}
