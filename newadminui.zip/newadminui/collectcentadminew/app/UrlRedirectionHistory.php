<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UrlRedirectionHistory extends Model
{
    //
     protected $table = 'urlRedirectionHistory';
     protected $fillable = ["redirect_id_advertiser","url",'statusCode','isLoopBackUrl','retryCount','errorRetryCount','requestDateTime'];
     public $timestamps = true;	
    
}
