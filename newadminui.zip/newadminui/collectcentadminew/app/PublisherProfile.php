<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


//use OwenIt\Auditing\AuditingTrait;

class PublisherProfile extends Model {

  

    protected $auditEnabled = true;

    /**
     * The database table used by the model.
     * @var string
     */
    protected $table = 'publisher_profile';
    protected $primaryKey = 'publisher_id';
    protected $fillable = ['publisher_id', 'pub_type', 'ccz', 'name', 'email', 'mobile',];
    public $timestamps = false;

    //protected $auditEnabled = true;
    public function user() {
        return $this->belongsTo('App\User', 'admin_id', 'id');
    }

    public function URLs(){
        return $this->hasMany('\App\PublisherUrl','publisher_id','publisher_id');
    }
    
    public function invoices(){
        return $this->hasMany('\App\PublisherInvoice','publisher_id','publisher_id');
    }
    
    public function postbacks(){ 
        return $this->hasMany('\App\NetworkPostback','ccz','ccz');
    }
    
    public function dashboardConfigs(){
        return $this->hasMany('\App\PublisherDashboardConfig','publisher_id','publisher_id');
    }
    
    public function requests(){
        return $this->hasMany('\App\OfferwallRequest','publisher_id','publisher_id');
    }
}
