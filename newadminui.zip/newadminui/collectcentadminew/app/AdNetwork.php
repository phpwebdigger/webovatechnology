<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdNetwork extends Model
{
 	protected $table = 'ad_network';
	protected $fillable = ['name','clickid_parameter','billing_trafficker','ccz','account_manager'];
   	public $timestamps = false;

   	public function User(){
    	return $this->belongsTo('App\User',"account_manager","id");
    }
}