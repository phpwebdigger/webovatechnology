<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ConfigDeactivation extends Model
{
    //
     protected $table = 'deactivation_config';
     protected $fillable = ["cca","ccz",'deactivation_url','created_at','updated_at'];
     public $timestamps = true;	
    
}
