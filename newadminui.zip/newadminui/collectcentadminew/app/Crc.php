<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Crc extends Model
{
    public $table  = 'crc_records_new';

     public function AdvertiserCampaign(){
        return $this->belongsTo('App\AdvertiserCampaigns','id_advertiser_campaign','id');
  	 }

  	 public function Networks(){
        return $this->belongsTo('App\AdNetwork','id_channel','ccz');
  	 }
}
