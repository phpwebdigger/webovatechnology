<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class city_mapping extends Model
{
	protected $table = 'city_mapping';
	public $timestamps = false;
}