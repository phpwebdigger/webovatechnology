<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use OwenIt\Auditing\AuditingTrait;

class Advertisers extends Model {

    //use AuditingTrait;

    public $timestamps = false;
    protected $auditEnabled = true;
    protected $primaryKey = 'id';
    protected $table = 'advertiser';

}
