<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Users1 extends Model
{
    //
    protected $table = 'users1';
     public $timestamps = false;
}
