<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DeliveryMapping extends Model
{
    //
    protected $table = 'delivery_mapping';
    protected $fillable = ["id_channel","parent_cca",'campaign_id','publisher_goal_id','event_name','sale','event_postback','filter','status']	;
    public $timestamps = false;	
    
}
