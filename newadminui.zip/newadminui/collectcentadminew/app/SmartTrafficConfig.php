<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmartTrafficConfig extends Model
{
    protected $table = 'smart_trfc_config';
	protected $fillable = ['id','cca','campaign_id','start_date','end_date','hold_percentage','is_primary_campaign','status','updated_at'];
   	public $timestamps = false;
}
