<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CampaignStopCron extends Model
{
	protected $table = 'campaign_stop_cron';

	protected $fillable = ['id_advertiser_campaign', 'parent_cca', 'clicks_limit', 'converstions_limit', 'time', 'to_time','cron_date','replace_with_campaign_id','status'];
	
}
