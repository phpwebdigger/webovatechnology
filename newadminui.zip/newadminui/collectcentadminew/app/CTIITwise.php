<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CTIITwise extends Model
{
	protected $table = 'conversions';
	public $timestamps = false;
}