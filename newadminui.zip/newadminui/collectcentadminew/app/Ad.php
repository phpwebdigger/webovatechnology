<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ad extends BaseModel
{
    //
    	public $timestamps = false;
}
