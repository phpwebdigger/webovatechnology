<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ConfigDeliveryEvent extends Model
{
    //
     protected $table = 'config_delivery_event';
     protected $fillable = ["id","id_zone","id_ad",'lower_limit','higher_limit','filter_status','post_back_url','postback_status']	;
     public $timestamps = false;	
    
}
