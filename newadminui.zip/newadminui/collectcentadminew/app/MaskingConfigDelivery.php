<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MaskingConfigDelivery extends Model
{
    //
     protected $table = 'masking_config_delivery';
     protected $fillable = ["id,id_zone","id_ad",'lower_limit','higher_limit','filter_status','post_back_url','postback_status','is_child','id_child']	;
     public $timestamps = false;	

    

    
}
