<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CronConfig extends Model
{
    //
    public $timestamps = false;
    protected $table = 'cron_config';
    protected $fillable = ["ccz","id_ad",'title','network_callback_url','lower_cr_in_percentage','time_interval','higher_cr_in_percentage','status'];
      
	public function Networks(){
        return $this->belongsTo('App\AdNetwork','ccz','ccz');
  	}
  	
  	public function Ads(){
        return $this->belongsTo('App\Ad','id_ad','id_ad');
  	}


}
