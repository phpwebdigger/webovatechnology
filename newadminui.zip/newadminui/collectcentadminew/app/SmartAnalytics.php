<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SmartAnalytics extends Model
{
	protected $table = 'smart_analytics';
	public $timestamps = false;
   	
   	
}
