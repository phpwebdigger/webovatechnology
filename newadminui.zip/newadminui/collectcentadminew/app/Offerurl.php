<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Offerurl extends Model
{
    protected $table = 'smart_rotator_campaigns_operators';
  
	protected $fillable = ['campaign_id','op_id','id_zone','country_code','smart_live','ads_cat','smart_status','is_offer_direct',
	'offer_url','redirect_operator_config'];
   	public $timestamps = false;
}
