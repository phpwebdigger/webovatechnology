<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Advertiser extends Model
{
	protected $table = 'advertiser';
	protected $fillable = ['name','account_manager'];
   	public $timestamps = false;
   	
   	public function User(){
    	return $this->belongsTo('App\User',"account_manager","id");
    }

    

}
