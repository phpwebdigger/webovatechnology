<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Operators extends Model {

    protected $table = 'operator';
    protected $fillable = ['name','country','country_code','language','rahul_cpa'];
    protected $primaryKey = 'id';
}