<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Smarttrfcconfig extends Model
{
    protected $table = 'smart_trfc_config';
	protected $primaryKey = 'id';
	protected $fillable = ['cca','campaign_id','campaign_id','start_date','end_date','status','is_primary_campaign','updated_at'];
   	public $timestamps = false;



   	
}
