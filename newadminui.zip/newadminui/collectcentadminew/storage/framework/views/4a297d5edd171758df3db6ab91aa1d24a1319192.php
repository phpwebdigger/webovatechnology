  <?php $__env->startSection('title', 'Edit Ads'); ?>
<?php $__env->startSection('custom_css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/bower_components/switchery/dist/switchery.min.css')); ?>"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('heading'); ?>
     Edit Ads  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_js'); ?>
<script src="<?php echo e(asset('plugins/bower_components/switchery/dist/switchery.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/validator.js')); ?>"></script>
<script type="text/javascript">
     var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
       $('.js-switch').each(function() {
           new Switchery($(this)[0], $(this).data());

       });
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
   <div class="col-md-12">
     <div class="panel panel-info">
         <div class="panel-wrapper collapse in" aria-expanded="true">
           <div class="panel-body">
            <form action="<?php echo e(route('updateAds')); ?>" data-toggle="validator" method = "post" >
            <?php echo e(csrf_field()); ?>

            
            
            <?php 
            
//                echo "<pre>";
//                print_r($data);
//                echo "</pre>";
//                echo "<pre>";
//                print_r($network);
//                echo "</pre>";
//                echo "<pre>";
//                print_r($network);
//                echo "</pre>";
            
            ?>
            
            
              <div class="form-body">
                 <div class="row">
                    <div class="col-md-6">
                      <div class="form-group">
                         <label class="control-label">Title</label> 
                             <input type="text" name="title" id="title" value="<?php echo e($data[0]['title']); ?>" class="form-control" required/>
                             <div class="help-block with-errors"></div>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                         <label class="control-label">Campaign Id(Id Advertiser)</label> 
                             <input type="text" name="id_advertiser" id="id_advertiser" value="<?php echo e($data[0]['id_advertiser']); ?>" class="form-control" required/> 
                             <div class="help-block with-errors"></div>
                      </div>
                    </div>
                  </div>
                  <div class="row">  
                    <div class="col-md-6">
                      <div class="form-group">
                         <label class="control-label">Click Url:</label>
                              <?php 
                              $url1 = '';
                              $url2 = '';
                              $urls = explode("?",$data[0]['click_url']);
                              if(count($urls) > 1){
                                echo $urls[0]."?";
                                $url1 =   $urls[0];
                                $url2 = $urls[1]; 
                              }
                               ?>
                            <input type="hidden" name="click_url1" id="click_url1" value="<?php echo $url1;?>" class="form-control"/>  
                            <input type="text" name="click_url2" id="click_url2" value="<?php echo $url2;?>" class="form-control"/> 
                            <div class="help-block with-errors"></div>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group required">
                        <label class="control-label">Operator</label> 
                              <select  name='operator_name' class="selectpicker form-control" id="operator_name" data-live-search="true" required>
                               <option value="">Select operator</option>
                               <?php $__currentLoopData = $operator; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $op): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <option value="<?php echo e($op->id); ?>?<?php echo e($op->name); ?>" <?php echo e($data[0]['cco'] == $op->id ? "selected":""); ?>><?php echo e($op->name); ?>-<?php echo e($op->country_code); ?></option>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                             <div class="help-block with-errors"></div>
                      </div>
                    </div>
                  </div>
                  <div class="row">  
                    <div class="col-md-6">
                      <div class="form-group required">
                         <label class="control-label">Type</label> 
                              <select  name='type' class="form-control" required>
                               <option value="">Select Type</option>
                                <?php $__currentLoopData = Config::get('collectcent.campaignType'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e($data[0]['type']== $cat?"selected":""); ?> value="<?php echo e($cat); ?>"><?php echo e($cat); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                             </select>
                             <div class="help-block with-errors"></div>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group required">
                        <label class="control-label">Country</label>
                        <input type="text" name="country_code" id="country_code" class="form-control" value="<?php echo e($data[0]['country_code']); ?>" required> 
                        <div class="help-block with-errors"></div>                                                 
                     </div>
                    </div>
                  </div>
                  <div class="row"> 
                    <div class="col-md-6">
                      <div class="form-group required">
                         <label class="control-label">Network CPA</label>
                          <input type="text" name="network_cpa" id="network_cap" class="form-control" value="<?php echo e($data[0]['network_cpa']); ?>">
                          <div class="help-block with-errors"></div>                                                 
                     </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group required">
                         <label class="control-label">Network Name</label>
                          <select name='network_name' id ="network_name" class="form-control selectpicker" required data-live-search="true">
                          <option value="">Select Network name</option>
                          <?php $__currentLoopData = $network; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $net): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($net->ccz); ?>?<?php echo e(trim($net->name)); ?>" <?php echo e($data[0]['id_zone'] == $net->ccz ? "selected":""); ?>><?php echo e($net->name); ?>(<?php echo e($net->ccz); ?>)
                          </option> 
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                           <div class="help-block with-errors"></div>                                                 
                     </div>
                    </div>
                  </div>
                  <div class="row">
                     <div class="col-md-6">
                      <div class="form-group">
                         <label>Description</label>
                          <select name='description' id ="description"  class="form-control">
                          <option value="">Select Description</option>
                          <option value="default" <?php echo e($data[0]['description2']== 'default'?"selected":""); ?>>Default</option>
                          </select>
                           <div class="help-block with-errors"></div>                                                 
                     </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group">
                         <label>Outward Status</label>
                          <div class="form-group col-sm-12">
                          <select name='outward_status' id ="outward_status"  class="form-control" required>
                          <option value="">Select Wifi status</option>
                          <option value="0" <?php echo e($data[0]['outward_status'] == 0 ?"selected":""); ?>>Off</option>
                          <option value="1" <?php echo e($data[0]['outward_status'] == 1 ?"selected":""); ?>>On</option>
                          </select>
                          <div class="help-block with-errors"></div>
                          </div>

                     </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group required">
                         <label class="control-label">WiFi Status</label>
                          <select name='wifi_status' id ="wifi_status"  class="form-control" required>
                          <option value="">Select Wifi status</option>
                          <option value="0" <?php echo e($data[0]['wifi_status'] == 0 ?"selected":""); ?>>Off</option>
                          <option value="1" <?php echo e($data[0]['wifi_status'] == 1 ?"selected":""); ?>>On</option>
                          </select>
                          <div class="help-block with-errors"></div>                                                 
                     </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group required">
                         <label class="control-label">Payout Currency</label>
                          <select name='payout_currency' id ="payout_currency"  class="form-control" required>
                            <option value="">Select Payout Currency</option>
                            <option value="INR" <?php echo e($data[0]['payout_currency'] == 'INR'?"selected":""); ?>>INR</option>
                            <option value="DOLLAR" <?php echo e($data[0]['payout_currency'] == 'DOLLAR'?"selected":""); ?>>DOLLAR</option>
                            <option value="EURO" <?php echo e($data[0]['payout_currency'] == 'EURO'?"selected":""); ?>>EURO</option>
                          </select>
                          <div class="help-block with-errors"></div>                                                 
                     </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group required">
                         <label class="control-label">Direct Condition</label>
                          <select name='id_ad_type' id ="id_ad_type"  class="form-control" required>
                          <option value="0" <?php echo e($data[0]['id_ad_type'] == 0 ?"selected":""); ?>>Off</option>
                          <option value="1" <?php echo e($data[0]['id_ad_type'] == 1 ?"selected":""); ?>>On</option>
                          </select>
                          <div class="help-block with-errors"></div>                                                 
                     </div>
                    </div>
                      <div class="col-md-6">
                      <div class="form-group">
                        <label class="control-label">Parent Id</label>
                        <input type="text" name="parent_id" id="parent_id" class="form-control" value="<?php echo e($data[0]['parent_id']); ?>" required> 
                        <div class="help-block with-errors"></div>                                                 
                     </div>
                    </div>
                      <div class="" style="display: none;">
                      <div class="form-group required">
                         <label class="control-label">Smart S2S CCA</label>
                          <select name='is_smart_cca' id ="is_smart_cca"  class="form-control" required>
                            <option value="0">No</option>
                            <option value="1" selected>Yes</option>
                          </select>
                          <div class="help-block with-errors"></div>                                                 
                     </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group required">
                         <label class="control-label">Fixed Url</label>
                          <select name='url_change' id ="url_change"  class="form-control" required>
                          <option value="0" <?php echo e($data[0]['url_change'] == 0 ?"selected":""); ?>>Disable</option>
                          <option value="1" <?php echo e($data[0]['url_change'] == 1 ?"selected":""); ?>>Enable</option>
                          </select>
                          <div class="help-block with-errors"></div>                                                 
                     </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group required">
                         <label class="control-label">Company name</label>
                          <select name='company_name' id ="company_name"  class="form-control" required>
                            <option  value="Collectcent" <?php echo e($data[0]['company_name'] == "" ? "selected":""); ?>>Collectcent</option>
                            <option  value="Imageperfect" $data[0]['company_name'] == "Imageperfect"?"selected":"">Imageperfect</option>
                            <option  value="Vacastudios" <?php if($data[0]['company_name'] == "Vacastudios"){ echo "selected='selected'";}?>>Vacastudios</option>
                            <option  value="Moiads" <?php if($data[0]['company_name']=="Moiads"){ echo "selected='selected'";}?>>Moiads</option>
                            <option  value="SF" <?php if($data[0]['company_name']=="SF"){ echo "selected='selected'";}?>>SF</option>
                            <option  value="Adsjoy" <?php if($data[0]['company_name']=="Adsjoy"){ echo "selected='selected'";}?>>Adsjoy</option>
                            <option  value="6TSeconds" <?php if($data[0]['company_name'] == "6TSeconds"){ echo "selected='selected'";}?>>6T Seconds</option>
                            <option  value="MVN" <?php if($data[0]['company_name'] == "MVN"){ echo "selected='selected'";}?>>MVN</option>
                            <option  value="Europaads" <?php if($data[0]['company_name'] == "Europaads"){ echo "selected='selected'";}?> value="Europaads">Europaads</option>
                          </select>
                          <div class="help-block with-errors"></div>                                                 
                     </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-md-6">
                      <div class="form-group required">
                         <label class="control-label">App Server</label>
                          <select name='app_server' id ="app_server"  class="form-control" required>
                            <?php $__currentLoopData = Config::get('collectcent.app_server'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cat); ?>"><?php echo e($cat); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                          </select>
                          <div class="help-block with-errors"></div>                                                 
                     </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group required">
                         <label class="control-label">Traffic Type</label>
                          <select name='traffic_type' id ="traffic_type"  class="form-control" required>
                          <option>Select Traffic Type</option>
                          <?php $__currentLoopData = Config::get('collectcent.category'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option <?php echo e($data[0]['traffic_type']== $cat?"selected":""); ?> value="<?php echo e($cat); ?>"><?php echo e($cat); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                          </select>
                           <div class="help-block with-errors"></div>                                                 
                     </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group required">
                            <label class="control-label">Os Type</label>
                            <select name='os_type' id ="os_type"  class="form-control" required>
                              <option>Select Os Type</option>
                              <?php $__currentLoopData = Config::get('collectcent.operatingSystem'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $os): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option <?php echo e($data[0]['os_type']== $os?"selected":""); ?> value="<?php echo e($os); ?>"><?php echo e($os); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </select>
                          <div class="help-block with-errors"></div>                                                 
                       </div>
                    </div>
                    <div class="col-md-6">
                      <div class="form-group required">
                         <label class="control-label">Vertical</label>
                          <select name='select_vertical' id ="select_vertical"  class="form-control" required>
                          <option>Select Vertical</option>
                          <?php $__currentLoopData = Config::get('collectcent.vertical'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option <?php echo e($data[0]['vertical']== $ver?"selected":""); ?> value="<?php echo e($ver); ?>"><?php echo e($ver); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                          </select>
                           <div class="help-block with-errors"></div>                                                 
                     </div>
                    </div>
                  </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Cap Count Conversions</label>
                            <input type="text" name="cap_count_conversions" id="cap_count_conversions" class="form-control" value="<?php echo e($data[0]['cap_count_conversions']); ?>" required>
                            <div class="help-block with-errors"></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Cap Count Sale</label>
                            <input type="text" name="cap_count_sale" id="cap_count_sale" class="form-control" value="<?php echo e($data[0]['cap_count_sale']); ?>" required>
                            <div class="help-block with-errors"></div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Cap Count Click</label>
                            <input type="text" name="cap_count_click" id="cap_count_click" class="form-control" value="<?php echo e($data[0]['cap_count_click']); ?>" required>
                            <div class="help-block with-errors"></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label class="control-label">Cap Count Delivery</label>
                            <input type="text" name="cap_count_delivery" id="cap_count_delivery" class="form-control" value="<?php echo e($data[0]['cap_count_delivery']); ?>" required>
                            <div class="help-block with-errors"></div>
                        </div>
                    </div>
                </div>
		 

                  
                  <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                         <input type="hidden" name="id_ad" id="id_ad" value="<?php echo e($data[0]['id_ad']); ?>"> 
                         <button type="submit"  id ="submit" class="btn btn-success">Submit</button>
                        <button type="button"  id ="cancel_button" class="btn btn-danger">Cancel</button>
                        </div>
                    </div>
                  </div>
                    </div>
                </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  
   

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>