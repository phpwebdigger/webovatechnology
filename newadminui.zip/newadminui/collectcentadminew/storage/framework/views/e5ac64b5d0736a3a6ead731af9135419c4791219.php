<?php $__env->startSection('login'); ?>

                <form class="form-horizontal form-material" id="loginform"  role="form" method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo e(csrf_field()); ?>

                    <a href="javascript:void(0)" class="text-center db"><img src="<?php echo e(asset('collectcent-logo-scroll.svg')); ?>" alt="Home" />
                        <br/></a>
                    <div class="form-group m-t-40">
                        <div class="col-xs-12">
                          
                            <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                             <?php if($errors->has('email')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-xs-12">
                            <input class="form-control" type="password" required="" name="password" placeholder="Password">
                              <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-12">
                            <div class="checkbox checkbox-primary pull-left p-t-0">
                                
                                <input id="checkbox-signup" type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                <label for="checkbox-signup"> Remember me </label>
                            </div>
                             </div>
                    </div>
                    <div class="form-group text-center m-t-20">
                        <div class="col-xs-12">
                            <button class="btn btn-info btn-lg btn-block text-uppercase waves-effect waves-light" type="submit">Log In</button>
                        </div>
                         <?php if(session('data')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e(session('data')); ?></strong>
                                    </span>
                         <?php endif; ?>
                        
                    </div>
                   
                </form>
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.loginlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>