<?php $__env->startSection('custom_css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/bower_components/switchery/dist/switchery.min.css')); ?>" />
<!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bread'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('heading'); ?>
  Networkwise Offer 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>-->
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<script src="../plugins/bower_components/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        
        jQuery('.mydatepicker1').datepicker({
            format:"yyyy-mm-dd"
        });

    var col = ['text_65px',
                  'text_60px', 
                    'text_80px',
                    '',
                    '',
                    '',
                    '',
                    '',
                    'text_60px',
                    'text_150px',     
                    'text_150px',     
                    "text_40px",
                    "text_40px",
                    "text_40px",
                    "text_40px",
                    "text_40px",
                    "text_40px",
                    "",
                    "",
                    "",
                    "text_150px",
                    
                ];

        var data =   <?php echo json_encode($data1); ?>;
        
//        alert(data);
        
//        console.log(data);
        createTableWithLazyLoad("#tableLazy",data,100,col);

    
//    $(".new_status_change").click(function (){
////           alert(786); 
////        alert($('.new_status_change').attr('id')
//
//        alert($('#new_active_status').attr("checked", $('span input[type=checkbox]', this).attr("checked") ))
//
//    });
    
    
    
    
    
    $("#change_status").click(function (){
//           alert(786); 
        var errmsg = $("#errmsg_chng_st");
        
        var cca = $("#chng_st_cca");
        var ccz = $("#chng_st_ccz");
        var id = $("#chng_st_id");
        if($("#chng_st_st option:selected").val()=="Select Status" )
        {
            errmsg.html('<span class="alert alert-danger">Please select status !</span>');
            return false;
        }

        if($("#chng_st_st option:selected").val() != "Select Status" && cca.val() != "" && ccz.val() != "" && id.val() != "")
        {
            errmsg.html('<span class="alert alert-info">please wait...</span>');

            $.ajax({
                type: 'GET',
                url: 'update_active_status',
                data: { id: id.val(), cca: cca.val(), ccz: ccz.val(), status: $("#chng_st_st option:selected").val()},
                dataType: 'html',
                success: function(responseText){ // Get the result and asign to each cases
                    var result = $.parseJSON(responseText);
                        
                        if(result.status == 0){
                            errmsg.html('<span class="alert alert-danger">'+result.message+'</span>');
                        }
                        else if(result.status == 1){
                            errmsg.html('<span class="alert alert-success">'+result.message+'</span>');
                            var text;
                            if($("#chng_st_st option:selected").val() == '1')
                            {
                                text = 'Active';
                            }
                            else if($("#chng_st_st option:selected").val() == '0')
                            {
                                text = 'Inactive';
                            }

                            $("#active_status_"+id.val()).html(text);
                            $('#changeActStatus').modal('hide');

                        }
                        else if(result.status == 2){
                            errmsg.html('<span class="alert alert-info">'+result.message+'</span>');                                        
                        }
                    },
                error: function(data){
    //                        alert("fail---->"+JSON.stringify(data));
                    errmsg.html('<span class="alert alert-info">'+JSON.stringify(data)+'</span>'); 
                }    
            });
        }
        else
        {
            errmsg.html('<span class="alert alert-info">Oops, something went wrong</span>'); 
        }
    });
    $("#change_cpa").click(function (){
//           alert(786); 
        var errmsg = $("#errmsg_chng_cpa");
        var cpa = $("#chng_cpa_cpa");
        var cca = $("#chng_cpa_cca");
        var ccz = $("#chng_cpa_ccz");
        var id = $("#chng_cpa_id");
        if(cpa.val() == "")
        {
            cpa.focus();
            errmsg.html('<span class="alert alert-danger">Please enter cpa</span>');
            return false;
        }

        if(cpa.val() != "" && cca.val() != "" && ccz.val() != "" && id.val() != "")
        {
            errmsg.html('<span class="alert alert-info">please wait...</span>');

            $.ajax({
                type: 'GET',
                url: 'update_cpa',
                data: { id: id.val(), cca: cca.val(), ccz: ccz.val(), cpa: cpa.val()},
                dataType: 'html',
                success: function(responseText){ // Get the result and asign to each cases
                    var result = $.parseJSON(responseText);
                        
                        if(result.status == 0){
                            errmsg.html('<span class="alert alert-danger">'+result.message+'</span>');
                        }
                        else if(result.status == 1){
                            errmsg.html('<span class="alert alert-success">'+result.message+'</span>');                                        
//                                window.location.href=window.location.href;
                            $("#cpa_"+id.val()).html(cpa.val());
                            $('#changeCpa').modal('hide');

                        }
                        else if(result.status == 2){
                            errmsg.html('<span class="alert alert-info">'+result.message+'</span>');                                        
                        }
                    },
                error: function(data){
    //                        alert("fail---->"+JSON.stringify(data));
                    errmsg.html('<span class="alert alert-info">'+JSON.stringify(data)+'</span>'); 
                }    
            });
        }
        else
        {
            errmsg.html('<span class="alert alert-info">Oops, something went wrong</span>'); 
        }
    });
    
    $("#change_cap").click(function (){
//           alert(786); 
        var errmsg = $("#errmsg_chng_cap");
        var cap = $("#chng_cap_cap");
        var cca = $("#chng_cap_cca");
        var ccz = $("#chng_cap_ccz");
        var id = $("#chng_cap_id");
        if(cap.val() == "")
        {
            cap.focus();
            errmsg.html('<span class="alert alert-danger">Please enter cpa</span>');
            return false;
        }

        if(cap.val() != "" && cca.val() != "" && ccz.val() != "" && id.val() != "")
        {
            errmsg.html('<span class="alert alert-info">please wait...</span>');

            $.ajax({
                type: 'GET',
                url: 'update_cap',
                data: { id: id.val(), cca: cca.val(), ccz: ccz.val(), cap: cap.val()},
                dataType: 'html',
                success: function(responseText){ // Get the result and asign to each cases
                    var result = $.parseJSON(responseText);
                        
                        if(result.status == 0){
                            errmsg.html('<span class="alert alert-danger">'+result.message+'</span>');
                        }
                        else if(result.status == 1){
                            errmsg.html('<span class="alert alert-success">'+result.message+'</span>');                                        
//                                window.location.href=window.location.href;
                            $("#cap_conversion_"+id.val()).html(cap.val());
                            
                            $('#changeCap').modal('hide');

                        }
                        else if(result.status == 2){
                            errmsg.html('<span class="alert alert-info">'+result.message+'</span>');                                        
                        }
                    },
                error: function(data){
    //                        alert("fail---->"+JSON.stringify(data));
                    errmsg.html('<span class="alert alert-info">'+JSON.stringify(data)+'</span>'); 
                }    
            });
        }
        else
        {
            errmsg.html('<span class="alert alert-info">Oops, something went wrong</span>'); 
        }
    });

    // Click cpa count chnages 

    $("#clicks_count_cpabtn").click(function (e){
         e.preventDefault(); 
        var errmsg = $("#errmsg_clicks_count_cap");
        var cap = $("#change_clicks_count_cpa");
        var cca = $("#chngc_cap_cca");
        var ccz = $("#chngc_cap_ccz");
        var id = $("#chngc_cap_id");
        if(cap.val() == "")
        {
            cap.focus();
            errmsg.html('<span class="alert alert-danger">Please enter cpa</span>');
            return false;
        }

        if(cap.val() != "" && cca.val() != "" && ccz.val() != "" && id.val() != "")
        {
            errmsg.html('<span class="alert alert-info">please wait...</span>');

            $.ajax({
                type: 'GET',
                url: 'update_click_count_cap',
                data: { id: id.val(), cca: cca.val(), ccz: ccz.val(), cap: cap.val()},
                dataType: 'html',
                success: function(responseText){ // Get the result and asign to each cases
                    var result = $.parseJSON(responseText);
                        
                        if(result.status == 0){
                            errmsg.html('<span class="alert alert-danger">'+result.message+'</span>');
                        }
                        else if(result.status == 1){
                            errmsg.html('<span class="alert alert-success">'+result.message+'</span>');                                        
//                                window.location.href=window.location.href;
                            $("#cap_countclick_"+id.val()).html(cap.val());
                            
                            $('#clicks_count_cap').modal('hide');

                        }
                        else if(result.status == 2){
                            errmsg.html('<span class="alert alert-info">'+result.message+'</span>');                                        
                        }
                    },
                error: function(data){
    //                        alert("fail---->"+JSON.stringify(data));
                    errmsg.html('<span class="alert alert-info">'+JSON.stringify(data)+'</span>'); 
                }    
            });
        }
        else
        {
            errmsg.html('<span class="alert alert-info">Oops, something went wrong</span>'); 
        }
    });

//cpa count install 

$("#install_count_cpabtn").click(function (event){
     event.preventDefault(); 
        var errmsg = $("#errmsg_chng_cap_install");
        var cap = $("#change_install_count_cpa");
        var cca = $("#chngi_cap_cca");
        var ccz = $("#chngi_cap_ccz");
        var id = $("#chngi_cap_id");
        if(cap.val() == "")
        {
            cap.focus();
            errmsg.html('<span class="alert alert-danger">Please enter cpa</span>');
            return false;
        }

        if(cap.val() != "" && cca.val() != "" && ccz.val() != "" && id.val() != "")
        {
            errmsg.html('<span class="alert alert-info">please wait...</span>');

            $.ajax({
                type: 'GET',
                url: 'update_install_count_cap',
                data: { id: id.val(), cca: cca.val(), ccz: ccz.val(), cap: cap.val()},
                dataType: 'html',
                success: function(responseText){ // Get the result and asign to each cases
                    var result = $.parseJSON(responseText);
                        
                        if(result.status == 0){
                            errmsg.html('<span class="alert alert-danger">'+result.message+'</span>');
                        }
                        else if(result.status == 1){
                            errmsg.html('<span class="alert alert-success">'+result.message+'</span>');                                        
//                                window.location.href=window.location.href;
                            $("#cap_countinstall_"+id.val()).html(cap.val());
                            
                            $('#install_count_cap').modal('hide');

                        }
                        else if(result.status == 3){
                            errmsg.html('<span class="alert alert-info">'+result.message+'</span>');                                        
                        }
                        else if(result.status == 2){
                            errmsg.html('<span class="alert alert-info">'+result.message+'</span>');                                        
                        }
                    },
                error: function(data){
    //                        alert("fail---->"+JSON.stringify(data));
                    errmsg.html('<span class="alert alert-info">'+JSON.stringify(data)+'</span>'); 
                }    
            });
        }
        else
        {
            errmsg.html('<span class="alert alert-info">Oops, something went wrong</span>'); 
        }
    });

$("#sale_count_cpabtn").click(function (event){
     event.preventDefault(); 
        var errmsg = $("#errmsg_chng_cap_sale");
        var cap = $("#change_sale_count_cpa");
        var cca = $("#sale_cap_cca");
        var ccz = $("#sale_cap_ccz");
        var id = $("#sale_cap_id");
        if(cap.val() == "")
        {
            cap.focus();
            errmsg.html('<span class="alert alert-danger">Please enter count</span>');
            return false;
        }

        if(cap.val() != "" && cca.val() != "" && ccz.val() != "" && id.val() != "")
        {
            errmsg.html('<span class="alert alert-info">please wait...</span>');

            $.ajax({
                type: 'GET',
                url: 'update_sale_count_cap',
                data: { id: id.val(), cca: cca.val(), ccz: ccz.val(), cap: cap.val()},
                dataType: 'html',
                success: function(responseText){ // Get the result and asign to each cases
                    var result = $.parseJSON(responseText);
                        
                        if(result.status == 0){
                            errmsg.html('<span class="alert alert-danger">'+result.message+'</span>');
                        }
                        else if(result.status == 1){
                            errmsg.html('<span class="alert alert-success">'+result.message+'</span>');                                        
//                                window.location.href=window.location.href;
                            $("#cap_countsale_"+id.val()).html(cap.val());
                            
                            $('#sale_count_cap').modal('hide');

                        }
                        else if(result.status == 3){
                            errmsg.html('<span class="alert alert-info">'+result.message+'</span>');                                        
                        }
                        else if(result.status == 2){
                            errmsg.html('<span class="alert alert-info">'+result.message+'</span>');                                        
                        }
                    },
                error: function(data){
    //                        alert("fail---->"+JSON.stringify(data));
                    errmsg.html('<span class="alert alert-info">'+JSON.stringify(data)+'</span>'); 
                }    
            });
        }
        else
        {
            errmsg.html('<span class="alert alert-info">Oops, something went wrong</span>'); 
        }
    });


    $("#update_kpi").click(function (){
//           alert(786); 
        var errmsg = $("#errmsg_edit_kpi");
        var kpi = $("#edit_pub_kpi");
        var cca = $("#edit_kpi_cca");
        var ccz = $("#edit_kpi_ccz");
        var id = $("#edit_kpi_id");
        var _token = $("#_token");
        if(kpi.val() == "")
        {
            kpi.focus();
            errmsg.html('<span class="alert alert-danger">Please enter KPI</span>');
            return false;
        }

        if(kpi.val() != "" && cca.val() != "" && ccz.val() != "" && id.val() != "")
        {
            errmsg.html('<span class="alert alert-info">please wait...</span>');

            $.ajax({
                type: 'POST',
                url: 'update_kpi',
                data: { id: id.val(), cca: cca.val(), ccz: ccz.val(), kpi: kpi.val(), _token:_token.val()},
                dataType: 'html',
                success: function(responseText){ // Get the result and asign to each cases
                    var result = $.parseJSON(responseText);
//                        alert(result);
                        if(result.status == 0){
                            errmsg.html('<span class="alert alert-danger">'+result.message+'</span>');
                        }
                        else if(result.status == 1){
                            errmsg.html('<span class="alert alert-success">'+result.message+'</span>');                                        
//                                window.location.href=window.location.href;
                            $("#edit_pub_kpi").val('');
                            $('#editKPI').modal('hide');

                        }
                        else if(result.status == 2){
                            errmsg.html('<span class="alert alert-info">'+result.message+'</span>');                                        
                        }
                    },
                error: function(data){
    //                        alert("fail---->"+JSON.stringify(data));
                    errmsg.html('<span class="alert alert-info">'+JSON.stringify(data)+'</span>'); 
                }    
            });
        }
        else
        {
            errmsg.html('<span class="alert alert-info">Oops, something went wrong</span>'); 
        }
    });
    
    
    $("#change_filter").click(function (){
//           alert(786); 
        var errmsg = $("#errmsg_chng_filter");
        var filter = $("#chng_filter_filter");
        var cca = $("#chng_filter_cca");
        var ccz = $("#chng_filter_ccz");
        var id = $("#chng_filter_id");
        if(filter.val() == "")
        {
            filter.focus();
            errmsg.html('<span class="alert alert-danger">Please enter cpa</span>');
            return false;
        }

        if(filter.val() != "" && cca.val() != "" && ccz.val() != "" && id.val() != "")
        {
            errmsg.html('<span class="alert alert-info">please wait...</span>');

            $.ajax({
                type: 'GET',
                url: 'update_filter',
                data: { id: id.val(), cca: cca.val(), ccz: ccz.val(), filter: filter.val()},
                dataType: 'html',
                success: function(responseText){ // Get the result and asign to each cases
                    var result = $.parseJSON(responseText);
                        
                        if(result.status == 0){
                            errmsg.html('<span class="alert alert-danger">'+result.message+'</span>');
                        }
                        else if(result.status == 1){
                            errmsg.html('<span class="alert alert-success">'+result.message+'</span>');                                        
//                                window.location.href=window.location.href;
                            $("#filter_"+id.val()).html(filter.val());
                            $('#changeFilter').modal('hide');

                        }

                        else if(result.status == 2){
                            errmsg.html('<span class="alert alert-info">'+result.message+'</span>');                                        
                        }
                    },
                error: function(data){
    //                        alert("fail---->"+JSON.stringify(data));
                    errmsg.html('<span class="alert alert-info">'+JSON.stringify(data)+'</span>'); 
                }    
            });
        }
        else
        {
            errmsg.html('<span class="alert alert-info">Oops, something went wrong</span>'); 
        }
    });
    $("#change_filterst").click(function (){
//           alert(786); 
        var errmsg = $("#errmsg_chng_filterst");
        var cca = $("#chng_filterst_cca");
        var ccz = $("#chng_filterst_ccz");
        var id = $("#chng_filterst_id");
        if($("#chng_filter_filterst option:selected").val()=="Select Status" )
        {
            errmsg.html('<span class="alert alert-danger">Please select status !</span>');
            return false;
        }

        if($("#chng_filter_filterst option:selected").val() != "Select Status" && cca.val() != "" && ccz.val() != "" && id.val() != "")
        {
            errmsg.html('<span class="alert alert-info">please wait...</span>');

            $.ajax({
                type: 'GET',
                url: 'update_filter_st',
                data: { id: id.val(), cca: cca.val(), ccz: ccz.val(), filterst: $("#chng_filter_filterst option:selected").val()},
                dataType: 'html',
                success: function(responseText){ // Get the result and asign to each cases
                    var result = $.parseJSON(responseText);
                        
                        if(result.status == 0){
                            errmsg.html('<span class="alert alert-danger">'+result.message+'</span>');
                        }
                        else if(result.status == 1){
                            errmsg.html('<span class="alert alert-success">'+result.message+'</span>');                                        
//                                window.location.href=window.location.href;
                            var text;
                            if($("#chng_filter_filterst option:selected").val() == '1')
                            {
                                text = 'Active';
                            }
                            else if($("#chng_filter_filterst option:selected").val() == '0')
                            {
                                text = 'Inactive';
                            }
                            $("#filter_st_"+id.val()).html(text);
                            $('#changeFilterSt').modal('hide');

                        }
                        else if(result.status == 2){
                            errmsg.html('<span class="alert alert-info">'+result.message+'</span>');                                        
                        }
                    },
                error: function(data){
    //                        alert("fail---->"+JSON.stringify(data));
                    errmsg.html('<span class="alert alert-info">'+JSON.stringify(data)+'</span>'); 
                }    
            });
        }
        else
        {
            errmsg.html('<span class="alert alert-info">Oops, something went wrong</span>'); 
        }
    });
    
    $("#change_postbackst").click(function (){
//           alert(786); 
        var errmsg = $("#errmsg_chng_postst");
        var cca = $("#chng_postst_cca");
        var ccz = $("#chng_postst_ccz");
        var id = $("#chng_postst_id");
        if($("#chng_postst_postst option:selected").val()=="Select Status" )
        {
            errmsg.html('<span class="alert alert-danger">Please select status !</span>');
            return false;
        }

        if($("#chng_postst_postst option:selected").val() != "Select Status" && cca.val() != "" && ccz.val() != "" && id.val() != "")
        {
            errmsg.html('<span class="alert alert-info">please wait...</span>');

            $.ajax({
                type: 'GET',
                url: 'update_post_st',
                data: { id: id.val(), cca: cca.val(), ccz: ccz.val(), postst: $("#chng_postst_postst option:selected").val()},
                dataType: 'html',
                success: function(responseText){ // Get the result and asign to each cases
                    var result = $.parseJSON(responseText);
                        
                        if(result.status == 0){
                            errmsg.html('<span class="alert alert-danger">'+result.message+'</span>');
                        }
                        else if(result.status == 1){
                            errmsg.html('<span class="alert alert-success">'+result.message+'</span>');                                        
//                                window.location.href=window.location.href;
                            var text;
                            if($("#chng_postst_postst option:selected").val() == '1')
                            {
                                text = 'Active';
                            }
                            else if($("#chng_postst_postst option:selected").val() == '0')
                            {
                                text = 'Inactive';
                            }
                            $("#postback_st_"+id.val()).html(text);
                            $('#changePostbackSt').modal('hide');

                        }
                        else if(result.status == 2){
                            errmsg.html('<span class="alert alert-info">'+result.message+'</span>');                                        
                        }
                    },
                error: function(data){
    //                        alert("fail---->"+JSON.stringify(data));
                    errmsg.html('<span class="alert alert-info">'+JSON.stringify(data)+'</span>'); 
                }    
            });
        }
        else
        {
            errmsg.html('<span class="alert alert-info">Oops, something went wrong</span>'); 
        }
    });
    

 var moveLeft = 20;
  var moveDown = 0;

  $('span#trigger').hover(function(e) {
    $('div#pop-up').show()
      .css('top', e.pageY + moveDown)
      .css('left', e.pageX + moveLeft)
      .appendTo('body');
  }, function() {
    $('div#pop-up').hide();
  });

  $('span#trigger').mousemove(function(e) {
    $("div#pop-up").css('top', e.pageY + moveDown).css('left', e.pageX + moveLeft);
  });


    
        
    });
$("input[name='is_offer_direct']").change(function(){
      if($(this).val() == 1 || $(this).val()==2 || $(this).val()==3){
         $('#process2').show().html('<span class="alert alert-info">Please Wait</span>');
         var thsi_value=$(this).val();
       $.ajax({
            url : '/editofferwallTrfcis_offer_direct',
            type: 'GET',
            data: 'selected_value='+thsi_value+'&camp_id='+$("#camp_id").val()+'&id_zone='+$("#id_zone").val(),
            // async: false,
            dataType:'json',
            }).done(function (response) {
                 
                  if(response.status == 1){
                    $('#process2').show().html('<span class="alert alert-success">'+response.message+'</span>');
                      $('#process2').delay(5000).fadeOut('slow');
                       // window.location.href=window.location.href;
                  }else if(response.status == 3){
                    $('#process2').show().html('<span class="alert alert-success">'+response.message+'</span>');
                      $('#process2').delay(5000).fadeOut('slow');
                    
                       // window.location.href=window.location.href;
                  }else{
                     $('#process2').show().html('<span class="alert alert-danger">'+response.message+'</span>');
                    
                    $('#process2').delay(3000).fadeOut('slow');

                  }

            });
        }
 $('#process2').delay(3000).fadeOut('slow');

});

    var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

  $(document).on("change",".radiobox3", function(){
        var x=1;
        var count_array =0;
          var check = true;
            var id = $(this).attr("id");
            console.log(id);
                var is_selected = $("#"+id).attr('checked', true);
                 var is_smart = $("#"+id).val();
                 var index_count = id.slice(-1);
                 
                var advertiser_campaign="";
                if(is_smart == 'DEFAULT'){
                  $("#campagin_name_diversion_"+index_count).html('').selectpicker('refresh');
                   var cca = $("#parent_cca").val();
                   var id = cca;
                   var cco = $("#op_id").val();
                   $('#process2').show().html('<span class="alert alert-info">Submitting data please wait......</span>');
                  $.ajax({
                    url : 'editofferwallTrfcisofferlist',
                    type: 'post',
                        cache: false,
                    dataType: 'JSON',
                     async: true,
                    data: "conditon=default&cca="+id+"&cco="+cco+"&_token="+CSRF_TOKEN,
                      success: function(response){
                       if(response.status == 1){
                          if(response.advertiser_campaigns){
                              $(response.advertiser_campaigns).each(function(key,campaign){
                              advertiser_campaign += '<option value="'+campaign.id+'"">'+campaign.name+'-- ('+campaign.id+')</option>';
                              });
                            }else{
                            alert('there is no campaign');
                            }
                            $("#spinner").hide();
                            $("#campagin_name_diversion_"+index_count).html(advertiser_campaign).selectpicker('refresh');
                            }
                            $('#process2').delay(3000).fadeOut('slow');
                        }
                });
                
                } else{
                if(is_selected && is_smart){
                   $('#process2').show().html('<span class="alert alert-info">Submitting data please wait......</span>');
                    var cca = $("#parent_cca").val();
                    $.ajax({
                        url : 'editofferwallTrfcisofferlist',
                        type: 'post',
                        dataType: 'JSON',
                         async: true,
                        data: "conditon=nodefault&is_smart="+is_smart+"&cca="+cca+"&_token="+CSRF_TOKEN,
                      
                    }).done(function (responses){
                       console.log(responses.status+"resCPI");
                            if($.trim(responses.status)==1){
                                if($.trim(responses.advertiser_campaigns)){
                                    $(responses.advertiser_campaigns).each(function(key,campaign){
                                       advertiser_campaign += '<option value="'+campaign.id+'"">'+campaign.name+'-- ('+campaign.id+')</option>';
                                    });
                                 }
                                else{
                                    alert('there is no campaign'+is_smart);
                                 }
                               $("#campagin_name_diversion_"+index_count).html(advertiser_campaign).selectpicker('refresh');
                               // $("#addCampaignsByOperator").selectpicker();
                                $('#process2').delay(3000).fadeOut('slow');
                            }
                        
                    }).fail(function () {
                            alert('Data could not be loaded.');
                            $("#spinner").hide();
                    });
                }
                 }     
            });
    
function display_pop(pacc,id_zone,camp){
$("#pop-up").html('');
  $.ajax({
    url:'display_popups',
    type:'get',
    async:'true',
    data:'campaign_id='+camp+"&id_zone="+id_zone,
    dataType : "html",

    beforeSend:function(){
       $("#pop-up").html('Please wait..');
    },
    success: function(response){
      
      $("#pop-up").html(response);
      
   }
  });


}

var selected_rotator_id = [];

function getSelectedValue(e, val) {
    var label = $(e).siblings("label");
//    alert(label.text());
    selected_rotator_id.push(label.text());    
}


function pause()
{
    console.log(selected_rotator_id);
//    alert(selected_rotator_id);
    $('#errmsg_chng_active_pause').html('<span class="alert alert-info">Please wait.......</span>');
    
    $.ajax({
        url: "/change_active_status", // make sure you set an action attribute to your form
        type: 'GET',
        cache: false,
        async: true,
        data: { id: selected_rotator_id},
        dataType: 'JSON',
        success: function(res)
        {
//            alert(res);
//                var res = response; 
            if(res.status == 1)
            {
                $('#errmsg_chng_active_pause').html('<span class="alert alert-success">'+res.message+'</span>');
                window.location.href=window.location.href;
            }
            else if (res.status == 2)
            {
                $('#errmsg_chng_active_pause').html('<span class="alert alert-info">'+res.message+'</span>');
            }
            else if (res.status == 0)
            {
                $('#errmsg_chng_active_pause').html('<span class="alert alert-danger">'+res.message+'</span>');
            }
        }
    });
    
}
function live()
{
    console.log(selected_rotator_id);
    $('#errmsg_chng_active_pause').html('<span class="alert alert-info">Please wait.......</span>');
    
    $.ajax({
        url: "/change_pause_status", // make sure you set an action attribute to your form
        type: 'GET',
        cache: false,
        async: true,
        data: { id: selected_rotator_id},
        dataType: 'JSON',
        success: function(res)
        {
//            alert(res);
//                var res = response; 
            if(res.status == 1)
            {
                $('#errmsg_chng_active_pause').html('<span class="alert alert-success">'+res.message+'</span>');
                window.location.href=window.location.href;
            }
            else if (res.status == 2)
            {
                $('#errmsg_chng_active_pause').html('<span class="alert alert-info">'+res.message+'</span>');
            }
            else if (res.status == 0)
            {
                $('#errmsg_chng_active_pause').html('<span class="alert alert-danger">'+res.message+'</span>');
            }
        }
    });
}

    function changeTrfc(_cca, _ccz, _id)
{
   addmore(_id);
    var info_obj;
    var info_detail;
    var campaign_ids = [];
    var percentage_vals = [];
    var select=$("#campagin_name_diversion_1");
    $('#div_list').html('');
//    $("#campagin_name_diversion_1").val('');
    $("#add_more").html('');
    select.html('');
    
//    var inc = 2;
    if(_cca!='' && _ccz!='' && _id!='')
    {
        $('#parent_cca').val(_cca);
        $('#id_zone').val(_ccz);
        $('#camp_id').val(_id);
        
        $("#process2").show().html('<span class="alert alert-info">Please wait......</span>');
        
    $.ajax({
            url: '/getTrfcCampaign',
            type: 'get',
            data: 
            {
                id : _id, id_zone:_ccz,
            },
            cache: false,
            dataType: 'json',
            success: function(response)
            {
                if(response.is_direct == 1)
                {
                 $("input[name='is_offer_direct'][value='"+response.is_direct+"']").prop('checked', true);
                }
                else if(response.is_direct == 2){
                $("input[name='is_offer_direct'][value='"+response.is_direct+"']").prop('checked', true);
                }
                else if(response.is_direct == 3){
                $("input[name='is_offer_direct'][value='"+response.is_direct+"']").prop('checked', true);
                }

                  $("#op_id").val(response.op_id);

                  $("#country_code").val(response.country_code);

                $.each(response.campaigns,function(index,json){
                    select.append($("<option></option>").attr("value", json.campaign_id).text(json.offer_url+"{"+json.campaign_id+"}"));
                });
                
                $("#div_list").html(response.diversion_list);
                $("#process2").hide();  
         
             
            }

        });
        
        $('#changeTrfc').modal({
            backdrop: 'static',
            keyboard: false,  // to prevent closing with Esc button (if you want this too)
            show: true
        });
        
    }
} 
 

    $('#submit_trfc').click(function(event)
    {
        event.preventDefault();
        var error = '';
        var campaign_ids = [];
        var percentage_vals = [];
        
        $('.campagin_name_diversion').each(function(){
          var count = 2;
            if($(this).val() == 'Select Campagin')
            {
//                $('#process2').show().html('<span class="alert alert-info">Select Campaign Name column '+count+'</span>');
                $('#process2').show().html('<span class="alert alert-info">Select Campaign Name column</span>');
                error +='1';
                return false;
            }
            else
            {
                //campaign_ids.push($(this).val());
                
                
                
//                console.log($(this).val() +"caamp");/
                if($(this).val()!="")
                {
                   campaign_ids.push($(this).val());
                }
                
                
                
        //   error +='';
        //  return true;
            }
            count = count + 1;
        });
  
        $('.percentage').each(function()
        {
            var count = 2;
            if($(this).val() == '')
            {
                $('#process2').show().html('<span class="alert alert-info">Enter Percentage column '+count+'</span>');
                error +='1';
                return false;
            }
            else
            {
                console.log($(this).val() +"percentage");
                percentage_vals.push($(this).val());
                error +='';
                return true;
            }
            count = count + 1;
        });
        
        

        console.log(error+"hello");
        if(error=='')
        {
            var camp_id=$("#camp_id").val();
            var op_id=$("#op_id").val();
            var id_zone=$("#id_zone").val();
            var div_val=$("input[name='is_offer_direct']:checked").val();

            $('#process2').show().html('<span class="alert alert-info">Submitting data please wait......</span>');
                    
            info_detail = [];
            info_obj = {
                'campaign_id': campaign_ids,
                'percentage_value': percentage_vals,
            }
            info_detail.push(info_obj);
            console.log(JSON.stringify(info_detail)+"details");
            $.ajax({
                type: 'GET',
                data : { campaign_data: JSON.stringify(info_detail), camp_id: camp_id, zone: id_zone, is_offer_direct:div_val },
                dataType: "JSON",
                 cache: false,
                url: '/addTrfcCampaign',
                success: function(responseText)
                { // Get the result and asign to each cases
                    var result = responseText;
//                                alert(result);
                    if(result.status == 1){
                        $('#process2').show().html('<span class="alert alert-success">'+result.message+'</span>');
                        // window.location.href=window.location.href;
                        $('#changeTrfc').modal('hide');
                    }
                    else if(result.status == 2){
                        $('#process2').show().html('<span class="alert alert-info">'+result.message+'</span>');
                    } 
                }
//                        error: function(data){
//                                    alert("fail---->"+JSON.stringify(data));
//                        }    
            });
        }
    });


 function addmore(_id){
       var inc=2;         
   
    
         $('.add_more_field').on('click',function(event){
        event.preventDefault(); 

          $("#add_more").html();
               
                    $('#process2').show().html('<span class="alert alert-info">Please wait......</span>');
                
                     $.ajax({
                        url: '/addMoreRaw',
                        type: 'get',
                        data: {
                                id : _id, button_id :  inc++,
                        },
                        cache: false,
                        dataType: 'html',
                  
                        success: function(response)
                        {
                           $("#add_more").append(response);

                            $('.mySelects').each(function(){$(this).select2()});
                            $("#process2").hide();
                           
                        }

                    });
                });
 }


  $("#add_more").on("click",".remove",function(e){

       $(this).parents('table').remove();
  });
    
    
function changeActStatus(_cca, _ccz, _id, _st)
{
    $('#errmsg_chng_st').html('');
    if(_cca!='' && _ccz!='' && _id!='')
    {
        $('#chng_st_cca').val(_cca);
        $('#chng_st_ccz').val(_ccz);
        $('#chng_st_id').val(_id);
        document.getElementById('chng_st_st').value=_st;
        
        $('#changeActStatus').modal({
            backdrop: 'static',
            keyboard: false,  // to prevent closing with Esc button (if you want this too)
            show: true
        })
    }
}
function changeCpa(_cca, _ccz, _id, _cpa)
{
    $('#errmsg_chng_cpa').html('');
    if(_cca!='' && _ccz!='' && _id!='')
    {
        $('#chng_cpa_cca').val(_cca);
        $('#chng_cpa_ccz').val(_ccz);
        $('#chng_cpa_id').val(_id);
        $('#chng_cpa_cpa').val(_cpa);
        
        $('#changeCpa').modal({
            backdrop: 'static',
            keyboard: false,  // to prevent closing with Esc button (if you want this too)
            show: true
        })
    }
}
function changeCap(_cca, _ccz, _id, _cap)
{
    $('#errmsg_chng_cap').html('');
    if(_cca!='' && _ccz!='' && _id!='')
    {
        $('#chng_cap_cca').val(_cca);
        $('#chng_cap_ccz').val(_ccz);
        $('#chng_cap_id').val(_id);
        $('#chng_cap_cap').val(_cap);
        
        $('#changeCap').modal({
            backdrop: 'static',
            keyboard: false,  // to prevent closing with Esc button (if you want this too)
            show: true
        })
    }
}

function changeCapClick(_cca, _ccz, _id, _cap_count_click)
{
    $('#errmsg_chng_cap').html('');
    if(_cca!='' && _ccz!='' && _id!='')
    {
        $('#chngc_cap_cca').val(_cca);
        $('#chngc_cap_ccz').val(_ccz);
        $('#chngc_cap_id').val(_id);
        $('#change_clicks_count_cpa').val(_cap_count_click);
        
        $('#clicks_count_cap').modal({
            backdrop: 'static',
            keyboard: false,  // to prevent closing with Esc button (if you want this too)
            show: true
        })
    }
}


function changeCapinstall(_cca, _ccz, _id, _cap_count_install)
{
    $('#errmsg_chng_cap').html('');
    if(_cca!='' && _ccz!='' && _id!='')
    {
        $('#chngi_cap_cca').val(_cca);
        $('#chngi_cap_ccz').val(_ccz);
        $('#chngi_cap_id').val(_id);
        $('#change_install_count_cpa').val(_cap_count_install);
        
        $('#install_count_cap').modal({
            backdrop: 'static',
            keyboard: false,  // to prevent closing with Esc button (if you want this too)
            show: true
        })
    }
}
function changeCapSale(_cca, _ccz, _id, _cap_count_sale)
{
    $('#errmsg_sale_cap').html('');
    if(_cca!='' && _ccz!='' && _id!='')
    {
        $('#sale_cap_cca').val(_cca);
        $('#sale_cap_ccz').val(_ccz);
        $('#sale_cap_id').val(_id);
        $('#change_sale_count_cpa').val(_cap_count_sale);
        
        $('#sale_count_cap').modal({
            backdrop: 'static',
            keyboard: false,  // to prevent closing with Esc button (if you want this too)
            show: true
        })
    }
}




function changeFilter(_cca, _ccz, _id, _filter)
{
    $('#errmsg_chng_filter').html('');
    if(_cca!='' && _ccz!='' && _id!='')
    {
        $('#chng_filter_cca').val(_cca);
        $('#chng_filter_ccz').val(_ccz);
        $('#chng_filter_id').val(_id);
        $('#chng_filter_filter').val(_filter);
        
        $('#changeFilter').modal({
            backdrop: 'static',
            keyboard: false,  // to prevent closing with Esc button (if you want this too)
            show: true
        })
    }
}

function changeFilterSt(_cca, _ccz, _id, _filterst)
{
    $('#errmsg_chng_filterst').html('');
    if(_cca!='' && _ccz!='' && _id!='')
    {
        $('#chng_filterst_cca').val(_cca);
        $('#chng_filterst_ccz').val(_ccz);
        $('#chng_filterst_id').val(_id);
        document.getElementById('chng_filter_filterst').value=_filterst;

            $('#changeFilterSt').modal({
            backdrop: 'static',
            keyboard: false,  // to prevent closing with Esc button (if you want this too)
            show: true
        })
    }
}
function changePostbackSt(_cca, _ccz, _id, _postst)
{
    $('#errmsg_chng_postst').html('');
    if(_cca!='' && _ccz!='' && _id!='')
    {
        $('#chng_postst_cca').val(_cca);
        $('#chng_postst_ccz').val(_ccz);
        $('#chng_postst_id').val(_id);
        document.getElementById('chng_postst_postst').value=_postst;

            $('#changePostbackSt').modal({
            backdrop: 'static',
            keyboard: false,  // to prevent closing with Esc button (if you want this too)
            show: true
        })
    }
}

function viewDetails(_cca, _ccz, _id)
{
    $('#errmsg_offer_details').html('Please wait......');
    $('#result_data').html('');
    if(_cca!='' && _ccz!='' && _id!='')
    {
//        $('#chng_postst_id').val(_id);
        $('#viewDetails').modal({
            backdrop: 'static',
            keyboard: false,  // to prevent closing with Esc button (if you want this too)
            show: true
        });
        $.ajax({
            type: 'GET',
            url: 'display_offer',
            data: { id: _id, cca: _cca, ccz: _ccz},
            dataType: 'JSON',
            success: function(responseText){ // Get the result and asign to each cases
//                var result = $.parseJSON(responseText);
                if(responseText.status == 0)
                {
                    alert(responseText.message);
                }
                else if(responseText.status == 1)
                {
                    $('#errmsg_offer_details').html('');
                    $('#result_data').html(responseText.array_data);
                }
                else if(responseText.status == 2){
                    alert(responseText.message);
                }
            },
            error: function(data){
                        alert("fail---->"+JSON.stringify(data));
            }    
        });

    }
}

function editKPI(_cca, _ccz, _id, _kpi)
{
//    $('#errmsg_edit_kpi').html('Please wait......');
    
//    alert(_id);
//    alert(_kpi);
    
    if(_cca!='' && _ccz!='' && _id!='')
    {
        $('#edit_kpi_cca').val(_cca);
        $('#edit_kpi_ccz').val(_ccz);
        $('#edit_kpi_id').val(_id);
        $('#edit_pub_kpi').val(_kpi);
        $('#editKPI').modal({
            backdrop: 'static',
            keyboard: false,  // to prevent closing with Esc button (if you want this too)
            show: true
        });

    }
}

function CopyUrl( _id, _text)
{
    if( _text!='' && _id!='')
    {
        copyToClipboard('#copy_'+_id)
    }
    else
    {
        alert("Url is empty");
    }
}
function CopyPreview( _id, _text)
{
    if( _text!='' && _id!='')
    {
        copyToClipboard2('#copy_preview_'+_id)
    }
    else
    {
        alert("Preview is empty");
    }
}
    
    
function copyToClipboard(element) 
{
    var $temp = $("<input>");
    $("body").append($temp);
    $temp.val($(element).text()).select();
    document.execCommand("copy");
    $temp.remove();
}
function copyToClipboard2(element) 
{
    var $temp = $("<input>");
    $("body").append($temp);
    $temp.val($(element).text()).select();
    document.execCommand("copy");
    $temp.remove();
}
//function copyToClipboard3() 
//{
//    alert(786);
////    var $temp = $("<input>");
////    $("body").append($temp);
//    var $temp.val($('#result_data').text()).select();
//    document.execCommand("copy");
//    $temp.remove();
//}


 $(document).on('click',".percentage-edit",function(){
          if($(".outer-container").find('.percentage-container').is(':hidden')){
             $(".outer-container").each(function(){ 
             $(this).find('.percentage-container').show();
             var div_id = $(this).find('.percentage-container').attr('id');
              id = div_id.split('_'); 
              closeEditPercenatge(id[1]);
            });  
          } 
          $(this).hide();
          var div_id = $(this).attr('id'),
          id_zone = $(this).attr('data_id_zone'),
          Percentage = $(this).attr('data-value'),
          campain_data= $(this).attr('campain_data'),
          editPercentage = '';

          id =  div_id.split('-');
          var new_id =$(this).attr('campaign_id');
          $("#percentage-container_"+id[1]).hide();
          if(id_zone && Percentage){
          editPercentage += '&nbsp;<input type="text" class="percentage-text" campain_data='+campain_data+' data_id_zone='+ id_zone+' id="percentage-edit_'+campain_data+'"  size="4"  org_value="'+new_id+'" value="'+Percentage+'">&nbsp&nbsp<i class="glyphicon glyphicon-remove cancel-percent" data-id='+campain_data+' id="cancel-'+campain_data+'"></i>';
        

          }
          // $("#percentage-container_"+id[1]).hide();
          $("#"+div_id).after(editPercentage);
        });
    
    $(document).on('keypress',".percentage-text",function(e){
        $('#process2').show().html('<span class="alert alert-info">Please wait!!!</span>');
          if(e.keyCode == 13){
           var div_id =  $(this).attr('id');
           
           var id_zone = $(this).attr('data_id_zone');
           var row_campain_id = $(this).attr('campain_data'),
           id = div_id.split('_'),
           org_va= $(this).attr('org_value');

           var Percentage = $("#percentage-edit_"+id[1]).val();
            $.ajax({
            url : '/editofferwallTrfc',
            type: 'GET',
            data: 'new_value='+Percentage+'&id='+org_va+'&id_zone='+id_zone+'&row_campain_id='+row_campain_id,
            // async: false,
            dataType:'json',
            }).done(function (response) {
                
                if(response.status == 1){
                    $("#percentage_container_"+row_campain_id).html(response.hold_percentage);

                    $("#percentage-"+row_campain_id).attr('data-value',response.hold_percentage);
                    closeEditPercenatge(row_campain_id);
                      $('#process2').show().html('<span class="alert alert-success">'+response.message+'</span>');
                    
                }
                 $('#process2').delay(2000).fadeOut('slow');
               
            }).fail(function () {
                alert('Data could not be loaded.');
               
            });
          }     
        });
      var closeEditPercenatge = function(id){
             $("#percentage-"+id).show();
             $("#percentage-edit_"+id).remove();
             $("#cancel-"+id).remove();
             $('#save-'+id).remove();
             $("#percentage_container_"+id).show();
         }
    function deleteTrfc(_jsoncam_id,_campaign_id,_id_zone)
{
    
    
    if(_jsoncam_id != '' && _campaign_id != '' && _id_zone != '')
    {
        $('#process2').show().html('<span class="alert alert-info">Please wait!!!</span>');
        
        $.ajax({
            url: "/delete_trfc", // make sure you set an action attribute to your form
            type: 'GET',
            cache: false,
            async: true,
            dataType: 'JSON',
            data: {'json_camp_id':_jsoncam_id,'campaign_id':_campaign_id,'id_zone':_id_zone},
            success: function(res)
            {
//                var res = response; 
                if(res.status == 1)
                {
                    $('#process2').show().html('<span class="alert alert-success">'+res.message+'</span>');
                    // window.location.href=window.location.href; _cca, _ccz, _id
                    changeTrfc(_campaign_id,_id_zone,_campaign_id);
                }
                else if (res.status == 2)
                {
                    $('#process2').show().html('<span class="alert alert-info">'+res.message+'</span>');
                }
            }
        });
    }
} 
 
  </script>




<style>
.body{width:100%;}
.table-head{background-color:#3e96c9;color:#fff;}
</style>
<style type="text/css">
    .lazy tr > td{
        text-align: center;
    }
    .modal-dialog {
    max-width: 1073px;
    margin: 30px auto;
}

input:focus {
         font-family:Verdana, Geneva, sans-serif;
    border-color:#9ecaed;
    box-shadow:0 0 5px #9ecaed;
}
div#pop-up {
  display: none;
  position: absolute;
  width: 380px;
  padding: 20px;
  background: #fff;
  color: #000000;
  border: 1px solid #1a1a1a;
  font-size: 90%;
}
</style>

<script type="text/javascript">

function resetFilters(){
  $(".selectpicker").val('default');
  $(".selectpicker").selectpicker("refresh");
  $("#diversion,#only_status, #end_date, #start_date").val("");
}
</script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php 
    
//    echo "<pre>";
//    print_r($data1);
//    echo "</pre>";
    
    ?>
    <div class="m-b-15 header-panel" style="text-align:center;">

        
    </div>
    <div class="row" style="margin: 2%">
        <div class="col-sm-12">
            <div class="form-group">
                <form name="" method="POST" action="/publisherOfferList">
                    <?php echo e(csrf_field()); ?>

                    <div class="row first-row">
                
                        <div class="col-sm-3">
                            <div><label>Network</label></div>     
                                <select name="network_name[]" id="network_name" multiple class="selectpicker"data-live-search="true" data-actions-box="true" data-selected-text-format="count > 3" data-size="10" data-style="btn-primary">
                                    <?php 
                                        foreach ($network as $key => $value) {?>
                                        <option value="<?php echo $value->ccz ?>"><?php echo $value->name.' ('.$value->ccz.')'; ?></option>
                                    <?php 
                                        }
                                    ?>

                                </select>
                        </div>
                        <div class="col-sm-3">
                            <div><label>Campaign</label></div>     
                            <select name="campaign_name[]" id="campaign_name" multiple class="selectpicker"data-live-search="true" data-actions-box="true" data-selected-text-format="count > 3" data-size="10" data-style="btn-danger">
                                <?php 
                                    foreach ($campaigns_list as $key => $value) {?>
                                    <option value="<?php echo $value->id ?>"><?php echo $value->name.' ('.$value->id.')'; ?></option>
                                <?php 
                                    }
                                ?>
                            </select>
                        </div>
                        <div class="col-sm-3">
                            <div><label>Diversion</label></div>
                            <select id="diversion" name="diversion" class="form-control">                        
                                <option value="">Select Diversion</option>
                                <option value="1" <?php if($div == '1') { echo 'selected';} ?>>1</option>
                                <option value="2" <?php if($div == '2') { echo 'selected';} ?>>2</option>
                                <option value="3" <?php if($div == '3') { echo 'selected';} ?>>3</option>                   
                            </select>
                        </div>
                        <div class="col-sm-3">
                            <div><label>Status</label></div>
                            <select id="only_status" name="only_status" class="form-control">                        
                                <option value="">Select Status</option>
                                <option value="1" <?php if($filter_st == '1') { echo 'selected';} ?>>Active</option>
                                <option value="0" <?php if($filter_st == '0') { echo 'selected';} ?>>Pause</option>
                            </select>
                        </div>
                    </div>
                    <br>
                    <div class="row first-row">                
                        
                        
                        <div class="col-sm-3">
                            <div><label>From Date</label></div>
                            <input type="text" value="<?php echo $dtvalue; ?>" style="width: 200px;" class="form-control mydatepicker1" name="start_date" id="start_date" placeholder="From Date">
                        </div>
                        <div class="col-sm-3">
                            <div><label>End Date</label></div>
                            <input type="text" value="<?php echo $dtvalue2; ?>" style="width: 200px;" class="form-control mydatepicker1" name="end_date" id="end_date" placeholder="To Date">
                        </div>
                        <div class="col-sm-3">
                            <button type="submit" class="form-control table-head" name="go_ahead" id="go_ahead">Go</button>
                        </div>
                        <div class="col-sm-3">
                            <button type="button" name="reset" onclick="resetFilters()" class="btn btn-warning pull-right">Reset</button>
                        </div>

                    </div>
<!--                    <br>
                    <div class="row first-row">
                        
                        <div class="col-sm-4"></div>
                        
                    </div>-->
                    
            
                </form>
                
            </div>            
        </div>
    </div>
    <div class="col-sm-12">
        
        <div id="errmsg_chng_active_pause" style="text-align: center;margin-bottom:20px;"></div>
        <div class="text-right ">
            <?php 
                $heads =  
                [
                    "CCA",  
                    "Active",    
                    "NetworkName",                                             
                    "CPA",                                             
                    "Pub Install Cap",                                             
                    "Clicks Count",                                             
                    "Install Count",                                             
                    "Sale Count",                                             
                    "Ads Type",                                                              
                    "Campaign",
                    "Offer",
                    "Div",
                    "Geo",
                    "Os",
                    "Filter",
                    "Filter Status",
                    "PostBack Status",
                    "Url",
                    "Preview",
                    "Details",
                    "Approved On"
                      
                            
                ];
                            
             ?>
                <div class="text-left" style="margin-bottom:10px">
                    <?php echo view('layouts.column', ['data' =>$heads]); ?>

                    <button type="button" name="pause" onclick="pause()" class="btn btn-danger">Pause</button>
                    <button type="button" name="pause" onclick="live()" class="btn btn-success">Live</button>
                </div>
            <div class="text-right">
                
            </div>
            <div class="text-right">
                
            </div>
            </div>
        <div class="table-responsive mainTableInfo">
                <table class="table color-table info-table scrollTable lazy" id="tableLazy">
                    <?php echo view('layouts.tableheadNew', ['data' =>$heads,'class'=>""]); ?>

                </table>


        </div> 
                           
    </div>
<div class="modal fade" id="changeActStatus" role="dialog" style="margin-top: 40px">
    <div class="modal-dialog bd-example-modal-md modal-md">    
    <!-- Modal content-->
        <div class="modal-content ">
            <div class="modal-header modal-header1 text-center" style="margin-top: 35px;">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Change Status</h4>
            </div>
            <div class="modal-body">            
                <div id="errmsg_chng_st" style="text-align: center;margin-bottom:20px;"></div>
                <form method="post" action="" class="form-horizontal">
                    <input class="form-control" type="hidden" name="chng_st_cca" id="chng_st_cca" readonly/>
                    <input class="form-control" type="hidden" name="chng_st_ccz" id="chng_st_ccz" readonly/>
                    <input class="form-control" type="hidden" name="chng_st_id" id="chng_st_id" readonly/>
                    <div class="form-group col-sm-12">
                        <div class="row">
                            <label class="col-sm-3 control-label">Status</label>
                            <div class="col-sm-8">
                                <select class="form-control" name="chng_st_st" id="chng_st_st">
                                    <option value="Select Status">Select Status</option>
                                    <option value="1">Active</option>
                                    <option value="0">Inactive</option>
                                </select>
                            </div>
                        </div>                        
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" style="color:#fff; background-color: #FF414D; border-color: #FF414D">Cancel</button>
                <button type="submit" class="btn btn-primary" style="color:#fff; background-color: #67C9E0; border-color: #67C9E0;" id="change_status">Change</button>
            </div>
      </div>      
    </div>
</div>
<div class="modal fade" id="changeCpa" role="dialog" style="margin-top: 40px">
    <div class="modal-dialog bd-example-modal-md modal-md">    
    <!-- Modal content-->
        <div class="modal-content ">
            <div class="modal-header modal-header1 text-center" style="margin-top: 35px;">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Change Cpa</h4>
            </div>
            <div class="modal-body">            
                <div id="errmsg_chng_cpa" style="text-align: center;margin-bottom:20px;"></div>
                <form method="post" action="" class="form-horizontal">
                    <input class="form-control" type="hidden" name="chng_cpa_cca" id="chng_cpa_cca" readonly/>
                    <input class="form-control" type="hidden" name="chng_cpa_ccz" id="chng_cpa_ccz" readonly/>
                    <input class="form-control" type="hidden" name="chng_cpa_id" id="chng_cpa_id" readonly/>
                    <div class="form-group col-sm-12">
                        <div class="row">
                            <label class="col-sm-3 control-label">Cpa</label>
                            <div class="col-sm-8">
                                <input style="width: 100%;"type="text" name="chng_cpa_cpa" id="chng_cpa_cpa" class="form-control" placeholder="0.2"/>
                            </div>
                        </div>                        
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" style="color:#fff; background-color: #FF414D; border-color: #FF414D">Cancel</button>
                <button type="submit" class="btn btn-primary" style="color:#fff; background-color: #67C9E0; border-color: #67C9E0;" id="change_cpa">Change</button>
            </div>
      </div>      
    </div>
</div>
<div class="modal fade" id="changeCap" role="dialog" style="margin-top: 40px">
    <div class="modal-dialog bd-example-modal-md modal-md">    
    <!-- Modal content-->
        <div class="modal-content ">
            <div class="modal-header modal-header1 text-center" style="margin-top: 35px;">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Change Cap</h4>
            </div>
            <div class="modal-body">            
                <div id="errmsg_chng_cap" style="text-align: center;margin-bottom:20px;"></div>
                <form method="post" action="" class="form-horizontal">
                    <input class="form-control" type="hidden" name="chng_cap_cca" id="chng_cap_cca" readonly/>
                    <input class="form-control" type="hidden" name="chng_cap_ccz" id="chng_cap_ccz" readonly/>
                    <input class="form-control" type="hidden" name="chng_cap_id" id="chng_cap_id" readonly/>
                    <div class="form-group col-sm-12">
                        <div class="row">
                            <label class="col-sm-3 control-label">Cap</label>
                            <div class="col-sm-8">
                                <input style="width: 100%;"type="text" name="chng_cap_cap" id="chng_cap_cap" class="form-control" placeholder="0.2"/>
                            </div>
                        </div>                        
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" style="color:#fff; background-color: #FF414D; border-color: #FF414D">Cancel</button>
                <button type="submit" class="btn btn-primary" style="color:#fff; background-color: #67C9E0; border-color: #67C9E0;" id="change_cap">Change</button>
            </div>
      </div>      
    </div>
</div>

<!-- clicks_count module-->
<div class="modal fade" id="clicks_count_cap" role="dialog" style="margin-top: 40px">
    <div class="modal-dialog bd-example-modal-md modal-md">    
    <!-- Modal content-->
        <div class="modal-content ">
            <div class="modal-header modal-header1 text-center" style="margin-top: 35px;">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Change Click Count Cap</h4>
            </div>
            <div class="modal-body">            
                <div id="errmsg_chng_cap" style="text-align: center;margin-bottom:20px;"></div>
                <form method="post" action="" class="form-horizontal">
                    <input class="form-control" type="hidden" name="chngc_cap_cca" id="chngc_cap_cca" readonly/>
                    <input class="form-control" type="hidden" name="chngc_cap_ccz" id="chngc_cap_ccz" readonly/>
                    <input class="form-control" type="hidden" name="chngc_cap_id" id="chngc_cap_id" readonly/>
                    <div class="form-group col-sm-12">
                        <div class="row">
                            <label class="col-sm-3 control-label">Cap</label>
                            <div class="col-sm-8">
                                <input style="width: 100%;"type="text" name="change_clicks_count_cpa" id="change_clicks_count_cpa" class="form-control" placeholder="0.2"/>
                            </div>
                        </div>                        
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" style="color:#fff; background-color: #FF414D; border-color: #FF414D">Cancel</button>
                <button type="submit" class="btn btn-primary" style="color:#fff; background-color: #67C9E0; border-color: #67C9E0;" id="clicks_count_cpabtn">Change</button>
            </div>
      </div>      
    </div>
</div>
<!-- End Here Cpa click module-->


<!-- install_count module-->
<div class="modal fade" id="install_count_cap" role="dialog" style="margin-top: 40px">
    <div class="modal-dialog bd-example-modal-md modal-md">    
    <!-- Modal content-->
        <div class="modal-content ">
            <div class="modal-header modal-header1 text-center" style="margin-top: 35px;">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Change Install Count Cap</h4>
            </div>
            <div class="modal-body">            
                <div id="errmsg_chng_cap_install" style="text-align: center;margin-bottom:20px;"></div>
                <form method="post" action="" class="form-horizontal">
                    <input class="form-control" type="hidden" name="chngi_cap_cca" id="chngi_cap_cca" readonly/>
                    <input class="form-control" type="hidden" name="chngi_cap_ccz" id="chngi_cap_ccz" readonly/>
                    <input class="form-control" type="hidden" name="chngi_cap_id" id="chngi_cap_id" readonly/>
                    <div class="form-group col-sm-12">
                        <div class="row">
                            <label class="col-sm-3 control-label">Cap</label>
                            <div class="col-sm-8">
                                <input style="width: 100%;"type="text" name="change_install_count_cpa" id="change_install_count_cpa" class="form-control" placeholder="0.2"/>
                            </div>
                        </div>                        
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" style="color:#fff; background-color: #FF414D; border-color: #FF414D">Cancel</button>
                <button type="submit" class="btn btn-primary" style="color:#fff; background-color: #67C9E0; border-color: #67C9E0;" id="install_count_cpabtn">Change</button>
            </div>
      </div>      
    </div>
</div>
<!-- sale_count module-->
<div class="modal fade" id="sale_count_cap" role="dialog" style="margin-top: 40px">
    <div class="modal-dialog bd-example-modal-md modal-md">    
    <!-- Modal content-->
        <div class="modal-content ">
            <div class="modal-header modal-header1 text-center" style="margin-top: 35px;">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Change Sale Count Cap</h4>
            </div>
            <div class="modal-body">            
                <div id="errmsg_chng_cap_sale" style="text-align: center;margin-bottom:20px;"></div>
                <form method="post" action="" class="form-horizontal">
                    <input class="form-control" type="text" name="sale_cap_cca" id="sale_cap_cca" readonly/>
                    <input class="form-control" type="text" name="sale_cap_ccz" id="sale_cap_ccz" readonly/>
                    <input class="form-control" type="text" name="sale_cap_id" id="sale_cap_id" readonly/>
                    <div class="form-group col-sm-12">
                        <div class="row">
                            <label class="col-sm-3 control-label">Sale Count</label>
                            <div class="col-sm-8">
                                <input style="width: 100%;"type="text" name="change_sale_count_cpa" id="change_sale_count_cpa" class="form-control" placeholder="0.2"/>
                            </div>
                        </div>                        
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" style="color:#fff; background-color: #FF414D; border-color: #FF414D">Cancel</button>
                <button type="submit" class="btn btn-primary" style="color:#fff; background-color: #67C9E0; border-color: #67C9E0;" id="sale_count_cpabtn">Change</button>
            </div>
      </div>      
    </div>
</div>
<!-- End here Install cap module -->

<div class="modal fade" id="changeFilter" role="dialog" style="margin-top: 40px">
    <div class="modal-dialog bd-example-modal-md modal-md">    
    <!-- Modal content-->
        <div class="modal-content ">
            <div class="modal-header modal-header1 text-center" style="margin-top: 35px;">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Change Filter</h4>
            </div>
            <div class="modal-body">            
                <div id="errmsg_chng_filter" style="text-align: center;margin-bottom:20px;"></div>
                <form method="post" action="" class="form-horizontal">
                    <input class="form-control" type="hidden" name="chng_filter_cca" id="chng_filter_cca" readonly/>
                    <input class="form-control" type="hidden" name="chng_filter_ccz" id="chng_filter_ccz" readonly/>
                    <input class="form-control" type="hidden" name="chng_filter_id" id="chng_filter_id" readonly/>
                    <div class="form-group col-sm-12">
                        <div class="row">
                            <label class="col-sm-3 control-label">Filter</label>
                            <div class="col-sm-8">
                                <input style="width: 100%;"type="text" name="chng_filter_filter" id="chng_filter_filter" class="form-control" placeholder="0.2"/>
                            </div>
                        </div>                        
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" style="color:#fff; background-color: #FF414D; border-color: #FF414D">Cancel</button>
                <button type="submit" class="btn btn-primary" style="color:#fff; background-color: #67C9E0; border-color: #67C9E0;" id="change_filter">Change</button>
            </div>
      </div>      
    </div>
</div>
<div class="modal fade" id="changeFilterSt" role="dialog" style="margin-top: 40px">
    <div class="modal-dialog bd-example-modal-md modal-md">    
    <!-- Modal content-->
        <div class="modal-content ">
            <div class="modal-header modal-header1 text-center" style="margin-top: 35px;">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Change Filter Status</h4>
            </div>
            <div class="modal-body">            
                <div id="errmsg_chng_filterst" style="text-align: center;margin-bottom:20px;"></div>
                <form method="post" action="" class="form-horizontal">
                    <input class="form-control" type="hidden" name="chng_filterst_cca" id="chng_filterst_cca" readonly/>
                    <input class="form-control" type="hidden" name="chng_filterst_ccz" id="chng_filterst_ccz" readonly/>
                    <input class="form-control" type="hidden" name="chng_filterst_id" id="chng_filterst_id" readonly/>
                    <div class="form-group col-sm-12">
                        <div class="row">
                            <label class="col-sm-3 control-label">Filter Status</label>
                            <div class="col-sm-8">
                                <select class="form-control" name="chng_filter_filterst" id="chng_filter_filterst">
                                    <option value="Select Status">Select Status</option>
                                    <option value="1">Active</option>
                                    <option value="0">Inactive</option>
                                </select>
                            </div>
                        </div>                        
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" style="color:#fff; background-color: #FF414D; border-color: #FF414D">Cancel</button>
                <button type="submit" class="btn btn-primary" style="color:#fff; background-color: #67C9E0; border-color: #67C9E0;" id="change_filterst">Change</button>
            </div>
      </div>      
    </div>
</div>
<div class="modal fade" id="changePostbackSt" role="dialog" style="margin-top: 40px">
    <div class="modal-dialog bd-example-modal-md modal-md">    
    <!-- Modal content-->
        <div class="modal-content ">
            <div class="modal-header modal-header1 text-center" style="margin-top: 35px;">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Change Postback Status</h4>
            </div>
            <div class="modal-body">            
                <div id="errmsg_chng_postst" style="text-align: center;margin-bottom:20px;"></div>
                <form method="post" action="" class="form-horizontal">
                    <input class="form-control" type="hidden" name="chng_postst_cca" id="chng_postst_cca" readonly/>
                    <input class="form-control" type="hidden" name="chng_postst_ccz" id="chng_postst_ccz" readonly/>
                    <input class="form-control" type="hidden" name="chng_postst_id" id="chng_postst_id" readonly/>
                    <div class="form-group col-sm-12">
                        <div class="row">
                            <label class="col-sm-3 control-label">Postback Status</label>
                            <div class="col-sm-8">
                                <select class="form-control" name="chng_postst_postst" id="chng_postst_postst">
                                    <option value="Select Status">Select Status</option>
                                    <option value="1">Active</option>
                                    <option value="0">Inactive</option>
                                </select>
                            </div>
                        </div>                        
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" style="color:#fff; background-color: #FF414D; border-color: #FF414D">Cancel</button>
                <button type="submit" class="btn btn-primary" style="color:#fff; background-color: #67C9E0; border-color: #67C9E0;" id="change_postbackst">Change</button>
            </div>
      </div>      
    </div>
</div>

<div class="modal fade" id="viewDetails" role="dialog" style="margin-top: 40px">
    <div class="modal-dialog bd-example-modal-lg modal-lg">    
    <!-- Modal content-->
        <div class="modal-content ">
            <div class="modal-header modal-header1 text-center" style="margin-top: 35px;">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">View Offer Details</h4>
            </div>
            <div class="modal-body">            
                <div id="errmsg_offer_details" style="text-align: center;margin-bottom:20px;"></div>
                <div id="result_data" style="text-align: center;"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" style="color:#fff; background-color: #FF414D; border-color: #FF414D">Cancel</button>
                <!--<button type="submit" class="btn btn-primary" style="color:#fff; background-color: #67C9E0; border-color: #67C9E0;" id="copy_offer_details" onclick="copyToClipboard3()">Copy</button>-->
            </div>
      </div>      
    </div>
</div>

<div class="modal fade" id="editKPI" role="dialog">
    <div class="modal-dialog bd-example-modal-lg modal-lg">    
    <!-- Modal content-->
        <div class="modal-content ">
            <div class="modal-header modal-header1 text-center" style="margin-top: 15%;">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">EDIT KPI</h4>
            </div>
            <div class="modal-body">            
                <div id="errmsg_edit_kpi" style="text-align: center;margin-bottom:20px;"></div>
                <form method="post" action="" class="form-horizontal">
                    <input type="hidden" name="_token" id="_token" value="<?php echo e(csrf_token()); ?>">
                    <input class="form-control" type="hidden" name="edit_kpi_cca" id="edit_kpi_cca" readonly/>
                    <input class="form-control" type="hidden" name="edit_kpi_ccz" id="edit_kpi_ccz" readonly/>
                    <input class="form-control" type="hidden" name="edit_kpi_id" id="edit_kpi_id" readonly/>
                    <div class="form-group col-sm-12">
                        <div class="row">
                            <label class="col-sm-1 control-label">KPI</label>
                            <div class="col-sm-11">
                                <textarea rows="8" style="width: 100%" id="edit_pub_kpi"></textarea>
                            </div>
                        </div>                        
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal" style="color:#fff; background-color: #FF414D; border-color: #FF414D">Cancel</button>
                <button type="submit" class="btn btn-primary" style="color:#fff; background-color: #67C9E0; border-color: #67C9E0;" id="update_kpi">Update</button>
            </div>
      </div>      
    </div>
</div>


<div class="modal fade" id="changeTrfc" role="dialog" style="padding-top: 160px;">
    <div class="modal-dialog modal-dialog-center">    
        <!-- Modal content-->
        <div class="modal-content ">
            <div class="modal-header modal-header1 text-center" >
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">TRFC</h4>
            </div>
            <div class="modal-body">
                <div class="form-group"><span id="process2" style="display: none;    margin-left: 397px;"></span>
                    
                    <input type="hidden" required class="form-control" name="parent_cca" id="parent_cca" readonly/>
                    <input type="hidden" required class="form-control" name="id_zone" id="id_zone" readonly/>
                    <input type="hidden" required class="form-control" name="camp_id" id="camp_id" readonly/>
                    <input type="hidden" required class="form-control" name="op_id" id="op_id" readonly/>
                    <input type="hidden" required class="form-control" name="country_code" id="country_code" readonly/>
                   
                    <form method="post" action="" name="offernetworkwiseedit"  id="offernetworkwiseedit" class="form-horizontal">
                           <div class="form-group col-sm-12">
                        <label class="radio-inline"><input type="radio" id="direct" value="1" name="is_offer_direct">Direct</label>
                        <label class="radio-inline"><input type="radio" id="nodirect"  value="2" name="is_offer_direct">No Direct</label>
                        <label class="radio-inline"><input type="radio" id="diversion" value="3" name="is_offer_direct" >Diversion</label>
                            </div>
                        <div class="form-group col-sm-12">
                            <div class="row">
                                <div class="table-responsive">  
                                    <table class="table table-bordered" id="dynamic_field_diversion">  
                                        <tr>
                                            <th>
                                                Campaign Name
                                            </th>
                                            <th>
                                                Is Smart
                                            </th>
                                            <th>
                                                Diversion Percentage
                                            </th>

                                          
                                            <th>
                                                Add New Row
                                            </th>
                                        </tr>
                                        <tr>
                                            <td>
                                                <select  required name="campagin_name_diversion[]" id="campagin_name_diversion_1" class="form-control mySelect select2 campagin_name_diversion"> 
                                                    <!--<option value="">Select Campaign</option>-->
                                                </select>
                                            </td>
                                            <td>

                    <input type="radio" name="is_smart_1"  id="default_radio_1" class="radiobox3" value="DEFAULT" class="radiobox2" checked="checked">Default &nbsp;&nbsp;
                    <input type="radio" name="is_smart_1" id="is_smart_cpa_1" value="CPA" class="radiobox3">CPA
                    &nbsp;&nbsp;&nbsp;
                    <input type="radio" name="is_smart_1" id="is_smart_cpi_1" value="CPI" class="radiobox3">CPI 

                                            </td>
                                            <td>
                                                <input type="text" required class="form-control percentage" name="percentage[]" id='percentage_1'  value="10"/>
                                            </td>
                                            
                                            <td>
                                                <button type="button" name="add_diversion_row_new_1" id="add_diversion_row_new-1" class="btn btn-success add_more_field">Add More</button>
                                            </td>
                                        </tr>                                                                               
                                    </table>
                                    <div id="add_more"></div>
                                    <div id="div_list"></div>                                    
                                </div>
                            </div>                        
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal" style="color:#fff; background-color: #FF414D; border-color: #FF414D">Cancel</button>

                    <button type="submit" class="btn btn-primary" style="color:#fff; background-color: #67C9E0; border-color: #67C9E0;" id="submit_trfc">Submit</button>
                </div>
            </div>      
        </div>
    </div>
</div>
<span id="process45"> </span>
<div id="pop-up"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>