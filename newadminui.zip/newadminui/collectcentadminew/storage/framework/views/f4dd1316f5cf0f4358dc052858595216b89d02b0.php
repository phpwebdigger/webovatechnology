<?php $__env->startSection('content'); ?>
<?php $__env->startSection('heading'); ?>
Add Advertiser
<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom_js'); ?>
<script>

//var countrylenght= $("#country").val().length;


$(document).ready(function(){

   
    $("#submit").on('click', function(){

      var password = $("#password").val();
      var cpassword = $("#cpassword").val();
      var passwordlenght= $("#password").val().length;

       if(passwordlenght<6)
       {
          alert("password atleast six character."); 
          $("#password").focus();  return false;

       }

      if(password!=cpassword)
      {
        alert("password and confirm password should be same.");
        $("#cpassword").focus();   return false;


      }


    })



  });

</script>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('bread'); ?>
<ol class="breadcrumb">
    <a href="<?php echo URL::asset('/adv_list'); ?>" class="btn btn-success img-responsive add_offer pull-left m-r-10">Advertiser List</a>
</ol>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

   <div class="row">
        <div class="col-md-12">
            <div class="white-box">
               
                <div class="panel panel-info addoffer-info">



             <?php if(Session::has('advnameis')): ?>
                    <div class="information_to "><?php echo e(Session::get('advnameis')); ?></div>
                    <?php endif; ?>

                    <?php if(Session::has('advemailis')): ?>
                    <div class="information_to"><?php echo e(Session::get('advemailis')); ?></div>
                    <?php endif; ?>
                    <?php if(Session::has('confirmpass')): ?>
                    <div class="information_to"><?php echo e(Session::get('confirmpass')); ?></div>
                    <?php endif; ?>
                                        <?php if(Session::has('advertisersuccess')): ?>
                    <div class="alert alert-info "><?php echo e(Session::get('advertisersuccess')); ?></div>
                    <?php endif; ?>
         </div>

         <div   id="successadvertiser"></div>

       
    <form action="<?php echo URL::asset('/addadvertiser')  ?>" method="post">

            
            <?php echo e(csrf_field()); ?>  

             <input type="hidden" name="addadv" value="addadv" >
             <div class="form-group">
                <label for="message-text" class="control-label">TimeZone:</label>
                    <select name="time_zone" id="time_zone" required  class="col-md-2 mySelect form-control">
                        <?php $__currentLoopData = Config::get('app.time_zone'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pkey => $pvalue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <option value="<?php echo e($pkey); ?>"><?php echo e($pvalue); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </select>
              </div>
               <div class="form-group">
                  <label for="recipient-name" class="control-label">Advertiser Name:</label>
         <input type="text" class="form-control" name="advname" value="<?php echo e(old('advname')); ?>" id="advname" placeholder="Advertiser Name" required>
               </div>

               <div class="form-group">
                  <label for="recipient-name" class="control-label">Advertiser Email:</label>
         <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" id="email" placeholder="Enter Email" required>
               </div>

<div class="form-group">
                  <label for="recipient-name" class="control-label">Phone:</label>
         <input type="number" min="0" class="form-control" name="phone" value="<?php echo e(old('phone')); ?>" id="phone" placeholder="Enter Phone" >
               </div>
               
               <div class="form-group">
                  <label for="recipient-name" class="control-label">Company Name:</label>
         <input type="text" class="form-control" name="company" value="<?php echo e(old('company')); ?>" id="company" placeholder="Company Name" required>
               </div>
<div class="form-group">
                  <label for="recipient-name" class="control-label">Address:</label>
         <input type="text" class="form-control" name="address" value="<?php echo e(old('address')); ?>" id="address" placeholder="Address" >
               </div>

               <div class="form-group">
                  <label for="recipient-name" class="control-label">Skype Id:</label>
         <input type="text" class="form-control" name="skype_id" value="<?php echo e(old('skype_id')); ?>" id="skype_id" placeholder="Skype Id" >
               </div>

<!--            <div class="form-group">
                  <div>
                  <label class="control-label">Placeholders For Postback</label>

                  <div class="dataTable_wrapper">
                  <table class="table table-striped table-bordered table-hover" style="font-size: 12px;" id="dataTables-example">

                  <thead style="background-color:#01c0c8;">
                  <tr>
                      <th style="color: #fff;">NAME</th>
                      <th style="color: #fff;">DESCRIPTION</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr><td>__NETWORKTOKEN__</td><td>Replaced with the value of publisher's unique id that was sent to us when a visitor redirects to our offer URL.</td></tr>
                  <tr><td>__COLLECCENTTOKEN__</td><td>Replaced witth Collectcent's uniq id[CCUID] which is generated when a visitor comes to our offer URL.</td></tr>

                  <tr><td>__PRICE__</td><td>Replaced your offers price</td></tr>


                  </tbody>
                  </table>
                  </div>
                  </div>
                <?php if(Session::has('posturl')): ?>
                <div class="information_to "><?php echo e(Session::get('posturl')); ?></div>
                <?php endif; ?>

            <label for="recipient-name" class="control-label">Global Postback:</label>
            <input type="text" class="form-control" name="globalpost" value="<?php echo e(old('globalpost')); ?>" id="globalpost" placeholder="Enter Global Postback" required>
            </div>-->

<!--          <div class="form-group">
          <label for="recipient-name" class="control-label">Click parameter:</label>
          <input type="text" class="form-control" name="clickparameter" value="token" readonly placeholder="Enter Click Parameter" required>
          </div>-->

               <div class="form-group">
                  <label for="recipient-name" class="control-label">Password:</label>
         <input type="password" class="form-control" name="password" value="<?php echo e(old('password')); ?>" id="password" placeholder="Password"  required>
               </div>

               <div class="form-group">
                  <label for="recipient-name" class="control-label">Confirm Password:</label>
         <input type="password" class="form-control" name="cpassword" value="<?php echo e(old('cpassword')); ?>" id="cpassword" placeholder="Confirm Password" required >
               </div>

<!--                 <div class="form-group">
                  <label for="message-text" class="control-label">Api Name:</label>
                  <select name=" apiname" id="apiname" class="form-control select2" >
                    <option value="">None</option>
                    <?php $__currentLoopData = Config::get('app.apiname'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pkey => $pvalue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <option <?php // if(old('apiname')==$pkey){ echo "selected"; } ?> value="<?php echo e($pkey); ?>"><?php echo e($pvalue); ?></option>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                    

                  </select>
               </div>-->

        <div style="clear: both" class="text-center">
        <button type="submit" id="submit"  class="btn btn-success waves-effect waves-light">Save</button>
         </div>


            </form>
        
</div>
</div></div></div>

   <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>