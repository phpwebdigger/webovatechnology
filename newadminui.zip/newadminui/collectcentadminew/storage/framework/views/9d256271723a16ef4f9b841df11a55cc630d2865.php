<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Collectcent -  <?php echo $__env->yieldContent('title'); ?></title>
    <!-- Bootstrap Core CSS -->
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('plugins/bower_components/datatables/media/css/jquery.dataTables.css')); ?>" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="<?php echo e(asset('css/select2.min.css')); ?>" rel="stylesheet">
    <!--link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet"-->
    <link href="<?php echo e(asset('css/simple.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/css/bootstrap-select.min.css">
    <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.css" />
    <?php echo $__env->yieldContent('custom_css'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
</head>
<body>
    <!-- Preloader -->
    <div class="preloader">
        <div class="cssload-speeding-wheel"></div>
    </div>
    <header>
        <a href="/" class="pull-left" style="margin-left:20px;">Home</a>
        <a href="" class="logo"><?php echo $__env->yieldContent('heading'); ?></a>
    </header>
    <div id="wrapper">
    <?php if(isset($message)): ?>
        <div id="alertbottomright" class="myadmin-alert flipInY alert-success myadmin-alert-bottom-right" style="display: block;"><a href="#" class="closed" onclick="javascript:document.getElementById('alertbottomright').style.display = 'none'">×</a>
            <?php echo e($message); ?>                            
        </div>
    <?php endif; ?>
     <?php if(isset($error)): ?>
        <div id="alertbottomright2" class="myadmin-alert flipInY alert-danger myadmin-alert-bottom-right" style="display: block;"><a href="#" class="closed" onclick="javascript:document.getElementById('alertbottomright2').style.display = 'none'">×</a>
            <?php echo e($error); ?>                            
        </div>
    <?php endif; ?>
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">
                           
                        </h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <?php echo $__env->yieldContent('bread'); ?>
                    </div>
                </div>
                <div class="row">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
            <footer class="footer text-center"> 2019 &copy; <?php echo e(config('app.name')); ?></footer>
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- jQuery -->
    <script src="<?php echo e(asset('plugins/bower_components/jquery/dist/jquery.min.js')); ?>"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('plugins/bower_components/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/js/bootstrap-select.min.js"></script>
    <?php echo $__env->yieldContent('custom_js'); ?>
    <script type="text/javascript">
    $(document).ready(function() {
        var allTheUrl = {};
        $(document).on('click', '.mainCollumn .dropdown-menu', function (e) {
                e.stopPropagation();
        });

        $(".nav-second-level li a").each(function(){
           allTheUrl[$(this).attr('href')] = $(this).text();
        });
        
        $("#searchBar").keyup(function(){
            var val = $(this).val().toLocaleLowerCase();
            var count = 0,str="";
            for(var key in allTheUrl){
                if(allTheUrl.hasOwnProperty(key)){
                    if(allTheUrl[key].toLocaleLowerCase().indexOf(val) > -1 && count < 8){
                        str = str +'<li><div class="drop-title"><a style="color:#54667a;font-weight: 500" href="'+key+'">'+allTheUrl[key]+'</a></div></li>';
                        count++;
                    }
                }
            }
            $("#searchbarUL").html(str);
        });
        
        var uncheckedOption = [];
        
        $(".columncheck").on('change',function(){
            // scrollFeature();
            var checked = $(this).is(":checked");
            var index = $(this).attr("data-index");
            $('.new th[data-index="'+index+'"]').toggleClass("hide");
               if(checked) {
               var column = tableLazyNew.column( index );
                    // Toggle the visibility
                    column.visible(true);
                     var indexA = uncheckedOption.indexOf(index);
                        if (indexA > -1) {
                            uncheckedOption.splice(indexA, 1);
                        }
                }else{
                     var column = tableLazyNew.column( index );
                    // Toggle the visibility
                        column.visible(false);
                     if(uncheckedOption.indexOf(index) == -1){
                        uncheckedOption.push(index); 
                    }
                }
               //  setCookieCol();
        });
    })
        $(document).ajaxStart(function(){
              $('.preloader').show();
          }).ajaxStop(function () {
              $('.preloader').hide();
        });
        $('.preloader').hide();
</script>
    <?php echo $__env->yieldContent('footer_css'); ?>
</body>

</html>
