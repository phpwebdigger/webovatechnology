<?php 

if(array_key_exists("test",$_COOKIE)){
    $cook = $_COOKIE['test'];
    if($cook){
      $cook = explode(",",$cook);
    }else{
      $cook = [];
    }

}else{
    $cook = [];
}


function isAssoc2(array $arr)
{
    if (array() === $arr) return false;
    return array_keys($arr) !== range(0, count($arr) - 1);
}
$isAsso2 = isAssoc2($data);
 ?>

<div class="btn-group mainCollumn dropdown m-r-10">
      <button aria-expanded="true" data-toggle="dropdown" class="btn btn-success dropdown-toggle waves-effect waves-light\" type="button">Columns <span class="caret"></span></button>
        <ul role="menu" class="dropdown-menu">

        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="#">
                	<div class="checkbox  checkbox-primary">
		                <input id="checkbox2<?php echo e($loop->index); ?>"  data-index="<?php echo e($loop->index); ?>" class="columncheck" type="checkbox" value="<?php echo e($isAsso2?$col:$val); ?>" <?php echo e(in_array($loop->index,$cook)?"":"Checked"); ?>>
		                <label for="checkbox2<?php echo e($loop->index); ?>"> <?php echo e($isAsso2?$col:$val); ?> </label>
                	</div>
                </a>
               
            </li>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </ul>
</div>

