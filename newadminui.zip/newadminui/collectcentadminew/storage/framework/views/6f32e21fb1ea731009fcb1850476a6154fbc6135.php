     <div ng-show="hourdata">
     <div class="row text-primary top20">
            <div class="col-sm-3">  
            <button ng-click="toggleCrInwardUnique()" class="btn btn-info">CR Inward(Unique)</button>
           </div>
           <div class="col-sm-2">  
            <button ng-click="toggleConversionInwardUnique()" class="btn btn-info">Conversion In(U)</button>
           </div>
           <div class="col-sm-2 top10 text-center">  
            <button ng-click="toggleSaleCount()" class="btn btn-danger">Sale Count</button>
           </div>
           <div class="col-sm-2">
             <input type="number" min="1" max="100" class="form-control" ng-model="pageSize" placeholder="Items Per Page" id="searchNumber">
           </div>  
            <div class="col-xs-3">
            <form class="form-inline">
                    <div class="form-group">
                      <input type="text" ng-model="search" class="form-control" placeholder="Search">
                    </div>
            </form>    
            <strong class="bottom10">last Updated: <% lastUpdated %></strong>
            </div>
    </div>      
  <div class="row top20">
        <table id="hourdata">
         <tr height="30" align="center" class="heading-row">
             <td ng-click="sort('country_code')" ng-cloak ng-if="country_code" class="country"><b>Country</b></td>
             <td ng-click="sort('report_type')" ng-cloak ng-if="report_type" class="reportType"><b>Report Type</b></td>
             <td ng-click="sort('traffic_type')" ng-cloak ng-if="traffic_type" class="trafficType"><b>Traffic Type</b></td>
             <td ng-click="sort('hour')" ng-cloak class="hours"><b>Hour</b></td>
             <td ng-click="sort('is_smart_cca')" ng-cloak ng-if="is_smart_cca" class="isSmart"><b>Is Smart</b></td>
             <td ng-click="sort('advertiser_name')" ng-cloak class="advertiser"><b>Advertiser</b></td>
             <td ng-click="sort('id_ad')" ng-cloak class="id_ad"><b>id_ad</b></td>
             <td ng-click="sort('parent_cca')" ng-cloak class="parentCCA"><b>Parent CCA</b></td>
             <td ng-click="sort('op_name')" ng-cloak class="telco"><b>Telco</b></td>
             <td ng-click="sort('network_name')" ng-cloak class="networkName"><b>Network Name</b></td>
             <td ng-click="sort('network_cpa')" ng-cloak ng-if="parentcca_type" class="networkCPA"><b>Network CPA</b></td>
             <td ng-click="sort('id_advertiser_campaign')" ng-cloak class="idAdvertiser"><b>Id advertiser</b></td>
             <td ng-click="sort('advertiser_campain_name')" ng-cloak class="campaignName"><b>Campaign Name</b></td>
             <td ng-click="sort('clickcount')" ng-cloak class="clicks"><b>Total Clicks</b></td>
             <td ng-click="sort('conversion_count')" ng-cloak class="convIn"><b>Conversion Inwards</b></td>
             <td ng-click="sort('conversion_count_unique')" ng-cloak ng-if="ConversionInwardUnique" class="convInUnique"><b>Conversion Inwards Unique</b></td>
             <td ng-click="sort('clicks_active_count')" ng-cloak class="convOut"><b>Conversion Outwards</b></td>
             <td ng-click="sort('crcIn')" ng-cloak class="crIn"><b>CR Inwards</b></td>
             <th width="10%" ng-click="sort('crcInUnique')" class="ng-cloak crInUnique"  ng-if="CrInwardUnique">CR Inward(Unique)</th>
             <td ng-click="sort('crcOut')" ng-cloak class="crOut"><b>CR Outwards</b></td>
             <td width="10%" ng-click="sort('ecpm')" class="ng-cloak ecpm">ecpm</td>
             <th width="5%" ng-click="sort('sale_count')" class="ng-cloak saleCount" ng-if =sale_count>Sale Count</th>
             <td ng-click="sort('total_costv')" ng-cloak class="totalCost"><b>Total Cost $</b></td>
             <td ng-click="sort('revenue_dollar')" ng-cloak class="revenue"><b>Revenue $</b></td>
             <td ng-click="sort('profit')" ng-cloak class="profit"><b>Profit $</b></td>
	     <td ng-click="sort('pub_offer_name')" ng-cloak class="pub_offer_name"><b> Pub Offer Name</b></td>
         </tr>
         <tr class="total-row">
             <td ng-cloak ng-if="country_code" class="country"></td>
             <td ng-cloak ng-if="report_type" class="reportType"></td>
             <td ng-cloak ng-if="traffic_type" class="trafficType"></td>
             <td ng-cloak class="hours"></td> 
             <td ng-cloak ng-if="is_smart_cca" class="isSmart"></td>
             <td ng-cloak class="advertiser"></td>
             <td ng-cloak class="id_ad"></td>
             <td ng-cloak class="parentCCA"></td>
             <td ng-cloak class="telco"></td>
             <td ng-cloak class="networkName"></td>
             <td ng-cloak ng-if="parentcca_type" class="networkCPA"></td>
             <td ng-cloak class="idAdvertiser">Total</td>
             <td ng-cloak class="campaignName"></td>
             <td ng-cloak class="clicks"><% filterResult.totalClickCount | number %></td>
             <td ng-cloak class="convIn"><% filterResult.Conversion_inwards | number: 2  %></td>
             <td ng-cloak ng-if="ConversionInwardUnique" class="convInUnique"><% filterResult.Conversion_inward_unique | number: 2  %></td>
             <td ng-cloak class="convOut"><% filterResult.Conversion_outwards | number: 2  %></td>
             <td ng-cloak class="crIn"></td>
             <td width="10%" class="ng-cloak crInUnique" ng-if="CrInwardUnique"></td>
             <td ng-cloak class="crOut"></td>
             <td width="10%" class="ng-cloak ecpm"><% items.total_ecpm | number: 4 %></td>
             <td width="5%" class="ng-cloak saleCount" ng-if =sale_count><% items.totalsale_count %></td>
             <td ng-cloak class="totalCost"><% filterResult.totalcostv | number: 2 %></td>
             <td ng-cloak class="revenue"><% filterResult.total_revenue | number: 2%></td>
             <td ng-cloak class="profit"><% filterResult.total_profit | number: 2%></td>
        <td ng-cloak class="pub_offer_name"></td>
         </tr>
         <tr dir-paginate="item in filterResult|orderBy:sortKey:reverse|filter:search|itemsPerPage:pageSize" pagination-id="filterPagination"> 
             <td ng-cloak ng-if="country_code" class="country"><% item.country_code %></td>
             <td ng-cloak ng-if="report_type" class="reportType"><% item.report_type %></td>
             <td ng-cloak ng-if="traffic_type" class="trafficType"><% item.traffic_type %></td>
             <td ng-cloak class="hours"><% item.hour %></td>
             <td ng-cloak ng-if="is_smart_cca" class="isSmart"><% item.is_smart_cca %></td>
             <td ng-cloak class="advertiser"><% item.advertiser_name %></td>
             <td ng-cloak class="id_ad"><% item.id_ad %></td>
             <td ng-cloak class="parentCCA"><% item.parent_cca %></td>
             <td ng-cloak class="telco"><% item.op_name %>(<% item.country_code %>)</td>
             <td ng-cloak class="networkName"><% item.network_name %>(<% item.id_channel %>)</td>
             <td ng-cloak ng-if="parentcca_type" class="networkCPA"><% item.network_cpa %></td>
             <td ng-cloak class="idAdvertiser"><% item.id_advertiser_campaign %></td>
             <td ng-cloak class="campaignName"><% item.advertiser_campain_name %>(<% item.id_advertiser_campaign %>)</td>
             <td ng-cloak class="clicks"><% item.clickcount | number %></td>
             <td ng-cloak class="convIn"><% item.conversion_count | number %></td>
             <td ng-cloak ng-if="ConversionInwardUnique" class="convInUnique"><% item.conversion_count_unique | number %></td>
             <td ng-cloak class="convOut"><% item.clicks_active_count | number %></td>
             <td ng-cloak class="crIn"><% item.crcIn | number: 2 %>%</td>
             <td width="10%" class="ng-cloak crInUnique" ng-if ="CrInwardUnique"><% item.crcInUnique | number: 2 %> %</td>
             <td ng-cloak class="crOut"><% item.crcOut | number: 2 %>%</td>
             <td ng-cloak class="ecpm"><% item.ecpm | number: 4 %></td>
             <td width="5%" class="ng-cloak saleCount" ng-if =sale_count><% item.sale_count %></td>
             <td ng-cloak class="totalCost"><% item.total_costv | number: 2 %></td>
             <td ng-cloak class="revenue"><% item.revenue_dollar | number: 2 %></td>
             <td ng-cloak class="profit"><% item.profit | number: 2 %></td>
	<td ng-cloak class="pub_offer_name"><% item.pub_offer_name%></td>
         </tr>
         
        </table>
        <dir-pagination-controls max-size="50" direction-links="true" boundary-links="true" pagination-id="filterPagination"></dir-pagination-controls>    
    </div>
</div>
