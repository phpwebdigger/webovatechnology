<?php $__env->startSection('custom_css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/bower_components/switchery/dist/switchery.min.css')); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('bread'); ?>
    <ol class="breadcrumb">
        <li><a href="#">Dashboard</a></li>
        <li class="active">Delivery</li>
    </ol>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('heading'); ?>
  Delivery Edit
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_js'); ?>
<script src="<?php echo e(asset('plugins/bower_components/switchery/dist/switchery.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/validator.js')); ?>"></script>
<script type="text/javascript">
     var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
       $('.js-switch').each(function() {
           new Switchery($(this)[0], $(this).data());

       });
       function copyToClipboard(element) {
            var $temp = $("<input>");
            $("body").append($temp);
            $temp.val($(element).text()).select();
            document.execCommand("copy");
            $temp.remove();
            $("#inputPassword").val($(element).text());
            alert('text copied and move');
        }
    $(document).ready(function(){

        
        
        $(document).on('change','#cca',function(){
              var  ccas = $(this).val();
              console.log(ccas);
              ccas = ccas + '';
              if(ccas.indexOf(',') != -1){
               $("#is_child").hide();
               console.log('A');           
              }else{
                console.log('B');
                $("#is_child").show();
              }
        });   

       // $(document).on("change","#ccz",function(event){
       //  var networks;
       //  var network_id = $(this).val();

       //  if(network_id){ 
       //      $.ajax({
       //              url : '/getnetwork/',
       //              type: 'GET',
       //              async: true,
       //              data: "network_id="+network_id,
       //              beforeSend: function(msg){
       //                  $("#cca").hide();
       //              },    
       //          }).done(function (response){
       //              if(response.status==1){
       //                  $(response.data).each(function(key,value){
       //                      networks += '<option value="'+value.id_ad+'"">('+value.id_ad+')'+value.title+'</option>';
       //                      $("#cca").html(networks).show();
       //                  });
       //              }else if(response.status==0){
       //                  $("#cca").html('<option value="">select CCA</option>').show();
       //                  alert('No CCA found.');
       //              }
       //          }).fail(function () {
       //                  $("#cca").html('<option value="">select CCA</option>').show();
       //                  alert('Data could not be loaded.');
                        
       //          });
       //      }
       //  });
// $('#ccz').trigger('click');

     $('#ccz').on('click change',function(){
          var id = $(this,':selected').val();
          var ccz_default = $("#ccz_default").val();
          if(id == ccz_default){
           return false;
          }else{
          onchnage(id);
          }

        });
   });

     function onchnage( id_zone){

        var post_back_url = $("#inputPassword");
            post_back_url.val('');
            $(".preloader").show();
            $("#cca").html('');
            var ccz = $("#ccz option:selected").text();
            $title = ccz.split('('); 
            $("#title").val($title[0]); 
            $.ajax({
                url : '/delivery/get-adsbynetwork/',
                type: 'GET',
                async: true,
                data: "id_zone="+id_zone,
            }).done(function (response){
                var adsData =  JSON.parse(response);
                var networks = '<option value="">select CCA</option>';    
                var postbackUrl = '<ul class="list-group"><li class="list-group-item"><b class="text-danger">Latest PostBacks</b></li>';
                console.log(adsData.deliveryPostBack);
                $(adsData.cca).each(function(key,network){
                    networks += '<option value="'+network.id_ad+'"" data-title="'+network.title+'">'+network.cca+'</option>';
                });
                $("#cca").html(networks).selectpicker('refresh');
                $(adsData.deliveryPostBack).each(function(key,delivery){
          postbackUrl += '<li class="list-group-item"><div onclick="copyToClipboard(this)">'+delivery.post_back_url+'</div>Total:'+delivery.total+'</li>';
                });
                if(postbackUrl){
                    $('.postback-url').html(postbackUrl);
                }else{
                    $('.postback-url').html('<li class="list-group-item">Postback URL : No postback Url</li>');
                }
                postbackUrl +='</ul>';
                $(".preloader").hide();      
            }).fail(function(){
                    alert('Data could not be loaded.');
                    $(".preloader").hide();
            });
  
     }

       
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <?php
//            echo "<pre>";
//            print_r($status);
//            echo "</pre>";
        ?>
        <div class="col-sm-6">
            <div class="white-box">
                <form data-toggle="validator" method="POST" action="<?php echo e(route('EventUpdate')); ?>">

	
                    <input type="hidden" name="id" value="<?php echo $status['id']; ?>" readonly>
                    <?php echo e(csrf_field()); ?>

                        <div class="form-group">
                            <label for="inputName" class="control-label">CCZ <span style="color: red">*</span> :<?php //echo $status['id_zone']  ?>
                                <input type="hidden" id="ccz_default" name="ccz_name" value="<?php echo $status['id_zone']; ?>" readonly>
                            <div class="help-block with-errors"></div>
                            <div class="form-group">
                               <select name="ccz" id="ccz" class="select2 form-control"  data-act="ajax-select" data-preload="true" data-post-text="concat(name,'(',ccz,')')" data-post-id="ccz" data-post-key="name" data-post-table="ad_network" data-min-input="2" data-placeholder="type to search CCZ" data-initial-id="<?php echo e($status['id_zone']); ?>"   required>
                                <option>All</option>
                                </select>
                                    </div>
                                    <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label for="inputName" class="control-label">CCA * </label>
                            <div class="form-group">
                                <input type="text" name="parent_cca" id="parent_cca" value="<?php echo $status['parent_cca']; ?>" data-toggle="validator" class="form-control" placeholder="Parent CCA">
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                    
                        <div class="form-group" style="clear: both;">
                            <label for="inputpostUrl" class="control-label">Campaign Id</label>
                            <div class="form-group col-sm-12">
                                <input type="text"  name="campaign_id"  value="<?php echo $status['campaign_id']; ?>" data-toggle="validator"   class="form-control" id="campaign_id" placeholder="campaign Id">
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>
                        <div class="form-group" style="clear: both;">
                            <label for="inputpostUrl" class="control-label">Event Name</label>
                            <div class="form-group col-sm-12">
                                <input type="text"  name="event_name"  value="<?php echo $status['event_name']; ?>" data-toggle="validator"   class="form-control" id="event_name" placeholder="Event Name">
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputpostUrl" class="control-label">Pub goal Id *</label>
                            <div class="form-group col-sm-12">
                                <input type="text"  name="publisher_goal_id"  data-toggle="validator" value="<?php echo $status['publisher_goal_id']; ?>"  class="form-control" id="publisher_goal_id" placeholder="Input Publisher Goal Id" required>
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>
                        <div class="form-group" style="clear: both;">
                            <label for="inputpostUrl" class="control-label">Sale </label>
                            <div class="form-group col-sm-12">
                                <input type="text"  name="sale_count"  value="<?php echo $status['sale']; ?>" data-toggle="validator"   class="form-control" id="sale_count" placeholder="Sale">
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>

                        <div class="form-group" style="clear: both;">
                            <label for="inputpostUrl" class="control-label">Post Back Url</label>
                            <div class="form-group col-sm-12">
                                <input type="text"  name="post_back_url"  value="<?php echo $status['event_postback']; ?>" data-toggle="validator"   class="form-control" id="post_back_url" placeholder="Post back URL">
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>
                        
                        <div class="form-group">
                           <label for="inputpostUrl" class="control-label">Status</label>
                           <div class="form-inline">      
                                   <div class="radio radio-info">
                                   <input type="radio" name="postback_status" id="status1" value="1" <?php echo $status['status'] == 1 ? 'checked':'' ?>>
                                   <label for="status1">Active </label>
                                   </div>
                                   <div class="radio radio-info">
                                   <input type="radio" name="postback_status" id="status2" value="0" <?php echo $status['status'] == 0 ? 'checked':'' ?>>
                                   <label for="status2">Deactive </label>
                                   </div>
                               </div>
                        </div>
                        <div class="form-group">
                            <label for="inputpostUrl" class="control-label">Filter *</label>
                                <div class="form-group col-sm-12">
                                    <input type="text"  name="filter_data" value="<?php echo $status['filter']?>" data-toggle="validator"   class="form-control" id="inputPassword" placeholder="Input Filter" required>
                                    <div class="help-block with-errors"></div>
                                </div>
                        </div>

                        <br>
                        <div class="form-group">
                            <button type="submit" class="btn btn-success">Update</button>
                        </div>
                </form>
            </div>
        </div>
                 <div class="col-sm-6 postback-url"></div>                           
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>