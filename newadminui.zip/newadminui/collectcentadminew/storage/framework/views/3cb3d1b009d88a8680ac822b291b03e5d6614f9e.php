<?php $__env->startSection('custom_css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/bower_components/switchery/dist/switchery.min.css')); ?>" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('bread'); ?>
                            <ol class="breadcrumb">
                            <li><a href="#">Add Resources</a></li>
                            <li><a href="#">Networks</a></li>
                            <li><a href="/Resources/list-network">List Network Resources</a></li>
                            <li class="active">Edit Network</li>
                        </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('heading'); ?>
  Edit <?php echo e($network->name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('#account_manager').selectpicker({ maxOptions:2 });       
    });
</script>


    <div class="row">
                    <div class="col-sm-6">
                        <div class="white-box">
                            <form data-toggle="validator" method="POST" action="<?php echo e(url('network/edit')); ?>">
                              <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <input type="hidden" name="id" value="<?php echo e($network->id); ?>">
                                    <label for="NetworkName" class="control-label">Network Name*</label>
                                    <input type="text" class="form-control" id="network_name" name="network_name"  value="<?php echo e($network->name); ?>" placeholder="input Network Name" required>
                                    <div class="help-block with-errors"></div>
                                     <?php if($errors->has('name')): ?>
                                        <div class="help-block with-errors"><?php echo e($errors->first('name')); ?></div>
                                     <?php endif; ?>
                                </div>
                                
                                <div class="form-group">
                                    <label for="CCZ" class="control-label">CCZ*</label>
                                    <input type="text" class="form-control" id="ccz" name="ccz" value="<?php echo e($network->ccz); ?>" placeholder="input CCZ" readonly>
                                </div>
                                 <?php if($role_id!='12'): ?>
                                <div class="form-group">
                                    <label for="TokenKey" class="control-label">Token key</label>
                                    <input type="text" class="form-control" id="token_key " name="token_key" value="<?php echo e($network->token_key); ?>"placeholder="input Token key">
                                </div>
                                
                                <?php endif; ?>

                                <div class="form-group">
                                    <label for="ClickID" class="control-label">Click ID Parameter</label>
                                      <?php if($role_id!='12'): ?>
                                    <input type="text" class="form-control" id="clickid" name="clickid" value="<?php echo e($network->clickid_parameter); ?>" placeholder="input Click ID Parameter">
                                    <?php else: ?>
                                    <input type="text" class="form-control" id="clickid" name="clickid" value="<?php echo e($network->clickid_parameter); ?>" placeholder="input Click ID Parameter" readonly>
                                    <?php endif; ?>
                                </div>
                               
                                 <?php if($role_id!='12'): ?>

                                <div class="form-group">
                                    <label>Account Manager</label>
<!--                                    <select data-preload="true" name="account_manager"
                                    data-initial-id="<?php echo e($network->User ? $network->User->id:'default'); ?>" class="col-md-2 select2 form-control" data-act="ajax-select"  data-post-text="distinct name" data-post-id="id" data-post-key="name" data-post-table="n_users" data-placeholder="Account Manager"></select>-->
<!--                                    <select name="account_manager[]" id="account_manager"
                                            data-initial-id="<?php echo e($network->id); ?>" class="form-control selectpicker " multiple >-->
                                    <select id="account_manager" name="account_manager[]" multiple class="selectpicker" 
                                            data-live-search="true" data-initial-id="<?php echo e($network->User ? $network->User->id:'default'); ?>" data-actions-box="true" data-selected-text-format="count < 3" 
                                            data-size="10" data-style="btn-info">
                                        <?php $__currentLoopData = Config::get('app.account_holder'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pkey => $pvalue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                <option value="<?php echo e($pkey); ?>" <?php echo e(($pkey==$network->account_manager)?'selected':''); ?> ><?php echo e($pvalue); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                    </select>

                                </div>
                                  <?php else: ?>
                                <input type="hidden" id="account_manager" name="account_manager" value="<?php echo e($network->account_manager); ?>">
                                <?php endif; ?>

                                <div class="form-group">
                                    <label>Status</label>
                                    <select class="form-control" name="status" id="status" data-initial-id="<?php echo e($network->status); ?>">
                                    <option value="0" <?php echo e($network->status==0 ? "selected":""); ?>>Inactive</option>
                                    <option value="1" <?php echo e($network->status==1 ? "selected":""); ?>>Active</option>
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label>Billing Trafficker</label>
                                    <select class="form-control" name="billing_trafficker" id="billing">
                                    <option value="0" <?php echo e($network->billing_trafficker==0 ? "selected":""); ?>>Yes</option>
                                   
                                    <option value="1" <?php echo e($network->billing_trafficker==1 ? "selected":""); ?>>No</option>
                                    </select>
                                </div>
                                
                                <br>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-success">Submit</button>
                                </div>           
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>