<?php $__env->startSection('custom_css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/bower_components/switchery/dist/switchery.min.css')); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('bread'); ?>
                        <ol class="breadcrumb">
                            <li><a href="#">Add Resources</a></li>
                            <li><a href="#">Advertiser</a></li>
                            <li class="active">List Advertiser Resources</li>
                        </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('heading'); ?>
  Advertiser Management 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
<script src="<?php echo e(asset('plugins/bower_components/switchery/dist/switchery.min.js')); ?>" type="text/javascript"></script>
<script type="text/javascript">
      var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
        $('.js-switch').each(function() {
            new Switchery($(this)[0], $(this).data());

        });
        $(document).ready(function() {

        var data =   <?php echo json_encode($data1); ?>;        
       createTableWithLazyLoad("#tableLazy",data,50);
       
    } );

</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
       <div class="m-b-15">
                <form class="form-inline" role="form" method="POST" action="<?php echo e(url('/Resources/list-advertiser')); ?>">
                        <?php echo e(csrf_field()); ?>                     
                          <div class="form-group col-md-2">
                              <?php 
                                $heads =  ["Sr.No",
                                  "Advertiser Id",
                                   "Advertiser Name",
                                   "Country",
                                   "language",
                                   "Account Manager",
                                   "Advertiser Key",
                                   "Create time",
                                   "Status",
                                   "Manage"];
                                  ?>

                                  <?php echo view('layouts.column', ['data' =>$heads]); ?>

                          </div>

                  </form>
            </div>
            
                    <div class="col-sm-12">
                    
                            
                            <div class="table-responsive mainTableInfo">
                                <table class="table color-table info-table scrollTable lazy" id="tableLazy">
                                    
                                        <?php echo view('layouts.tableheadNew', ['data' =>$heads,'class'=>""]); ?>

                                           
                                    
                                </table>
                            </div>  
                                  
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>