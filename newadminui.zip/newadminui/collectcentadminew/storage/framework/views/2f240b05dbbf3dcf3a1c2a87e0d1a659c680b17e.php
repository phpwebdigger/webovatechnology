<thead class="<?php echo e($class); ?>">
      <tr>
    
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <th data-index="<?php echo e($loop->index); ?>" data-val="<?php echo e($col); ?>"><?php echo e($col); ?></th>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


      </tr>
</thead>
