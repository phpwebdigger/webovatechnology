<?php $__env->startSection('bread'); ?>
     <ol class="breadcrumb">
       <li><a href="#"></a>Add Resources</li>

       <li class="active">Add Network Resources</li>
      </ol>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('heading'); ?>
Add Network Resources
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
 <div class="row">
                    
                    <div class="col-sm-6">
                        <div class="white-box">
                            <form data-toggle="validator" method="POST" action="<?php echo e(url('/Resources/add-network')); ?>">
                              <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label for="NetworkName" class="control-label">Create Network Name*</label>
                                    <input type="text" class="form-control" id="network_name" name="network_name" placeholder="Input Network Name" required>
                                    <div class="help-block with-errors"></div>
                                     <?php if($errors->has('name')): ?>
                                        <div class="help-block with-errors"><?php echo e($errors->first('name')); ?></div>
                                     <?php endif; ?>
                                </div>

                                <div class="form-group">
                                    <label for="ClickID" class="control-label">Network Click ID</label>
                                     <?php if($role_id!='12'): ?>
                                    <input type="text" class="form-control" id="clickid" name="clickid" placeholder="Input Network Click ID">
                                      <?php else: ?>
                                <input type="text" class="form-control"  id="clickid" name="clickid" value="token" readonly>
                                <?php endif; ?>   

                                </div>

                                <div class="form-group">
                                    <label>Billing Trafficker</label>
                                    <select class="form-control" name="billing" id="billing">
                                    <option value="0">No</option>
                                    <option value="1">Yes</option>
                                    </select>
                                </div>
                                <?php if($role_id!='12'): ?>
                                <div class="form-group">
                                    <label>Account Manager</label>
<!--                                    <select data-preload="true" name="account_manager"
                                    " class="col-md-2 select2 form-control" data-act="ajax-select"  data-post-text="distinct name" data-post-id="id" data-post-key="name" data-post-table="n_users" data-placeholder="Account Manager"></select>-->
                                    <select name="account_manager" id="account_manager" class="form-control" >
                                        <option>Select</option>
                                        <?php $__currentLoopData = Config::get('app.account_holder'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pkey => $pvalue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                            <option value="<?php echo e($pkey); ?>"><?php echo e($pvalue); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                </div>
                                <?php else: ?>
                                <input type="hidden" id="account_manager" name="account_manager" value="<?php echo e($user_email); ?>">
                                <?php endif; ?>

                                <br>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-success">Submit</button>
                                </div>
                            </form>
                        </div>
                </div>
                
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>