<?php 
function isAssoc(array $arr)
{
    if (array() === $arr) return false;
    return array_keys($arr) !== range(0, count($arr) - 1);
}
$isAsso = isAssoc($data);
 ?>

<thead class="bg-primary ">
      <tr>
      <?php if($isAsso): ?>
         <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th data-val="<?php echo e($col); ?>" data-index="<?php echo e($loop->data-index); ?>">
            <?php if($val !=""): ?>
             <?php 
              if(Request::get('colorder') == $val){
                if(Request::get('order')=='desc'){
                  $ic = "arrow-down";
                }else{
                  $ic = "arrow-up";
                }
              
              }else{
                $ic = "";
              }
             ?>
            <a class="pagination-sort" style="color:white" href="?colorder=<?php echo e($val); ?>&order=<?php echo e(Request::get('order')=="desc"?"asc":"desc"); ?>"><?php echo e($col); ?><i class='fa fa-<?php echo e($ic); ?>'></i></a>
      			<?php else: ?>
      			<?php echo e($col); ?>

			      <?php endif; ?>
           </th>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
          <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <th data-val="<?php echo e($col); ?>"><?php echo e($col); ?></th>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

      </tr>
</thead>
