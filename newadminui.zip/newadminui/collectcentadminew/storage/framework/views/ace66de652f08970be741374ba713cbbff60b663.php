<?php $__env->startSection('content'); ?>
<?php 
$GroupBy = config('constants.GROUP_BY_OPTION'); 
$TrafficType = config('constants.TRAFFIC_TYPE');
$ReportType = config('constants.RESULT_TYPE');
$Vertical = config('constants.VERTICALS');

?>
<style>
  .first-row .bootstrap-select{width:160px !important}
</style>
<script src="http://code.jquery.com/jquery-1.11.0.min.js"></script>
<script>
// define application
var crcApp = angular.module("crcApp", ['angularUtils.directives.dirPagination'] ,function($interpolateProvider) {
        $interpolateProvider.startSymbol('<%');
        $interpolateProvider.endSymbol('%>');
    });
crcApp.controller("crchourController", function($scope,$http){
    $scope.items = [];
    $scope.flag = {};
    $scope.pageSize = 50;

    // function to get records from the database
    $scope.fraud = false;
    $scope.CrInwardUnique = false;
    $scope.ConversionInwardUnique = false;
    $scope.sale_count = false;
    $scope.is_smart_cca = false;
    
    $scope.getRecords = function(){
        $scope.loading = true;
        $scope.dayHoursData = false;
        $http.get('hourly/gethourdata').success(function(response){
               // console.log(response);
        	if(response.status == 'OK'){
                $scope.loading = false;
                $scope.dayHoursData = true;
                $scope.items = conversion(response.records);
                $scope.sort = function(keyname){
                $scope.sortKey = keyname;  //set the sortKey to the param passed
                $scope.reverse = !$scope.reverse; 
                //if true make it false and vice versa
                } 
                getOperators();
            }
        });
    }; 
    
    var getPercentage = function ($param1, $param2){
      if($param2 == 0 ){return 0;}  
       $percent =  ($param1/$param2)*100;
       return parseFloat($percent);
    }

     var conversion = function (json){
            var item = json;
            item.totalClickCount = 0;
            item.Conversion_inwards = 0;
            item.Conversion_inward_unique = 0;
            item.Conversion_outwards = 0;
            item.totalcostv = 0; 
            item.totalcostdollar = 0; 
            item.total_fraud = 0;
            item.total_revenue = 0;
            item.total_profit = 0;
            item.total_ecpm = 0;
            item.totalsale_count = 0;
            for(i=0; i < json.length; i++){
                 //  
                 var obj = json[i];
                 if(obj.revenue_dollar == null){
                    obj.revenue_dollar = 0;
                 }
                 if(obj.total_costv == null){
                    obj.total_costv = 0;
                 }
                 
                 item[i].country_code = obj.country_code;
                 item[i].hour = parseFloat(obj.hour);
                 item[i].id_ad = parseFloat(obj.id_ad);
                 item[i].parent_cca = parseFloat(obj.parent_cca);
                 item[i].clickcount = parseFloat(obj.clickcount);
                 item[i].clicks_active_count = parseFloat(obj.clicks_active_count);
                 item[i].conversion_count = parseFloat(obj.conversion_count);  
                 item[i].conversion_count_unique = parseFloat(obj.conversion_count_unique);
                 item[i].total_costv = parseFloat(obj.total_costv);
                 item[i].id_advertiser_campaign = parseFloat(obj.id_advertiser_campaign);
                 item[i].sale_count = parseFloat(obj.sale_count);
                 item[i].id_ad = parseFloat(obj.id_ad);
                 item[i].revenue_dollar = parseFloat(obj.revenue_dollar);
                 item[i].is_smart_cca = obj.is_smart_cca;
                 item[i].ecpm = parseFloat(obj.revenue_dollar/obj.clickcount) * 1000;
                 
                 item[i].crcIn = getPercentage(obj.conversion_count,obj.clickcount);
                 item[i].crcOut = getPercentage(obj.clicks_active_count,obj.clickcount);
                 item[i].crcInUnique = getPercentage(obj.conversion_count_unique,obj.clickcount);
                 item[i].profit = parseFloat(obj.revenue_dollar) - parseFloat(obj.total_costv);
                 
                 item.totalClickCount =  parseInt(item.totalClickCount) + parseInt(obj.clickcount);
                 item.Conversion_inwards =  parseFloat(item.Conversion_inwards) + parseFloat(obj.conversion_count);
                 item.Conversion_outwards =  parseFloat(item.Conversion_outwards) + parseFloat(obj.clicks_active_count);
                 item.Conversion_inward_unique =  parseFloat(item.Conversion_inward_unique) + parseFloat(obj.conversion_count_unique);
                 item.totalcostv =  parseFloat(item.totalcostv) + parseFloat(obj.total_costv);
                 item.totalsale_count =  parseFloat(item.totalsale_count) + parseFloat(obj.sale_count);
                 item.total_fraud =  parseFloat(item.total_fraud) + parseFloat(obj.clickcount_fraud);
                 item.total_revenue =  parseFloat(item.total_revenue) + parseFloat(obj.revenue_dollar);
                 item.total_profit = parseFloat(item.total_profit) + parseFloat(item[i].profit);
                 item.total_ecpm = parseFloat(item.total_ecpm) + parseFloat(item[i].ecpm);
                 // console.log(item.total_ecpm);
			}
            return item 
    }
        var checkString = function(param1){
            var param = param1
            if(param){
               param = param.toString();
          }
            return param;
        } 

          /* To Show the column according to GroupBy request */
          var CheckGroupBy = function(groupByData){
            if(groupByData !=undefined){
            var str = groupByData;
            var hasCountry = str.indexOf('country') != -1;
            var hasReportType = str.indexOf('report_type') != -1;
            var hasTrafficType = str.indexOf('traffic_type') != -1;
            var hasTrafficType = str.indexOf('traffic_type') != -1;
            var hasParentCca = str.indexOf('parent_cca') != -1;
				if(hasCountry){
                    $scope.country_code = true;
                }
                if(hasReportType){
                    $scope.report_type = true;
                }
                if(hasTrafficType){
                    $scope.traffic_type = true;
                }
                if(hasParentCca){
                $scope.parentcca_type = true;
                }
              }    
            }

        // function to insert or update user data to the database
        $scope.filterdata = function(type){
            $scope.pageSize = 50;
            $scope.table = false;
            $scope.country_code = false; 
            $scope.report_type = false;
            $scope.traffic_type = false;
            $scope.parentcca_type = false;    
            var operator = $("#operator").val();
            operator = checkString(operator);
            var network = $("#network").val();
            network = checkString(network);
            var groupby = $("#groupby").val();
            groupby = checkString(groupby);
            var advertiser = $("#advertiser").val();
            advertiser = checkString(advertiser);
            var hour = $("#hour").val();
            hour = checkString(hour);
            var id_advt = $("#idadvt").val();
            id_advt = checkString(id_advt);
            var parent_cca = $("#parent_cca").val();
            parent_cca = checkString(parent_cca);
            var dateRange = $("#reportrange").val();
            dateRange = checkString(dateRange);
            var report_type = $("#report_type").val();
            report_type = checkString(report_type);
            var traffic_type = $("#traffic_type").val();
            traffic_type = checkString(traffic_type);
            var country = $("#country").val();
            country = checkString(country);
            var id_ad = $("#id_ad").val();
            id_ad = checkString(id_ad);
            var vertical = $("#vertical").val();
            vertical = checkString(vertical);
            if(!(operator || network || groupby || advertiser 
                || hour || id_advt  || parent_cca || id_ad || vertical)){
            // alert('Please select any of the filter');
            // return false;
            }
            $scope.loading = true;  
            $http.get("hourly/filterresult",{
            params:{
                'operator':operator,
                'network':network,
                'advertiser':advertiser,
                'hour':hour,
                'id_advt':id_advt,
                'parent_cca':parent_cca,
                'groupby':groupby,
                'daterange':dateRange,
                'report_type':report_type,
                'traffic_type':traffic_type,
                'country':country,
                'id_ad':id_ad,
                'vertical':vertical	
            }
            }).success(function(response){
            if(response.status == 'OK'){
				$scope.loading = false;
                $scope.dayHoursData = false;
                CheckGroupBy(groupby);
                $scope.filterResult = conversion(response.item);
                $scope.lastUpdated = response.lastUpdated;
                // console.log($scope.lastUpdated);
                $scope.hourdata = true;
                $scope.messageSuccess(response.msg); 
            } 
            }) 
            .error(function (response) {
                $scope.loading = false;  
                alert('There is something went wrong');
            });
    };

  
    
    // function to display success message
    $scope.messageSuccess = function(msg){
        $('.alert-success > p').html(msg);
        $('.alert-success').show();
    };
    
    // function to display error message
    $scope.messageError = function(msg){
        $('.alert-danger > p').html(msg);
        $('.alert-danger').show();
    };
    $scope.toggleFraud = function(){
    if($scope.fraud === true)
      $scope.fraud = false;
    else if($scope.fraud === false)
      $scope.fraud = true;
    }
      $scope.toggleCrInwardUnique = function(){
        if($scope.CrInwardUnique === true)
          $scope.CrInwardUnique = false;
        else if($scope.CrInwardUnique === false)
          $scope.CrInwardUnique = true;
      }
     $scope.toggleConversionInwardUnique = function(){
        if($scope.ConversionInwardUnique === true)
          $scope.ConversionInwardUnique = false;
        else if($scope.ConversionInwardUnique === false)
          $scope.ConversionInwardUnique = true;
      }
      $scope.toggleSaleCount = function(){
        if($scope.sale_count === true)
          $scope.sale_count = false;
        else if($scope.sale_count === false)
          $scope.sale_count = true;
      }  
     
});


 $('#dayHoursData').dataTable( {
        "sDom": 'C>"clear"<lfrtip'
    } );
   
</script>
<script type="text/javascript">
    $(document).ready(function () {
    var $chk = $("#grpChkBox input:checkbox"); // cache the selector
//    var $ack = $("#grpChkBox a"); // cache the selector
    var $tbl = $("#dayHoursData");
    var $tbl2 = $("#hourdata");
 
    $chk.prop('checked', true); // check all checkboxes when page loads
 
    $chk.click(function () {
        var colToHide = $tbl.find("." + $(this).attr("name"));
        $(colToHide).toggle();
        var colToHide2 = $tbl2.find("." + $(this).attr("name"));
        $(colToHide2).toggle();
    });
    
    
    jQuery('.dropdown-toggle').on('click', function (e) {
  $(this).next().toggle();
});
jQuery('.dropdown-menu.keep-open').on('click', function (e) {
  e.stopPropagation();
});
/* Anything that gets to the document
   will hide the dropdown */
$(document).click(function(){
  $("#dropdown").hide();
});

/* Clicks within the dropdown won't make
   it past the dropdown itself */
$("#dropdown").click(function(e){
  e.stopPropagation();
});
});



</script>
<div class="container" ng-app="crcApp" ng-controller="crchourController" ng-init="getRecords()">
 	<div class="loader" ng-show="loading" ></div>
    <!--div class="small-loader"></div-->
    <div class="wrapper">
        <form action="/hourly" method="GET" id="filterform">
            <div class="row first-row">
                <div class="col-sm-2">
                    <div><label>Choose Date</label></div>
                    <input id="reportrange" name="reportrange">
                </div>
                <div class="col-sm-3">
                    <div><label>Traffic Type</label></div>     
                    <select id="traffic_type" name="traffic_type" multiple class="selectpicker" data-live-search="true" data-actions-box="true" data-selected-text-format="count > 3" data-size="10" data-style="btn-danger">
                    <?php foreach($TrafficType as $key=>$value){?>
                    <option value="<?php echo $value;?>"><?php echo $value; ?></option>
                    <?php } ?>
                    </select>
                </div>
                <div class="col-sm-2">
                    <div><label>Report Type</label></div>     
                    <select id="report_type" name="report_type" multiple class="selectpicker" data-live-search="true" data-actions-box="true" data-selected-text-format="count > 3" data-size="10" data-style="btn-danger">
                    <?php foreach($ReportType as $key=>$value){?>
                    <option value="<?php echo $value;?>"><?php echo $value; ?></option>
                    <?php } ?>
                    </select>
                </div>
                <div class="col-sm-2">
                    <div><label>Vertical</label></div>     
                    <select id="vertical" name="vertical" multiple class="selectpicker" data-live-search="true" data-actions-box="true" data-selected-text-format="count > 3" data-size="10" data-style="btn-success">
                    <?php foreach($Vertical as $vertical){?>
                    <option value="<?php echo $vertical;?>"><?php echo $vertical; ?></option>
                    <?php } ?>
                    </select>
                </div>
                <div class="col-sm-3">
                    <div><label>Country</label></div>     
                    <select id="country" name="country" multiple class="selectpicker" data-live-search="true" data-actions-box="true" data-selected-text-format="count > 3" data-size="10" data-style="btn-danger">
                    <?php foreach($country as $key=>$value){?>
                    <option value="<?php echo $value->iso;?>"><?php echo $value->iso;?>(<?php echo $value->name; ?>)</option>
                    <?php } ?>
                    </select>
                </div>    
            </div>
        <div class="row">
            <div class="col-sm-3">
                <div><label>Operator</label></div>
                <select name="operator" id="operator" multiple class="selectpicker" data-live-search="true" data-actions-box="true" data-selected-text-format="count > 3" data-size="10"  data-style="btn-primary">
                    <option>Operator</option>
                </select>
            </div>
            <div class="col-sm-3">    
            <div><label> Network</label></div>
                <select name="network" id="network" multiple class="selectpicker"data-live-search="true" data-actions-box="true" data-selected-text-format="count > 3" data-size="10" data-style="btn-primary">
                <option></option> 
                </select>
            </div>
             <div class="col-sm-3"> 
            <div><label> Advertiser</label></div>    
                <select select="advertiser" id="advertiser" multiple class="selectpicker" data-live-search="true" data-actions-box="true" data-selected-text-format="count > 3" data-size="10" data-style="btn-warning"></select>
            </div>
            <div class="col-sm-3">
            <div><label> Hours</label></div>      
                <select name="hour" id="hour" multiple class="selectpicker" data-live-search="true" data-actions-box="true" data-selected-text-format="count > 3" data-size="10" data-style="btn-warning">
                <?php for($i=0 ;$i<25;$i++): ?>
                <option value=<?php echo e($i); ?>> <?php echo e($i); ?></option>
                <?php endfor; ?> 
                </select>
            </div>     
        </div>
            <div class="row">
                <div class="col-sm-3">
                    <div><label>Id Advt(Campaign)</label></div>
                     <select name="idadvt" id="idadvt" multiple class="selectpicker"  data-live-search="true" data-actions-box="true" data-selected-text-format="count > 3" data-size="10" data-style="btn-success">
                    </select>
                </div>
                <div class="col-sm-3">
                    <div><label>Id Ad</label></div>     
                    <input type="text" id="id_ad" name="id_ad" Placeholder ="Id Ad" value="" class="form-control input-sm">
                </div>
                <div class="col-sm-3">
                    <div><label>Parent CCA</label></div>     
                    <input type="text" id="parent_cca" name="parent_cca" Placeholder ="Parent CCA" value="" class="form-control input-sm">
                </div>
                <div class="col-sm-3">
                    <div><label>Group By</label></div>     
                    <select id="groupby" name="select_group_by" class="selectpicker" multiple data-live-search="true" data-actions-box="true" data-selected-text-format="count > 3" data-size="10" data-style="btn-success">
                    <?php foreach($GroupBy as $group){?>
                    <option value="<?php echo $group['key']; ?>"><?php echo $group['val']; ?></option>
                    <?php } ?>
                    </select>
                </div>    
            </div>
            <div class="row  top10">
                <div class="col-md-1">
                    <div class="" id="grpChkBox">
      <button data-toggle="dropdown" class="btn btn-success dropdown-toggle waves-effect waves-light\" type="button">Columns <span class="caret"></span></button>
      <ul role="menu" class="dropdown-menu" id="dropdown">
            <li class="dropdown-item" style="width:100%;">
                <a href="javascript:void(0)" >
                        <input id="checkbox1" data-index="0" class="columncheck" value="Hours" checked="Checked" name="hours" type="checkbox">
                        <label for="checkbox1" >Hours</label>
                </a>
            </li>
            <li class="dropdown-item">
                <a href="javascript:void(0)">
                        <input id="checkbox2" data-index="1" class="columncheck" value="Total Clicks" checked="Checked" name="clicks" type="checkbox">
		        <label for="checkbox2">Total Clicks</label>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
                        <input id="checkbox3" data-index="2" class="columncheck" value="Fraud Count" checked="Checked" name="fraud" type="checkbox">
		        <label for="checkbox3">Fraud Count</label>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
                        <input id="checkbox4" data-index="3" class="columncheck" value="Conversion Inward" checked="Checked" name="convIn" type="checkbox">
		        <label for="checkbox4">Conversion Inward</label>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
		        <input id="checkbox5" data-index="4" class="columncheck" value="Conversion Inward Unique" checked="Checked" name="convInUnique" type="checkbox">
		        <label for="checkbox5">Conversion Inward Unique</label>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
		        <input id="checkbox6" data-index="5" class="columncheck" value="Conversion Outward" checked="Checked" name="convOut" type="checkbox">
		        <label for="checkbox6">Conversion Outward</label>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
		        <input id="checkbox7" data-index="6" class="columncheck" value="CR Inward" checked="Checked" name="crIn" type="checkbox">
		        <label for="checkbox7">CR Inward</label>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
		        <input id="checkbox8" data-index="7" class="columncheck" value="CR Inward(Unique)" checked="Checked" name="crInUnique" type="checkbox">
		        <label for="checkbox8">CR Inward(Unique)</label>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
		        <input id="checkbox9" data-index="8" class="columncheck" value="CR Outward" checked="Checked" name="crOut" type="checkbox">
		        <label for="checkbox9">CR Outward</label>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
		        <input id="checkbox10" data-index="9" class="columncheck" value="ecpm" checked="Checked" name="ecpm" type="checkbox">
		        <label for="checkbox10">ecpm</label>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
		        <input id="checkbox11" data-index="10" class="columncheck" value="Sale Count" checked="Checked" name="saleCount" type="checkbox">
		        <label for="checkbox11">Sale Count</label>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
		        <input id="checkbox12" data-index="11" class="columncheck" value="Total Cost $" checked="Checked" name="totalCost" type="checkbox">
		        <label for="checkbox12">Total Cost $</label>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
		        <input id="checkbox13" data-index="12" class="columncheck" value="Revenue $" checked="Checked" name="revenue" type="checkbox">
		        <label for="checkbox13">Revenue $</label>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
		        <input id="checkbox14" data-index="13" class="columncheck" value="profit $" checked="Checked" name="profit" type="checkbox">
		        <label for="checkbox14">profit $</label>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
		        <input id="checkbox15" data-index="14" class="columncheck" value="Country" checked="Checked" name="country" type="checkbox">
		        <label for="checkbox15">Country</label>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
		        <input id="checkbox16" data-index="15" class="columncheck" value="Report Type" checked="Checked" name="reportType" type="checkbox">
		        <label for="checkbox16">Report Type</label>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
		        <input id="checkbox17" data-index="16" class="columncheck" value="Traffic Type" checked="Checked" name="trafficType" type="checkbox">
		        <label for="checkbox17">Traffic Type</label>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
		        <input id="checkbox18" data-index="17" class="columncheck" value="Is Smart" checked="Checked" name="isSmart" type="checkbox">
		        <label for="checkbox18">Is Smart</label>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
		        <input id="checkbox19" data-index="18" class="columncheck" value="Advertiser" checked="Checked" name="advertiser" type="checkbox">
		        <label for="checkbox19">Advertiser</label>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
		        <input id="checkbox20" data-index="19" class="columncheck" value="id_ad" checked="Checked" name="id_ad" type="checkbox">
		        <label for="checkbox20">id_ad</label>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
		        <input id="checkbox21" data-index="20" class="columncheck" value="Parent CCA" checked="Checked" name="parentCCA" type="checkbox">
		        <label for="checkbox21">Parent CCA</label>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
		        <input id="checkbox22" data-index="21" class="columncheck" value="Telco" checked="Checked" name="telco" type="checkbox">
		        <label for="checkbox22">Telco</label>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
		        <input id="checkbox23" data-index="22" class="columncheck" value="Network Name" checked="Checked" name="networkName" type="checkbox">
		        <label for="checkbox23">Network Name</label>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
		        <input id="checkbox24" data-index="23" class="columncheck" value="Network CPA" checked="Checked" name="networkCPA" type="checkbox">
		        <label for="checkbox24">Network CPA</label>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
		        <input id="checkbox25" data-index="24" class="columncheck" value="Id advertiser" checked="Checked" name="idAdvertiser" type="checkbox">
		        <label for="checkbox25">Id advertiser</label>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
		        <input id="checkbox26" data-index="25" class="columncheck" value="Campaign Name" checked="Checked" name="campaignName" type="checkbox">
		        <label for="checkbox26">Campaign Name</label>
                </a>
            </li>
            <li>
                <a href="javascript:void(0)">
		        <input id="checkbox27" data-index="26" class="columncheck" value="Sale Count" checked="Checked" name="saleCount" type="checkbox">
		        <label for="checkbox27">Sale Count</label>
                </a>
            </li>
        </ul>
                </div>
                </div>

                <div class="col-sm-2">
                    <a class="btn btn-danger pull-left" href="javascript:void()" onclick="window.location.reload();">Refresh</a>
                </div>
                <div class="col-xs-4 col-xs-offset-1">
                    <button type="button" id="search" name="hourly" ng-click="filterdata()" class="btn btn-primary align-center">Search
                 </button>  
                </div> 
                <div class="col-xs-4">
                 <button type="button" name="reset" onclick="resetFilters()" class="btn btn-warning pull-right">Reset
                 </button> 
                </div>
            </div>
        </form>
    </div><!-- Wrapper div end -->
     <div ng-show="dayHoursData">
         <div class="row text-primary top20">
            <div class="col-sm-3 top10 text-center">
                <button ng-click="toggleFraud()" class="btn btn-info">Fraud Count</button>
            </div>
            <div class="col-sm-2 top10 text-center">  
            <button ng-click="toggleCrInwardUnique()" class="btn btn-info"> Inward(U)</button>
           </div>
           <div class="col-sm-2 top10 text-center">  
            <button ng-click="toggleConversionInwardUnique()" class="btn btn-info">ConversionIn(U)</button>
           </div>
           <div class="col-sm-2 top10 text-center">  
            <button ng-click="toggleSaleCount()" class="btn btn-danger">Sale Count</button>
           </div>  
            <div class="col-sm-3 text-center">
                <input type="number" min="1" max="100" class="form-control" ng-model="pageSize" placeholder="Items Per Page">
            <strong class="bottom10">last Updated: <?php echo e(SimpleHelper::lastUpdated()); ?></strong>
            </div>
         </div> 
        <div class="row top20" style="overflow-x:auto">
        <table id="dayHoursData">
		<thead>

			<tr class="heading-row">
			<th width="10%" ng-click="sort('hour')" class="ng-cloak hours">Hours</th>
			<th width="10%" ng-click="sort('clickcount')" class="ng-cloak clicks">Total Clicks</th>
			<th width="10%" ng-click="sort('clickcount_fraud')" class="ng-cloak fraud" ng-if="fraud">Fraud Count</th>
            <th width="10%" ng-click="sort('conversion_count')" class="ng-cloak convIn">Conversion Inward</th>
            <th width="10%" ng-click="sort('conversion_count_unique')" class="ng-cloak convInUnique" ng-if="ConversionInwardUnique">Conversion Inward Unique</th>
			<th width="10%" ng-click="sort('clicks_active_count')" class="ng-cloak convOut">Conversion Outward</th>
            <th width="10%" ng-click="sort('crcIn')" class="ng-cloak crIn">CR Inward</th>
            <th width="10%" ng-click="sort('crcInUnique')" class="ng-cloak crInUnique"  ng-if =CrInwardUnique>CR Inward(Unique)</th>
			<th width="10%" ng-click="sort('crcOut')" class="ng-cloak crOut">CR Outward</th>
			<th width="10%" ng-click="sort('ecpm')" class="ng-cloak ecpm">ecpm</th>
			<th width="5%" ng-click="sort('sale_count')" class="ng-cloak saleCount" ng-if =sale_count>Sale Count</th>
            <th width="10%" ng-click="sort('total_costv')" class="ng-cloak totalCost">Total Cost $</th>
            <th width="10%" ng-click="sort('revenue_dollar')" class="ng-cloak revenue">Revenue $</th>
			<th width="10%" ng-click="sort('profit')" class="ng-cloak profit">profit $</th>
            </tr>
		</thead>
		<tbody>
       <tr class="total-row">
            <td width="10%" class="ng-cloak hours">Total</td>
            <td width="10%" class="ng-cloak clicks"><% items.totalClickCount | number %></td>
            <td width="10%" class="ng-cloak fraud" ng-if="fraud"><% items.total_fraud | number: 2 %></td>
            <td width="10%" class="ng-cloak convIn"><% items.Conversion_inwards | number %></td>
            <td width="10%" class="ng-cloak convInUnique" ng-if="ConversionInwardUnique"><% items.Conversion_inward_unique | number %></td>
            <td width="10%" class="ng-cloak convOut"><% items.Conversion_outwards %></td>
            <td width="10%" class="ng-cloak crIn"></td>
            <td width="10%" class="ng-cloak crInUnique" ng-if="CrInwardUnique"></td>
            <td width="10%" class="ng-cloak crOut"></td>
            <td width="10%" class="ng-cloak ecpm"><% items.total_ecpm | number: 4 %></td>
            <td width="5%" class="ng-cloak saleCount" ng-if =sale_count><% items.totalsale_count %></td>
            <td width="10%" class="ng-cloak totalCost"><% items.totalcostv | number: 2 %></td>
            <td width="10%" class="ng-cloak revenue"><% items.total_revenue | number: 2%></td>
            <td width="10%" class="ng-cloak profit"><% items.total_profit | number: 2%></td>
  <td width="10%" class="ng-cloak pub_offer_name"><% items.pub_offer_name%></td>
            </tr>
			<tr dir-paginate="item in items|orderBy:sortKey:reverse|filter:search|itemsPerPage:pageSize" pagination-id="mainPagination">
			<td width="10%" class="ng-cloak hours"><% item.hour %></td>
			<td width="10%" class="ng-cloak clicks"><% item.clickcount | number %></td>
			<td width="10%" class="ng-cloak fraud" ng-if="fraud"><% item.clickcount_fraud | number %></td>
                        <td width="10%" class="ng-cloak convIn"><% item.conversion_count | number %></td>
                        <td width="10%" class="ng-cloak convInUnique"  ng-if="ConversionInwardUnique"><% item.conversion_count_unique | number %></td>
			<td width="10%" class="ng-cloak convOut"><% item.clicks_active_count | number %></td>
			<td width="10%" class="ng-cloak crIn"><% item.crcIn | number: 3%> %</td>
			<td width="10%" class="ng-cloak crInUnique" ng-if =CrInwardUnique><% item.crcInUnique | number: 3 %> %</td>
                        <td width="10%" class="ng-cloak crOut"><% item.crcOut | number: 3 %> %</td>
			<td width="10%" class="ng-cloak ecpm"><% item.ecpm | number: 4 %></td>
			<td width="5%" class="ng-cloak saleCount" ng-if =sale_count><% item.sale_count %></td>
                        <td width="10%" class="ng-cloak totalCost"><% item.total_costv | number: 2 %></td>
                        <td width="10%" class="ng-cloak revenue"><% item.revenue_dollar | number: 2 %></td>
                        <td width="10%" class="ng-cloak profit"><% item.profit | number: 2 %></td>
			</tr>
            
        </tbody>
    </table>
    <dir-pagination-controls max-size="15" direction-links="true" boundary-links="true" pagination-id="mainPagination"></dir-pagination-controls>
    </div>
  </div>      
    <?php echo $__env->make('Hourly.hourfilter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="main-content"></div>
</div>
<script type="text/javascript">
    var input = document.getElementById("id_ad");
input.addEventListener("keyup", function(event) {
    event.preventDefault();
    if (event.keyCode === 13) {
        document.getElementById("search").click();
    }
});

var input2 = document.getElementById("parent_cca");
input2.addEventListener("keyup", function(event) {
    event.preventDefault();
    if (event.keyCode === 13) {
        document.getElementById("search").click();
    }
});
</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.hourly', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>