<?php $__env->startSection('custom_css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/bower_components/switchery/dist/switchery.min.css')); ?>" />
<!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('bread'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('heading'); ?>
  Advertiser Report Timezone Wise
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_js'); ?>
<script type="text/javascript">
    $(document).ready(function() {
      

        var col = ['text_65px',
                    'text_80px',
                    'text_240px',
                    'text_40px',
                    'text_50px',
                    'text_40px',
                    'text_40px',     
                    'text_40px',     
                    'text_40px',     
                    '',     
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    ""
                    
                ];
        var data =   <?php echo json_encode($data1); ?>;        
        createTableWithLazyLoad("#tableLazy",data,200,col);
        $(".rupees").hide();    
        var column;
          var unCheckedColumn = ['1','4','5','9'];
            /* to hide coluun according to condition */
            $(unCheckedColumn).each(function(key,uncheckIndex){
             $('.new th[data-index="'+uncheckIndex+'"]').toggleClass("hide");
             column = tableLazyNew.column(uncheckIndex);
             column.visible(false); 
            });
            // unchecking checkboxes 
            $(".dropdown-menu li").each(function(key,element){
                if($(element).find('input[type="checkbox"]').is(":checked")){
                    var dataI = $(element).find('input[type="checkbox"]').attr('data-index');
                    if(unCheckedColumn.indexOf(dataI) != -1){
                        $(element).find('input[type="checkbox"]').removeAttr("checked");
                    }
                }

            }); 
        
    } );
    
    
 
  </script>
<style type="text/css">
    .open > .dropdown-menu {
    display: block;
    max-width: 286% !important ;
}
.mydatepicker {
    width: 289px !important;
}

</style>
<script src="<?php echo e(asset('plugins/bower_components/switchery/dist/switchery.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/validator.js')); ?>"></script>
<script src="../plugins/bower_components/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script type="text/javascript">
     
    jQuery('.mydatepicker').datepicker({
       format:"yyyy-mm-dd"
    });
    jQuery(document).on('change','.currency',function(){
        if($(this).val() == 0){
            $(".dollar").show();
            $(".rupees").hide();
        }else{
            $(".dollar").hide();
            $(".rupees").show();
        }
    });
    
$("#resert").click(function() { 
                //$("#d").trigger("reset"); 
                //$("#d").get(0).reset(); 
                // $("#d")[0].reset();
                $(".selectpicker").val('').selectpicker("refresh");
            }); 

</script>
<style type="text/css"></style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="m-b-15 header-panel" style="text-align:center;">
        <div class="text-right">
            <select name="currency" class="currency btn btn-success">
                <option value="0">Dollar</option>
                <option value="1">Rupees</option>
            </select>    
        </div>
    </div>
    <div class="wrapper">
        
    </div>
</br>

<div class="row" style="margin: 2%">
        <div class="col-sm-12">
            <div class="form-group">
                <form name="" method="POST" action="/advertiser-report-timezonewise">
                    <?php echo e(csrf_field()); ?>

                    <div class="row first-row">
                
                        <div class="col-sm-3">
                            <div><label>Operating System</label></div>     
                                <select id="operating_id" name="operating_id[]" multiple  class="selectpicker" data-live-search="true" data-actions-box="true" data-selected-text-format="count > 3" data-size="10" data-style="btn-warning">
                                    <option value="all" <?php
                                    //echo ("all"==$select_opertings) ? "selected" :""
                                    if (isset($select_opertings)) {
                                        echo in_array("all", $select_opertings) ? "selected" : "";
                                    }
                                    ?>>All</option>
                                    <option value="android" <?php
                                    //echo ("android"==$select_opertings) ? "selected" :""
                                    if (isset($select_opertings)) {
                                        echo in_array("android", $select_opertings) ? "selected" : "";
                                    }
                                    ?>>Android</option>
                                    <option value="ios" <?php
                                    // echo ("ios"==$select_opertings) ? "selected" :""
                                    if (isset($select_opertings)) {
                                        echo in_array("ios", $select_opertings) ? "selected" : "";
                                    }
                                    ?>>ios</option>
                                    <option value="desktop"  <?php
                                    // echo ("desktop"==$select_opertings) ? "selected" :""
                                    if (isset($select_opertings)) {
                                        echo in_array("desktop", $select_opertings) ? "selected" : "";
                                    }
                                    ?>>desktop</option>
                                </select>
                        </div>
                        <div class="col-sm-3">
                            <div><label>Vertical</label></div>     
                            <select id="vertical" name="vertical[]"  multiple class="selectpicker" data-live-search="true" data-actions-box="true" data-selected-text-format="count > 3" data-size="10" data-style="btn-success">
                                <?php
                                $Vertical = config('constants.VERTICALS');
                                foreach ($Vertical as $vertical) {
                                    ?>
                                    <option value="<?php echo $vertical; ?>"  <?php
                                    //echo ($vertical ==$selected_vertical) ? "selected" :""
                                    if (isset($selected_vertical)) {
                                        echo in_array($vertical, $selected_vertical) ? "selected" : "";
                                    }
                                    ?>><?php echo $vertical; ?></option>
                                <?php } ?>
                            </select>
                        </div>
			
			 <div class="col-sm-3">
                            <div><label>Country</label></div>     
                            <select id="country" name="country[]" multiple class="selectpicker" data-live-search="true" data-actions-box="true" data-selected-text-format="count > 3" data-size="10" data-style="btn-warning">
                                <?php foreach($countryarray as $value){?>
                                <option value="<?php echo $value->iso;?>" <?php 
                                    if(isset($select_country)){
                                     echo in_array($value->iso,$select_country) ? "selected" :"";
                                    }

                                 ?>><?php echo $value->name." (".$value->iso.")";?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <?php 
//                            echo "timezone = ";
//                            echo "<pre>";
//                            print_r($timezone);
//                            echo "</pre>";
                        
                        ?>
                        <div class="col-sm-3">
                            <div><label>Time Zone</label></div>
                            <select id="time_zone" name="time_zone" class="selectpicker" data-live-search="true" data-selected-text-format="count > 3" data-size="10" data-style="btn-info">
                                <?php $__currentLoopData = Config::get('app.time_zone'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo $key;?>" <?php if($key==$time_zone) echo 'selected=selected'; ?>><?php echo $value; ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        

                        <input type="hidden" name="filter" value="1">
                        <div class="col-sm-3">
				<div><label>&nbsp;</label></div>
                            <button type="submit" class="form-control btn btn-success" name="go_ahead" id="go_ahead">Go</button>
                        </div>
                        
                    </div>
<!--                    <br>
                    <div class="row first-row">
                        
                        <div class="col-sm-4"></div>
                        
                    </div>-->
                    
            
                </form>
                
            </div>            
        </div>
    </div>


    <div class="col-sm-12">
        <div class="text-right ">
            <?php 
            $heads =  
                        [
                            "Advertiser Id",
                            "Advertiser Name",                                                            
                            "Campaign Name",
                            "TimeZone",
                            "Country",
                            "Vertical",
                            "Os type",                            
                            "Cap",
                            "Install Cap",
                            "Clicks",
                            "Install",
                            "Event",
                            "Outwards",
                            "CR In(%)",
                            "CR Out(%)",
                            "Cost($)",       
                            "Rev($)",                        
                            "Profit($/INR)",       
                            
                        ];
                            $heads2 =  
                            [
                                "Total",
                                "",
                                "",
                                "",                               
                                "",                               
                                "",                               
                                "", 
                                "",
                                "",
                                $lastRow[0],
                                $lastRow[1],
                                $lastRow[2],
                                $lastRow[3],
                                "", 
                                "",
                                $lastRow[4],                                
                                $lastRow[5],                             
                                $lastRow[6]                             
                            ];
                 ?>
                <div class="text-left" style="margin-bottom:10px">
                    <?php echo view('layouts.column', ['data' =>$heads]); ?>

                </div>
            </div>
        <div class="table-responsive mainTableInfo">
                <table class="table color-table info-table scrollTable lazy" id="tableLazy">
                    <?php echo view('layouts.tableheadNew', ['data' =>$heads,'class'=>""]); ?>

                    <?php echo view('layouts.tableheadNew', ['data' =>$heads2,'class'=>"new"]); ?>

                </table>


        </div> 
                           
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>