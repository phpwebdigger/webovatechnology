<?php $__env->startSection('title', $page_name); ?>
<?php $__env->startSection('heading'); ?>
  <?php echo e($page_name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
<script src="../js/url.js"></script>
<script type="text/javascript">
     var $heads =  [
                        'text_50px',
                        '',
                        'text',
                        'text_200px',
                        'text',
                        'text_40px',
                        'text_40px',
                        'text_40px',
			'text_40px',
                        'text_40px',
                        'text_40px',
                        'text_40px',
                        'text_40px',
                        'text_40px',
                        'text_40px',
                        'text_40px',
                        'text_40px',
                        'text_350px',
                        'text_50px'
                   ];      
    var data =   <?php echo json_encode($data1); ?>;
    $(document).ready(function(){
       createTableWithLazyLoad("#tableLazy",data,50,$heads);
        $(".showUrl").click(function(){
          var text = $(this).html();
          $("#data").html(text);
        });
    
        $("#ad-url").on('submit',function(e){
         e.preventDefault(); 
         $(".preloader").show();
         var id_ad = $("#id_ad").val(),
         network = $("#net_id").val(),
         operator = $("#op_id").val(),
         advert = $("#advert_id").val(),
         is_smart_cca =  $("#is_smart_cca").val(),
         is_permanent_status =$("#is_permanent_status").val();
//         alert(id_ad);
//         break;
         if(id_ad || network || operator || is_smart_cca || is_permanent_status || advert){   
          var formdata = $("#ad-url").serialize();
          $.ajax({
              url: "urls/filter-ads", 
              type: 'POST',
              cache: false,
              async: false,
              dataType: 'JSON',
              data:formdata+'&page_name=ads&urlFilter=adsFilter',
              success: function(res){
                var response = res;
                if(response.status == "1"){
                 $("#tableLazy").dataTable().fnClearTable();
                 $("#tableLazy").dataTable().fnDestroy();
                 $("#tableLazy .new").remove();
                 var head ='<thead class="new"><tr>';
                  $(response.lastRow).each(function(key,val){
                  head +='<th data-index="'+key+'" data-val="'+val+'">'+val+'</th>';
                  });
                  head +='</tr></thead>';
                 $("#tableLazy thead").after(head);
                 createTableWithLazyLoad("#tableLazy",response.data,200,$heads);
                 // columnreset();  
              }else if(response.status == "2"){
                alert('Please search again there is no result');
              }else{
                alert('Please search again there is no result');  
              }
              $(".preloader").hide();
              }, 
              error: function (textStatus,errorThrown){
                 alert('There is something went wrong');
                 $('.preloader').hide();   
              }
          });
        }else{
            alert('Please select one of the option');
            $(".preloader").hide();
            return false;
        }
        // e.preventDefault();  
    });
    
      $('.reset').click(function(){
        $('.selectpicker').val("").selectpicker('refresh');
        $('.bg-primary').find("input").val("");
        $("#id_ad").val("");
        // $("input[type=text]").change();
        $("#tableLazy").dataTable().fnClearTable();
        $("#tableLazy").dataTable().fnDestroy();
        createTableWithLazyLoad("#tableLazy",data,50,$heads);
        // columnreset();
    });
      
  });

  var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

       $(document).on('click','.ad_type',function(){
          var is_selected = $(this).attr('checked', true);
          $(".preloader").show();
          var id_ad = $(this).attr('id');
          var id_ad_type = $(this).val();
          if(id_ad){
              $.ajax({
                  url : '/ads/partialUpdate/',
                  type: 'GET',
                  async: true,
                  data: "action=id_ad_type&id_ad="+id_ad+"&id_ad_type="+id_ad_type+"&_token="+CSRF_TOKEN
              }).done(function (response) {
                  if(response.status == 1){
                    $('#'+id_ad).val(response.data);
                    $('#type_container-'+id_ad).html(response.msg);
                  }else {
                    alert('Some thing went wrong');
                  }
                  $(".preloader").hide();      
              }).fail(function () {
                      alert('Data could not be loaded.');
                      $(".preloader").hide();
              });
          }   
        });
    
  

    
  </script>
  <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php 
$heads = [   
    'CCA',
    'Manage',
    'Adv Name(Id)',
    'Campaign Name',
    'Operator Name',
    'Cap Count Conversions',
    'Wifi Status',
    'Payout Currency',
    'Type',
    'Block Status',
    'Traffic Type',
    'Network Cpa',
    'Network Name',
    'Smart CCA',
    'URL Change',
    'Direct Change',
    'Status',
    'Advertiser URL',
    'Permanent Status',
    ];
 ?>
<div class="col-sm-12">
    <!-- will be used to show any messages -->
    <?php if(Session::has('message')): ?>
        <div class="alert alert-info"><?php echo e(Session::get('message')); ?></div>
    <?php endif; ?>
</div>
<form class="form-inline" id="ad-url" role="form" method="POST">
<div class="row filter-panel">
       <?php echo e(csrf_field()); ?>    
        <div class="col-sm-1">
            <?php echo view('layouts.column', ['data' => $heads]); ?>

        </div>
       <div class="col-sm-3">
            <select name="net_id" id="net_id" class="selectpicker" data-style="btn btn-warning" data-live-search="true">
             <option value="">Select Network</option>   
            <?php $__currentLoopData = $networks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $network): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($network->ccz); ?>"><?php echo e($network->name); ?>(<?php echo e($network->ccz); ?>)</option>   
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
            </select>
        </div>
        <div class="col-sm-3">
           <select name="op_id" class="selectpicker" id="op_id" data-style="btn btn-danger" data-live-search="true">
            <option value="">Select Operator</option>
           <?php $__currentLoopData = $operators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($operator->id); ?>"><?php echo e($operator->name); ?>-<?php echo e($operator->country_code); ?>(<?php echo e($operator->id); ?>)</option>   
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select>
        </div>
        <div class="col-sm-3">
           <select name="advert_id" class="selectpicker" id="advert_id" data-style="btn btn-warning" data-live-search="true">
            <option value="">Select Advertiser</option>
            <?php foreach($advertiser as $adv){?>
                        <option value="<?php echo $adv->id_advertiser?>"><?php echo $adv->campaign_advertiser;?>(<?php echo $adv->id_advertiser;?>)</option>
                        <?php  } ?>
<!--           <?php $__currentLoopData = $operators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($operator->id); ?>"><?php echo e($operator->name); ?>(<?php echo e($operator->id); ?>)</option>   
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
           </select>
        </div>
          <div class="col-sm-2">
           <select name="is_smart_cca" id="is_smart_cca" class="selectpicker" data-style="btn btn-danger" data-live-search="true">
            <option value="">Smart CCA</option>
              <option value="0">No</option>   
              <option value="1">Yes</option>   
            </select>
        </div>
          <div class="col-sm-3">
           <select name="is_permanent_status" id="is_permanent_status" class="selectpicker" data-style="btn btn-danger" data-live-search="true">
            <option value="">Permanent Status</option>
              <option value="Active">Active</option>   
              <option value="Inactive">Inactive</option>   
            </select>
        </div>

	     <div class="col-sm-2">
            <input type="text" class="form-control" value="" name="id_ad" id="id_ad" Placeholder="cca">
        </div>
        <!-- <div class="clearfix"></br></div> -->
        <div class="col-sm-1">
             <button type="submit" class="btn btn-success waves-effect waves-light">Go</button>
        </div>
        <div class="col-sm-1">
            <a href = "javascript:void(0);" class="reset btn btn-warning">Reset</a>
        </div>
        <div class="col-sm-1">
            <a href = "urls/edit-smarturl" class="btn btn-info">Change Ads Url</a>
        </div>
    </div>
</form>    
    <div class="col-sm-12">
        <div class="mainTableInfo">
            <table class="table" id="tableLazy">
               <?php echo view('layouts.tablehead', ['data' => $heads]); ?>

               <?php echo view('layouts.tablefoot', ['data' =>$heads,'class'=>"new"]); ?>    
            </table>
        </div>           
    </div>
<!-- sample modal content -->
<div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display:none;" id="testmodel">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                <h4 class="modal-title" id="myLargeModalLabel">Mannual Cron Details</h4>
            </div>
            <div class="modal-body">
                <h4>Response</h4>
                <p id="data"></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger waves-effect text-left" data-dismiss="modal">Close</button>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->
<?php echo $__env->make('ad.edit-ad-url', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.simple', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>