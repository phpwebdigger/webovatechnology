<!-- Left navbar-header -->

        <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse">
                <ul class="nav" id="side-menu">
                    <li class="sidebar-search hidden-sm hidden-md hidden-lg">
                        <!-- input-group -->
                        <div class="input-group custom-search-form">
                            <input type="text" class="form-control" placeholder="Search...">
                            <span class="input-group-btn">
            <button class="btn btn-default" type="button"> <i class="fa fa-search"></i> </button>
            </span> </div>
                        <!-- /input-group -->
                    </li>
                         
                      <?php if(Session::get('roles')->name == "admin"): ?>
                    <?php $__currentLoopData = Config::get('menu.all'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li> <a href="/<?php echo e($value['link']); ?>" class="waves-effect <?php echo e($value['class']); ?>"><i data-icon="F" class="linea-icon fa-fw fa <?php echo e($value['icon']); ?>" style="font-size: 20px"></i> <span class="hide-menu"><?php echo e($value['name']); ?><span class="fa arrow"></span></span></a>
                        <?php if(count($value['child']) !=0 ): ?>
                        <ul class="nav nav-second-level">
                            <?php $__currentLoopData = $value['child']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyC => $valueC): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(Session::get('roles')->name == "admin"): ?>
                                      <?php if($valueC['target'] == 'true'): ?>
                                         <li> <a href="<?php echo e($valueC['link']); ?>" target="_blank"><?php echo e($valueC['name']); ?></a> </li> 
                                        <?php else: ?> 
                                         <li> <a href="/<?php echo e($valueC['link']); ?>"><?php echo e($valueC['name']); ?></a> </li>
                                        <?php endif; ?> 
                                <?php elseif(in_array($keyC, explode(',',Session::get('roles')->permission))): ?>
                                        <?php if($valueC['target'] == 'true'): ?>
                                         <li> <a href="<?php echo e($valueC['link']); ?>" target="_blank"><?php echo e($valueC['name']); ?></a> </li> 
                                        <?php else: ?> 
                                         <li> <a href="/<?php echo e($valueC['link']); ?>"><?php echo e($valueC['name']); ?></a> </li>
                                        <?php endif; ?> 
                                <?php endif; ?>

                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php endif; ?>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php elseif(Session::get('roles')->name == "report_manager"): ?>
                              <?php $__currentLoopData = Config::get('menu_reportmanager.all'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li> <a href="/<?php echo e($value['link']); ?>" class="waves-effect <?php echo e($value['class']); ?>"><i data-icon="F" class="linea-icon fa-fw fa <?php echo e($value['icon']); ?>" style="font-size: 20px"></i> <span class="hide-menu"><?php echo e($value['name']); ?><span class="fa arrow"></span></span></a>
                        <?php if(count($value['child']) !=0 ): ?>
                        <ul class="nav nav-second-level">
                            <?php $__currentLoopData = $value['child']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyC => $valueC): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(Session::get('roles')->name == "report_manager"): ?>
                                      <?php if($valueC['target'] == 'true'): ?>
                                         <li> <a href="<?php echo e($valueC['link']); ?>" target="_blank"><?php echo e($valueC['name']); ?></a> </li> 
                                        <?php else: ?> 
                                         <li> <a href="/<?php echo e($valueC['link']); ?>"><?php echo e($valueC['name']); ?></a> </li>
                                        <?php endif; ?> 
                                <?php elseif(in_array($keyC, explode(',',Session::get('roles')->permission))): ?>
                                        <?php if($valueC['target'] == 'true'): ?>
                                         <li> <a href="<?php echo e($valueC['link']); ?>" target="_blank"><?php echo e($valueC['name']); ?></a> </li> 
                                        <?php else: ?> 
                                         <li> <a href="/<?php echo e($valueC['link']); ?>"><?php echo e($valueC['name']); ?></a> </li>
                                        <?php endif; ?> 
                                <?php endif; ?>

                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php endif; ?>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <?php elseif(Session::get('roles')->name == "att_report_manager"): ?>

                              <?php $__currentLoopData = Config::get('menu_att_reportmanager.all'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                      <li> <a href="/<?php echo e($value['link']); ?>" class="waves-effect <?php echo e($value['class']); ?>"><i data-icon="F" class="linea-icon fa-fw fa <?php echo e($value['icon']); ?>" style="font-size: 20px"></i> <span class="hide-menu"><?php echo e($value['name']); ?><span class="fa arrow"></span></span></a>
                        <?php if(count($value['child']) !=0 ): ?>
                        <ul class="nav nav-second-level">
                            <?php $__currentLoopData = $value['child']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyC => $valueC): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(Session::get('roles')->name == "att_report_manager"): ?>
                                      <?php if($valueC['target'] == 'true'): ?>
                                         <li> <a href="<?php echo e($valueC['link']); ?>" target="_blank"><?php echo e($valueC['name']); ?></a> </li> 
                                        <?php else: ?> 
                                         <li> <a href="/<?php echo e($valueC['link']); ?>"><?php echo e($valueC['name']); ?></a> </li>
                                        <?php endif; ?> 
                                <?php elseif(in_array($keyC, explode(',',Session::get('roles')->permission))): ?>
                                        <?php if($valueC['target'] == 'true'): ?>
                                         <li> <a href="<?php echo e($valueC['link']); ?>" target="_blank"><?php echo e($valueC['name']); ?></a> </li> 
                                        <?php else: ?> 
                                         <li> <a href="/<?php echo e($valueC['link']); ?>"><?php echo e($valueC['name']); ?></a> </li>
                                        <?php endif; ?> 
                                <?php endif; ?>

                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php endif; ?>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
        <!-- Left navbar-header end -->
