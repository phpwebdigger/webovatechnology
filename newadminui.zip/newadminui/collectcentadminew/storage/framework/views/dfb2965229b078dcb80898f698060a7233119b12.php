<?php $__env->startSection('custom_css'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('plugins/bower_components/switchery/dist/switchery.min.css')); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('bread'); ?>
<!--    <ol class="breadcrumb">
        <li><a href="#">Dashboard</a></li>
        <li class="active">Delivery</li>
    </ol>-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('heading'); ?>
   Add Event
<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom_js'); ?>
<script src="<?php echo e(asset('plugins/bower_components/switchery/dist/switchery.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('js/validator.js')); ?>"></script>
<script type="text/javascript">

     var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
       $('.js-switch').each(function() {
           new Switchery($(this)[0], $(this).data());

       });
       $(".ischild").on('change',function(){
            if($(this).is(":checked")){
                $("#outW").removeClass("hide");
            }else{
                $("#outW").addClass("hide");
            }
       });

       function copyToClipboard(element) {
            var $temp = $("<input>");
            $("body").append($temp);
            $temp.val($(element).text()).select();
            document.execCommand("copy");
            $temp.remove();
            $("#post_back_url").val($(element).text());
            alert('text copied and move');
        }
        
        $(document).on('change','#cca',function(){
              var  ccas = $(this).val();
              console.log(ccas);
              ccas = ccas + '';
              if(ccas.indexOf(',') != -1){
               $("#is_child").hide();
               console.log('A');           
              }else{
                console.log('B');
                $("#is_child").show();
              }
        });   
       $(document).on('change','#ccz',function(){
            var post_back_url = $("#post_back_url");
            post_back_url.val('');
            $(".preloader").show();
            $id_zone = $(this).val();
            var ccz = $("#ccz option:selected").text();
            $title = ccz.split('('); 
            $("#title").val($title[0]); 
            $.ajax({
                url : '/event/get-adsbynetwork/',
                type: 'GET',
                async: true,
                data: "id_zone="+$id_zone
            }).done(function (response){
                
//                alert(response);
                var adsData =  JSON.parse(response);
//                alert(adsData.event_url)
//                var networks = '<option value="">select CCA</option>';    
                var postbackUrl = '<ul class="list-group"><li class="list-group-item"><b class="text-danger">Latest PostBacks</b></li>';
                console.log(adsData.deliveryPostBack);
                
//                $(adsData.cca).each(function(key,network){
//                    networks += '<option value="'+network.id_ad+'"" data-title="'+network.title+'">'+network.cca+'</option>';
//                });
                
//                $("#cca").html(networks).selectpicker('refresh');
                postbackUrl += '<li class="list-group-item"><div onclick="copyToClipboard(this)">'+adsData.event_url+'</div>Total:'+adsData.total+'</li>';
                
//                $(adsData.deliveryPostBack).each(function(key,delivery){
//                    
//                });
                if(postbackUrl){
                    $('.postback-url').html(postbackUrl);
                }else{
                    $('.postback-url').html('<li class="list-group-item">Postback URL : No postback Url</li>');
                }
                postbackUrl +='</ul>';
                $(".preloader").hide();      
            }).fail(function(){
                    alert('Data could not be loaded.');
                    $(".preloader").hide();
            });
   });

    

</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php 
       $class = '';
       if(isset($is_smart) &&  $is_smart == 'smart'){
            $class = 'hide';  
       }
     ?> 
    <div class="row">
                   
                    <div class="error text text-center center text-danger col-sm-12" style="padding:20px;text-align: center;" ><?php echo e($errors??""); ?></div>
                    <div class="col-sm-6">
                        <div class="white-box">
                            
                            <form data-toggle="validator" method="POST" action="<?php echo e(url('event/add')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <label for="inputName" class="control-label">CCZ *</label>
                                    <div class="form-group">

                                    <select name="ccz" id="ccz" class=" select2 form-control"  data-act="ajax-select" data-preload="true" data-post-text="concat(name,'(',ccz,')')" data-post-id="ccz" data-post-key="name" data-post-table="ad_network" data-min-input="2" data-placeholder="type to search CCZ" required>
                                       <option> Select CCZ</option>
                                    </select>
                                    </div>
                                    <div class="help-block with-errors"></div>
                                </div>
                                <div class="form-group">
                                    <label for="inputName" class="control-label">CCA *</label>
                                    <div class="form-group">
                                        <input type="text"  name="parent_cca"  value="" data-toggle="validator"   class="form-control" id="parent_cca" placeholder="CCA">
                                    </div>
                                    <div class="help-block with-errors"></div>
                                </div>
<!--                                <div class="form-group <?php echo e($class); ?>" id="is_child">
                                    <label for="inputpostUrl" class="control-label">Is Child</label>
                                        <div class="form-group col-sm-5">
                                           Inactive  <input type="checkbox" name="isChild" class="ischild js-switch" /> Active
                                        <div class="help-block with-errors"></div>
                                        </div>
                                        <div class="form-group col-sm-5">
                                            <input id="outW" class="outHide hide form-control" type="text" name="childId"  />
                                        </div>
                                </div>-->

                                <div class="form-group" style="clear: both;">
                                    <label for="inputpostUrl" class="control-label">Campaign Id</label>
                                    <div class="form-group col-sm-12">
                                        <input type="text"  name="campaign_id"  value="" data-toggle="validator"   class="form-control" id="campaign_id" placeholder="campaign Id">
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                <div class="form-group" style="clear: both;">
                                    <label for="inputpostUrl" class="control-label">Event Name</label>
                                    <div class="form-group col-sm-12">
                                        <input type="text"  name="event_name"  value="" data-toggle="validator"   class="form-control" id="event_name" placeholder="Event Name">
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                <div class="form-group" style="clear: both;">
                                    <label for="inputpostUrl" class="control-label">Sale </label>
                                    <div class="form-group col-sm-12">
                                        <input type="text"  name="sale_count"  value="" data-toggle="validator"   class="form-control" id="sale_count" placeholder="Sale">
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>

                                <div class="form-group" style="clear: both;">
                                    <label for="inputpostUrl" class="control-label">Post Back Url</label>
                                    <div class="form-group col-sm-12">
                                        <input type="text"  name="post_back_url"  value="" data-toggle="validator"   class="form-control" id="post_back_url" placeholder="Post back URL">
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                
                                 <div class="form-group">
                                    <label for="inputpostUrl" class="control-label">Status</label>
                                    <div class="form-group col-sm-12">
                                        Inactive <input name="postback_status"  type="checkbox" checked class="js-switch" /> Active
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="inputpostUrl" class="control-label">Filter *</label>
                                    <div class="form-group col-sm-12">
                                        <input type="text"  name="filter_data"  data-toggle="validator"   class="form-control" id="filter_data" placeholder="Input Filter" required>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="inputpostUrl" class="control-label">Pub goal Id *</label>
                                    <div class="form-group col-sm-12">
                                        <input type="text"  name="publisher_goal_id"  data-toggle="validator"   class="form-control" id="publisher_goal_id" placeholder="Input Publisher Goal Id" required>
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
<!--                                <div class="form-group">
                                    <label for="inputpostUrl" class="control-label">Higher Percentage *</label>
                                        <div class="form-group col-sm-12">
                                            <input type="text" name="higher_limit" data-toggle="validator"  value="100" class="form-control" id="higher_limit" placeholder="Input Percentage" required>
                                            <div class="help-block with-errors"></div>
                                        </div>
                                </div>
                                <div class="form-group">
                                    <label for="inputpostUrl" class="control-label">Filter Status</label>
                                    <div class="form-group col-sm-12">
                                        Inactive <input type="checkbox" name="filter_status" checked class="js-switch" /> Active
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>-->
<!--                                <div class="form-group">
                                    <label for="isCron" class="control-label">Want to insert on Cron</label>
                                        <div class="form-group col-sm-12">
                                            Inactive <input type="checkbox" name="isCron" class="js-switch" /> Active
                                        <div class="help-block with-errors"></div>
                                        </div>
                                </div>-->
                                <div class="form-group">
                                    <input type="hidden" name="title" value="" id="title"> 
                                    <button type="submit" class="btn btn-success">Submit</button>
                                    <a href="/delivery" class="btn btn-danger">Cancel</a> 
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-sm-6 postback-url">
                          
                    </div>
                                        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>