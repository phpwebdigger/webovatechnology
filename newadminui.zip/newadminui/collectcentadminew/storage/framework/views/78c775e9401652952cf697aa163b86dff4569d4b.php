<form method="post" action="" name="edit_form" id="edit_form" data-abide method="post"> 
    <div class="modal fade" id="editUrl" role="dialog" aria-hidden="true" style="display:none;">
    <div class="modal-dialog modal-lg" style="top:150px">    
        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-body">            
                <div id="msg"></div>
                    <div class="form-group">
                            <div class="row">
                                <div class="col-sm-2"><label for="id_ad">Id ad</label></div>
                                <div class="col-sm-10">  
                                    <input type="text" name="id_ad" id="id_ad" readonly value=""  class="form-control id_ads input-sm"/> 
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-sm-2">
                                    <label for="adv_id">Advertiser Id</label>
                                </div> 
                                <div class="col-sm-10"> 
                                    <input type="text" name="adv_id" id="adv_id" readonly value="{adv_id}" class="form-control  input-sm"/>                            
                                 </div> 
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-sm-2">
                                    <label for="title">Title</label>
                                </div>
                                <div class="col-sm-10">
                                    <input type="text" name="title" id="title" readonly class="form-control input-sm" value="{title}"/>
                                </div>
                            </div>    
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-sm-2">
                                    <label for="network_name">Network Name</label>
                                </div>
                                <div class="col-sm-10">
                                    <input type="text" name="network_name" id="network_name" readonly value="{network_name}" class="form-control input-sm"/>
                                </div>
                            </div>     
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-sm-2">
                                    <label for="traffic_typ">Traffic Type*</label>
                                </div>
                                <div class="col-sm-10">    
                                    <!--select name="traffic_typ" id="traffic_typ">
                                    <option></option>
                                    </select--> 
                                    <input type="text" name="traffic_typ" id="traffic_typ" readonly value="{traffic type}" class="form-control input-sm"/>
                                </div>
                            </div>    
                        </div>  
                        <div class="form-group">
                            <div class="row">
                                <div class="col-sm-2">
                                    <label for="operator_name">Operator Name</label>
                                </div>
                                <div class="col-sm-10">
                                    <input type="text" name="operator_name" id="operator_name" value="" readonly class="form-control input-sm"/>
                                </div>
                            </div>        
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-sm-2">
                                    <label>Click Url*</label>
                                </div>
                                <div class="col-sm-10">    
                                    <textarea name="click_url" id="click_url" cols="35" rows="3" disabled class="form-control">{Url}</textarea>
                                 </div>
                            </div>     
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-sm-2">
                                    <label for="is_smart">Is smart</label>
                                </div>
                                <div class="col-sm-10">
                                <input type="radio" name="is_smart" id="default_radio" value="DEFAULT" class="radiobox" class="form-control input-sm" checked="checked">
                                Default
                                <input type="radio" name="is_smart" id="is_smart_cpa" value="CPA" class="radiobox" class="form-control input-sm">
                                CPA 
                                <input type="radio" name="is_smart" id="is_smart_cpi" value="CPI" class="radiobox" class="form-control input-sm">
                                CPI 
                                <span id='spinner' style="display:none;">Processing.... </span>
                                </div>
                            </div>    
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-sm-2">
                                    <label for="id_advertiser">Advertiser Campaign Name </label>
                                </div>
                                <div class="col-sm-10"> 
                                    <select name="id_advertiser" id="id_advertiser" data-act="ajax-call" class="form-control input-sm" data-live-search="true">
                                    {id_advertiser}
                                    </select>
                                </div>
                            </div>    
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-sm-2">
                                    <label for="url">URL </label>
                                </div>
                                <div class="col-sm-10">    
                                    <textarea rows="3" resize:none type="text" id="url" readonly class="form-control input-sm">
                            </textarea>
                                 </div>
                            </div>                    
                        </div>
                        <div class="form-group">
                        <div>    
                        <button type="button" class="btn btn-danger pull-right" data-dismiss="modal" id="cancel_data">Cancel</button>
                        </div>
                        <div>
                        <a href="javascript:void(0)" class="btn btn-primary pull-right" id="update" >Update</a>
                        </div>
                        </div> 
                    </div>
                </div>      
            </div>
        </div>  
</form>
