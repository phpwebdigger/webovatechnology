@extends('layouts.app')
@section('custom_css')
<link rel="stylesheet" type="text/css" href="{{asset('plugins/bower_components/switchery/dist/switchery.min.css')}}" />
@endsection

@section('bread')
                            <ol class="breadcrumb">
                                <li><a href="#">Dashboard</a></li>
                                <li class="active">My Profile</li>
                            </ol>
@endsection
@section('heading')
  My Profile
@endsection
@section('content')
<style type="text/css">
    .white-box{
        background-color: #edf1f5 !important;
    }
</style>

                    <div class="row">
                    <div class="col-md-4 col-xs-12" style="background-color: white; height:45%">
                        <div class="white-box">
                            <div class="user-bg" style="padding-bottom: 5px" > 
                                <div class="overlay-box">
                                    <div class="user-content">
                                        <a href="javascript:void(0)"><img src="{{asset('photo.jpg')}}" class="thumb-lg img-circle" alt="img"></a>
                                        <h4 class="text-white">{{Auth::user()->name}}</h4>
                                        <h5 class="text-white">{{Auth::user()->email}}</h5>
                                    </div>
                                </div>
                            </div>
                           
                        </div>
                    </div>
                    <div class="col-md-8 col-xs-12">
                        <div class="white-box " style="background-color: white !important;">
                            <h4  style="color: purple">
                                
                               <span class="visible-xs"><i class="fa fa-user"></i></span> <strong>Profile</strong role="presentation">
                                <br><br>
                            
                            </h4>
                            
                                
                            
                                    <form class="form-horizontal form-material">
                                        <div class="form-group">
                                            <label class="col-md-12">Full Name</label>
                                            <div class="col-md-12">
                                                <input type="text" readonly=true value="{{Auth::user()->name}}" class="form-control form-control-line">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="example-email" class="col-md-12">Email</label>
                                            <div class="col-md-12">
                                                <input type="text" readonly=true value="{{Auth::user()->email}}" class="form-control form-control-line">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-12">Role Assign</label>
                                            <div class="col-md-12">
                                                 <input type="text" readonly=true value="{{Auth::user()->roles ?Auth::user()->roles->name :""}}" class="form-control form-control-line">
                                               
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-12">Status</label>
                                            <div class="col-md-12">
                                                <p class="text-muted">
                                                @if(Auth::user()->status==1)         
                                                <div class="label label-success">
                                                    <strong>Active</strong>
                                                </div>       
                                                @else        
                                                <div class="label label-danger">
                                                    <strong>Deactive</strong>
                                                </div>                            
                                                @endif
                                                </p>
                                            </div>
                                        </div>
                                                                             
                                    </form>
                                                         
                            
                        </div>
                    </div>
                </div>
@endsection