@extends('layouts.app')
@section('title', 'Home Page')
@section('content')
<div class="container">
    <div class="row">
         <select name="publishers" class="col-md-2 select2 form-control" id="publisher" data-act="ajax-select"  data-post-text="concat(network_name,id_zone)" data-post-id="id_zone" data-post-key="network_name" data-post-table="ads" data-min-input="1" data-placeholder="Type to get Publishers" required></select>

          <select name="country" class="col-md-2 select2 form-control" id="country" data-act="ajax-select"  data-post-text="name" data-post-id="iso" data-post-key="name" data-post-table="country" data-min-input="1" data-placeholder="Type to get Publishers" required></select>
        

          <select name="user" class="col-md-2 select2 form-control" id="asd" data-act="ajax-select"  data-post-text="name" data-post-id="id" data-post-key="name" data-post-table="n_users" data-min-input="1" data-placeholder="Type to get Users" required></select>
        
        <select name="country" class="col-md-2 select2 form-control" id="campaign" data-act="ajax-select"  data-post-text="name" data-post-id="campaignid" data-post-key="name" data-post-table="campaigns" data-min-input="1" data-placeholder="Type to get campaigns" required></select>
        
            
       
    </div>
</div>
@endsection
