@extends('layouts.app')
@section('heading')
  Ip pools
@endsection
@section('custom_js')
<script type="text/javascript">
    $(document).ready(function(){
        $(document).ajaxStart(function(){
            $(".preloader").css("display", "block");
        });
        $(document).ajaxComplete(function(){
            $(".preloader").css("display", "none");
        });
        var col = [
                    'text_30px',
                    'text_40px',
                    'text_100px',
                    'text_70px',
                    'text_70px',
                    'text',                    
                 ];
        var data =   {!! json_encode($data1) !!};        
        createTableWithLazyLoad("#tableLazy",data,50,col);
    });   
       
  </script>
  @endsection
@section('content')
<div>
    <div class="m-b-15 header-panel-form">
        <div class="text-right">
        @php
        $heads =  [
                    "ID",
                    "name",
                    "ip",
                    "created",
                    "Updated",
                    "Actions"
                   ];
        @endphp
            <div class="text-left">
            {!!view('layouts.column', ['data' =>$heads])!!}
            <a href="/add-ip-pool" class="btn btn-success">Add</a>
            </div>
               
        </div>
    </div>
</div>
        <div class="col-sm-12">
                        <div class="table-responsive mainTableInfo">
                                <table class="table color-table info-table scrollTable lazy" id="tableLazy">
                                    
                                        {!!view('layouts.tableheadNew', ['data' =>$heads,'class'=>""])!!}
                                </table>
                        </div>               
                            
                           
    </div>


@endsection
