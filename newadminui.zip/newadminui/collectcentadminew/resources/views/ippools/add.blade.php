@extends('layouts.app')
@section('bread')
    <ol class="breadcrumb">
        <li><a href="#">Dashboard</a></li>
        <li class="active">Add Ip Pool</li>
    </ol>
@endsection
@section('heading')
   Add Ip Pool
@endsection
@section('custom_js')
<script src="{{asset('js/validator.js')}}"></script>
@endsection
@section('content')
    <div class="row">
          @if(Session::has('message'))
                <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('message') }}</p>
           @endif
          <div class="error text text-center center text-danger col-sm-12" style="text-align:center;">{{$errors??""}}</div>
                    <div class="col-sm-6">
                        <div class="white-box">
                            <form data-toggle="validator" method="POST" action="{{ url('add-ip-pool') }}">
                              {{ csrf_field() }}
                                <div class="form-group">
                                    <label for="inputName" class="control-label">Name *</label>
                                    <div class="form-group">
                                        <input type="text" name="name" class="form-control" placeholder="Name" value=""  required>
                                    </div>
                                    <div class="help-block with-errors"></div>
                                </div>
                                <div class="form-group">
                                    <label for="inputName" class="control-label">Ip Pool *</label>
                                    <div class="form-group">
                                    <textarea name="ip_pools" rows="10" class="form-control" placeholder="Please add ip pool" class="required">
                                    </textarea>
                                    </div>
                                    <div class="help-block with-errors"></div>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-success">Submit</button>
                                    <a href="/ip-pools" class="btn btn-danger">Cancel</a> 
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-sm-6 postback-url">
                          
                    </div>
                                        
    </div>
@endsection
