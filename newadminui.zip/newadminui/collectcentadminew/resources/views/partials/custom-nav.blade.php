<div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse">
                <ul class="nav" id="side-menu">
                    <li class="sidebar-search hidden-sm hidden-md hidden-lg">
                        <!-- input-group -->
                        <div class="input-group custom-search-form">
                            <input type="text" class="form-control" placeholder="Search...">
                            <span class="input-group-btn">
            <button class="btn btn-default" type="button"> <i class="fa fa-search"></i> </button>
            </span> </div>
                        <!-- /input-group -->
                    </li>
                    @foreach(Config::get('custommenu.all') as $key => $value)
                    <li> <a href="/{{$value['link']}}" class="waves-effect {{$value['class']}}"><i data-icon="F" class="linea-icon fa-fw fa {{$value['icon']}}" style="font-size: 20px"></i> <span class="hide-menu">{{$value['name']}}<span class="fa arrow"></span></span></a>
                        @if(count($value['child']) !=0)
                        <ul class="nav nav-second-level">
                            @foreach($value['child'] as $keyC => $valueC)
                                @if($valueC['target'] == 'true')
                                    <li> <a href="{{$valueC['link']}}" target="_blank">{{$valueC['name']}}</a> </li> 
                                @else 
                                    <li> <a href="/{{$valueC['link']}}">{{$valueC['name']}}</a> </li>
                                @endif 
                            @endforeach
                        </ul>
                        @endif
                    </li>
                    @endforeach
                </ul>
            </div>
        </div>
        <!-- Left navbar-header end -->