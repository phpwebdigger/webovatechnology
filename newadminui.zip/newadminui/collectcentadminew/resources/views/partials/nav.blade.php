<!-- Left navbar-header -->

        <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse">
                <ul class="nav" id="side-menu">
                    <li class="sidebar-search hidden-sm hidden-md hidden-lg">
                        <!-- input-group -->
                        <div class="input-group custom-search-form">
                            <input type="text" class="form-control" placeholder="Search...">
                            <span class="input-group-btn">
            <button class="btn btn-default" type="button"> <i class="fa fa-search"></i> </button>
            </span> </div>
                        <!-- /input-group -->
                    </li>
                         
                      @if(Session::get('roles')->name == "admin")
                    @foreach(Config::get('menu.all') as $key => $value)
                      <li> <a href="/{{$value['link']}}" class="waves-effect {{$value['class']}}"><i data-icon="F" class="linea-icon fa-fw fa {{$value['icon']}}" style="font-size: 20px"></i> <span class="hide-menu">{{$value['name']}}<span class="fa arrow"></span></span></a>
                        @if(count($value['child']) !=0 )
                        <ul class="nav nav-second-level">
                            @foreach($value['child'] as $keyC => $valueC)
                                @if(Session::get('roles')->name == "admin")
                                      @if($valueC['target'] == 'true')
                                         <li> <a href="{{$valueC['link']}}" target="_blank">{{$valueC['name']}}</a> </li> 
                                        @else 
                                         <li> <a href="/{{$valueC['link']}}">{{$valueC['name']}}</a> </li>
                                        @endif 
                                @elseif(in_array($keyC, explode(',',Session::get('roles')->permission)))
                                        @if($valueC['target'] == 'true')
                                         <li> <a href="{{$valueC['link']}}" target="_blank">{{$valueC['name']}}</a> </li> 
                                        @else 
                                         <li> <a href="/{{$valueC['link']}}">{{$valueC['name']}}</a> </li>
                                        @endif 
                                @endif

                                
                            @endforeach
                        </ul>
                        @endif
                    </li>
                    @endforeach
                          @elseif(Session::get('roles')->name == "report_manager")
                              @foreach(Config::get('menu_reportmanager.all') as $key => $value)
                      <li> <a href="/{{$value['link']}}" class="waves-effect {{$value['class']}}"><i data-icon="F" class="linea-icon fa-fw fa {{$value['icon']}}" style="font-size: 20px"></i> <span class="hide-menu">{{$value['name']}}<span class="fa arrow"></span></span></a>
                        @if(count($value['child']) !=0 )
                        <ul class="nav nav-second-level">
                            @foreach($value['child'] as $keyC => $valueC)
                                @if(Session::get('roles')->name == "report_manager")
                                      @if($valueC['target'] == 'true')
                                         <li> <a href="{{$valueC['link']}}" target="_blank">{{$valueC['name']}}</a> </li> 
                                        @else 
                                         <li> <a href="/{{$valueC['link']}}">{{$valueC['name']}}</a> </li>
                                        @endif 
                                @elseif(in_array($keyC, explode(',',Session::get('roles')->permission)))
                                        @if($valueC['target'] == 'true')
                                         <li> <a href="{{$valueC['link']}}" target="_blank">{{$valueC['name']}}</a> </li> 
                                        @else 
                                         <li> <a href="/{{$valueC['link']}}">{{$valueC['name']}}</a> </li>
                                        @endif 
                                @endif

                                
                            @endforeach
                        </ul>
                        @endif
                    </li>
                    @endforeach
                     @elseif(Session::get('roles')->name == "att_report_manager")

                              @foreach(Config::get('menu_att_reportmanager.all') as $key => $value)
                            
                      <li> <a href="/{{$value['link']}}" class="waves-effect {{$value['class']}}"><i data-icon="F" class="linea-icon fa-fw fa {{$value['icon']}}" style="font-size: 20px"></i> <span class="hide-menu">{{$value['name']}}<span class="fa arrow"></span></span></a>
                        @if(count($value['child']) !=0 )
                        <ul class="nav nav-second-level">
                            @foreach($value['child'] as $keyC => $valueC)
                                @if(Session::get('roles')->name == "att_report_manager")
                                      @if($valueC['target'] == 'true')
                                         <li> <a href="{{$valueC['link']}}" target="_blank">{{$valueC['name']}}</a> </li> 
                                        @else 
                                         <li> <a href="/{{$valueC['link']}}">{{$valueC['name']}}</a> </li>
                                        @endif 
                                @elseif(in_array($keyC, explode(',',Session::get('roles')->permission)))
                                        @if($valueC['target'] == 'true')
                                         <li> <a href="{{$valueC['link']}}" target="_blank">{{$valueC['name']}}</a> </li> 
                                        @else 
                                         <li> <a href="/{{$valueC['link']}}">{{$valueC['name']}}</a> </li>
                                        @endif 
                                @endif

                                
                            @endforeach
                        </ul>
                        @endif
                    </li>
                    @endforeach
                    @endif
                </ul>
            </div>
        </div>
        <!-- Left navbar-header end -->
