@extends('layouts.app')
@section('bread')
                        
@endsection

@section('heading')
  {{$header}}
@endsection


@section('custom_js')
<script src="../plugins/bower_components/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script type="text/javascript">
    jQuery('.mydatepicker').datepicker({
       format:"yyyy-mm-dd"
    });
    


</script>
@endsection

@php 
   
   $hour_format = array(0 => '00:00 - 01:00', 1 => '01:00 - 02:00', 2 => '02:00 - 03:00', 3 => '03:00 - 04:00', 4 => '04:00 - 05:00', 5 => '05:00 - 06:00', 6 => '06:00 - 07:00', 7 => '07:00 - 08:00', 8 => '08:00 - 09:00', 9 => '09:00 - 10:00', 10 => '10:00 - 11:00', 11 => '11:00 - 12:00', 12 => '12:00 - 13:00', 13 => '13:00 - 14:00', 14 => '14:00 - 15:00', 15 => '15:00 - 16:00', 16 => '16:00 - 17:00', 17 => '17:00 - 18:00', 18 => '18:00 - 19:00', 19 => '19:00 - 20:00', 20 => '20:00 - 21:00', 21 => '21:00 - 22:00', 22 => '22:00 - 23:00', 23 => '23:00 - 00:00');


  
  $hour_format_bg = array(0 => '#ccc', 1 => '#fff', 2 => '#ccc', 3 => '#fff', 4 => '#ccc', 5 => '#fff', 6 => '#ccc', 7 => '#fff', 8 => '#ccc', 9 => '#fff', 10 => '#ccc', 11 => '#fff', 12 => '#ccc', 13 => '#fff', 14 => '#ccc', 15 => '#fff', 16 => '#ccc', 17 => '#fff', 18 => '#ccc', 19 => '#fff', 20 => '#ccc', 21 => '#fff', 22 => '#ccc', 23 => '#fff');







@endphp


@section('content')
       <div class="m-b-15">
        <form class="form-inline" role="form" method="POST" action="{{route($routename)}}">
                        {{ csrf_field() }}    
            <input type="hidden" name="filter" id="filter" value="filter">

                            <input type="radio" <?php if($report_base==1){ echo "checked";  }?> name="report_base" value="1" id="report_base1" checked="checked"/>Current</td>
                              <td><input type="radio" <?php if($report_base==2){ echo "checked";  }?> name="report_base" value="2" id="report_base2"/>Previous




                                                <div class="form-group m-r-5">
                                                        
                                                        <div class="input-group">
                                                                <input type="text" value="{{$dtvalue}}" class="form-control mydatepicker" name="start" placeholder="From">
                                    
                                                        </div>
                                                </div>






                                                <div class="form-group m-r-5">
                                                       
                                                       <div class="input-group">
                                                                <input type="text" name="end" value="{{$dtvalue2}}" class="form-control mydatepicker" placeholder="To">
                                    
                                                        </div>
                                                </div>
                                                <div class="form-group m-r-5">
                                                  <select name="op_id[]" multiple id="op_id" class="col-md-2 mySelect form-control" data-placeholder="Select Operator">
                                                          <option value="-1">Select All Operator</option>
                                                          @foreach($opdata as $key => $value)
                                <option <?php if(in_array($key , $op_id)){ echo "selected"; } ?> value="{{$key}}">{{$value}}</option>
                                                          @endforeach
                                                        </select>
                                                </div>
                                                 <div class="form-group m-r-5">
                                                         
                                                        <select name="net_id[]" data-initial-id = "" id="net_id" class="col-md-2 select2  form-control" data-act="ajax-select"  data-post-text="name" data-preload="true" data-post-id="ccz" data-post-key="name" data-post-table="ad_network" data-min-input="2" data-placeholder="Network Name" multiple data-is-multiple="true" 

                                  data-initial-id="{{$net_id?implode(',',$net_id):''}}">
                                                           <option value="-1">Select All Network</option>
                                                        </select>
                                                </div>

                                                <div class="form-group m-r-5">
                              <select name="advertiser[]" id="advertiser" class="col-md-2 select2 form-control" data-act="ajax-select" data-post-text="name" data-preload="true" data-post-id="id" data-post-key="name" data-post-table="advertiser" data-min-input="2" data-placeholder="Select Advertiser" multiple data-is-multiple="true" data-initial-id="{{$advertiser?implode(',',$advertiser):''}}"> 
                                   

                                    <option value="-1">Select All Advertiser</option>
                                          </select>
                                                </div>

                                        <div class="form-groupm-r-5">
                                    <select class="col-md-2 select2 form-control" name="hour" id="hour"   data-preload="true" data-placeholder="Select hour"  >
                                        <option value="">Hour</option>
                                       @php foreach ($hour_format as $key => $val) {
                                     
                                         @endphp
                                    <option <?php if(in_array($key , $hour)) { echo "selected"; } ?> value="<?php echo $key; ?>"><?php echo $key; ?></option>
                                    
                                    @php
                                       }
                                      @endphp
                                     </select>     
                                        </div>   

                                <div class="form-group m-r-5">
                                <div class="input-group">
                                <input type="text" value="<?php echo $idadvt; ?>" class="form-control" name="idadvt" placeholder="Id Advt">
                                </div>
                                </div>  

                              <div class="form-group m-r-5">
                              <div class="input-group">
                              <input type="text"  class="form-control" name="Idad" placeholder="Id Ad" value="<?php echo $idad; ?>">
                              </div>
                              </div> 
                          <div class="form-group m-r-5">
                          <div class="input-group">
                          <input type="text" value="<?php echo $parent_cca; ?>" class="form-control" name="parent_cca" placeholder="parent cca">
                          </div>
                          </div>    

                          <div class="form-group m-r-5">
                          <select class="col-md-2 select2 mySelect form-control" name="select_group_by[]" id="gp"   data-preload="true" data-placeholder="Select Group By" multiple >
                         <option  <?php if(in_array('date' , $select_group_by)){ echo "selected"; } ?> value="date" >Group By Date</option>

                          <option <?php if(in_array('hour' , $select_group_by)){ echo "selected"; } ?> value="hour" >Group By Hour</option> 

                          <option <?php if(in_array('op_id' , $select_group_by)){ echo "selected"; } ?>  value="op_id">Group By Operator</option> 

                          <option <?php if(in_array('id_channel' , $select_group_by)){ echo "selected"; } ?>  value="id_channel">Group By Network</option> 

                          <option <?php if(in_array('id_advertiser' , $select_group_by)){ echo "selected"; } ?>  value="id_advertiser">Group By Advertiser</option> 

                      <option <?php if(in_array('id_advertiser_campaign' , $select_group_by)){ echo "selected"; } ?>  value="id_advertiser_campaign">Group By Id Advertiser</option>

                          <option  <?php if(in_array('id_ad' , $select_group_by)){ echo "selected"; } ?>  value="id_ad">Group By Id Ad</option>

                          <option <?php if(in_array('parent_cca' , $select_group_by)){ echo "selected"; } ?>   value="parent_cca">Group by Parent CCA</option> 



                          </select>     
                          </div>   




                                                <div class="form-group m-r-5">
                                                     <button type="submit" class="btn btn-success waves-effect waves-light">GO</button>
                                        
                                                @php
                                                  $heads =    ["Hour",
                                                    "Total Clicks",
                                                    "Conversion Inwards",
                                                    "Conversion Outwards",
                                                    "CR Inwards",
                                                    "CR Outwards",
                                                    "Total Cost"]
                                           @endphp

                                            
                                                       
                                                </div>
                                        </form>
                            </div>
    <div class="col-sm-12">
                    
                            
                            <div class="table-responsive mainTableInfo m-t-20">
                                <table class="table color-table info-table">
                                   
                                    <thead>
                                       <tr >
                                                    <th><b>Hour</b></th>


                                  
                            <?php  if($filter=="filter") { //echo $filter; ?>
                                                    <?php if($parent_cca!=''){?>
                                                    
                                                    <?php } else{?>
                                                    <th><b>Advertiser</b></th>
                                                    <?php if($gbad==0){?>
                                                    <th><b>id_ad</b></th>
                                                    <?php }?>
                                                    <?php }?>
                                                    <?php if($gbad==0){?>
                                                     <th><b>Parent CCA</b></th>
                                                   
                                                    <th><b>Telco</b></th>
                                                    <th><b>Network Name</b></th>
                                                     <?php }?>
                                                    <?php if($parent_cca!=''){?>
                                                    
                                                    <?php } else{?>
                                                      <?php if($gbad==0){?>
                                                    <th><b>Campaign name</b></th>
                                                      <?php }?>
                                                    <?php }?>
          <?php }else{  //echo $filter; die('99');//echo '<th colspan="5"></th>';
              }?>


                                                    <th><b>Total Clicks</b></th>
                                                    <th><b>Conversion Inwards</b></th>
                                                    <th><b>Conversion Outwards</b></th>
                                                    <th><b>CR Inwards</b></th>
                                                    <th><b>CR Outwards</b></th>
                                                    <th><b>Total Cost</b></th>

                                                </tr>

                                    </thead>
                                    <tbody>
                                    @php
                                      $tclickcount = 0;
                                      $tconversion_count = 0;
                                      $tclicks_active_count = 0;
                                      $ttotal_costv = 0;
                                    @endphp

                                    @foreach($data as $fetch_records)
                                        <tr>
                                            <td>{{$fetch_records->hour}}</td>

                           
                          

                          <?php if($filter=="filter") {?>
                          <?php if($parent_cca!=''){?>

                          <?php } else{?>
                          <td id="td2"  style="background:<?php if(!empty($fetch_records->hour)) { echo $hour_format_bg[$fetch_records->hour]; }?>" ><?php if(!empty($fetch_records->advertiser_name)){
                          echo $fetch_records->advertiser_name;                                                                                         
                          } 
                          ?></td> 

                          <?php if($gbad==0){?>
                          <td id="td2"  style="background:<?php if(!empty($fetch_records->hour)) { echo $hour_format_bg[$fetch_records->hour]; }?>"><?php 
                             if(!empty($fetch_records->id_ad)){  echo $fetch_records->id_ad; }?></td> 
                          <?php }?>


                          <?php }?>


                          <?php if($gbad==0){?>
                          <td id="td2"  style="background:<?php if(!empty($fetch_records->hour)){ echo $hour_format_bg[$fetch_records->hour];}?>"><?php echo $fetch_records->parent_cca; ?></td>  
                          <td id="td2"  style="background:<?php if(!empty($fetch_records->hour)){ echo $hour_format_bg[$fetch_records->hour];}?>"><?php if(!empty($fetch_records->op_name)) { echo $fetch_records->op_name; }?></td>

                          <td><?php  if(!empty($fetch_records->network_name)){ echo $fetch_records->network_name; }?></td>
                          <?php }?>


                          <?php if(isset($parent_cca) && $parent_cca!=''){?>

                          <?php } else{?>
                          <?php if($gbad==0){?>
                          <td><?php if(isset($fetch_records->advertiser_campain_name)){ echo $fetch_records->advertiser_campain_name;} else{ echo $fetch_records->id_advertiser_campaign;} ?></td>
                          <?php }?>
                          <?php }?>


                          <?php } else{ //echo '<td colspan="5"></td>';
                          }?>
            



                                            <td>{{$fetch_records->clickcount}}</td>
                                            <td>{{$fetch_records->conversion_count}}</td>
                                            <td>{{$fetch_records->clicks_active_count}}</td>
                                           
                                          
                                             <td> 
                                             @if($fetch_records->clickcount == 0)
                                             @else
                                              {{round(100*$fetch_records->conversion_count/$fetch_records->clickcount??1,2)}}%
                                             @endif
                                            </td>
                                         <td> 
                                           @if($fetch_records->clickcount == 0)
                                             @else
                                              {{round(100*$fetch_records->clicks_active_count/$fetch_records->clickcount??1,2)}}%
                                             @endif
                                        </td>
                                           <td>{{$fetch_records->total_costv}}</td>
                                         
                                        </tr>
                                        @php
                                          $tclickcount += $fetch_records->clickcount;
                                          $tconversion_count += $fetch_records->conversion_count;
                                      $tclicks_active_count += $fetch_records->clicks_active_count ;
                                      $ttotal_costv += $fetch_records->total_costv;

                                        @endphp
                                       @endforeach

                                       <tr class="bg-info text-white white-text">

                        
                                    <?php if ($filter=="filter") {?>
                                                   <?php if(isset($parent_cca) && $parent_cca!=''){?>
                                                    
                                                    <?php } else{?>
                                                     <?php if($gbad==0){?>
                                                   <td id="td1"></td>           
                                                    <td id="td1"></td>
                                                     <td id="td1"></td>
                                                     <?php }?>
                                                    <?php }?>
                                                     <?php if($gbad==0){?>
                                                    <td id="td1"></td>
                                                    <td id="td1"></td>
                                                     <?php }?>
                                                    <td id="td1"></td>
                                         <?php }else{ //echo '<td colspan="5"></td>';
                                                }?>
                       


                                         <td>Total</td>
                                         <td>{{$tclickcount}}</td>
                                         <td>{{$tconversion_count}}</td>
                                         <td>{{$tclicks_active_count}}</td>
                                         <td></td>
                                         <td></td>
                                         <td>{{$ttotal_costv}}</td>
                                         

                                       </tr>


                                    </tbody>

                                </table>
                                <b>@php  echo $NoResult;  @endphp</b>
                            </div>    
                                 
    </div>


@endsection
