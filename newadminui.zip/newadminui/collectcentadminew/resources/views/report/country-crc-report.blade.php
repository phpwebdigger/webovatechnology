@extends('layouts.app')
@section('bread')
                        
@endsection

@section('heading')
  {{$header}}
@endsection


@section('custom_js')
<script src="../plugins/bower_components/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script type="text/javascript">
    jQuery('.mydatepicker').datepicker({
       format:"yyyy-mm-dd"
    });
    $(document).ready(function() {

            var data =   {!! json_encode($data1) !!};        
           createTableWithLazyLoad("#tableLazy",data,50);
    });


</script>
@endsection
@section('content')
       <div class="m-b-15">
        <form class="form-inline" role="form" method="POST" action="{{route($routename)}}">
                        {{ csrf_field() }}    
                         <div class="form-group col-md-1">
                                                         
                                                    <input type="number" class="form-control" value="{{$total}}" name="total">
                                                </div>
                                                 
                                                <div class="form-group col-md-1">
                                                        
                                                        <div class="input-group">
                                                                <input type="text" value="{{$dtvalue}}" class="form-control mydatepicker" name="start" placeholder="From">
                                    
                                                        </div>
                                                </div>
                                                <div class="form-group col-md-1">
                                                       
                                                       <div class="input-group">
                                                                <input type="text" name="end" value="{{$dtvalue2}}" class="form-control mydatepicker" placeholder="To">
                                    
                                                        </div>
                                                </div>
                                                <div class="form-group col-md-2">
                                                     <button type="submit" class="btn btn-success waves-effect waves-light">GO</button>
                                        
                                                @php
                                                  $heads =    ["Parent cca",
                                                               "Network Name",
                                                               "Clicks Count",
                                                               "Conversion Inwards",
                                                               "Conversion Outwards",
                                                               "CR Inwards",
                                                               "CR Outwards",
                                                               "Unique Conversion",
                                                               "CR Goal",
                                                               "Source Cost $/Rs.",
                                                               "Revenue Rs.",
                                                               "Profit Rs."]
                                           @endphp

                                            {!!view('layouts.columnNew', ['data' => $heads])!!}
                                                       
                                                </div>
                                        </form>
                            </div>
    <div class="col-sm-12">
                       
                            
                            <div class="table-responsive mainTableInfo">
                                <table class="table color-table info-table scrollTable lazy" id="tableLazy">
                                    
                                        {!!view('layouts.tableheadNew', ['data' =>$heads,'class'=>""])!!}
                                       
                                           
                                    
                                </table>
                                

                            </div> 
</div>


@endsection
