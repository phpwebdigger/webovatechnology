@extends('layouts.app')
@section('bread')
                        
@endsection

@section('heading')
  {{$header}}
@endsection


@section('custom_js')
<script src="../plugins/bower_components/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script type="text/javascript">
    jQuery('.mydatepicker').datepicker({
       format:"yyyy-mm-dd"
    });
    


</script>
@endsection
@section('content')
       <div class="m-b-15">
        <form class="form-inline" role="form" method="POST" action="{{route($routename)}}">
                        {{ csrf_field() }}    
                                                                      
                                                <div class="form-group col-md-2">
                                                        
                                                        <div class="input-group">
                                                                <input type="text" value="{{$dtvalue}}" class="form-control mydatepicker" name="start" placeholder="From">
                                    
                                                        </div>
                                                </div>
                                                <div class="form-group col-md-2">
                                                       
                                                       <div class="input-group">
                                                                <input type="text" name="end" value="{{$dtvalue2}}" class="form-control mydatepicker" placeholder="To">
                                    
                                                        </div>
                                                </div>
                                                <div class="form-group col-md-2">
                                                @php
                                                  $optionArray=array("00","01","02","03","04","05","06","07","08","09","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24");
                                                @endphp
                                                  <select name="hours" id="hours" class="col-md-2 mySelect form-control" placeholder="Select Hours">
                                                          <option value="all">All Hours</option>
                                                          @foreach($optionArray as  $value)
                                                          <option {{$hours == $value ? "selected":""}} value="{{$value}}">{{$value}}</option>
                                                          @endforeach
                                                        </select>
                                                </div>
                                                 <div class="form-group col-md-2">
                                                    <select id="groupby" name="groupby" class="mySelect form-control">
                                                      <option value="">Group by None</option>
                                                      <option value="app_id" {{$groupby == "app_id"? 'selected':''}}>App Id</option>
                                                      <option value="hour" {{$groupby == "hour"? 'selected':''}}>Hour</option>
                                                      <option value="date" {{$groupby == "date"? 'selected':''}}>Date</option>
                                                  </select>
                                
                                                 </div>    

                                                <div class="form-group col-md-2">
                                                <select id="appserver" name="appserver" class="mySelect form-control">
                                                    <option value="">All Server</option>
                                                        @foreach(Config::get('collectcent.app_server') as $key => $value)
                                                                                                      
                                                    <option value="{{$key}}" {{$appserver == $key ? "selected":""}}>{{$value}}</option>
                                                    @endforeach
                                                </select> 
                                                </div>

                                                <div class="form-group col-md-2">
                                                     <button type="submit" class="btn btn-success waves-effect waves-light">GO</button>
                                        
                                                @php
                                                  $heads =  ["Date",
                                                                "AppServer",
                                                                "Hours",
                                                                "Clicks Count",
                                                                "Conversion Inwards",
                                                                "Last Updated Time"]
                                           @endphp

                                            {!!view('layouts.column', ['data' =>$heads])!!}
                                                       
                                                </div>
                                        </form>
                            </div>
    <div class="col-sm-12">
                    
                            
                            <div class="table-responsive mainTableInfo" style="margin-top:20px;">
                                <table class="table color-table info-table">
                                    
                                        {!!view('layouts.tablehead', ['data' =>$heads])!!}
                                    </thead>
                                   
                                  
                                    @foreach($data as $fetch_records)
                                    @php
                                        $id=str_split($fetch_records->id,8);

                                        $date=$id[0];
                                        $next1=str_split($id[1],2);

                                        $hours=$next1[0];
                                        $AppServer=$next1[1];
                                       
                                    @endphp
                                        <tr>
                                            <td>{{date('d-m-Y',strtotime($date))}}</td>
                                   
                                            <td>{{$AppServer}}</td>
                                            <td>{{$hours}}</td>
                                            <td>{{$fetch_records->clickcount}}</td>
                                           
                                          
                                             <td> {{ $fetch_records->conversioncount}}</td>
                                         <td> {{$fetch_records->updatetime}}</td>
                                           
                                        </tr>
                                       
                                       @endforeach
                                       
                                    </tbody>
                                </table>
                            </div>    
                                 
    </div>


@endsection
