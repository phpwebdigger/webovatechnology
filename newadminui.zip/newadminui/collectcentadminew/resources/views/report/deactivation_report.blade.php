@extends('layouts.app')
@section('bread')
                        
@endsection

@section('heading')
  {{$header}}
@endsection


@section('custom_js')
<script src="../plugins/bower_components/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script type="text/javascript">
    jQuery('.mydatepicker2').datepicker({
       format:"yyyy-mm-dd"
    });
jQuery(document).ready(function(){
  $("#tableList").DataTable({ 
            "aaSorting": [],
            "autoWidth": false,
            "pageLength": 50,
            "oLanguage": {
                "sLengthMenu": "_MENU_ "
            }
        });
});
    
    


</script>
@endsection

@php 
   
   $hour_format = array(0 => '00:00 - 01:00', 1 => '01:00 - 02:00', 2 => '02:00 - 03:00', 3 => '03:00 - 04:00', 4 => '04:00 - 05:00', 5 => '05:00 - 06:00', 6 => '06:00 - 07:00', 7 => '07:00 - 08:00', 8 => '08:00 - 09:00', 9 => '09:00 - 10:00', 10 => '10:00 - 11:00', 11 => '11:00 - 12:00', 12 => '12:00 - 13:00', 13 => '13:00 - 14:00', 14 => '14:00 - 15:00', 15 => '15:00 - 16:00', 16 => '16:00 - 17:00', 17 => '17:00 - 18:00', 18 => '18:00 - 19:00', 19 => '19:00 - 20:00', 20 => '20:00 - 21:00', 21 => '21:00 - 22:00', 22 => '22:00 - 23:00', 23 => '23:00 - 00:00');


  
  $hour_format_bg = array(0 => '#ccc', 1 => '#fff', 2 => '#ccc', 3 => '#fff', 4 => '#ccc', 5 => '#fff', 6 => '#ccc', 7 => '#fff', 8 => '#ccc', 9 => '#fff', 10 => '#ccc', 11 => '#fff', 12 => '#ccc', 13 => '#fff', 14 => '#ccc', 15 => '#fff', 16 => '#ccc', 17 => '#fff', 18 => '#ccc', 19 => '#fff', 20 => '#ccc', 21 => '#fff', 22 => '#ccc', 23 => '#fff');







@endphp


@section('content')
       <div class="m-b-15">
        <form class="form-inline" role="form" method="POST" action="{{route($routename)}}">
                        {{ csrf_field() }}    
            <input type="hidden" name="filter" id="filter" value="filter">


                                                 <div class="form-group ">
                                                        
                                                        <div class="input-group">
                                                                <input type="text"  style="width: 120px" value="{{$dtvalue}}" class="form-control mydatepicker2" name="from" placeholder="From">
                                    
                                                        </div>
                                                </div>
                                                 <div class="form-group ">
                                                       
                                                       <div class="input-group">
                                                                <input type="text" style="width: 120px" name="to" value="{{$dtvalue2}}" class="form-control mydatepicker2" placeholder="To">
                                    
                                                        </div>
                                                </div>
                                                 <div class="form-group col-md-1">
                                                        
                                                        <div class="input-group">
                                                               
                                                                 <input  class="form-control"  placeholder="Parent CCA" type="text" name='parent_cca' id="advtd"  value="<?php $parVal=$parent_cca; if(!empty($parent_cca)) {echo $parVal;}?>"></input>
                                    
                                                        </div>
                                                </div>
                                               
                                               
                                                <div class="form-group col-md-2">
                                                        <label class="control-label "></label> 
                                                        <select class="form-control full mySelect" name="advertiser_id[]" data-placeholder="Select Advertiser" multiple="multiple"  data-is-multiple = "true" id="advrtsr">
                                                            <option value="">All Advertiser</option>
                                                              <?php
                  $adAr=array();
                  if(sizeof($advertiser_id)>0){
                          foreach($advertiser_id as $key=>$val)
                    {
                      $adAr[]=$val;
                    }
                  }
                                                              foreach ($advertiser_dropdown as $ad_id => $ad_name) {
                    $advlsd='';
                    if(in_array($ad_id, $adAr)){ $advlsd='selected="selected"'; }
                                                                  echo "<option value='" . $ad_id . "' ".$advlsd.">" . $ad_name . "(" . $ad_id . ")</option>";
                                                              }
                                                            ?>
                                                 
                                                        </select>
                                                </div>
                                                <div class="form-group col-md-2">
                                                <select name='campaign[]' class="form-control full mySelect"  id="opcamp" data-placeholder="Select Operator" multiple="multiple"  data-is-multiple = "true" >
                                                            <option value="">All</option>
              <?php
                $opAr=array();
                if(sizeof($campaign)>0){
                        foreach($campaign as $key=>$val)
                  {
                    $opAr[]=$val;
                  }
                }
                                                            foreach ($campaign_dropdown as $c_id => $c_name) {
                  $opsld='';
                  if(in_array($c_id, $opAr)){ $opsld='selected="selected"'; }

                                                                echo "<option value='" . $c_id . "' ".$opsld.">" . $c_name . "</option>";
                                                            }
                                                            ?>
                                                        </select>
                                                </div>
                                                <div class="form-group col-md-2">
                                                <select name='operator_id[]' id="ntw" class="form-control full mySelect" data-placeholder="Select OperNetworkator" multiple="multiple"  data-is-multiple = "true" >
                                                <option value="">All </option>
                                                            <?php
                $ntAr=array();
                if(sizeof($operator_id)>0){
                        foreach($operator_id as $key=>$val)
                  {
                    $ntAr[]=$val;
                  }
                }
                //sort($operator_dropdown);
                                                            foreach ($operator_dropdown as $op_id => $op_name) {
                  $ntsld='';
                  if(in_array($op_name, $ntAr)){ $ntsld='selected="selected"'; }
                                                                echo "<option value='" . $op_name . "' ".$ntsld.">" . $op_name . "(" . $op_name . ")</option>";
                                                            }
                                                            ?>
                                                        </select> </div>
                                                         <div class="form-group col-md-2">
                                                <select  name="select_group_by[]" id="gp" class="form-control full mySelect" data-placeholder="Group By" multiple="multiple"  data-is-multiple = "true" >
                                               <?php
                $gpAr=array();
                if($select_group_by2 && sizeof($select_group_by2)>0){
                        foreach($select_group_by2 as $key=>$val)
                  {
                    $gpAr[]=$val;
                  }
                }
              ?>
                                                            <option value="">--Select--</option> 
                                                            <option value="summary_date" <?php if(in_array('summary_date', $gpAr)){ echo 'selected="selected"'; } ?>>Date</option> 
                                                            <option value="advertiser_name" <?php if(in_array('advertiser_name', $gpAr)){ echo 'selected="selected"'; } ?> >Advertiser</option> 
                                                            <option value="operator_name" <?php if(in_array('operator_name', $gpAr)){ echo 'selected="selected"'; } ?>>Operator</option> 
                                                            <option value="network_name" <?php if(in_array('network_name', $gpAr)){ echo 'selected="selected"'; } ?>>Network</option>
                                                            <option value="parent_cca" <?php if(in_array('parent_cca', $gpAr)){ echo 'selected="selected"'; } ?>>Parent CCA</option> 
                                                            </select></div>
                                                              <div class="form-group col-md-2">
                                                <select   name="select_order_by[]" id="or" class="form-control full mySelect" data-placeholder="Order By" multiple="multiple"  data-is-multiple = "true" >
                                              <?php
                $ordAr=array();
                if(!empty($select_order_by)){
                        foreach($select_order_by as $key=>$val)
                  {
                    $ordAr[]=$val;
                  }
                }
              ?>
                                                            <option value="">--Select--</option> 
                                                            <option value="summary_date" <?php if(in_array('summary_date', $ordAr)){ echo 'selected="selected"'; } ?>>Date</option> 
                                                            <option value="advertiser_name" <?php if(in_array('advertiser_name', $ordAr)){ echo 'selected="selected"'; } ?> >Advertiser</option> 
                                                            <option value="operator_name" <?php if(in_array('operator_name', $ordAr)){ echo 'selected="selected"'; } ?>>Operator</option> 
                                                            <option value="network_name" <?php if(in_array('network_name', $ordAr)){ echo 'selected="selected"'; } ?>>Network</option>
                                                            <option value="parent_cca" <?php if(in_array('parent_cca', $ordAr)){ echo 'selected="selected"'; } ?>>Parent CCA</option>
                                                            <option value="conCount" <?php if(in_array('conversion_count', $ordAr)){ echo 'selected="selected"'; } ?>>Total Conversions</option>
                                                            <option value="deCount DESC" <?php if(in_array('deactivation_count', $ordAr)){ echo 'selected="selected"'; } ?>>Total Deactivations</option>
                                                            <option value="falseCount DESC" <?php if(in_array('false_deactivation_count', $ordAr)){ echo 'selected="selected"'; } ?>>False Deactivation</option>
                                                        </select>
                                                    </div>



                                                <div class="form-group m-r-5">
                                                     <button type="submit" name="submit" value="submit" class="btn btn-success waves-effect waves-light">GO</button>
                                        
                                                @php
                                                  $heads =    ["Advertiser",
                                                   "Operator",
                                                   "URL Name",
                                                   "Network Name",
                                                   "Parent CCA",
                                                   "Conversions",
                                                   "20-Min Deactivations",
                                                   "20-Min Deactivation %",
                                                   "28-Hour Deactivations",
                                                   "28-Hour Deactivation %",
                                                   "False Deactivation",
                                                   "Date"]
                                           @endphp

                                            
                                                       
                                                </div>
                                        </form>
                            </div>
    <div class="col-sm-12">
                    
                            
                            <div class="table-responsive mainTableInfo m-t-20">
                                 <table class="table color-table info-table scrollTable lazy" id="tableList">
                                   
                                        {!!view('layouts.tablehead', ['data' =>$heads])!!}
                                    <tbody>
                                      @php
                                       $totalConv = 0;
        $totalDeac = 0;
        $totalDePer = 0;
        $falsePer = 0;
        $totaltwenty = 0;
        $twentyPer = 0;
        $x = 0;
                                           
                                    @endphp

                                    @if(sizeOf($data) !=0)
                                    @foreach($data as $fetch_records)
                                        <tr>
                                             <td>{{$fetch_records->advertiser_name}}
                                                            <td>{{$fetch_records->operator_name}}
                                                            <td>{{$fetch_records->url_name}}
                                                            <td>{{$fetch_records->network_name}}
                                                            <td><a href="site_wise_deactivation.php?pcca={{$fetch_records->parent_cca}}&camp_id={{$fetch_records->id_advertiser_campaign}}&dated={{$fetch_records->summary_date}}" target="_blank">{{$fetch_records->parent_cca}}</a></td>
                                                            <td>{{$fetch_records->conCount}}</td>
                                                            <td>{{$fetch_records->deCountTwenty}}</td>
                                                            @php
                                                                $tconv='';
                                                                $tdeconv='';
                                                                $tper='';
                                                                $col1='';
                                                                $tconv=$fetch_records->conCount;

                                                                $tdeconv=$fetch_records->deCountTwenty;
                                                                if($tconv != 0){
                                                                    $tper=($tdeconv/$tconv)*100;
                                                                }else{
                                                                     $tper = 0;
                                                                }
                                                                if($tper < 13)
                                                                {
                                                                    $col1='#008000';
                                                                }
                                                                elseif ($tper > 20)
                                                                {
                                                                    $col1='#ff0000';
                                                                }
                                                                else
                                                                {
                                                                    $col1='#ff8c00';
                                                                }
                                                            @endphp
                                                            <td style="color:{{$col1}}">{{number_format((float)$tper, 1, '.', '')}} %</td>
                                                            <td>{{$fetch_records->deCount}}</td>
                                                            <?php
                                                                $conv='';
                                                                $deconv='';
                                                                $per='';
                                                                $col2='';
                                                                $conv=$fetch_records->conCount;
                                                                $deconv=$fetch_records->deCount;
                                                                 if($conv != 0){
                                                                    $per=($deconv/$conv)*100;
                                                                }else{
                                                                    $per = 0;
                                                                }
                                                               
                                                                if($per < 13)
                                                                {
                                                                    $col2='#008000';
                                                                }
                                                                elseif ($per > 20)
                                                                {
                                                                    $col2='#ff0000';
                                                                }
                                                                else
                                                                {
                                                                    $col2='#ff8c00';
                                                                }
                                                                $falseSum=$fetch_records->falseCount+$fetch_records->falseTwenty;
                                                            ?>
                                                            <td style="color:{{$col2}}">{{number_format((float)$per, 1, '.', '')." %"}}</td>
                                                            <td><a href="#" style="text-decoration:none;" target="_blank">{{$falseSum}}</a></td>
                                                            <td>{{date('d-m-Y', strtotime($fetch_records->summary_date))}}</td>

                                         
                                        </tr>
                                        @php
        
              $totalConv = $totalConv + $fetch_records->conCount;
              $totalDeac = $totalDeac + $fetch_records->deCount;
              $totaltwenty = $totaltwenty + $fetch_records->deCountTwenty;
              $falsePer = $falsePer + $falseSum;
              //$totalDePer = $totalDePer + $per;
              $x++;
           
                                        @endphp
                                       @endforeach
                                   
                                           <tr>
                                             
            <?php 
            if (!$submit) {?>
                                                   <?php if(isset($pcca) && $pcca!=''){?>
                                                    
                                                    <?php } else{?>
                                                     <?php if($gbad==0){?>
                                                     <?php }?>
                                                    <?php }?>
                                                     <?php if($gbad==0){?>

                                                     <?php }?>

            <?php }else{ 
              }?>
                                                   
                                                   
                                                   <?php
                                                        
                                                        $totalDePer = ($totalDeac/$totalConv)*100;
                                                        $twentyPer = ($totaltwenty/$totalConv)*100;
                                                   ?>
                                                   
                                                   
                                                    <td id="td1"><strong>Total</strong></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td id="td1"><strong><?php echo  $totalConv; ?></strong></td>
                                                    <td id="td1"><strong><?php echo  $totaltwenty; ?></strong></td>
                                                    <td id="td1"><strong><?php echo  number_format((float)$twentyPer, 1, '.', '')." %"; ?></strong></td>
                                                    <td id="td1"><strong><?php echo  $totalDeac; ?></strong></td>
                                                    <td id="td1"><strong><?php echo  number_format((float)$totalDePer, 1, '.', '')." %"; ?></strong></td>
                                                    <td id="td1"><strong><?php echo  $falsePer; ?></strong></td>
                                                    <td></td>
                                                </tr>
                                                    @endif
<!-- current hours data end -->
                                    </tbody>
                                </table>
                              
                            </div>    
                                 
    </div>


@endsection
