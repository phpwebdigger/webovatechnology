@php

$date = date('Y-m-d');
$newdate = strtotime ( '-1 day' , strtotime ( $date ) ) ;
$newdate = date ( 'Y-m-d' , $newdate );
$newdate1 = strtotime ( '-2 day' , strtotime ( $date ) ) ;
$newdate1 = date ( 'Y-m-d' , $newdate1 );

@endphp

@extends('layouts.app')


@section('heading')
  Conversion Count Report
  
@endsection


@section('custom_js')
<script type="text/javascript">
  $(".mytable table").addClass("table").addClass("color-table").addClass("info-table");
      $( "#yesterday table tr:eq( 4 )" ).hide()
      $( "#yesterday table  tr:eq( 5 )" ).hide()
       
      $( "#ondayyesterday table tr:eq( 4 )" ).hide()
      $( "#ondayyesterday table  tr:eq( 5 )" ).hide()
</script>
@endsection
@section('content')
                                       
    <div class="col-sm-12">
                    
                            <div class="heading m-t-20"><b>Consversion ({{$date}})</b></div>
                            <div class="table-responsive mytable">
                            {!!file_get_contents("http://162.243.119.231:8080/Report.jsp")!!}
                            </div>
                          

                          <div class="heading m-t-20"><b>Consversion ({{$newdate}})</b></div>
                            <div class="table-responsive mytable" id="yesterday">
                             @php 
                              $report1 = "http://162.243.119.231:8080/Report".str_replace('-','',  $newdate);
                            @endphp
                            {!!file_get_contents($report1.".jsp")!!}
                            </div>


                            <div class="heading m-t-20"><b>Consversion ({{$newdate1}})</b></div>
                            <div class="table-responsive mytable" id="ondayyesterday">
                            @php 
                              $report2 = "http://162.243.119.231:8080/Report".str_replace('-','',  $newdate1);
                            @endphp
                            {!!file_get_contents($report2.".jsp")!!}
                            </div>
                            
    </div>


@endsection
