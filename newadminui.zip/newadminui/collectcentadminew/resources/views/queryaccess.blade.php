@extends('layouts.app')

@section('bread')
                        <ol class="breadcrumb">
                            <li><a href="#">Dashboard</a></li>
                            <li class="active">Query</li>
                        </ol>
@endsection

@section('heading')
  Query Access Log
@endsection



@section('content')
<div class="container-fluid">
                
                <div class="row">
                    
                    <div class="col-sm-12 ">
                        <div class="white-box">
                          
                            <div class="table-responsive">
                                <table class="table color-table success-table info-table">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Name</th>
                                            <th>Query</th>
                                          
                                             <th>Time</th>
                                            

                                        </tr>
                                    </thead>
                                    <tbody>
                                    @foreach ($QueryAccess as $Query)
                                        <tr>
                                            <td>{{$Query->id}}</td>
                                             <td>{{$Query->User->name}}</td>
                                            <td>{{$Query->query}}</td>
                                            <td>{{$Query->created_at}}</td>
                                        </tr>
                                     @endforeach
                                    </tbody>
                                </table>
                                <div class="pagination-wrapper"> {!! $QueryAccess->appends(['search' => Request::get('search')])->render() !!} </div>
                            </div>
                            </div>
                           
                        </div>
                    </div>
                    
                    
                    
                   
                
@endsection
