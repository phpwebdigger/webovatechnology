<div id="editUrl" class="modal fade"> <!-- class modal and fade -->
      
    <div class="modal-dialog modal-lg" style="margin-top: 15%">
        <div class="modal-content">
          
           <div class="modal-header"> <!-- modal header -->
            <button type="button" class="close" 
             data-dismiss="modal" aria-hidden="true">×</button>
             
                    <h4 class="modal-title">Campaign Update</h4>
           </div>
         <div id="message"></div>
     <div class="modal-body"> <!-- modal body --> 
     <form class="form-horizontal" role="form">
                  <div class="form-group col-sm-12">
                            <div class="row">
                                <div class="col-sm-2"><label for="id_ad">Country</label></div>
                                <div class="col-sm-10">  
                                    <input type="text" name="select_country" id="select_country" value="" readonly class="form-control  input-sm"/>
                                </div>
                            </div>
                        </div>
                          <div class="form-group col-sm-12">
                            <div class="row">
                                <div class="col-sm-2">
                                    <label for="adv_id">Operator</label>
                                </div> 
                                <div class="col-sm-10"> 
                                    <input type="text" name="select_operator" id="select_operator" readonly value="" class="form-control  input-sm"/>                            
                                 </div> 
                            </div>
                        </div>
                        <div class="form-group col-sm-12">
                            <div class="row">
                                <div class="col-sm-2">
                                    <label for="title">Category</label>
                                </div>
                                <div class="col-sm-10">
                                    <input type="text" name="select_category" id="select_category" readonly class="form-control input-sm" value=""/>
                                </div>
                            </div>    
                        </div>
                        <div class="form-group col-sm-12">
                            <div class="row">
                                <div class="col-sm-2">
                                    <label for="title">Advertiser Campaign</label>
                                </div>
                                <div class="col-sm-10">
                                    <input type="text" name="select_adv_camp" id="select_adv_camp" readonly value="" class="form-control input-sm"/>
                                </div>
                            </div>     
                        </div>
                        <div class="form-group col-sm-12">
                            <div class="row">
                                <div class="col-sm-2" style="float: left;">
                                    <label for="title">Waitage Percentage</label>
                                </div>
                                <div class="col-sm-8">    
                                    <input type="text" name="waitage_percentage" id="waitage_percentage" readonly value="" class="form-control col-sm-8 input-sm"/>
                                </div>
                            </div>    
                        </div>  
                        <div class="form-group col-sm-12">
                            <div class="row">
                                <div class="col-sm-2">
                                    <label for="operator_name">Offer url</label>
                                </div>
                                <div class="col-sm-10">
                                    <input type="text" name="url_offer" id="url_offer" value="" readonly class="form-control col-sm-10 input-sm"/>
                                </div>
                            </div>        
                        </div>
                        <div class="form-group col-sm-12">
                            <div class="row">
                                <div class="col-sm-2">
                                    <label for="is_smart">Is smart</label>
                                </div>
                                <div class="col-sm-10">
                                <input type="radio" name="is_smart" id="default_radio" value="DEFAULT" class="radiobox" class="form-control input-sm" checked="checked">
                                Default
                                <input type="radio" name="is_smart" id="is_smart_cpa" value="CPA" class="radiobox" class="form-control input-sm">
                                CPA 
                                <input type="radio" name="is_smart" id="is_smart_cpi" value="CPI" class="radiobox" class="form-control input-sm">
                                CPI 
                                <span id='spinner' style="display:none;">Processing.... </span>
                                </div>
                            </div>    
                        </div>
                        <div class="form-group col-sm-12">
                            <div class="row">
                                <div class="col-sm-2">
                                    <label for="select_id_advertiser">Advertiser Campaign Name </label>
                                </div>
                                <div class="col-sm-10" style="color:#000;"> 
                                    <select name="select_id_advertiser" id="select_id_advertiser" data-act=ajax-call class="form-control input-sm" data-live-search="true">
                                    {id_advertiser}
                                    </select>
                                </div>
                            </div>    
                        </div>
                        <div class="form-group col-sm-12">
                            <div class="row">
                                <div class="col-sm-2">
                                    <label for="url">URL </label>
                                </div>
                                <div class="col-sm-10">    
                                    <textarea rows="3" style="width: 625px;" resize:none type="text" id="url" readonly class="form-control input-sm">
                            </textarea>
                                 </div>
                            </div>                    
                        </div>
                        <input type="hidden" id="id" name="id">
                        </form>
     </div>
     
     <div class="modal-footer"> <!-- modal footer -->
       <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
      <button type="button" class="btn btn-primary" id="save_chanages">Update</button>
      </div>
                
      </div> <!-- / .modal-content -->
      
    </div> <!-- / .modal-dialog -->