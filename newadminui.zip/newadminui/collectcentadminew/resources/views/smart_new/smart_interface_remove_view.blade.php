@extends('layouts.app')
<meta name="csrf-token" content="{{ csrf_token() }}">
@section('custom_css')
<link rel="stylesheet" type="text/css" href="{{asset('plugins/bower_components/switchery/dist/switchery.min.css')}}" />
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/css/bootstrap-select.min.css">

@endsection
@section('bread')
@endsection
@section('heading')
  {{$title}}
@endsection
@section('custom_css')
<style type="text/css">
    .new_textbox{
        width: 40px;
    }
    .new_textbox2{
        width: 80px;
    }
</style>
@endsection
@section('custom_js')
   <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/js/bootstrap-select.min.js"></script>
<script type="text/javascript">
var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
  $(window).on('load',function(){ 
                $('#overlay').fadeOut();
            });
    $(document).ready(function(){


        var col = [   'text_74px',
                      '',
                      '',
                      '',
                      '',
                        'text_80px',
                        'text_40px',
                        'text_40px',     
                         "text_74px",
                        'text_80px',
                        "text_80px",
                        "text_80px",
                        "text_80px",
                        "text_80px",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "text_80px",
                        "text_80px",
                        "text_80px",
                        "text_700px",
                    ];
        var data =   {!! json_encode($data1) !!};     

        createTableWithLazyLoad("#tableLazy",data,250,col);

   $('.reset').click(function(){
         $('.selectpicker').val('');
          $('.selectpicker').selectpicker('refresh');
         // $('.selectpicker').get(0).selectedIndex = 1;

            $('.bg-primary').find("input").val("");
            $("input[type=text]").change();
            $("#tableLazy").dataTable().fnClearTable();
            $("#tableLazy").dataTable().fnDestroy();

            createTableWithLazyLoad("#tableLazy",data,50,col);
        });


             $('#search').click(function(){

                var campaign_id = $("#campaign_id").val();
                var id_channel = $("#id_channel").val();
                var operator_id = $("#operator_id").val();
                var traffic_type = $("#traffic_type").val();
                var country = $("#country").val();
                var smart_live = $("#smart_live").val();
                var offer_url = $("#offer_url").val();
                if(campaign_id == '' && id_channel == '' && operator_id == '' && traffic_type == '' && country=='' && smart_live=='' && offer_url==''){
                 alert('Please choose the any option');
                 return false;
                }
                $.ajax({
                    url: '/smart-interface-new/filterSmartinterfaceData',
                    type: 'POST',
                    cache: false,
                    async: true,
                    data: "action=getTrfcData&campaign_id="+campaign_id+"&id_channel="+id_channel+"&operator_id="+operator_id+"&traffic_type="+traffic_type+"&country="+country+"&smart_live="+smart_live+"&offer_url="+offer_url+"&_token="+CSRF_TOKEN,
                    beforeSend: function(res){
                       $("#overlay").show();
                    },
                    success: function(res){
                       $("#tableLazy").dataTable().fnClearTable();
                            $("#tableLazy").dataTable().fnDestroy();
                            $("#tableLazy").dataTable().fnDraw();
                        response = JSON.parse(res);
                        if(response.status == "1"){
                            $("#tableLazy").dataTable().fnClearTable();
                            $("#tableLazy").dataTable().fnDestroy();
                           
                            $("#tableLazy.new").remove();
                            createTableWithLazyLoad("#tableLazy",response.data,200,col);
                             // $("#tableLazy").dataTable().fnReloadAjax();

                        }else if(response.status == "2"){
                           $("#tableLazy").dataTable().fnClearTable();
                            $("#tableLazy").dataTable().fnDestroy();
                            $("#tableLazy").dataTable().fnDraw();
                           alert('Please search again there is no result');
                        }else{
                           $("#tableLazy").dataTable().fnClearTable();
                            $("#tableLazy").dataTable().fnDestroy();
                            alert('there is some error');
                            $("#tableLazy").dataTable().fnDraw();
                        }

                        $("#overlay").hide();
                    },
                    fail:function(err){
                      alert('Something went wrong');  
                      $("#overlay").hide();
                    },
                });
            });


        /* model functionality for waitage*/
        var flag = 0;
        $('#edit_waitage').change(function () {
            $("#waitage_time").prop("disabled", false).val('');
             flag = 0;
            if ($(this).val() == 'manual') {
                $("#waitage_time").prop("disabled", true);
                flag = 1;
            }
        });
       
       
       $("#update_type").click(function(){
            var msg2 = $("#errormsg_typ");
            var id = $("#waitage_id");
            var var1 = $("#edit_waitage option:selected").val();
            var var2 = $("#waitage_time option:selected").val();
            if(var1 == "WaitageType" ){
                msg2.html('<span class="alert alert-danger">Please select waitage type !</span>');
                return false;
            }
            if(var2 == "" && flag == 0){
                msg2.html('<span class="alert alert-danger">Please select waitage time !</span>');
                return false;
            }
            if(var1 !="WaitageType" && id.val() != ''){
                $.ajax({
                    url: "/smart-interface-WaitageTypeUpdate", // make sure you set an action attribute to your form
                    type: 'GET',
                    cache: false,
                    async: true,
                    dataType: 'JSON',
                    data: {'id': id.val(),'waitage_type': var1,'waitage_time': var2},
                    success: function(res){
                        var responseText = res; 
                        if(responseText.status == 3){
                            msg2.html('<span class="alert alert-danger">Oops, something went wrong!</span>');
                        }else if(responseText.status == 1){
                            msg2.html('<span class="alert alert-success">sucsessfully waitage updated!</span>');                                        
                                if($("#waitage_time option:selected").val() == ''){
                                    $('#waitage_type_'+id.val()).text($("#edit_waitage option:selected").val());
                                    $('#waitage_time_'+id.val()).text('');
                                }else{
                                    $('#waitage_type_'+id.val()).text($("#edit_waitage option:selected").val());
                                    $('#waitage_time_'+id.val()).text($("#waitage_time option:selected").val());
                                }
                                $('#EditWaitage').modal('hide');
                        }else if(responseText.status == 2){
                                    msg2.html('<span class="alert alert-info">Sorry please try again!</span>');                                        
                        }
                    }
                });
            }else{
                msg2.html('<span class="alert alert-danger">Oopss.. !!!</span>');
            }
        })

        

        $("#update_desktop").click(function(){
            var msgx = $("#errormsg_des");
            var id = $("#desk_id");
            if($("#edit_desk option:selected").val()=="Select Status"){
                msgx.html('<span class="alert alert-danger">Please select option !</span>');
                return false;
            }
            if($("#edit_desk option:selected").val()!="Select Status" && id.val() != ''){
                msgx.html('<span class="alert alert-info">Please wait.. !!!</span>');
                $.ajax({
                    url: "/smart-interface-desktop_update", // make sure you set an action attribute to your form
                    type: 'GET',
                    cache: false,
                    async: true,
                    dataType: 'JSON',
                    data: {'id': id.val(),'option_type': $("#edit_desk option:selected").val()},
                    success: function(responseText){
                        if(responseText == 3){
                                msgx.html('<span class="alert alert-danger">Oops, something went wrong!</span>');
                        }else if(responseText == 1){
                                msgx.html('<span class="alert alert-success">sucsessfully waitage updated!</span>');                                        
                            if($("#edit_desk option:selected").val() == '0'){
                                $('#is_desktop_status_'+id.val()).text('Mobile');
                            }
                            else if($("#edit_desk option:selected").val() == '1'){
                                $('#is_desktop_status_'+id.val()).text('Desktop');
                            }
                            else if($("#edit_desk option:selected").val() == '2'){
                                $('#is_desktop_status_'+id.val()).text('Both');
                            }
                            $('#EditDesktop').modal('hide');
                        }else if(responseText == 2){
                                msgx.html('<span class="alert alert-info">Sorry please try again!</span>');                                        
                        }
                    }
                });
                
            }else{
                msgx.html('<span class="alert alert-danger">Oopss.. !!!</span>');
            }
        });


        
    });
        //edit url magaemnet
        var advertiser_campaign_option = '';
            $(document).on('click','.change-campaign', function(){
                var id_ad = $(this).attr('data-value');
                var smart_trfc_config_id = $(this).attr('data-smart_id');
              
                // console.log(smart_trfc_config_id);
                var divId = $(this).attr('id');
                var id = 0;
                $('#msg').html("");
                divId  = divId.split("-");
                if(divId.length > 1){
                    id = divId[1];
                } 
                if(id_ad > 0){
                    $.ajax({
                        url : 'smart-interface/getUrlDataSmart',
                        type: 'GET',
                        async: true,
                        cache: false,
                        data: "id="+id_ad,
                        // beforeSend: function() {
                        //     $("#overlay").show();
                        //     $(".preloader").show();
                        // },    
                        }).done(function (response) {
                        $(".preloader").hide();      
                        var res = JSON.parse(response);
                        var data = res;
                        if(data){
                            console.log(data);
                            advertiser_campaign_option = '';

                             $("#id").val(id_ad);
                             $("#country").val(data.country_name);
                             $("#select_operator").val(data.op_id);
                             $("#select_category").val(data.category);
                             $("#select_adv_camp").val(data.Advertiser_Campaign_name);
                             $("#waitage_percentage").val(data.waitage_percentage);
                             $("#url_offer").val(data.url_offer);
                            $(data.advertiser_campaigns).each(function(key,campaign){
                                advertiser_campaign_option += '<option value="'+campaign.id+'"">('+campaign.id+')'+campaign.name+'</option>';
                            });
                            $("#id_advertiser").html(advertiser_campaign_option).selectpicker('refresh');
                            $('#editUrl').modal({backdrop:'static'});
                            $("#div_id").val(id);
                            $("#smart_trfc_config_id").val(smart_trfc_config_id);
                          
                        }else if(response.status == 2){
                             alert('There is something went wrong');
                        }else{
                            alert('response failed');
                        }
                        $("#overlay").hide();
                        $(".preloader").hide();      
                    }).fail(function () {
                            alert('Data could not be loaded.');
                            $("#overlay").hide();
                            $(".preloader").hide();
                    });
                }
             });   
            //
    $(".radiobox").click(function(){
    var is_selected = $(this).attr('checked', true);
    var is_smart = $(this).val();
    var advertiser_campaign;
    if(is_smart == 'DEFAULT'){
       $("#id_advertiser").html(advertiser_campaign_option).selectpicker('refresh');
    }else{
    if(is_selected && is_smart){
        $("#spinner").show();
        $.ajax({
            url : '/urls/getCpiCpa/',
            type: 'GET',
            async: true,
            data: "is_smart="+is_smart
        }).done(function (response){
            if(response.status==1){
                $(response.advertiser_campaign).each(function(key,campaign){
                    advertiser_campaign += '<option value="'+campaign.id+'"">'+campaign.name+'</option>';
                });
               $("#spinner").hide();
               $("#id_advertiser").html(advertiser_campaign).selectpicker('refresh');
            }
            // $('#editUrl').modal({backdrop:'static'});
        }).fail(function () {
                alert('Data could not be loaded.');
                $("#spinner").hide();
        });
    }
    }        
});
    //update url function
    $("#save_chanages").click(function(){
     var id_advertiser = $('#id_advertiser').val();
     var id = $("#id").val();
     var offer_url = $("#url").val().trim(); 
     if(offer_url == '')
     {
        alert('URL should not blank !');
        return false;
     }
     $.ajax({
        url: '/smart-interface-new/UpdateCampaignurl/',
        data : { id:id,id_advertiser: id_advertiser,url:offer_url},
        success: function(response){  // Get the result and asign to each cases
         // console.log(response);
          var response = JSON.parse(response);
           if(response.status == 0){
          alert(response.message);
        }else if(response.status == 1){
             alert(response.message);
             // console.log(response);
            $("#adv_cmp_id_"+id).html('');
            $("#name_id_"+id).html('');
            $("#name_id_"+id).attr('');
            $("#url_id_"+id).attr('');
            $("#url_id_"+id).html('');
           // $('#editUrl').find('form')[0].reset();
             $('#editUrl').modal('hide');
           $("#adv_cmp_id_"+id).html(response.return_campaign_id);
           $("#name_id_"+id).attr('title',response.return_name);
           $("#name_id_"+id).html(response.return_name+'('+response.return_campaign_id+')');
           $("#url_id_"+id).attr('title',response.return_offer_url);
           $("#url_id_"+id).html(response.return_offer_url);
           
        }else if(response.status == 2){
          alert('<span class="alert alert-info">Problem while Tracking</span>');                                        
        }
       
       }
    });             
   
    });

    $(document).on("click",".cancel-fields",function(){
        var container_id = $(this).attr('data-id');
        var waitage_percentage = $(this).attr('data-val');
        $("#"+container_id).html(waitage_percentage);
    });

    $('.alert-dismissable').fadeOut();

    function EditPercent(id,camp_id,value,action){
        var msg = $("#errormsg_rm_st");
            if(id !='' && camp_id && value != 'undefined'){
            $("#waiting_percentage_temp1_"+id).removeClass("fa fa-edit");
            $("#waiting_percentage_"+id).html('<input type="text" id="waiting_percentage_temp_'+id+'" class="new_textbox" value="'+value+'"><br/><a id="waiting_percentage_temp_but_'+id+'" href="javascript:void(0);" class="pad5"><i class="glyphicon glyphicon-ok"></i></a>|<a href="javascript:void(0)" class="pad5"><span class="glyphicon glyphicon-remove cancel-fields" data-id="waiting_percentage_'+id+'" data-val="'+value+'"></span></a>');
            $("#waiting_percentage_temp_"+id).focus();
            $("#waiting_percentage_temp_but_"+id).click(function (){
                var temp_val = $("#waiting_percentage_temp_"+id);
                var waitage_percent = temp_val.val();
                if(temp_val.val() == value){
                    alert('Please change the value first');
                    return false;
                }
                if(temp_val.val()==""){
                    msg.html('<span class="alert alert-danger">Please enter % value</span>');
                    return false;
                }
                if(temp_val.val()!="" && id !=""){
                    msg.html('<span class="alert alert-info">Please wait !!!</span>');
                $.ajax({
                        url: "/smart-interface-percent_update", // make sure you set an action attribute to your form
                        type: 'GET',
                        cache: false,
                        async: false,
                        data: 'id='+id+'&waitage_percent='+waitage_percent,
                        success: function(response){
                            var res = JSON.parse(response);
                                if(res.status == 3){
                                msg.html('<span class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">x</button><strong>Failed</strong>Oops, something went wrong!</span>');
                                }else if(res.status == 1){
                                msg.html('<span class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert">x</button><strong>Success</strong>Successfully percentage updated</span>');
                                $('#waiting_percentage_'+id).text(temp_val.val());    
                                $("#waiting_percentage_temp1_"+id).addClass("fa fa-edit");
                                }else if(res.status == 2){
                                msg.html('<span class="alert alert-info alert-dismissable">Sorry please try again!</span>');                                        
                                }
                            }
                        });
                    }
                });
            }
    }   

    function EditDesktop(id,st){
        var msg1 = $("#errormsg_des");
        msg1.html('');
        if(id){
            $("#desk_id").val(id);
            document.getElementById('edit_desk').value='Select Status';
            $('#EditDesktop').modal({
                backdrop: 'static',
                keyboard: false,  // to prevent closing with Esc button (if you want this too)
                show: true
            });
        }
    }

    function EditStatus(id,campaign_id,is_live){
        var msg1 = $("#errormsg_rm_st");
        msg1.html('<span class="alert alert-info">Please wait!!!</span>');
        if(is_live == 1){
            is_live = 0;
        }else{
            is_live = 1;
        }
        if(id){
            $.ajax({
                url: "/smart-interface-livestatus_update", // make sure you set an action attribute to your form
                type: 'GET',
                cache: false,
                async: true,
                dataType: 'JSON',
                data: {'id':id,'is_live':is_live,'campaign_id':campaign_id},
                success: function(response){
                    var res = response; 
                    if(res.status == 3){
                    msg1.html('<span class="alert alert-danger">'+res.message+'</span>');
                    }else if(res.status == 1){
                        msg1.html('<span class="alert alert-success">'+res.message+'</span>');      
                        if($('#smart_live_'+id).text() == "Live"){
                            $('#smart_live_'+id).text("NotLive");
                            $('#smart_live_temp_'+id).css({'color':'#F05355'});
                        }else{
                            $('#smart_live_'+id).text("Live");
                            $('#smart_live_temp_'+id).css({'color':'#32CEA7'});
                        }
                        $('#smart_live_temp_'+id).attr("onclick",'EditStatus('+id+','+campaign_id+','+is_live+')');    
                        msg1.html('');
                    }else if(res.status == 2){
                        alert(res.message);
                        msg1.html('');                                        
                    }
                }
            });
        }
    }

    function EditFraud(id,st){
        var msg1 = $("#errormsg_rm_st");
        msg1.html('<span class="alert alert-info">Please wait!!!</span>');
        if(st == 1){
          status_live = 0;
        }else{
          status_live = 1;  
        }
        if(id){
            $.ajax({
                url: "/smart-interface-edit-fraud_update", // make sure you set an action attribute to your form
                type: 'GET',
                cache: false,
                async: true,
                dataType: 'JSON',
                data: {'id': id,'status':st},
                success: function(response){
                    var res = response;
                    if(res.status == 3){
                    msg1.html('<span class="alert alert-danger">'+res.message+'</span>');
                    }else if(res.status == 1){
                    msg1.html('<span class="alert alert-success">'+res.message+'</span>');      
                        if($('#is_fraud_'+id).text() == "True"){
                        $('#is_fraud_'+id).text("False");
                        $('#is_fraud_temp_'+id).css({'color':'#F05355'});
                        }else{
                        $('#is_fraud_'+id).text("True");
                        $('#is_fraud_temp_'+id).css({'color':'#32CEA7'});
                        }
                        $('#is_fraud_temp_'+id).attr("onclick",'EditFraud('+id+','+status_live+')');    
                    msg1.html('');
                    }else if(res.status == 2){
                        msg1.html('<span class="alert alert-info">'+res.message+'</span>');                                        
                    }
                }
            });
        }
    }    


    /* To remove campaign from smart table */ 
    function RemoveCamp(smartoperator_id,smart_status){
      var tableID=$('#tableLazy').DataTable();
      
        if(confirm("Are you sure?")){
            
            var items=document.getElementsByName('smart_status');
				var selectedItems="";
                                var j = 0;
                                var end = items.length;
				for(var i=0; i<items.length; i++){
                                    
					if(items[i].type=='checkbox' && items[i].checked==true)
						selectedItems+=items[i].value+",";
                                        
				}
                                selectedItems = selectedItems.trimRight(",");
                                var sillyString = selectedItems.slice(0, -1);
//                                alert(sillyString);
//                                var qry="DELETE FROM abc where id IN ("+sillyString+")";
                                var selectedItems2 = sillyString.split(',');
//                                var arr = new Array("Java","PHP","Ruby");
//                                var str = selectedItems.join();
//				alert(selectedItems2);
//				alert(qry);
                                var msg = $("#errormsg_rm_st");
        msg.html('<span class="alert alert-info">Please wait!!!</span>');   
        // var row =  $(this).parentNode.parentNode;
//        $(this).parent().parent().remove();
        if(sillyString !== ''){
//            alert(qry);
            $.ajax({
                url: "/smart-interface-new-smartstatus_update_remove", // make sure you set an action attribute to your form
                type: 'GET',
                cache: false,
                async: true,
                data: {'smartoperator_id':selectedItems2},
                success: function(response){
                     var res = JSON.parse(response);
                    if(res.status == 3){
                            msg.html('<span class="alert alert-danger">'+res.message+'</span>');
                    }else if(res.status == 1){
                            msg.html('<span class="alert alert-success">'+res.message+'</span>');                                        
//                        $("#tableLazy").dataTable().fnReloadAjax();
                        window.location.href=window.location.href;
                    }else if(res.status == 2){
                            msg.html('<span class="alert alert-info">'+res.message+'</span>');                                        
                    }
                }
            });
          }
            
        
        }
    }  



    function EditWaitage(id,typ){
        var msg2 = $("#errormsg_typ");
        msg2.html('');    
        if(id){
            $("#waitage_id").val(id);
            document.getElementById('waitage_time').value='';
            if(typ =='auto'){
                $("#waitage_time").prop("disabled", false);
                document.getElementById('edit_waitage').value=typ;
                $('#EditWaitage').modal({
                    backdrop: 'static',
                    keyboard: false,  // to prevent closing with Esc button (if you want this too)
                    show: true
                });
            }else if(typ ==''){
                $("#waitage_time").prop("disabled", false);
                document.getElementById('edit_waitage').value='WaitageType';
            $('#EditWaitage').modal({
                    backdrop: 'static',
                    keyboard: false,  // to prevent closing with Esc button (if you want this too)
                    show: true
                });
            }else{
                document.getElementById('edit_waitage').value=typ;
                $("#waitage_time").prop("disabled", true);            
                $('#EditWaitage').modal({
                    backdrop: 'static',
                    keyboard: false,  // to prevent closing with Esc button (if you want this too)
                    show: true
                });
            }
        }
    } 

    function EditClick(id,value){
        var msg_click = $("#errormsg_rm_st");
        if(id){
            $("#cap_count_click_temp1_"+id).removeClass("fa fa-edit");
            $("#cap_count_click_"+id).html('<input type="text" id="cap_count_click_temp_'+id+'" class="new_textbox2"><a id="cap_count_click_temp_but_'+id+'" href="javascript:void()"class="pad5"><i class="glyphicon glyphicon-ok"></i></a><a href="javascript:void(0)" class="pad5"><span class="glyphicon glyphicon-remove cancel-fields" data-id="cap_count_click_'+id+'" data-val="'+value+'"></span></a>');
            $("#cap_count_click_temp_but_"+id).focus();
            $("#cap_count_click_temp_but_"+id).click(function (){
                var temp_val = $("#cap_count_click_temp_"+id);
                if(value == temp_val.val()){
                    alert('Please change the value first');
                }
                if(temp_val.val()==""){
                    msg_click.html('<span class="aleinterfacert alert-danger">Please enter click count value</span>');
                return false;
                }
                if(temp_val.val()!="" && id !=""){
                    msg_click.html('<span class="alert alert-info">Please wait !!!</span>');
                    $.ajax({
                            url: "/smart-interface-click_update", // make sure you set an action attribute to your form
                            type: 'GET',
                            cache: false,
                            async: true,
                            dataType: 'HTML',
                            data: {'id': id,'click_count':temp_val.val()},
                            success: function(responseText){
                                if(responseText == 3){
                                    msg_click.html('<span class="alert alert-danger">Oops, something went wrong!</span>');
                                }else if(responseText == 1){
                                    msg_click.html('<span class="alert alert-success">Sucsessfully click count updated!</span>');
                                    $('#cap_count_click_'+id).text(temp_val.val());    
                                    $("#cap_count_click_temp1_"+id).addClass("fa fa-edit");
                                }else if(responseText == 2){
                                    msg_click.html('<span class="alert alert-info">Sorry please try again!</span>');                                        
                                }
                            }
                        });
                    }
                });
            }
    }       

        function EditConversion(id,con_count){
            var msg_conversion = $("#errormsg_rm_st");
            if(id){
                $("#cap_count_conversions_temp1_"+id).removeClass("fa fa-edit");
                $("#cap_count_conversions_"+id).html('<input type="text" id="cap_count_conversions_temp_'+id+'" class="new_textbox2"> | <button id="cap_count_conversions_temp_but_'+id+'"><i class="fa fa-check"></i></button> ');
                $("#cap_count_conversions_temp_but_"+id).focus();
                $("#cap_count_conversions_temp_but_"+id).click(function (){
                    var temp_val = $("#cap_count_conversions_temp_"+id);
                        if(temp_val.val()==""){
                            msg_conversion.html('<span class="alert alert-danger">Please enter conversion count value</span>');
                            return false;
                        }
                        if(temp_val.val()!="" && id !=""){
                            msg_conversion.html('<span class="alert alert-info">Please wait !!!</span>');
                            $.ajax({
                                url: "/smart-interface-conversion_update", // make sure you set an action attribute to your form
                                type: 'GET',
                                cache: false,
                                async: true,
                                dataType: 'HTML',
                                data: {'id': id,'conversion_count':temp_val.val()},
                                success: function(responseText){
                                    if(responseText == 3){
                                        msg_conversion.html('<span class="alert alert-danger">Oops, something went wrong!</span>');
                                    }else if(responseText == 1){
                                        msg_conversion.html('<span class="alert alert-success">Sucsessfully conversion count updated!</span>');
                                        $('#cap_count_conversions_'+id).text(temp_val.val());    
                                        $("#cap_count_conversions_temp1_"+id).addClass("fa fa-edit");
                                    }else if(responseText == 2){
                                        msg_conversion.html('<span class="alert alert-info">Sorry please try again!</span>');                                        
                                    }
                                }
                            });
                        }
                    });
                }
            }   

         
     

  </script>

<script src="{{asset('plugins/bower_components/switchery/dist/switchery.min.js')}}" type="text/javascript"></script>
<script src="{{asset('js/validator.js')}}"></script>

@endsection

@section('content')
    <div class="m-b-15 header-panel">
        <div class="form-group">
            <div id="errormsg_rm_st" style="margin-top:1%;text-align:center;"></div>
        </div>
    </div>
  <div >
    <div class="m-b-15 header-panel-form">
              <form class="form-inline" role="form" id="smart_interface_form" method="POST" action="{{route('smartInternewfaceViewFilter')}}">
                        {{ csrf_field() }}    
                                               <div class="form-group  hide">
                                                   
                                                </div>
                                                <div class="form-group">
                                                    <input type="number" class="form-control" value="{{ ($campaign_id!='')?$campaign_id:$campaign_id }}" name="campaign_id" id="campaign_id" placeholder="campaign id" >
                                                </div>
                                                 <div class="form-group "> 
                                                    <select name='id_channel' data-preload="true"  data-actions-box="true" 
                                                     class="col-md-2  selectpicker form-control" id="id_channel" data-live-search="true">
                                                       <option value="">Select Network</option>
                                                       @foreach ($netData as $network_id => $network_name)
                                                       <option value="{{$network_id}}" {{$network_id == $id_channel ? "selected":""}} >{{$network_name}}</option>
                                                       @endforeach
                                                     </select>
                                                </div>
                                                <div class="form-group "> 
                                                       <select name="operator_id" class="selectpicker  form-control"  id="operator_id" data-live-search="true">
                                                   <option value="">Select Operator</option>
                                                   
                                                    @foreach ($opdata as $opdata_id => $opdata_name)
                                                       <option value="{{$opdata_id}}"  
                                                       @if($selected_operator_id) 
                                                       {{ $opdata_id==$selected_operator_id ? "selected":"" }}  
                                                       @endif
                                                       > {{$opdata_name}}</option>
                                                       @endforeach
                                                  </select>
                                                </div>
                                                <div class="form-group ">
                                                        <label class="control-label "></label> 
                                        <select class="form-control full selectpicker" name="traffic_type" id="traffic_type" data-live-search="true">
                                            <option value="">All Ad Category</option>
                                            <option value="A" @if($traffic_type){{'A' == $traffic_type ? "selected":""}} @endif>A</option>
                                            <option value="B"  @if($traffic_type){{'B' == $traffic_type ? "selected":""}}@endif>B</option>
                                            <option value="C"  @if($traffic_type){{'C' == $traffic_type ? "selected":""}}@endif>C</option>
                                            <option value="I"  @if($traffic_type){{'I' == $traffic_type ? "selected":""}}@endif>I</option>
                                            <option value="D"  @if($traffic_type){{'D' == $traffic_type ? "selected":""}}@endif>D</option>
                                            <option value="IG" @if($traffic_type){{'IG' == $traffic_type ? "selected":""}}@endif>IG</option>
                                            <option value="WM" @if($traffic_type){{'WM' == $traffic_type ? "selected":""}}@endif>WM</option>
                                            <option value="WG" @if($traffic_type){{'WG' == $traffic_type ? "selected":""}}@endif>WG</option>
                                            <option value="SM" @if($traffic_type){{'SM' == $traffic_type ? "selected":""}}@endif>SM</option>
                                            <option value="SG" @if($traffic_type){{'SG' == $traffic_type ? "selected":""}}@endif>SG</option>
                                            <option value="OM" @if($traffic_type){{'OM' == $traffic_type ? "selected":""}}@endif>OM</option>
                                 
                                        </select>
                                                </div>
                                                 <div class="form-group">
                                                        <label class="control-label "></label> 
                                                        <select class="form-control full selectpicker" name="country" id="country" data-live-search="true">
                                                            <option value="">Select Country</option>
                                                           @foreach ($countrydata as $contdata_id => $contdata_name)
                                                       <option value="{{$contdata_id}}" @if($country){{$country == $contdata_id ? "selected":""}}@endif >{{$contdata_name}}</option>
                                                       @endforeach
                                                 
                                                        </select>
                                                </div>
                                                <div class="form-group">
                                                <select class="form-control selectpicker" name="smart_live" id="smart_live">
                                                   <option value=''>Select Status</option>
                                                    <option value="0" @if($smart_live_vale){{($smart_live_vale=='0')?"selected":""}}@endif>Not Live</option>
                                                    <option value="1" @if($smart_live_vale){{($smart_live_vale=='1')?"selected":""}}@endif>Live</option>
                                                </select>
                                                </div>
                                            <!--     <div class="form-group">
                                                <select class="form-control" name="smart_status">
                                                  <option value="">Select Smart Status</option>
                                                    <option value="0" @if($smart_status){{1 == $smart_status ? "selected":""}}@endif>Not Active</option>
                                                    <option value="1"  @if($smart_status){{1 == $smart_status ? "selected":""}}@endif>Active</option>
                                                </select>
                                                </div> -->
                                                    <div class="form-group">
                                                <input type="url" name="offer_url" id="offer_url" value="" placeholder="Offer url Serach">
                                                </div>
                                                 <div class="form-group">
                                                     <!-- <button type="submit" class="btn btn-success waves-effect waves-light">Submit</button> -->
                                                      <a href="javascript:void(0);" id="search" class="btn btn-danger">Search</a>
                                                </div>
                                                 <div class="form-group">
                                                   <a href="javascript:void(0)" class="btn btn-warning reset">Reset</a>
                                                </div> 
            @php
                $heads =  [ "id",
                            "Campaign Id",
                            "Action",
                            "Add New",
                            "Smart Status",
                            "Name",                                                                
                            "Waitage %",
                            "Ads Category",
                            "Country",
                            "Operator",
                            "URL",
                            "Waitage Type",
                            "Waitage Time",
                            "Click Count",
                            "Conversions Count",
                            "Live Status",
                            "Start Date",
                            "End Date",       
                            "Exclude Network",
                            "Include Network",
                            "Exclude SiteId",
                            "Include SiteId",
                            "Exclude Browser",
                            "Include Browser",
                            "Exclude OS",
                            "Include OS",
                            "Exclude Referrer",
                            "Include Referrer",
                            "Desktop/Mobile",
                           
                            "Is Fraud",
                            
                           ];
            @endphp
            <div class="pad10">
            <div class="form-group">
                                            
            </div>
            <a href="smart-interface-add"><button type="button" class="btn btn-primary waves-effect waves-light">Add New</button></a>
            {!!view('layouts.column', ['data' =>$heads])!!}
            <a href="javascript:void(0);" onclick='RemoveCamp()'><button type="button" class="btn btn-primary waves-effect waves-light">Remove</button></a>
            
            </div>
          
            </div>
            </form>
        <div class="table-responsive mainTableInfo">
            <table class="table color-table info-table scrollTable lazy" id="tableLazy">
                {!!view('layouts.tableheadNew', ['data' =>$heads,'class'=>""])!!}
            </table>
            <table>

            </table>
   @include('smart_new.editUrl')
        </div> 
                           
    </div>
<!--Edit Desktop/Mobile-->
<div class="modal fade" id="EditDesktop" role="dialog">
    <div class="modal-dialog bd-example-modal-sm" style="margin-top: 15%">    
    <!-- Modal content-->
        <div class="modal-content col-sm-12">
            <div class="modal-header modal-header1">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title" style="text-align: center">Edit Desktop/Mobile</h4>
            </div>
            
            <div id="errormsg_des" style="text-align: center;margin-bottom:20px; margin-top: 4%;"></div>
            
            <input type="hidden" id ="desk_id" name="desk_id"  class="form-control">
            
            <div class="row">
                <div class="col-sm-6" style="margin-top: 2%;">
                    <label class="control-label">Change</label>
                </div>
                <div class="col-sm-6" style="margin-top: 2%;">
                    <div class="form-group">
                        <select name="edit_desk" id="edit_desk" class="form-control" >
                            <option value="Select Status">Select Option</option>
                            <option value="0">Mobile</option>
                            <option value="1">Desktop</option>
                            <option value="2">Both</option>
                            
                        </select>
                    </div>
                </div>
                
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-info" id="update_desktop">Update</button>
            </div>
      </div>      
    </div>
</div>


<!--Edit Waitage Modal-->
<div class="modal fade" id="EditWaitage" role="dialog">
    <div class="modal-dialog bd-example-modal-sm" style="margin-top: 15%">    
    <!-- Modal content-->
        <div class="modal-content col-sm-12">
            <div class="modal-header modal-header1">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title" style="text-align: center">Edit Waitage Type</h4>
            </div>
            
            <div id="errormsg_typ" style="text-align: center;margin-bottom:20px; margin-top: 4%;"></div>
            
            <input type="hidden" id ="waitage_id" name="waitage_id"  class="form-control">
            
            <div class="row">
                <div class="col-sm-6" style="margin-top: 2%;">
                    <label class="control-label">Waitage Type</label>
                </div>
                <div class="col-sm-6" style="margin-top: 2%;">
                    <div class="form-group">
                        <select name="edit_waitage" id="edit_waitage" class="form-control" >
                            <option value="WaitageType">Select Type</option>
                            <option value="auto">Auto</option>
                            <option value="manual">Manual</option>
                            
                        </select>
                    </div>
                </div>
                
            </div>
            <div class="row">
                <div class="col-sm-6" style="margin-top: 2%;">
                    <label class="control-label">Waitage Time</label>
                </div>
                <div class="col-sm-6" style="margin-top: 2%;">
                    <div class="form-group">
                        <select id="waitage_time" class="form-control" name="waitage_time">
                            <option value="">Waitage Time</option>
                            <option value="0">0</option>
                            <option value="15">15</option>
                            <option value="30">30</option>
                            <option value="45">45</option>
                            <option value="60">60</option>
                        </select>
                    </div>
                </div>
                
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-info" id="update_type">Update</button>
            </div>
      </div>      
    </div>
</div>

@endsection
