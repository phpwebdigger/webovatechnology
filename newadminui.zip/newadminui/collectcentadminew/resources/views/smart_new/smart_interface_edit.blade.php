@extends('layouts.app')
@section('custom_css')
<link rel="stylesheet" type="text/css" href="{{asset('plugins/bower_components/switchery/dist/switchery.min.css')}}" />
@endsection
@section('bread')
Smart Interface / Edit Campaign
@endsection
@section('heading')
 Smart Interface Edit 
@endsection
@section('custom_js')
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.6/moment.min.js"></script><script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.37/js/bootstrap-datetimepicker.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/css/bootstrap-datetimepicker.min.css"></script>
<script type="text/javascript">
    $('.mydatepickers').datetimepicker({
        format: 'YYYY-MM-DD HH:mm:ss'
    });
    
    $(document).ready(function() {
        var flag = 0;
        var id = $('#id');
        var waitage_perce = $('#waitage_perce');
        var cap_conversion_count = $('#cap_conversion_count');
        var cap_click_count = $('#cap_click_count');
        var start_datetime = $('#start_datetime');
        var end_datetime = $('#end_datetime');
        var exclude_network = $('#exclude_network');
        var include_network = $('#include_network');
        var exclude_siteid = $('#exclude_siteid');
        var include_siteid = $('#include_siteid');
        var exclude_browser = $('#exclude_browser');
        var include_browser = $('#include_browser');
        var exclude_os = $('#exclude_os');
        var include_os = $('#include_os');
        var exclude_referrer = $('#exclude_referrer');
        var include_referrer = $('#include_referrer');
        var campaign_id = $('#campaign_id');
        var is_offer = $("#is_offer").val();
    
    if($('#waitage_type').val()=='manual'){
        $("#waitage_time").prop("disabled", true); 
        flag = 1;
        $("#waitage_time").val('');
    }else{
        $("#waitage_time").prop("disabled", false);
        flag = 0;
    }

    $('#waitage_type').change(function () {
        if($(this).val() == 'manual'){
            $("#waitage_time").prop("disabled", true);
            $("#waitage_time").val('');
            flag = 1;
        }else if($(this).val() == 'WaitageType') {
            $("#waitage_time").prop("disabled", false);
            flag = 0;
        }else{
            $("#waitage_time").prop("disabled", false);
            flag = 0;
            $("#waitage_time").val('');
        }
    });
        
        $("#editCampaignForm").validator();
        $("#editCampaignForm").on("submit",function(e){
            if(!e.isDefaultPrevented()){
            var msg = $('#errormsg'); // Get the msg result div
            msg.html('<span class="alert alert-info">Please wait !!!!</span>');
                $.ajax({
                    url: "/smart-interface-update", // make sure you set an action attribute to your form
                    type: 'GET',
                    async: true,
                    dataType: 'JSON',
                    contentType : 'application/json',
                    data: $("#editCampaignForm").serialize(),
                        success: function(response){
                            var result = response;
                        if(result.status == 3){
                            msg.html('<span class="alert alert-danger">'+result.message+'</span>');
                        }
                        else if(result.status == 1){
                            msg.html('<span class="alert alert-success">'+result.message+'</span>');
                            if(is_offer == 1){
                            window.location = '/offerwall'; 
                            }else{
                            window.location = '/smart-interface-new';
                            }
                        }else if(result.status == 2){
                                msg.html('<span class="alert alert-info">'+result.message+'</span>');
                        }
                        msg.html(data);
                        return false;
                    },
                });
                return false;
                }
            });
        
        }); // document end here 
  
    function getOperator(){
      var msg = $('#errormsg');
      var countryCode = $("#country").val();
        var content = "concat(name,'-',country_code)";
            msg.html('<span class="alert alert-info">Please wait!</span>');
            $.ajax({
                url: "/setect2/fetch", // make sure you set an action attribute to your form
                type: 'POST',
                async: true,
                dataType: 'JSON',
                data: 'condition=country_code,=,'+countryCode+'&id=id&key=name&table=operator&text='+content,
                success: function(responseText){ 
                    msg.html('');
                    if(responseText.results){
                        $("#select_operator").html("");
                        $('#select_operator').append($("<option></option>").attr("value","").text("Select operator"));
                        $('#select_operator').append($("<option></option>").attr("value","0").text("All Operator"));
                        $('#select_operator').append($("<option></option>").attr("value","33").text("Country Wifi default"));   
                        $('#select_operator').append($("<option></option>").attr("value","-1").text("Wifi Default"));        
                        $.each(responseText.results, function(key,value){
                            $('#select_operator').append($("<option></option>").attr("value",value.id).text(value.text)); 
                        })
                    }
                }
            });
    }
 </script>
 <script src="{{asset('plugins/bower_components/switchery/dist/switchery.min.js')}}" type="text/javascript"></script>
 <script src="{{asset('js/validator.js')}}"></script>
@endsection
@section('content')
    <div class="row">
        <div class="col-sm-12">
            <div class="white-box">                            
                <form data-toggle="validator" method="GET" id="editCampaignForm">
                      {{ csrf_field() }}
                      <div id="errormsg" style="text-align: center;margin-bottom:20px;"></div>
                    <div class="row">
                        <div class="col-sm-3">
                            <label class="control-label">Id<span style="color: #F05355">*</span></label>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <input title="{{  $data['id']  }}" type="text" id= "id" name="id" value="{{  $data['id']  }}" class="form-control" readonly required>
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>
                        <div class="col-sm-1">
                            <div class="form-group" style="text-align: center;"></div>
                        </div>
                        <div class="col-sm-2">
                            <label class="control-label">Name <span style="color: #F05355">*</span></label>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <input title="{{ $data['name'] }}" type="text" id= "adv_name" name="adv_name" value="{{ $data['name'] }}" class="form-control" readonly required>
                                <div class="help-block with-errors"></div>  
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-3">
                            <label class="control-label">Url<span style="color: #F05355">*</span></label>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <input title="{{ $data['url'] }}" type="text" id= "url" name="url" value="{{ $data['url'] }}" class="form-control" readonly required>
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>
                        <div class="col-sm-1">
                            <div class="form-group" style="text-align:center;"></div>
                        </div>
                        <div class="col-sm-2">
                            <label class="control-label">CPA <span style="color: #F05355">*</span></label>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <input title="{{ $data['cpa'] }}" type="text" id= "url" name="url" value="{{ $data['cpa'] }}" class="form-control" readonly required>
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-3">
                            <label class="control-label">Country<span style="color: #F05355">*</span></label>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <select name="country" id="country" class="form-control select2" required onchange="getOperator()">
                                    <option value="">Select Country</option>
                                    @foreach($country_data as $key => $country)
                                        <option value="{{$country->iso}}" {{$data['country_code'] == $country->iso ? "selected":""}}>{{$country->name}}({{$country->iso}})</option>
                                    @endforeach
                                </select>
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>    
                        <div class="col-sm-1">
                            <div class="form-group" style="text-align:center;"></div>
                        </div>
                        <div class="col-sm-2">
                            <label class="control-label">Operator <span style="color: #F05355">*</span></label>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <select name="operator" id="select_operator" class="form-control select2" required>
                                   <option value="">Select Operator</option>
                                   <option value="0" {{ $data['op_id'] == 0 ? "selected":""}}>All Operator</option>
                                   <option value="33" {{ $data['op_id'] == 33 ? "selected":""}}>Country Wifi default</option>
                                   <option value="-1" {{ $data['op_id'] == -1 ? "selected":""}}>Wifi Default</option>
                                    <option value="-2" {{ $data['op_id'] == -2 ? "selected":""}}>Both</option>
                                    @foreach($operator_data as $key => $operator)
                                        <option value="{{$operator->id}}" {{ $data['op_id'] == $operator->id ? "selected":""}}>
                                        {{$operator->name}}({{$operator->country_code}})
                                        </option>
                                    @endforeach
                                </select>
                                 <div class="help-block with-errors"></div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-3">
                            <label class="control-label">Category<span style="color: #F05355">*</span></label>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                            <select name="category" id="select_category" class="form-control" required>
                                   <option value="Select Category">Select Category</option>
                                   <option value="A" {{$data['ads_cat'] == 'A' ? "selected":""}}>A</option>
                                   <option value="B" {{$data['ads_cat'] == 'B' ? "selected":""}}>B</option>
                                   <option value="C" {{$data['ads_cat'] == 'C' ? "selected":""}}>C</option>
                                   <option value="D" {{$data['ads_cat'] == 'D' ? "selected":""}}>D</option>
                                   <option value="I" {{$data['ads_cat'] == 'I' ? "selected":""}}>I</option>
                                   <option value="IG" {{$data['ads_cat'] == 'IG' ? "selected":""}}>IG</option>
                                   <option value="WM" {{$data['ads_cat'] == 'WM' ? "selected":""}}>WM</option>
                                   <option value="WG" {{$data['ads_cat'] == 'WG' ? "selected":""}}>WG</option>
                                   <option value="OM" {{$data['ads_cat'] == 'OM' ? "selected":""}}>OM</option>
                                   <option value="OG" {{$data['ads_cat'] == 'OG' ? "selected":""}}>OG</option>
                            </select>
                             <div class="help-block with-errors"></div>
                            </div>
                        </div> 
                          
                        <div class="col-sm-1">
                            <div class="form-group" style="text-align: center;"></div>
                        </div>
                        
                        <div class="col-sm-2">
                            <label class="control-label">Waitage Percentage <span style="color:#F05355">*</span></label>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <input type="text" id= "waitage_percentage" name="waitage_percentage" value="{{ $data['waitage_percentage'] }}" class="form-control" required> 
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-3">
                         <label class="control-label">Waitage Type<span style="color: #F05355">*</span></label>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <select name="waitage_type" id="waitage_type" class="form-control" required>
                                    <option value="manual">Manual</option>
                                    <option value="auto" {{$data['waitage_type'] == 'auto' ? "selected":""}}>Auto</option>
                                </select>
                            </div>
                        </div> 
                          
                        <div class="col-sm-1">
                            <div class="form-group" style="text-align:center;"></div>
                        </div>
                        
                        <div class="col-sm-2">
                            <label class="control-label">Waitage Time<span style="color:#F05355">*</span></label>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <select name="waitage_time" id="waitage_time" class="form-control">
                                   <option value="">Select Waitage Time</option>
                                   <option value="0" {{ $data['waitage_time'] == '0' ? "selected":""}}>0</option>
                                   <option value="15" {{ $data['waitage_time'] == '15' ? "selected":""}}>15</option>
                                   <option value="30" {{ $data['waitage_time'] == '30' ? "selected":""}}>30</option>
                                   <option value="45" {{ $data['waitage_time'] == '45' ? "selected":""}}>45</option>
                                   <option value="60" {{ $data['waitage_time'] == '60' ? "selected":""}}>60</option>
                                </select>
                            </div>
                        </div>  
                    </div>
                    <div class="row">
                        <div class="col-sm-3">
                            <label class="control-label">Cap Conversion Count <span style="color:#F05355">*</span></label>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <input title="{{ $data['cap_count_conversions'] }}" type="text" id= "cap_count_conversions" name="cap_count_conversions" value="{{ $data['cap_count_conversions'] }}" class="form-control">
                            </div>
                        </div>    
                        <div class="col-sm-1">
                            <div class="form-group" style="text-align:center;"></div>
                        </div>
                        <div class="col-sm-2">
                            <label class="control-label">Cap Click Count <span style="color:#F05355">*</span></label>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <input title="{{ $data['cap_count_click'] }}" type="text" id= "cap_click_count" name="cap_count_click" value="{{ $data['cap_count_click'] }}" class="form-control" required>
                                <div class="help-block with-errors"></div>
                            </div>
                        </div>
                        
                    </div>
                    <div class="row">
                        <div class="col-sm-3">
                            <label class="control-label">Start Datetime</label>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <input title="{{ $data['start_date'] }}" type="text" id= "start_datetime" name="start_datetime" value="{{ $data['start_date'] }}" class="form-control mydatepickers">
                            </div>
                        </div>    
                        <div class="col-sm-1">
                            <div class="form-group" style="text-align:center;"></div>
                        </div>
                        <div class="col-sm-2">
                            <label class="control-label">End Datetime</label>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <input title="{{ $data['end_date'] }}" type="text" id= "end_datetime" name="end_datetime" value="{{ $data['end_date'] }}" class="form-control mydatepickers">
                            </div>
                        </div>
                        
                    </div>
                    <div class="row">
                        <div class="col-sm-3">
                            <label class="control-label">Exclude Network</label>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <input title="" type="text" id= "exclude_network" name="exclude_network" value="@if(isset($excludes->network)) {{$excludes->network}} @endif" class="form-control">
                            </div>
                        </div>    
                        <div class="col-sm-1">
                            <div class="form-group" style="text-align: center;"></div>
                        </div>
                        <div class="col-sm-2">
                            <label class="control-label">Include Network</label>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <input title="" type="text" id= "include_network" name="include_network" value="@if(isset($includes->network)){{$includes->network}} @endif"  class="form-control">
                            </div>
                        </div>
                        
                    </div>
                    <div class="row">
                        <div class="col-sm-3">
                            <label class="control-label">Exclude SiteId </label>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <input title="" type="text" id= "exclude_siteid" name="exclude_siteid" value="@if(isset($excludes->site_id)){{$excludes->site_id}} @endif" class="form-control">
                            </div>
                        </div>    
                        <div class="col-sm-1">
                            <div class="form-group" style="text-align: center;"></div>
                        </div>
                        <div class="col-sm-2">
                            <label class="control-label">Include SiteId </label>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <input title="" type="text" id= "include_siteid" name="include_siteid" value="@if(isset($includes->site_id)){{$includes->site_id}} @endif" class="form-control">
                            </div>
                        </div>
                        
                    </div>
                    <div class="row">
                        <div class="col-sm-3">
                            <label class="control-label">Exclude Browser </label>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <input title="" type="text" id= "exclude_browser" name="exclude_browser" value="@if(isset($excludes->browser)){{$excludes->browser}} @endif" class="form-control">
                            </div>
                        </div>    
                        <div class="col-sm-1">
                            <div class="form-group" style="text-align: center;"></div>
                        </div>
                        <div class="col-sm-2">
                            <label class="control-label">Include Browser </label>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <input title="" type="text" id= "include_browser" name="include_browser" value="@if(isset($includes->browser)){{$includes->browser}} @endif" class="form-control">
                            </div>
                        </div>
                        
                    </div>
                    <div class="row">
                        <div class="col-sm-3">
                            <label class="control-label">Exclude OS </label>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <input title="" type="text" id= "exclude_os" name="exclude_os" value="@if(isset($excludes->os)){{$excludes->os}} @endif" class="form-control">
                            </div>
                        </div>    
                        <div class="col-sm-1">
                            <div class="form-group" style="text-align: center;"></div>
                        </div>
                        <div class="col-sm-2">
                            <label class="control-label">Include OS </label>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <input title="" type="text" id= "include_os" name="include_os" value="@if(isset($includes->os)){{$includes->os}} @endif" class="form-control">
                            </div>
                        </div>
                        
                    </div>
                    <div class="row">
                        <div class="col-sm-3">
                            <label class="control-label">Exclude Referrer </label>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <input title="" type="text" id= "exclude_referrer" name="exclude_referrer" value="@if(isset($excludes->referrer)){{$excludes->referrer}} @endif " class="form-control">
                            </div>
                        </div>    
                        <div class="col-sm-1">
                            <div class="form-group" style="text-align: center;"></div>
                        </div>
                        <div class="col-sm-2">
                            <label class="control-label">Include Referrer</label>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <input title="" type="text" id= "include_referrer" name="include_referrer" value="@if(isset($includes->referrer)){{$includes->referrer}} @endif" class="form-control">
                            </div>
                        </div>
                        
                    </div>
                    <div class="row">
                        <div class="col-sm-3">
                            <label class="control-label">Smart Status <span style="color: #F05355">*</span></label>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <div class="form-group">
                                <select name="smart_status" id="smart_status" class="form-control" >
                                   <option value="SelectStatus">Select Status</option>
                                   <option value="1" {{$data['smart_status'] == 1 ? "selected":""}}>Active</option>
                                   <option value="0" {{$data['smart_status'] == 0 ? "selected":""}}>Inactive</option>
                                </select>
                            </div>
                            </div>
                        </div>
                        <div class="col-sm-1">
                            <div class="form-group" style="text-align: center;"></div>
                        </div>
                        <div class="col-sm-2">
                            <label class="control-label">Applicable for:<span style="color: #F05355">*</span></label>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <select name="is_desktop" class="form-control">
                                <option value="0" @if($data['is_desktop'] == '0') "selected=selected" @endif>Mobile</option>
                                <option value="1" @if($data['is_desktop'] == '1') "selected=selected" @endif>Desktop</option>
                                <option value="2" @if($data['is_desktop'] == '2') "selected=selected" @endif>Both</option> 
                                </select>
                            </div>
                        </div>
                    </div>    
                    <div class="row">    
                        <div class="col-sm-12 text-right">
                            <div class="form-group">
                                <input type="hidden" name="is_offer" id="is_offer" value="{{$is_offer}}">
                                <button type="submit" class="btn btn-success" id="save">Update</button>
                                <a href="/smart-interface" class="btn btn-danger">Cancel</a>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
