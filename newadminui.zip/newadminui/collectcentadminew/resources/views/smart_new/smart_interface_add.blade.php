@extends('layouts.app')
@section('custom_css')
<link rel="stylesheet" type="text/css" href="{{asset('plugins/bower_components/switchery/dist/switchery.min.css')}}" />
<!--link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css"-->
@endsection

@section('heading')
  Smart Interface Add
@endsection
@section('custom_js')
<style type="text/css">
.listbox{width: 200px;}
</style>
<script type="text/javascript">
$(document).ready(function() {

    var all_adv_val = $("#all_adv_val");
    var all_country_val = $("#all_country_val");
    var all_opr_val = $("#all_opr_val");
    var all_advt_val = $("#select_advertiser");
   $("#select_adv_camp").selectpicker('refresh'); 
    
    $("#select_adv_camp option:selected").change(function() {
        all_adv_val.val($(this).val());
    });
    $("#select_country option:selected").change(function() {
        all_country_val.val($(this).val());
    });
    $("#select_operator option:selected").change(function() {
        all_opr_val.val($(this).val());
    });

    $("#select_operator").change(function(){

        var op_id= $(this).val();
 
            $.ajax({
            url: "/smart-interface-new-advertiser", 
            type: 'GET',
            cache: false,
            async: true,
            dataType: 'JSON',
            data: {'op_id': op_id},
            success: function(responseText){
                var result = responseText;
                 var list   = [];
                if(result){
                    list.push('<option value="">select campaign</option>');
                    $.each(result, function(key, value){

                        list.push('<option value="' + value.id + '" data-cat="'+ value.id +'">' + value.name +'('+ value.id +')' + '</option>');
                    });
                    $('#select_adv_camp').html(list.join(''));
                    $('#select_adv_camp').selectpicker('refresh');
                }else{
                    alert('There is no campaign available');
                }
            }
        });

    });

  $("#select_country").change(function() {
             $country_value= $("#select_country").val();

             $.ajax({
                url: '/smart-interface-new/getOps/',
                data : { country_value:$country_value},
                success: function(response){  // Get the result and asign to each cases
                var result = response;
                 var list   = [];
                if(result){
                    list.push('<option value="">select operator</option>');

                    $.each(result, function(key, value){
                        list.push('<option value="' + value.id + '" data-cat="'+ value.id +'">' + value.name+'('+value.country_code+')'+'</option>');
                    });
                    $('#select_operator').html(list.join(''));
                    $('#select_operator').selectpicker('refresh');
                }else{
                    alert('There is no operator available');
                }
               }
            });             
        });



    $("#select_advertiser").change(function() {
    $('#select_adv_camp').html('').selectpicker('refresh');
    // var all_country_val = $("#all_country_val");
    // var opr_list = $('#all_opr_val');
    // var cat_list = $('#select_category');
    var adv_list = $('#select_advertiser');
    var msg = $('#errormsg');
    msg.html('<span class="alert alert-info">Please wait!</span>');
        $.ajax({
            url: "/smart-interface-get-list", 
            type: 'GET',
            cache: false,
            async: true,
            dataType: 'JSON',
            data: {'adv_list':adv_list.val(),'status':'1'},
            success: function(responseText){
                msg.html('');
                var list   = [];
                var result = responseText;
                if(result.status == 1){
              
                    advertiser_campaign='<option value="">select campaign</option>';
                     $(result.data).each(function(key,campaign){
                    advertiser_campaign += '<option value="'+campaign.id+'"">'+campaign.name+'</option>';
                });
               $("#spinner").hide();
               $("#select_adv_camp").html(advertiser_campaign).selectpicker('refresh');
                   
                }else{
                    alert('There is no campaign available');
                }
            }
        });
    });

     $(".radiobox").click(function(){
    var is_selected = $(this).attr('checked', true);
    var is_smart = $(this).val();
    var advertiser_campaign;
    if(is_smart == 'DEFAULT'){
       //$("#select_adv_camp").html(advertiser_campaign).selectpicker('refresh');
       var op_id= $("#op_id_data").val();
            $.ajax({
            url: "/smart-interface-new-advertiser", 
            type: 'GET',
            cache: false,
            async: true,
            dataType: 'JSON',
            data: {'op_id': op_id},
            success: function(responseText){
                var result = responseText;
                 var list   = [];
                if(result){
                    list.push('<option value="">select campaign</option>');
                    $.each(result, function(key, value){
                        list.push('<option value="' + value.id + '" data-cat="'+ value.id +'">' + value.name +'('+key+')'+'</option>');

                    });
                    $('#select_adv_camp').html(list.join(''));
                    $('#select_adv_camp').selectpicker('refresh');
                }else{
                    alert('There is no campaign available');
                }
            }
        });
    }else{
    if(is_selected && is_smart){
        $("#spinner").show();

        $.ajax({
            url : '/urls/getCpiCpa/',
            type: 'GET',
            async: true,
            data: "is_smart="+is_smart
        }).done(function (response){
            if(response.status==1){
                $(response.advertiser_campaign).each(function(key,campaign){
                    advertiser_campaign += '<option value="'+campaign.id+'"">'+campaign.name+'</option>';
                });
                $("#select_adv_camp").html(advertiser_campaign).selectpicker('refresh');
                $("#spinner").hide();
            }
            // $('#editUrl').modal({backdrop:'static'});
        }).fail(function () {
                alert('Data could not be loaded.');
                $("#spinner").hide();
        });
    }
    }        
});


    $('#select_adv_camp').change(function(){
        let Category = $("#select_adv_camp option:selected").attr("data-cat");
        $("#ads_cat").val(Category); 
    });

    $("#update_status").click(function (){
        var msg = $('#errormsg');  // Get the msg result div

        var cat_list = $('#select_category option:selected').val();
        var country =  $("#select_country option:selected").val();
        var operator = $("#select_operator option:selected").val();
        var $operator_name = $("#select_operator option:selected").text();
        var waitage_percentage = $("#waitage_percentage").val();
        var waitage_type = $("#waitage_type").val();
        var waitage_time = $("#waitage_time").val();
        var all_adv_val = $("#select_adv_camp option:selected").val();
        var smart_status = $("#smart_status").val();
        var offer_url = $("#url").val();

        if(operator.indexOf('33') > -1 && country == ""){
            msg.html('<span class="alert alert-danger">Please select country !</span>');
            return false;
        }
        if(operator == "" ){
            msg.html('<span class="alert alert-danger">Please select Operator !</span>');
            return false;
        }
        if(all_advt_val.val() == "" ){
            msg.html('<span class="alert alert-danger">Please select Advertiser !</span>');
            return false;
        }
        if(cat_list== ""){
            msg.html('<span class="alert alert-danger">Please select category !</span>');
            return false;
        }
        if(all_adv_val == "" ){
            msg.html('<span class="alert alert-danger">Please select Campaign !</span>');
            return false;
        }
        if($("#select_adv_camp option:selected").val()!="Select Campaign") {
            msg.html('<span class="alert alert-info">Please wait !!!!</span>');
            var all_country_val = $("#all_country_val");
            var adv_list = '';//$('#select_advertiser');
            var opr_list = $('#select_operator option:selected').val();
            $.ajax({
                url: "/smart-interface-add-new-store", 
                type: 'post',
                cache: false,
                 async: true,
                dataType: 'JSON',
                data: {'adv_camp_id': all_adv_val,'country_id':country,'opr_list':opr_list,
                    'cat_list':cat_list,'adv_list':'','operator_name':$operator_name,'waitage_percentage':waitage_percentage,'offer_url':offer_url,'smart_status':smart_status,'waitage_type':waitage_type,'waitage_time':waitage_time, '_token': "{{ csrf_token() }}",},
                success: function(responseText){
                    var res = responseText;  
                    if(res.status == 3){
                            msg.html('<span class="alert alert-danger">'+res.message+'</span>');
                    }else if(res.status == 1){
                            msg.html('<span class="alert alert-success">sucsessfully added!</span>');
                            window.location = '/smart-interface-new';  
                    }else if(res.status == 2){
                            msg.html('<span class="alert alert-info">Sorry please try again!</span>');                                        
                    }
                    
                }, error: function (textStatus,errorThrown) {
                msg.html('<span class="alert alert-danger">Oops, Something went wrong !</span>');
            }
            });
         }
        });
    $(document).on("change","[data-change=ajax-call]",function(event){
    var $selector = $(this),
        redirect_url = $selector.attr('data-onchange-url'),
        action = $selector.attr('data-onchange-action'),
        action_id = $selector.attr('data-onchange-id'),
        id = $(this).val();
    $("#camp_data,#id_camps,#clivecca,#select_adv_camp").html("").selectpicker('refresh');
    $.ajax({
            url : redirect_url,
            type: 'GET',
            async: true,
            data: "op_id="+id+"&action="+action
        }).done(function (response){
            if(response.status == 1){
                $("#camp_data").html(response.data);
                $("#id_camps").html(response.data);
                $(".selectpicker").selectpicker('refresh');
            }    
        }).fail(function () {
                alert('Data could not be loaded.');
        });
});

  

});
</script>
@endsection
@section('content')
    <div class="row">
        <div class="col-sm-12">
            <div class="white-box">                            
                <form data-toggle="validator" method="post" action="" class="smart-interface-form">
                    <h2>Add Smart Campaign</h2>
                      {{ csrf_field() }}
                      <div id="errormsg" style="text-align:center;margin-bottom:20px;">
                      </div>

                    <div class="row">
                        <div class="col-sm-3"></div>
                        <div class="col-sm-2">
                            <label class="control-label">Country</label>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                                <select class="selectpicker" class="form-control input-sm" name="select_country" id="select_country" data-live-search="true" data-width="75%">
                                   <option value="">Select Country</option>
                                   @foreach ($country as $key => $country)
                                        <option value="{{$country->iso}}" {{$country->iso == $country_name ? "selected":""}}>{{$country->nicename}}({{$country->iso}})</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-3"></div>    
                        <div class="col-sm-2">
                            <label class="control-label">Operator <span style="color: #F05355">*</span> </label>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                                <select class="selectpicker" class="form-control input-sm" name="select_operator" id="select_operator" data-live-search="true" data-actions-box="true" data-selected-text-format="count > 3" data-size="10" data-width="75%">
                                    @foreach ($operator as $op)
                                        <option value="{{$op->id}}" {{$op_id == $op->id ? "selected":""}} >{{$op->name}}({{$op->iso}})</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>    
                    <!-- <div class="row">
                        <div class="col-sm-3"></div>
                         <div class="col-sm-2">
                            <label class="control-label">Advertiser <span style="color: #F05355">*</span> </label>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                                <select name="select_advertiser" id="select_advertiser" class="selectpicker" data-live-search="true" data-actions-box="true" data-width="75%">
                                   <option value="">Select Advertiser</option>
                                   @foreach ($advertiser as $adv)
                                    <option value="{{$adv->id}}">{{$adv->name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>   
                    </div> -->
                    <div class="row">
                    <div class="col-sm-3"></div>    
                        <div class="col-sm-2">
                            <label class="control-label">Category <span style="color:#F05355">*</span></label>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                                <select name="select_category" id="select_category" class="selectpicker form-control input-sm" data-width="75%">
                                   <option value="">Select Category</option>
                                   <option value="A" {{'A' == $category ? "selected":""}}>A</option>
                                   <!--<option value="B" {{'B' == $category ? "selected":""}}>B</option>-->
                                   <option value="C" {{'C' == $category ? "selected":""}}>C</option>
                                   <!--<option value="D" {{'D' == $category ? "selected":""}}>D</option>-->
                                   <!--<option value="I" {{'I' == $category ? "selected":""}}>I</option>-->
                                   <!--<option value="IG" {{'IG' == $category ? "selected":""}}>IG</option>-->
                                   <!--<option value="WM" {{'WM' == $category ? "selected":""}}>WM</option>-->
                                   <!--<option value="WG" {{'WG' == $category ? "selected":""}}>WG</option>-->
                                </select>
                            </div>
                        </div>
                    </div>
                      <div class="row">
                    <div class="col-sm-3"></div>    
                        <div class="col-sm-2">
                                    <label for="is_smart">Is smart</label>
                                </div>
                                <div class="col-sm-4">
                            <div class="form-group">
                                <input type="radio" name="is_smart" id="default_radio" value="DEFAULT" class="radiobox" class="form-control input-sm" checked="checked">
                                Default
                                <input type="radio" name="is_smart" id="is_smart_cpa" value="CPA" class="radiobox" class="form-control input-sm">
                                CPA 
                                <input type="radio" name="is_smart" id="is_smart_cpi" value="CPI" class="radiobox" class="form-control input-sm">
                                CPI 
                                <span id='spinner' style="display:none;">Processing.... </span>
                                </div>
                           </div>
                        </div>
                    
                    <div class="row">
                        <div class="col-sm-3"></div>
                        <div class="col-sm-2">
                            <label class="control-label">Advertiser Campaign <span style="color: #F05355">*</span></label>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                               <select name="select_adv_camp" id="select_adv_camp" data-act=ajax-call class="form-control input-sm" data-live-search="true" data-width="75%">
                                    <option value="">Select Campaign</option>
                                     @foreach ($advertiser_campaigns as $adv)
                                    <option value="{{$adv->id}}">{{$adv->name.'('.$adv->id.')'}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                       <div class="row">
                        <div class="col-sm-3"></div>
                        <div class="col-sm-2">
                            <label class="control-label">Offer url <span style="color: #F05355">*</span></label>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                               <input type="text" name="offer_url" id="url" class="form-control input-sm">
                            </div>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-sm-3"></div>
                        <div class="col-sm-2">
                            <label class="control-label">Waitage Percentage<span style="color: #F05355">*</span></label>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                               <input type="number" name="waitage_percentage" id="waitage_percentage" class="form-control" value="">
                            </div>
                        </div>

                    </div>
                              <div class="row">
                        <div class="col-sm-3"></div>
                        <div class="col-sm-2">
                            <label class="control-label">Status<span style="color: #F05355">*</span></label>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                             <label style="float:left;">Active</label>
                              <input style="float:left;" type="radio" id="smart_status" name="smart_status" value="1" checked=""/>
            <label style="float:left;">&nbsp;&nbsp;&nbsp;Inactive</label>

            <input style="float:left;" type="radio" id="smart_status" name="smart_status" value="0"  />
                            </div>
                        </div>
                        
                    </div>
                    <div class="row">
                        <div class="col-sm-3"></div>
                        <!-- <div class="col-sm-2">
                            <label class="control-label">waitage type <span style="color: #F05355">*</span></label>
                        </div> -->
                        <div class="col-sm-4">
                            <div class="form-group">
                              <!--  <select name="waitage_type" id="waitage_type" class="selectpicker" data-live-search="true" data-width="75%">
                                    <option value="manual">Manual</option>
                                    <option value="auto">Auto</option>
                                </select> -->
                                <input type="hidden"  name="waitage_type" id="waitage_type" value="manual">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-3"></div>
                        <!-- <div class="col-sm-2">
                            <label class="control-label">Waitage time <span style="color: #F05355">*</span></label>
                        </div> -->
                        <div class="col-sm-4">
                            <div class="form-group">
                              <!--  <select name="waitage_time" id="waitage_time" class="selectpicker" data-live-search="true" data-width="75%">
                                    <option value="0">0</option>
                                    <option value="15">15</option>
                                    <option value="30">30</option>
                                    <option value="45">55</option>
                                    <option value="60">60</option>
                                </select> -->
                                 <input type="hidden"  name="waitage_time" id="waitage_time" value="0">
                                 <input type="hidden"  name="op_id_data" id="op_id_data" value="{{$op_id}}">

                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-5"></div>    
                        <div class="col-sm-2">
                            <div class="form-group" style="width: 100%;">
                                
                                <button type="button" class="btn btn-success btn-lg" id="update_status">Submit</button>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="form-group" style="text-align: center;">
                                <input type="hidden" id="all_country_val" name="all_country_val" class="form-control">
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group" style="text-align: center;">
                                <input type="hidden" id="all_adv_val" name="all_adv_val" class="form-control">
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group" style="text-align: center;">
                                <input type="hidden" id="all_opr_val" name="all_opr_val" class="form-control">
                                <input type="hidden" id="ads_cat" name="ads_cat" class="form-control">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
                                        
    </div>
@endsection
