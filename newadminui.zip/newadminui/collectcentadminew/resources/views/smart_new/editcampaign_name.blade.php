<div id="editPercentageModel" class="modal fade" role="dialog">
      <div class="modal-dialog percentage-container">
          <!-- Modal content-->
          <div class="modal-content">
            <form id="smartTrfcconfig" name="smartTrfcconfig" method="POST">
            	  <input type="hidden" name="_token" value={{ csrf_token() }}>
              <!--div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">Edit percentage</h4>
              </div-->
              <div class="modal-body">
              	  <div class="editPercentageBody"></div>	
                  <input type="hidden" name="container_id" id="container_id" value="">
                  <input type="hidden" name="cca" id="cca" value=""> 
                  <div class="margin10">
                  	<a href="javascript:void" id="percentage_submit" class="btn btn-success">Submit</a>
                    <button type="button" class="btn btn-default text-right" data-dismiss="modal">Close</button>
                  </div>
              </div>
        	  </form>
          </div>
      </div>
</div>