@php

if(array_key_exists("test",$_COOKIE)){
    $cook = $_COOKIE['test'];
    if($cook){
      $cook = explode(",",$cook);
    }else{
      $cook = [];
    }

}else{
    $cook = [];
}

@endphp

<div class="btn-group mainCollumn dropdown m-r-10">
      <button aria-expanded="true" data-toggle="dropdown" class="btn btn-success dropdown-toggle waves-effect waves-light\" type="button">Columns <span class="caret"></span></button>
        <ul role="menu" class="dropdown-menu">
          @foreach($data as $col)
            <li>
                <a href="#">
                	<div class="checkbox  checkbox-primary">
		                <input id="checkbox2{{$loop->index}}"  data-index="{{$loop->index}}"   class="columncheck" type="checkbox" value="{{$col}}" checked="Checked">
		                <label for="checkbox2{{$loop->index}}"> {{$col}} </label>
                	</div>
                </a>
               
            </li>
           @endforeach
         </ul>
</div>

