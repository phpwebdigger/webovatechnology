<!DOCTYPE html>
<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>CPACPI CRC Hour records</title>
	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" rel="stylesheet">
	<!--script src = "https://ajax.googleapis.com/ajax/libs/angularjs/1.5.7/angular.min.js"></script-->
	<!--link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css" rel="stylesheet"-->
	<script src = "lib/angular/angular.js"></script>
	<script src = "lib/dirPagination.js"></script>
	<!-- Include Date Range Picker -->
	<link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.css" />
	<!--script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" src="js/tablesorter.js"></script>
	<!--link href="css/jquery.dataTables.css" rel="stylesheet"-->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/css/bootstrap-select.min.css">
	<!-- Latest compiled and minified JavaScript -->
	<link href="css/hours-style.css" rel="stylesheet">
	</head>
    <body>
	<header class="hourly-header">
	<div class="col-sm-1"><a href="/" class="text-left">Home</a></div>
	<div class="col-sm-11"><a href="{{ URL::to("/hourly") }}" class="logo">CPACPI Hourly Module</a></div>
	</header>	
	@yield('content') 
	</body>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>	
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="//cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
	<script type="text/javascript" src="//cdn.jsdelivr.net/bootstrap.daterangepicker/2/daterangepicker.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/js/bootstrap-select.min.js"></script>
	<script type="text/javascript" src="js/hours.js"></script>
	
</html>
