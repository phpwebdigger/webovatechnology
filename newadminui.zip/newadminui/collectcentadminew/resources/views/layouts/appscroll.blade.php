<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Collectcentadmin</title>
    <!-- Bootstrap Core CSS -->
    <link href="{{ asset('bootstrap/dist/css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('plugins/bower_components/bootstrap-extension/css/bootstrap-extension.css')}}" rel="stylesheet">
    <!-- Menu CSS -->
    <link href="{{ asset('plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.css')}}" rel="stylesheet">

    <link href="{{asset('plugins/bower_components/datatables/media/css/jquery.dataTables.css')}}" rel="stylesheet">

    <!-- animation CSS -->
    <link href="{{ asset('css/animate.css')}}" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="{{asset('css/select2.min.css')}}" rel="stylesheet">
    <link href="{{ asset('css/style.css')}}" rel="stylesheet">

    <!-- color CSS you can use different color css from css/colors folder -->
    <link href="{{ asset('css/colors/megna.css') }}" id="theme" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/css/bootstrap-select.min.css">
    @yield('custom_css')

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
   <!--  <script src="http://www.w3schools.com/lib/w3data.js"></script>
     --><style type="text/css">
        body{overflow: scroll;}
        .select2-container--default .select2-selection--single {
            background-color: #fff;
            border: 1px solid #e4e7ea;
            border-radius: 0px;
            padding-top: 1px;
            height: 28px;
        }
        .select2{
            width: 100% !important;
        }
        .full{
            width: 100% !important;
        }
        #header-fixed { 
        position: fixed; 
        top: 13px; display:none;
        background-color:white;
        z-index: 9999;
        display: none;
    }
    .dataTables_filter input {
    border: 1px solid rgba(120,130,140,.13);
    padding: 4px 2px;
}

    td{
        max-width: 500px !important;
        word-wrap: break-word !important;
    }
    #tableLazy > thead{
        
    }
    .white-box{width:100%;}
</style>
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <div class="cssload-speeding-wheel"></div>
    </div>

    <button id="navToggle" class="btn btn-danger btn-circle btn-md"><i class="fa fa-angle-double-up"></i></button>

    <div id="wrapper">
     
    @if(isset($message))
        <div id="alertbottomright" class="myadmin-alert flipInY alert-success myadmin-alert-bottom-right" style="display: block;"><a href="#" class="closed" onclick="javascript:document.getElementById('alertbottomright').style.display = 'none'">×</a>
            {{$message}}                            
        </div>
    @endif
     @if(isset($error))
        <div id="alertbottomright2" class="myadmin-alert flipInY alert-danger myadmin-alert-bottom-right" style="display: block;"><a href="#" class="closed" onclick="javascript:document.getElementById('alertbottomright2').style.display = 'none'">×</a>
            {{$error}}                            
        </div>
    @endif


        <!-- Top Navigation -->
         @include("partials.header")
        <!-- End Top Navigation -->
         @include("partials.nav")
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">
                           
                        </h4>
                    </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        @yield('bread')
                        
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="white-box" >
                           @yield('content')
                        </div>
                    </div>
                </div>
                <!-- .right-sidebar -->
               
                <!-- /.right-sidebar -->
            </div>
            <!-- /.container-fluid -->
            <footer class="footer text-center"> 2019 &copy; {{ config('app.name') }}</footer>
        </div>
        <!-- /#page-wrapper -->
    </div>
    <div class="modal" id="ajaxModal" tabindex="-1" role="dialog" aria-labelledby="ajaxModal" aria-hidden="true">
    <div class="modal-dialog mini-modal">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" style="font-size:20px" id="ajaxModalTitle" data-title=""></h4>
            </div>
            <div id="ajaxModalContent">

            </div>
            <div id='ajaxModalOriginalContent' class='hide'>
                <div class="original-modal-body">
                    <div class="circle-loader"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
</div>
    <!-- /#wrapper -->
    <!-- jQuery -->
    <script src="{{asset('plugins/bower_components/jquery/dist/jquery.min.js')}}"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="{{asset('bootstrap/dist/js/tether.min.js')}}"></script>
    <script src="{{asset('bootstrap/dist/js/bootstrap.min.js')}}"></script>
    <script src="{{asset('plugins/bower_components/bootstrap-extension/js/bootstrap-extension.min.js')}}"></script>
<script src="{{asset('plugins/bower_components/datatables/jquery.dataTables.min.js')}}"></script>


    <!-- Menu Plugin JavaScript -->
    <script src="{{asset('plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js')}}"></script>
    <!--slimscroll JavaScript -->
    <script src="{{asset('js/jquery.slimscroll.js')}}"></script>
    <!--Wave Effects -->
    <script src="{{asset('js/waves.js')}}"></script>
    <!-- Custom Theme JavaScript -->
    <script src="{{asset('js/custom.min.js')}}"></script>
    <script src="{{asset('js/select2.min.js')}}"></script>
     <script src="{{asset('js/main.js')}}"></script>
     <script src="{{asset('js/url.js')}}"></script>
    <!--Style Switcher -->
    <script src="{{asset('plugins/bower_components/jquery-steps-master/lib/jquery.cookie-1.3.1.js')}}"></script>
    <script src="{{asset('plugins/bower_components/styleswitcher/jQuery.style.switcher.js')}}"></script>
    <!--script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.12.4/js/bootstrap-select.min.js"></script-->
    @yield('custom_js')
    <script type="text/javascript">
    $(document).ready(function() {

        var allTheUrl = {};
        $(document).on('click', '.mainCollumn .dropdown-menu', function (e) {
                e.stopPropagation();
        });

        $(".nav-second-level li a").each(function(){
           allTheUrl[$(this).attr('href')] = $(this).text();
        });
          $("#searchBar").keyup(function(){
            var val = $(this).val().toLocaleLowerCase();
            var count = 0,str="";
            for(var key in allTheUrl){
                if(allTheUrl.hasOwnProperty(key)){
                    if(allTheUrl[key].toLocaleLowerCase().indexOf(val) > -1 && count < 8){
                        str = str +'<li><div class="drop-title"><a style="color:#54667a;font-weight: 500" href="'+key+'">'+allTheUrl[key]+'</a></div></li>';
                        count++;
                    }
                }
            }
            $("#searchbarUL").html(str);
          })
          $(".pagination-sort").on('click',function(e){
                e.preventDefault();
                var mainUrl = $(this).attr("href");
                var href= $(this).attr("href").split("?");
                var href1 = href[1];
               
                try{

                    var url = $('.pagination a:first').attr("href").split("?");
                    var url0 = url[0];
                    var url1 = url[1].split("&");
                    for (var i = 0; i < url1.length; i++) {
                        if(url1[i].indexOf("page") == -1){
                            href1 += "&"+url1[i];
                        }
                    }
                    url0 = url0 +'?'+href1;
                    window.location = url0;
                }catch(e){
                    window.location = mainUrl;
                }
                

          });

        var uncheckedOption = [];

        function setCookieCol(){
            var table= ""
            for (var i = 0; i < uncheckedOption.length; i++) {
                var val = uncheckedOption[i];

                 //e.preventDefault();
 
               
                //var index =$('.table th[data-val="'+val+'"]').index();
                 // Get the column API object
                $('.new th[data-index="'+val+'"]').addClass("hide");
                var column = tableLazyNew.column( val );
         
                // Toggle the visibility
                column.visible(false);
                            
            }
            
            
            $.cookie("test",uncheckedOption,{path:window.location.pathname});
        }
        if(a = $.cookie("test")){

             uncheckedOption = $.cookie("test").split(",");
             setCookieCol();
        }
       
        $(".columncheck").on('change',function(){
                
                scrollFeature();
                 var checked = $(this).is(":checked");
                 var index = $(this).attr("data-index");
                
                $('.new th[data-index="'+index+'"]').toggleClass("hide");
                if(checked) {
                     var column = tableLazyNew.column( index );
         
                    // Toggle the visibility
                    column.visible(true);
                     var indexA = uncheckedOption.indexOf(index);
                        if (indexA > -1) {
                            uncheckedOption.splice(indexA, 1);
                        }
                    

                    
                    
                } else {
                     var column = tableLazyNew.column( index );
         
                        // Toggle the visibility
                        column.visible(false);
                     if(uncheckedOption.indexOf(index) == -1){
                        uncheckedOption.push(index); 
                    }
                     
                }
               //  setCookieCol();
        })
    })

    var toggleNav =  $("#navToggle .fa");
    var breadHeight = parseInt($(".breadcrumb").css("height"))-15;

    if(isNaN(breadHeight)){
        breadHeight = -3;
    }


</script>
</body>

</html>
