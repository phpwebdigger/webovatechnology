<thead class="{{$class}}">
      <tr>
    
          @foreach($data as $col)
                  <th data-index="{{$loop->index}}" data-val="{{$col}}">{{$col}}</th>
          @endforeach


      </tr>
</thead>
