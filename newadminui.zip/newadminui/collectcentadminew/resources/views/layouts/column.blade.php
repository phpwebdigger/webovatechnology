@php

if(array_key_exists("test",$_COOKIE)){
    $cook = $_COOKIE['test'];
    if($cook){
      $cook = explode(",",$cook);
    }else{
      $cook = [];
    }

}else{
    $cook = [];
}


function isAssoc2(array $arr)
{
    if (array() === $arr) return false;
    return array_keys($arr) !== range(0, count($arr) - 1);
}
$isAsso2 = isAssoc2($data);
@endphp

<div class="btn-group mainCollumn dropdown m-r-10">
      <button aria-expanded="true" data-toggle="dropdown" class="btn btn-success dropdown-toggle waves-effect waves-light\" type="button">Columns <span class="caret"></span></button>
        <ul role="menu" class="dropdown-menu">

        @foreach($data as $col=>$val)
            <li>
                <a href="#">
                	<div class="checkbox  checkbox-primary">
		                <input id="checkbox2{{$loop->index}}"  data-index="{{$loop->index}}" class="columncheck" type="checkbox" value="{{$isAsso2?$col:$val}}" {{ in_array($loop->index,$cook)?"":"Checked"}}>
		                <label for="checkbox2{{$loop->index}}"> {{$isAsso2?$col:$val}} </label>
                	</div>
                </a>
               
            </li>
           @endforeach
         </ul>
</div>

