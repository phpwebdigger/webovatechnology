@php
function isAssoc(array $arr)
{
    if (array() === $arr) return false;
    return array_keys($arr) !== range(0, count($arr) - 1);
}
$isAsso = isAssoc($data);
@endphp

<thead class="bg-primary ">
      <tr>
      @if($isAsso)
         @foreach($data as $col => $val)
            <th data-val="{{$col}}" data-index="{{$loop->data-index}}">
            @if($val !="")
             @php
              if(Request::get('colorder') == $val){
                if(Request::get('order')=='desc'){
                  $ic = "arrow-down";
                }else{
                  $ic = "arrow-up";
                }
              
              }else{
                $ic = "";
              }
            @endphp
            <a class="pagination-sort" style="color:white" href="?colorder={{$val}}&order={{Request::get('order')=="desc"?"asc":"desc"}}">{{$col}}<i class='fa fa-{{$ic}}'></i></a>
      			@else
      			{{$col}}
			      @endif
           </th>
        @endforeach
    @else
          @foreach($data as $col)
                  <th data-val="{{$col}}">{{$col}}</th>
          @endforeach
    @endif

      </tr>
</thead>
