@extends('layouts.app')
@section('bread')
@endsection
@section('heading')
  {{$page_name}}
@endsection
@section('custom_js')
<script type="text/javascript">
  $(document).ready(function() {

        var data =   {!! json_encode($data1) !!};        
       createTableWithLazyLoad("#tableLazy",data,50);
       
    } );
  </script>
@endsection
@section('content')

<div >
    <div class="m-b-15 header-panel-form">
              <form class="form-inline" role="form" method="POST" action="{{ route('trafficFilter') }}">
                        {{ csrf_field() }}    
                                               <div class="form-group  hide">
                                                    <input type="number" class="form-control" value="{{$total}}" name="total">
                                                </div>
                                                <div class="form-group">
                                                    <input type="number" class="form-control" value="{{$parent_cca}}" name="parent_cca" placeholder="Parent CCA">
                                                </div>
                                                 <div class="form-group ">
                                                        <select name="net_id" class=" select2 form-control" id="publisher" data-act="ajax-select"  data-post-text="name" data-post-id="ccz" data-post-key="name" data-post-table="ad_network" data-min-input="3" data-placeholder="Network Name" ></select>
                                                </div>
                                                <div class="form-group ">
                                                       <select name="op_id" class=" select2 form-control" id="publisher" data-act="ajax-select"  data-post-text="concat(name,'-',country_code)" data-post-id="id" data-post-key="name" data-post-table="operator" data-min-input="2" data-placeholder="Operators" ></select>
                                                </div>
                                                <div class="">
                                                     <button type="submit" class="btn btn-success waves-effect waves-light">Filter</button>
                                                </div>
                                                @php
                                                           $heads =  ["Id",
                                                                    "Action",
                                                                    "Network Name",
                                                                    "Operator",
                                                                    "CCZ",
                                                                    "PARENT CCA",
                                                                    "CCA",
                                                                    "Campaign Name",
                                                                    "Percentage",
                                                                    "Is Child",
                                                                    "Status"];
                                                @endphp
                                                <div class="text-right ">
                                                    {!!view('layouts.columnNew', ['data' =>$heads])!!}
                                                </div>
                                                
                                                

                                            
                                              
                                        </form>
                                            
                            </div>
    </div>


    <div class="col-sm-12">
                       
                            
                           <div class="table-responsive mainTableInfo">
                                <table class="table color-table info-table scrollTable lazy" id="tableLazy">
                                    
                                        {!!view('layouts.tableheadNew', ['data' =>$heads,'class'=>""])!!}
                                        
                                           
                                    
                                </table>
                                <table>
                                
                                </table>

                            </div>          
    </div>
</div>

@endsection
