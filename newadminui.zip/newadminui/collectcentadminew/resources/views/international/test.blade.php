@extends('layouts.app')


@section('custom_js')
<script type="text/javascript">
$(document).ready(function () {
     $('#country_name').select2({search: true});

   $('#operator_name').select2({search: true});
    $('.alert').hide();
    
    $('input[name=traffic_type]').on('change',function(){
    var check_radio = $('input[name=traffic_type]:checked').attr('data-val');
     if(check_radio=='WG_33'){
            $(".operator_div").hide();
           
        }
     else if(check_radio=='WM_33'){
            $(".operator_div").hide();
           
        }
        else{
             $(".operator_div").show();
        }
        
    });
    
    //country_name list display after append
    $("#country_name").on('change', function () {
        var str = "";
        var content = "";
        str = $(this).val();
        $('#spinner').show();
        $.ajax({
            type: "POST",
            url: "/internationalcountryname",
            data: 'country_name=' + str,
            datatype: 'json',
            success: function (data) {
                var data = JSON.parse(data);
                var content = "";
                content += '<option disabled selected value> select an operator </option>';
                $.each(data, function (i, j) {
                    content += '<option value=' + j.id + '>' + j.name + '</option>';
                });
                $("#operator_name").html(content);
                $('#operator_name').select2({search: true});
               
            }

        }).done(function () {
            $('#spinner').hide();
        });

    });

   
  


    $("#submit_data").on('click', function (e) {
      
        $("#display_data").html("");
        var strs = "";
        var contents = "";
        var dis = "" ,check_value ="",country_name='';
        
          var check_value3 = $('input[name=traffic_type]:checked').attr('data-val');
        
        if(check_value3=='WG_33'){
            var a_data = check_value3.split('_');
              var country_name = $("#country_name option:selected").val();
              
        if(country_name.selectedIndex == 0) {
        alert('select one country name');
        return false;
        }else{
            var country_name = $("#country_name option:selected").val();
        }
           
            check_value=a_data[0];
            strs=a_data[1];
            $("#operator_name").hide();
           
        }
        else if(check_value3=='WM_33'){
               var a_data = check_value3.split('_');
                var country_name = $("#country_name option:selected").val();
            check_value=a_data[0];
            strs=a_data[1];
              $("#operator_name").hide();
              
        }else if(check_value3=='cleanoperatore'){
       
        var check_value = $('input[name=traffic_type]:checked').val();
        var strs = $("#operator_name option:selected").val();
         var country_name = $("#country_name option:selected").val();
        if(country_name.selectedIndex == 0) {
        alert('select one country name');
        return false;
        }
        
        if(strs.selectedIndex == -1) {
        alert('select one operator name');
        return false;
        }
        
        var strs = $("#operator_name option:selected").val();
        }
        else if(check_value3 =='glamouroperatore'){
        var country_name = document.getElementById("country_name");
        if(country_name.selectedIndex == 0) {
        alert('select one country name');
        return false;
        }else{
            var country_name = $("#country_name option:selected").val();
        }
        
        var check_value = $('input[name=traffic_type]:checked').val();
     
        
       var strs = document.getElementById("operator_name");
        if(strs.selectedIndex == -1) {
        alert('select one operator name');
        return false;
        }else{
         strs = $("#operator_name option:selected").val();
        }
        
        }    
       
        $('#spinner1').show();
        $.ajax({
            type: "POST",
            url: "/internationalrotatormgnt_list2",
            data: 'operator_name=' + strs + '&country_name=' + country_name + '&traffic_type=' + check_value,
            datatype: 'json',
            success: function (data) {
                var i = 1;
                var data = JSON.parse(data);
                $.each(data, function (index, data) {
                    dis += "<tr>";
                    dis += "<td>" + i + "</td>";
                    dis += "<td id='row_id' data-tag='" + data.parent_cca + "'>" + data.name + "</td>";
                    dis += "<td>" + data.operator_name + "</td>";
                    dis += "<td>" + data.id_zone + "</td>";
                    dis += "<td>" + data.parent_cca + "</td>";
                    dis += "<td>" + data.id_ad + "</td>";
                    dis += "<td>" + data.nicename + "(" + data.country_code + ")</td>";
                    dis += "<td>" + data.campaign_name +"("+ data.id_advertiser +")</td>";
                    dis += "<td class='editable-col' data-val=" + data.id + " contenteditable='true'>" + data.hold_percentage + "<div class='thumb'><div class='close'>Edit</div></div></td>";
                    dis += "<td>" + data.is_child + "</td>";
                    if (data.status > 0) {
                        dis += "<td><input type='checkbox' id=" + data.id + " name='tc_staus' value='" + data.status + "' checked></td>";
                    } else {
                        dis += "<td><input type='checkbox' id=" + data.id + " name='tc_staus' value='" + data.status + "'></td>";
                    }

                    //dis += "<td> </td>";
                    dis += "</tr>";
                    dis += "<span id='spinner3'/>Processing...</span>";
                    i++;
                });

                $("#show_o").hide();
                $("#display_data").append(dis);
                
                    $("td[contenteditable=true]").blur(function () {
                    var new_id_ad = $("#row_id").attr("data-tag");
                    var hold_percentage = $(this).text();
                    
                    hold_percentage = hold_percentage.replace("Edit","");
                    var tarfic_id = $(this).attr("data-val");
                    $.ajax({
                        url: "/internationalrotatoreditvalue",
                        type: "POST",
                        data: 'new_id_ad=' + new_id_ad + '&hold_percentage=' + hold_percentage + '&tarfic_id=' + tarfic_id,
                        datatype: 'json',
                        success: function (response)
                        {
                            alert(response);
                        }
                    });
                });
                
                $('input:checkbox[name=tc_staus]').change(function () {

                    if ($(this).prop('checked') === true) {
                        var id_ad = $(this).attr('id');
                        var checked_value = '1';

                    } else {
                        var id_ad = $(this).attr('id');
                        var checked_value = '0';
                    }
                    var data = "";
                    $.ajax({
                        url: "/trfc_status_update",
                        type: 'POST',
                        cache: false,
                        async: false,
                        data: "id_ad=" + id_ad + "&check_value=" + checked_value,
                        success: function (response) {
                            alert(response);
                        }
                    });
                });

          


            }
        }).done(function () {
            $('#spinner1').hide();
        });
    });


    $('#display_data').on('mouseenter', '.thumb', function () {
        $(this).find('.close').fadeIn();

    });

    $('#display_data').on('mouseleave', '.thumb', function () {
        $(this).find('.close').fadeOut();
    });

    $("td[contenteditable=true]").on('click', function () {
        $(".thumb").find('.close').fadeOut();

    });
     $('input[name=traffic_type]').on('change',function(){
        var value = $( 'input[name=traffic_type]:checked').val();
        $("#display_data").html('');
         $('#country_name').select2('val',"");
         
         
        $('#operator_name').select2('val',"");
    });
});


</script>

@endsection
@section('heading')
  {{$header}}
  
@endsection
@section('bread')
      <ol class="breadcrumb">
      
        <li><a href="/internationalrotatormgntadd" class="btn btn-success">Add New</a></li>
   
       </ol>
@endsection
@section('content')
<style>
    #spinner{
        display: none;
        position: absolute;
        left: 50%;
        top: 20%;
    }
    #spinner1{
        display: none;
        position: absolute;
        left: 50%;
        top: 20%;
    }
    #spinner2{
        display: none;
        position: absolute;
        left: 50%;
        top: 20%;
    }
    #spinner3{
        display: none;
        position: absolute;
        left: 50%;
        top: 20%;
    }
    .search {
        width: 253px !important ;
    }
    .select2>.optWrapper {
        width: 253px !important ;
    }
    .alignright {
        float: right;
    }
    .close {
        display: none;
        cursor: pointer;
        padding: 0 2px;
        color: #e68;
        font-weight: 300;
        align: right;
        top: 12px;

    }
    .thumb {
        float:right;
        margin: 5px;
        width: 50px;
        position: relative;
    }
</style>

       

            <div class = "panel-body">
                <div class="col-lg-10">
                    <label class = "checkbox-inline">
                        <input type = "radio" id = "optionsRadios3" name="traffic_type" value = "WG" checked="true" data-val="glamouroperatore"> Glamour Operator
                    </label>

                    <label class = "checkbox-inline">
                       <!--<input type = "radio" id = "optionsRadios3"  name="traffic_type" value = "WM,C,I"> Clean Operator-->
                        <input type = "radio" id = "optionsRadios3"  name="traffic_type" value = "WM" data-val="cleanoperatore"> Clean Operator
                    </label>

                    <label class = "checkbox-inline">
                        <input type = "radio" id = "optionsRadios3" name="traffic_type" value = "WG" data-val="WG_33" > Glamour WI-FI
                    </label>

                    <label class = "checkbox-inline">
                        <input type = "radio"  id ="optionsRadios3"  name="traffic_type"  value = "WM" data-val="WM_33"> Clean WI-FI
                    </label>
                </div>
            </div>

            <div class = "panel-body">
                <div class="form-group">
                    <div class="col-xs-3 col-sm-3 col-md-3">
                        <select name="country_name" id="country_name" class="form-control input-sm"  placeholder="Select Country">
                            <option>Select Country</option>
                            @foreach($country_list as $countryname)
                            <option value="{{ $countryname->iso }}">{{$countryname->name }} ({{ $countryname->iso }})</option>
                            @endforeach
                        </select>
                        <span id="spinner"/>Processing...</span>
                    </div>
                    <div class="col-xs-3 col-sm-3 col-md-3 operator_div" >
                        <select name="operator_name" id="operator_name" class="form-control input-sm">

                        </select>
                        <span id="spinner1"/>Processing...</span>
                    </div>
                    <button type="button" class="btn btn-primary col-md-1" id="submit_data">Submit</button>
                    <div class="col-xs-3 col-sm-3 col-md-3">
                        <span id="spinner2"/>Processing...</span>
                        <span id="spinner3"/>Processing...</span>
                    </div>
                    
                        
                    
                </div>
            </div>
        

        <div class="col-sm-12">
                    
            <div id="msg" class="alert"></div>
            
                        <!-- /.panel-heading -->
                         <div class="table-responsive mainTableInfo m-t-0">
                                <table class="table color-table info-table scrollTable lazy" id="tableLazy">
                                    
 
                                <thead>
                                    <tr>
                                            <th>Sr.No</th>
                                            <th>Network Name</th>
                                            <th>Operator</th>
                                            <th>CCZ</th>
                                            <th>Parent cca</th>
                                            <th>CCA</th>
                                            <th>Country Name</th>
                                            <!--<th>Country Code</th>-->
                                            <th>Campaign Name</th>
                                            <th>Percentage</th>
                                            <th>is Child</th>
                                            <th>Status</th>
                        <!--                <th>Action</th>-->
                                    </tr>
                                </thead>
                                <tbody id="display_data">
                                    <?php
                                    echo'<tr class="odd gradeX" id="show_o">'
                                    . '<td colspan=11>NO DATA FOUND</td>'
                                    . '</tr>';
                                    ?>


                                </tbody>
                            </table>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.panel-body -->
                    
   

<!-- Latest compiled and minified JavaScript -->

@endsection