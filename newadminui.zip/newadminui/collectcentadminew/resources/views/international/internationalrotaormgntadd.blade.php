@extends('layouts.app')
@section('heading')
   Smartlink Management
@endsection
@section('content')

<div class = "panel panel-primary">
        <style>
    #spinner{
        display: none;
        position: absolute;
        left: 50%;
        top: 20%;
    }
    #spinner1{
        display: none;
        position: absolute;
        left: 50%;
        top: 20%;
    }
    #spinner2{
        display: none;
        position: absolute;
        left: 50%;
        top: 20%;
    }
    #spinner21{
        display: none;
        position: absolute;
        left: 50%;
        top: 20%;
    }
    #spinner3{
        display: none;
        position: absolute;
        left: 50%;
        top: 20%;
    }
    .search {
        width: 253px !important ;
    }
  
 
    
</style>
           

            <div class = "panel-body">
                <div class="row">
                    <label class = "radio-inline">
                        <input type = "radio" id = "optionsRadios3" name="traffic_type" value = "WG" checked="true" data-val="glamouroperatore"> Glamour Operator
                    </label>

                    <label class = "radio-inline">
                       <!--<input type = "radio" id = "optionsRadios3"  name="traffic_type" value = "WM,C,I"> Clean Operator-->
                        <input type = "radio" id = "optionsRadios3"  name="traffic_type" value = "WM" data-val="cleanoperatore"> Clean Operator
                    </label>

                    <label class = "radio-inline">
                        <input type = "radio" id = "optionsRadios3" name="traffic_type" value = "WG" data-val="WG_33"> Glamour WI-FI
                    </label>

                    <label class = "radio-inline">
                        <input type = "radio"  id ="optionsRadios3" name="traffic_type"  value = "WM" data-val="WM_33"> Clean WI-FI
                    </label>
                </div>
            </div>
            <div class="row">
                    <div class="col-sm-3">
                        <select name="country_name" id="country_name" class="form-control input-sm"  placeholder="Select Country">
                            <option>Select Country</option>
                            @foreach($country_list as $countryname)
                            <option value="{{ $countryname->iso }}">{{$countryname->name }} ({{$countryname->iso}})</option>
                            @endforeach
                        </select>
                        <span id="spinner"/>Processing...</span>
                    </div>
                    

                    <div class="col-sm-3 operator_div">
                        <select name="operator_name" id="operator_name" class="form-control input-sm">

                        </select>
                        <span id="spinner1"/>Processing...</span>
                    </div>
                     <div class="col-md-1">
                     <button type="button" class="btn btn-primary" id="submit_data_my" >Submit</button>
                    </div>
                     <div class="col-sm-3">
                        <span id="spinner2"/>Processing...</span>
                        <span id="spinner21"/>Processing...</span>

                    </div>
 <!--<button type="button" class="btn btn-primary" id="submit_data_my" onclick="this.disabled=true;this.value='Sending, please wait...';">Submit</button>-->



                </div>
            </div>
        <div class = "panel panel-primary">
            <div id="containerss"></div>

        </div>


@endsection
@section('custom_js')
<script type="text/javascript" language="javascript" >

$(document).ready(function () {
    $('#country_name').select2({search: true});

   $('#operator_name').select2({search: true});
    $('.alert').hide();
    
    $('input[name=traffic_type]').on('change',function(){
    var check_radio = $('input[name=traffic_type]:checked').attr('data-val');
     if(check_radio=='WG_33'){
            $(".operator_div").hide();
           
        }
     else if(check_radio=='WM_33'){
            $(".operator_div").hide();
           
        }
        else{
             $(".operator_div").show();
        }
        
    });
    
    //country_name list display after append
    $("#country_name").on('change', function () {
        var str = "";
        var content = "";
        str = $(this).val();
        $('#spinner').show();
        $.ajax({
            type: "POST",
            url: "/internationalcountryname",
            data: 'country_name=' + str,
            datatype: 'json',
            success: function (data) {
                var data = JSON.parse(data);
                var content = "";
                content += '<option disabled selected value> select an operator </option>';
                $.each(data, function (i, j) {
                    content += '<option value=' + j.id + '>' + j.name + '</option>';
                });

                $("#operator_name").html(content);
                $('#operator_name').select2({search: true});
               
            }

        }).done(function () {
            $('#spinner').hide();
        });

    });

    //operator list display after append
    $("#submit_data_my").on('click', function (e) {
          e.preventDefault();
        $("#table_data").html("");
        $("#containerss").text("");
        var strs = "";
        var contents = "";
        var dis = "" ,check_value ="",country_name='';
        
        var check_value3 = $('input[name=traffic_type]:checked').attr('data-val');
        
        if(check_value3=='WG_33'){
            var a_data = check_value3.split('_');
              var country_name = $("#country_name option:selected").val();
        if(country_name.selectedIndex == 0) {
        alert('select one country name');
        return false;
        }else{
            var country_name = $("#country_name option:selected").val();
        }
           
            check_value=a_data[0];
            strs=a_data[1];
            $("#operator_name").hide();
           
        }
        else if(check_value3=='WM_33'){
               var a_data = check_value3.split('_');
                var country_name = $("#country_name option:selected").val();
            check_value=a_data[0];
            strs=a_data[1];
              $("#operator_name").hide();
              
        }else if(check_value3=='cleanoperatore'){
        var country_name = $("#country_name option:selected").val();
        var check_value = $('input[name=traffic_type]:checked').val();
        var strs = $("#operator_name option:selected").val();
        if(country_name.selectedIndex == 0) {
        alert('select one country name');
        return false;
        }
        
        if(strs.selectedIndex == -1) {
        alert('select one operator name');
        return false;
        }
        
        var strs = $("#operator_name option:selected").val();
        }
        else if(check_value3 =='glamouroperatore'){
        var country_name = document.getElementById("country_name");
        if(country_name.selectedIndex == 0) {
        alert('select one country name');
        return false;
        }else{
            var country_name = $("#country_name option:selected").val();
        }
        
        var check_value = $('input[name=traffic_type]:checked').val();
     
        
       var strs = document.getElementById("operator_name");
        if(strs.selectedIndex == 0) {
        alert('select one operator name');
        return false;
        }else{
         strs = $("#operator_name option:selected").val();
        }
        
        }    
        $('#spinner21').show();
        $.ajax({
            type: "POST",
            url: "/internationalccadata",
            data: 'operator_name=' + strs + '&country_name=' + country_name + '&traffic_type=' + check_value,
            datatype: 'json',
              cache: false,
            success: function (data) {
                var data = JSON.parse(data);
                var i = 1;
               
                dis += '<div class="dataTable_wrapper">';
                dis += '<table class="table table-striped table-bordered table-hover" id="dataTables-example">';
                dis += '<thead>';
                dis += '<tr>';
                dis += '<th>Id Ad</th>';
                dis += '<th>Advertiser Name</th>';
                dis += '<th>Network Name</th>';
                dis += '<th>Country Name</th>';
                dis += '<th>Operator Name</th>';
                dis += '<th>Traffic Type</th>';
                dis += '<th>Parent id</th>';
                dis += '<th>Clickcount</th>';
                dis += '<th>Conversion Count</th>';
                dis += '<th>Conversion Outword</th>';
                dis += '<th>Campaign Name</th>';
//                dis += '<th>Url</th>';
                dis += '<th>Action</th></tr>';
                dis += '</thead>';
                dis += '<tbody>';
        
                $.each(data, function (index, data) {
                    dis += "<tr id='" + i + "' >";
                    if(data.parent_id == 0)
                    {
                    dis += "<td id='row_id' class='details-control-child' data-tag='" + data.id_ad + "'><a href='javascript:void(0);' data-tagret='" + data.id_ad + "'>" + data.id_ad + "</a></td>";
                    }else
                    {
                    dis += "<td>" + data.id_ad + "</td>";                        
                    }
                    dis += "<td>" + data.adv_name +"("+data.id_advertiser+")" + "</td>";
                    dis += "<td>" + data.network_name + "</td>";
                    dis += "<td>" + data.cntry+"("+data.country_code +")" +"</td>";
                    dis += "<td>" + data.operator_name + "</td>";
                    dis += "<td>" + data.traffic_type + "</td>";
                    dis += "<td id='parent_id' data-tag='" + data.parent_id + "'>" + data.parent_id + "</td>";
                    dis += "<td>" + data.clickcount + "</td>";
                    dis += "<td>" + data.conversion_count + "</td>";
                    dis += "<td>" + data.clicks_active_count + "</td>";
                    dis += "<td>" + data.title +"("+data.id_advertiser+")"+ "</td>";
//                    dis += "<td>" + data.click_url + "</td>";
                    if(data.traffic_type == 'A')
                    {
                        dis += "<td>&nbsp;</td>";
                    }
                    else if(data.parent_id != 0)
                    {
                       dis += "<td>&nbsp;</td>";
                    }
                    else {
                        dis += "<td class='details-control'><button type='button' \n\
                    id='" + 'button_submit_' + data.id_ad + "' name='button_submit' value='Add' class='btn btn-primary button_submit'>Add</button></td>";
                    }
                    dis += "</tr>";
                    i++;
                });
                
//                else{
//                alert('No data');
//                }
                dis += '</tbody></table></div>';
               
                $("#containerss").html(dis);
                 $("#show_o").hide();
                var table = $('#dataTables-example').DataTable({
                    destroy: true,
                    responsive: true,
                     "bPaginate": false,
                });

                $('#dataTables-example tbody').on('click', 'td.details-control', function () {
                    var row_id = $(this).attr('data-tag');
                    $("#id_ad").val(row_id);
                    var tr = $(this).closest('tr');
                    var row = table.row(tr);
                    if(row.child.isShown()) {
                        row.child.hide();
                        tr.removeClass('shown');
                    } else {
                        row.child(format(row.data(), row_id)).show();
                        var tabless = $('#dataTables-example2').DataTable({
                            destroy: true,
                        });
                            tr.addClass('shown');
                            $('button[id^="button_submit_newdata_"]').click(function () {
                            $('#spinner3').show();
                            var row_id = $('#row_id').attr('data-tag');
                            var parent_cca = $('#row_id_parent_cca').attr('data-tag');
                            var parent_id = $('#parent_id').attr('data-tag');
                            var selected_url = $('#selected_url option:selected').val();
                            if(selected_url==''){  alert("Select Url required!");
         return false; }
                            var country_name = $("#country_name option:selected").val();
                            var check_value = $('input[name=traffic_type]:checked').val();
                            var input_perctange= $('#input_perctange').val();
     if(input_perctange=='')
     {
         alert("Percentage value required!");
         return false;
     }
       if(input_perctange > 100)
     {
         alert("Percentage value not more than 100!");
         $('#input_perctange').val('');
         return false;
     }
     var checked_site_radio = $('input:radio[name=status]:checked').val();
      $.ajax({
           type: "POST",
           url: "/internationalrotatorupdatevalue",
           data: 'action=update&parent_cca='+parent_cca+'&country_name='+country_name+'&row_id='+row_id+'&id_ad='+row_id+'&selected_url='+selected_url+'&input_perctange='+input_perctange+'&staus='+checked_site_radio,
           datatype:'json',
           success: function(data){
              alert(data);
		$("#selected_url")[0].selectedIndex = 0;
             $("#input_perctange").val('');
             $("statuss").val('');
           }
       }).done(function () {
                        $('#spinner3').hide();
                        
                    });
                            });
                    }
                });
                
                
                    $('#dataTables-example tbody').on('click', 'td.details-control-child', function () {
                    var row_id = $(this).attr('data-tag');
                   $("#id_ad").val(row_id);
                    var tr = $(this).closest('tr');
                    var row = table.row(tr);
                    if (row.child.isShown()) {
                        // This row is already open - close it
                        row.child.hide();
                        tr.removeClass('shown');
                    } else {
                        row.child(format_data(row.data(), row_id)).show(); tr.addClass('shown');
                        var tablesss = $('#dataTables-example4').DataTable({
                            destroy: true,
                             "pageLength": 50,
                        });
                        $('#dataTables-example4 tbody').on('click', '.details-control-child2', function () {
                             var row_id = $(this).attr('data-tag2');
                            var tr = $(this).closest('tr');
                    var row = tablesss.row(tr);
                    if (row.child.isShown()) { 
                        row.child.hide();
                        tr.removeClass('shown');
                    }else {
                        row.child(format_data3(row.data(), row_id)).show(); tr.addClass('shown');
                        var tablesss2 = $('#dataTables-example3').DataTable({
                            destroy: true,responsive: true,
                        });
                    }
                            
                        });
                        
                        
                        }
                });
                
            

            }


        }).done(function () {
            $('#spinner21').hide();
        });

    });

    $('input[name=traffic_type]').on('change',function(){
        var value = $( 'input[name=traffic_type]:checked').val();
        $("#containerss").html('');
       
        $('#country_name').select2('val',"");
         
         
        $('#operator_name').select2('val',"");
    });


});

function format(d, row_id) {
    $('#spinner2').show();
    var row_id = $('#row_id').attr('data-tag');
    var parent_id = $('#parent_id').attr('data-tag');
    var counter = 1;
    var country_name = $("#country_name option:selected").val();
    var strs = $("#operator_name option:selected").val();
    var check_value = $('input[name=traffic_type]:checked').val();
    var appendTxt = "";
    $.ajax({
        type: "POST",
        url: "/internationaldatanew",
        data: 'action=addnewidad&id_ad='+row_id+'&parent_id='+parent_id+'&operator_name='+strs+'&country_name='+country_name+'&traffic_type='+check_value,
        dataType: 'JSON',
        async: false,
        cache: false,
        success: function (data) {
           
            appendTxt += '<div class="dataTable_wrapper">';
            appendTxt += '<table class="table table-striped table-bordered table-hover" id="dataTables-example2">';
            appendTxt += '<thead>';
            appendTxt += '<tr>';
            //appendTxt += "<th>New Id Ad</th>";
            appendTxt += "<th>URL</th>";
            appendTxt += "<th>Hold Prectange</th>";
            appendTxt += "<th>Status</th>";
            appendTxt += "<th>Action</th>";
            appendTxt += '</tr>';
            appendTxt += '</thead>';
            appendTxt += "<tbody id='table_datd_cca'>";
            appendTxt += "<tr>";
            //appendTxt += "<td class='details-controlsss' id='row_id_parent_cca' data-tag='" + data.new_parent_cc + "'>" + data.new_parent_cc + "</td>";
            appendTxt += "<td><select class='btn btn-mini' id='selected_url' style='width: 100% !important;' name='selected_url'>";
            appendTxt += "<option value=''>Select Url</option>";
            $.each(data.url_list, function (i, item) {
                appendTxt += "<option value=" + item.id_ad + ">" + item.url + "</option>";
            });
            appendTxt += "</select></td>";
            appendTxt += "<td><input type='text' id='input_perctange' name='input_perctange' placeholder='Enter Precentage' value=''></td>";
            appendTxt += "<td><input type='radio' id='completeON' class='statuss' name='status' value='1'/><label for='completeSwYes'>On</label>\n\
                                         <input type='radio' id='completeOFF' class='statuss' name='status' value='0' checked='checked'/><label for='completeSwNo'>Off</label></td>";
            appendTxt += "<td><button type='button'  id='" + 'button_submit_newdata_' + data.id_ad + "' name='button_submit_newdata' value='Submit' class='btn btn-primary'>Submit</button></td>";
            appendTxt += "</tr></tbody></table></div>";
           
        }

    });
    $('#spinner2').hide();
  
    return appendTxt;
}

   

function format_data(d, row_id) {
    var row_id = $('#row_id').attr('data-tag');
    //var country_name = $("#country_name option:selected").val();
    //var strs = $("#operator_name option:selected").val();
    //var check_value = $('input[name=traffic_type]:checked').val();
       var check_value3 = $('input[name=traffic_type]:checked').attr('data-val');
        
        if(check_value3=='WG_33'){
            var a_data = check_value3.split('_');
             var country_name = $("#country_name option:selected").val();
            check_value=a_data[0];
            strs=a_data[1];
            $("#operator_name").hide();
           
        }
        else if(check_value3=='WM_33'){
               var a_data = check_value3.split('_');
                var country_name = $("#country_name option:selected").val();
            check_value=a_data[0];
            strs=a_data[1];
              $("#operator_name").hide();
              
        }else if(check_value3=='cleanoperatore'){
        var country_name = $("#country_name option:selected").val();
        var check_value = $('input[name=traffic_type]:checked').val();
        var strs = $("#operator_name option:selected").val();
        if(country_name.selectedIndex == 0) {
        alert('select one country name');
        }
        
        if(strs.selectedIndex == 0) {
        alert('select one operator name');
        }
        
        var strs = $("#operator_name option:selected").val();
        }
        else if(check_value3 =='glamouroperatore'){
        var country_name = document.getElementById("country_name");
        if(country_name.selectedIndex == 0) {
        alert('select one country name');
        }else{
            var country_name = $("#country_name option:selected").val();
        }
        
        var check_value = $('input[name=traffic_type]:checked').val();
     
        
       var strs = document.getElementById("operator_name");
        if(strs.selectedIndex == 0) {
        alert('select one operator name');
        }else{
                strs = $("#operator_name option:selected").val();
        }
        
        }
      
      
    var dis = "";
    var clickcount = 0;
                                    var conversion_count = 0;
                                    var clicks_active_count = 0;
                                    var unique_conversion = 0;
                                    var total_cost = 0;
                                    var total_cost_rs = 0;
                                    var total_profit = 0;
                                    var profit = 0;
                                     $('#spinner2').show();
    $.ajax({
        type: "POST",
        url: "/internationalrotatormgnt_masterchildrow",
        data: 'id_ad='+row_id+'&operator_name='+strs+'&country_name='+country_name+'&traffic_type='+check_value,
        dataType: 'JSON',
           cache:false,
           async: false,
           
        success: function (data) {
            var i = 1;
           
            dis += '<div class="dataTable_wrapper">';
            dis += '<table class="tables" id="dataTables-example4">';
            dis += '<thead>';
            dis += '<tr>';
            dis += '<th>Id Ad</th>';
            dis += '<th>Id Channel</th>';
            dis += '<th>Advertiser Campaign Name</th>';
            dis += '<th>Adnetwork Name</th>';
            dis += '<th>Telco</th>';
            dis += '<th>Clicks Count</th>';
            dis += '<th>Conversion Inwards</th>';
            dis += '<th>Conversion Outwards</th> ';
            dis += '<th>CR Inwards</th>';
            dis += '<th>CR Outwards</th>';
              dis += '<th>Revenue ($/Rs.)</th>';
            dis += '<th>Source Cost ($/Rs.) $</th>';
          
            dis += '</tr>';
            dis += '</thead>';
            dis += '<tbody>';
                $.each(data, function (index, data) {
                   //console.log(index, data);
                    dis += '<tr>';
                    dis += '<td id="row_id1" class=""   data-tag2="' + data.id_ad + '">' + data.id_ad + '</td>';
                    dis += '<td>' + data.id_channel + '</td>';
                    dis += '<td>' + data.name +"("+data.id_advertiser+")"+ '</td>';
                    dis += '<td>' + data.network_name + '</td>';
                    dis += '<td>' + data.op_name + '</td>';
                    dis += '<td>' + data.clickcount + '</td>';
                    dis += '<td>' + data.conversion_count + '</td>';
                    dis += '<td>' + data.clicks_active_count + '</td>';
                    dis += '<td>' + data.cr_received + '</td>';
                    dis += '<td>' + data.cr_given + '</td>';
                      dis += '<td>' + parseFloat(data.revenue_dollar).toFixed(2) +'/'+ parseFloat((data.revenue_dollar) * 65).toFixed(2) +'</td>';
                    dis += '<td>' + parseFloat(data.total_cost).toFixed(2) +'/'+parseFloat((data.total_cost) * 65).toFixed(2) + '</td>';
                  
                    dis += '</tr>';
                       clickcount = clickcount + parseInt(data.clickcount);
                                                    conversion_count = conversion_count + parseInt(data.conversion_count);
                                                    clicks_active_count = parseInt(clicks_active_count) + parseInt(data.clicks_active_count);
                                                    total_cost = parseFloat(total_cost) + parseFloat(data.total_cost);
                                                    total_cost_rs = parseFloat(total_cost_rs) + parseFloat(data.total_cost);
                                                    total_profit = parseFloat(total_profit) + parseFloat(data.revenue_dollar);
                                                    unique_conversion = unique_conversion + parseFloat(data.unique_conversion_count);
    
                    i++;
                });
               dis += '</tbody>';
                 dis += '<tfoot>';
                                                dis += '<tr>';
                                                dis += '<th colspan="5">TOTAL</th>';
                                                dis += '<th>' + clickcount + '</th>';
                                                dis += '<th>' + conversion_count + '</th>';
                                                dis += '<th>' + clicks_active_count + '</th>';
                                                dis += '<th></th>';
                                                dis += '<th></th>';
                                                dis += '<th>'+parseFloat(total_profit).toFixed(2)+'</th>';
                                                dis += '<th>' + total_cost + '</th>';
                                                
                                                dis += '</tr>';
                                                dis += '</tfoot></table></div>';
            //}
            

     }
    });
     $('#spinner2').hide();
    return dis;
}



function format_data3(d, row_id) {
//alert(d +"--" + row_id);
//   var row_id = $('#row_id1').attr('data-tag2');
//   alert(row_id);
                                    var clickcount = 0;
                                    var conversion_count = 0;
                                    var clicks_active_count = 0;
                                    var unique_conversion = 0;
                                    var total_cost = 0;
                                    var total_cost_rs = 0;
                                    var total_profit = 0;
                                    var profit = 0;

    var dis = "";
    $.ajax({
        type: "POST",
        url: "/internationalrotator_publisher_childern",
        data: 'id_ad=' + row_id,
        dataType: 'JSON',
           async: false,
           cache:false,
        success: function (data) {
            var i = 1;
           
            dis += '<div class="dataTable_wrapper">';
            dis += '<table class="table" id="dataTables-example3">';
            dis += '<thead>';
            dis += '<tr>';
            dis += '<th>Id Ad</th>';
            dis += '<th>Id Channel</th>';
            dis += '<th>Advertiser Campaign Name</th>';
            dis += '<th>Adnetwork Name</th>';
            dis += '<th>Telco</th>';
            dis += '<th>Clicks Count</th>';
            dis += '<th>Conversion Inwards</th>';
            dis += '<th>Conversion Outwards</th> ';
            dis += '<th>CR Inwards</th>';
            dis += '<th>CR Outwards</th>';
            dis += '<th>CR Expected</th>';
            dis += '<th>Source Cost $</th>';
            dis += '<th>Revenue Rs.</th>';
            dis += '</tr>';
            dis += '</thead>';
            dis += '<tbody>';
            if (data.length > 0)
            {
                $.each(data, function (index, data) {
                   //console.log(index, data);
                    dis += '<tr>';
                    dis += '<td>' + data.id_ad + '</td>';
                    dis += '<td>' + data.id_channel + '</td>';
                    dis += '<td>' + data.name + '</td>';
                    dis += '<td>' + data.network_name + '</td>';
                    dis += '<td>' + data.op_name + '</td>';
                    dis += '<td>' + data.clickcount + '</td>';
                    dis += '<td>' + data.conversion_count + '</td>';
                    dis += '<td>' + data.clicks_active_count + '</td>';
                    dis += '<td>' + data.cr_received + '</td>';
                    dis += '<td>' + data.cr_given + '</td>';
                    dis += '<td>' + data.cr_goal + '</td>';
                    dis += '<td>' + data.total_cost + '</td>';
                    dis += '<td>' + parseFloat(data.advertiser_campaign_cpa) * parseFloat(data.conversion_count) + '</td>';
                    dis += '</tr>';
                    
                                                     clickcount = clickcount + parseInt(key.clickcount);
                                                    conversion_count = conversion_count + parseInt(key.conversion_count);
                                                    clicks_active_count = parseInt(clicks_active_count) + parseInt(key.clicks_active_count);
                                                    total_cost = total_cost + parseInt(key.total_cost);
                                                    total_cost_rs = total_cost_rs + parseInt(key.total_cost);
                                                    total_profit = parseInt(total_profit) + parseInt(key.cr_rev);
                                                    unique_conversion = unique_conversion + parseInt(key.unique_conversion_count);
    
            i++;
                    
                    
                });
                dis += '</tbody>';
                 dis += '<tfoot>';
                                                dis += '<tr>';
                                                dis += '<th colspan="2">TOTAL</th>';
                                                dis += '<th>' + clickcount + '</th>';
                                                dis += '<th>' + conversion_count + '</th>';
                                                dis += '<th>' + clicks_active_count + '</th>';
                                                dis += '<th></th>';
                                                dis += '<th></th>';
                                                dis += '<th>' +unique_conversion +'</th>';
                                                dis += '<th></th>';
                                                dis += '<th>' + total_cost + '</th>';
                                                dis += '<th>'+total_profit+'</th>';
                                                dis += '<th>'+ parseInt(total_profit - total_cost_rs) +'</th>';
                                                dis += '</tr>';
                                                dis += '</tfoot></table></div>';
            }
            

     }
    });
    
    return dis;
}



 function Callback()
     {
        alert("Successfull");
     }
</script>
@endsection
