@extends('layouts.app')
@section('bread')
                            <ol class="breadcrumb">
                                <li><a href="#">Dashboard</a></li>
                                <li class="active">Reverce Calculation</li>
                            </ol>
@endsection

@section('heading')
  Reverce Calculation
@endsection
@section('custom_js')
<script src="../plugins/bower_components/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script type="text/javascript">
      jQuery('.mydatepicker, #datepicker').datepicker();
    jQuery('#datepicker-autoclose').datepicker({
        autoclose: true,
        todayHighlight: true
    });

    jQuery('#date-range').datepicker({
        toggleActive: true
    });
    jQuery('#datepicker-inline').datepicker({

        todayHighlight: true
    });


</script>
@endsection

@section('content')


   

       <div class="col-sm-12">
                            <div class="table-responsive">
                                <table class="table ">
                                    <thead>
                                        <tr>
                                            <th>
                                                <div class="form-group">
                                                        <label class="control-label">Advertiser</label> 
                                                        <select class="form-control">
                                                            <option value="">All</option>
                                                            <option value="">xyz</option>
                                                        </select>
                                                </div>

                                            </th>
                                            <th>
                                                <div class="form-group">
                                                        <label class="control-label">Telco</label> 
                                                        <select class="form-control">
                                                            <option value="">All</option>
                                                            <option value="">XYZ</option>
                                                        </select>
                                                </div>
                                            </th>
                                            
                                           
                                            <th>
                                                <div class="form-group">
                                                        <label class="control-label ">From</label> 
                                                        <div class="input-group">
                                                                <input type="text" class="form-control mydatepicker" placeholder="mm/dd/yyyy">
                                                                <span class="input-group-addon"><i class="icon-calender"></i></span>
                                                        </div>
                                                </div>
                                            </th>
                                            <th>
                                                <div class="form-group">
                                                        <label class="control-label ">TO</label> 
                                                       <div class="input-group">
                                                                <input type="text" class="form-control mydatepicker" placeholder="mm/dd/yyyy">
                                                                <span class="input-group-addon"><i class="icon-calender"></i></span>
                                                        </div>
                                                </div>
                                            </th>

                                            <th style="vertical-align: middle;">
                                                <div class="text-right">
                                                     <button type="submit" class="btn btn-success waves-effect waves-light m-r-10">GO</button>
                                                </div>
                                            </th>
                                             <th style="vertical-align: middle;">
                                                <div class="text-right">
                                                     <button type="submit" class="btn btn-success waves-effect waves-light m-r-10">Home Page</button>
                                                </div>
                                            </th>
                                             

                                            <th style="vertical-align: middle;">
                                                <div class="text-right">
                                                     <button type="submit" class="btn btn-success waves-effect waves-light m-r-10">Add New</button>
                                                </div>
                                            </th>



    <div class="col-sm-12">
                       
                            
                            <div class="table-responsive">
                                <table class="table color-table info-table">
                                    <thead>
                                        <tr>
                                            <th>Advertiser ID</th>
                                            <th>Advertiser Name</th>
                                            <th>Telco</th>
                                            <th>Campaign Name</th>
                                            <th>Country</th>
                                            <th>Clicks Count</th>
                                            <th>Clicks Reverse</th>
                                            <th>Net Clicks</th>
                                            <th>Conversion Inwards</th>
                                            <th>Conversion Outwards</th>
                                            <th>CR Inwards  </th>
                                            <th>CR Outwards</th>
                                            <th>Unique Conversion</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td>Nigam</td>
                                            <td>Eichmann</td>
                                            <td>@Sonu</td>
                                            <td>1</td>
                                            <td>Nigam</td>
                                            <td>Eichmann</td>
                                            <td>@Sonu</td>
                                            <td>1</td>
                                            <td>Nigam</td>
                                            <td>Eichmann</td>
                                            <td>1</td>
                                            <td>Nigam</td>
                                            
                                         
                                        </tr>
                                       
                                    </tbody>
                                </table>
                            </div>           
    </div>


@endsection
