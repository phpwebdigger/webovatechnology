@extends('layouts.app')
@section('heading')
  {{$header}}
@endsection
@section('custom_js')
<script src="../plugins/bower_components/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script type="text/javascript">
   jQuery('.mydatepicker').datepicker({
       format:"yyyy-mm-dd"
    });


</script>
@endsection
@section('content')
       <div class="row">
       @if(sizeof($data) !== 0)
        <div class="col-sm-12"><strong class="text-danger">Last Updated Time : {{ $data[sizeof($data)-1]->create_time}}</strong></div>
       @endif 
       </div>
       <div class="m-b-15">
        <form class="form-inline" role="form" method="POST" action="{{route($routename,$id)}}">
                        {{ csrf_field() }}    
                                               

                                               
                                                <div class="form-group col-md-1">
                                                        
                                                        <div class="input-group">
                                                                <input type="text" value="{{$dtvalue}}" class="form-control mydatepicker" name="start" placeholder="From">
                                    
                                                        </div>
                                                </div>
                                                <div class="form-group col-md-1">
                                                       
                                                       <div class="input-group">
                                                                <input type="text" name="end" value="{{$dtvalue2}}" class="form-control mydatepicker" placeholder="To">
                                    
                                                        </div>
                                                </div>
                                                <div class="form-group col-md-2">
                                                     <button type="submit" class="btn btn-success waves-effect waves-light">GO</button>
                                        
                                                @php
                                                  $heads =  ["Id Ad",
                                                              "Advertiser Campaign Name",
                                                               "Clicks Count",
                                                               "Conversion Inwards",
                                                               "Conversion Outward",
                                                               "CR Inwards",
                                                               "CR Outward",
                                                               "Unique Conversions",
                                                               "Source Cost $/Rs",
                                                               "Revenue $/Rs."
                                                              ];
                                           @endphp

                                            {!!view('layouts.column', ['data' =>$heads])!!}
                                                       
                                                </div>
                                        </form>
                            </div>
    <div class="col-sm-12">
                    
                            
                            <div class="table-responsive">
                                <table class="table color-table info-table scrollTable">
                                    <thead>
                                        {!!view('layouts.tablehead', ['data' =>$heads])!!}
                                    </thead>
                                    <tbody>
                                    @php
                                       $totalClick = 0;
                                       $totalconversion = 0;
                                       $clicks_active_count = 0;
                                       $total_cost = 0;
                                       $final_profit = 0;
                                       $totalconversion_count_unique = 0;
                                       $allTotalCost = 0;
                                       $totalReven = 0;
                                    @endphp
                                    
                                    @foreach($data as $fetch_records)
                                        <tr>
                                            <td>{{$id}}</td>
                                            <td>{{$fetch_records->name}}</td>
                                            <td>{{$fetch_records->clickcount}}</td>
                                            <td>{{$fetch_records->conversion_count}}</td>
                                            <td>{{$fetch_records->clicks_active_count}}</td>
										    <td>
										        @php 
										                $val1=$fetch_records->conversion_count; 
										                $val2=$fetch_records->clickcount;
										                $val3=($val1/$val2)*100;
										                echo round($val3, 2)."%";
										        @endphp
										    </td>
										    <td>
										        @php
										                $val4=$fetch_records->clicks_active_count;
										                $val5=$fetch_records->clickcount;
										                $val6=($val4/$val5)*100;
										                echo round($val6, 2)."%";
										        @endphp
										    </td>
                                            <td>{{$fetch_records->conversion_count_unique}} </td>
                                            <td>{{$fetch_records->total_cost}} / {{round($fetch_records->total_cost * 65, 2)}}</td>
                                            <td> {{number_format($fetch_records->revenue_dollar, 2)}}/{{round($fetch_records->revenue_dollar * 65, 2)}}</td>
                                    
                                         
                                        </tr>
                                        @php 
                                            $totalClick += $fetch_records->clickcount;
                                            $totalconversion += $fetch_records->conversion_count;
                                            $clicks_active_count += $fetch_records->clicks_active_count;
                                            $totalconversion_count_unique += $fetch_records->conversion_count_unique;
                                            $allTotalCost += round($fetch_records->total_cost * 65, 2);
                                            $total_cost += $fetch_records->total_cost; 
                                            $final_profit += ($final_profit + number_format($fetch_records->revenue_dollar, 2));
                                            $totalReven += round($fetch_records->revenue_dollar * 65, 2);
                                        @endphp
                                       @endforeach
                                       <tr>
                                            <td></td>
                                            <td>Total</td>
                                           
                                            <td>{{$totalClick}}</td>
                                            <td>{{$totalconversion}}</td>
                                            <td>{{$clicks_active_count}}</td>
                                            <td></td>  
                                            <td></td>
                                            <td>{{$totalconversion_count_unique}}</td>
                                            <td>{{$total_cost}}/{{$allTotalCost}}</td>
                                            <td>{{$final_profit}}/{{$totalReven}}</td>
                                        </tr>
                                    </tbody>
                                    {!!view('layouts.tablefoot', ['data' =>$heads,'class'=>"new"])!!}
                                </table>

                            </div>    
                                   
    </div>


@endsection
