@extends('layouts.app')
@section('heading')
  {{$header}}
@endsection
@section('custom_js')
<script src="../plugins/bower_components/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script type="text/javascript">
    jQuery('.mydatepicker').datepicker({
       format:"yyyy-mm-dd"
    });
</script>
@endsection
@section('content')
        @if(sizeof($data) !== 0)  
       <div class="row">
            <div class="col-sm-12 pull-right"><strong class="text-danger">Last Updated Time : {{ $data[sizeof($data)-1]->create_time}}</strong></div>
        </div>
        @endif    
       <div class="m-b-15 header-panel">
        <form class="form-inline" role="form" method="POST" action="{{route($routename)}}">
                        {{ csrf_field() }}    
                                               <div class="form-group">
                                                         
                                                    <input type="text" class="form-control" value="{{$total}}" name="total">
                                                </div>

                                                <div class="form-group">
                                                    <select name='id_channel' data-preload="true" 
                                                     class="col-md-2 select2 mySelect form-control" id="chanel" >
                                                       <option value="0">Select Network</option>
                                                       @foreach ($ddData['network_dropdown'] as $network_id => $network_name)
                                                       <option value="{{$network_id}}" {{$network_id == $id_channel ? "selected":""}}>{{$network_name}}</option>
                                                       @endforeach
                                                     </select>
                                                </div>
                            
                                                <div class="form-group">
                                                  <select name="operator_id" class="mySelect select2 form-control"  id="operator_id" >
                                                   <option value="0">Select Operator</option>
                                                     @foreach ($ddData['operator_dropdown'] as $operator_id1 => $operator_name)
                                                      <option value="{{$operator_id1}}" {{$operator_id1 == $operator_id ? "selected":""}}>{{$operator_name}}
                                                      </option>
                                                      @endforeach
                                                  </select>
                                                </div>
                                                <div class="form-group">
                                                        <label class="control-label "></label> 
                                                        <select class="form-control full mySelect" name="traffic_type">
                                                            <option value="0">All Ad Category</option>
                                                             @foreach ($ddData['traffictype_dropdown'] as $traffic)
                                                              <option {{$traffic == $traffic_type ? "selected":""}} value="{{$traffic}}" >{{$traffic}}</option>
                                                              @endforeach
                                                 
                                                        </select>
                                                </div>
                                               
                                                <div class="form-group">
                                                        <label class="control-label "></label> 
                                                        <select class="form-control full mySelect" name="country">
                                                            <option value="0">Select Country</option>
                                                             @foreach ($ddData['country_dropdown'] as $key =>$val)
                                                              <option value="{{$key}}" {{$key == $country ? "selected":""}} >{{$val}}</option>
                                                              @endforeach
                                                 
                                                        </select>
                                                </div>
                                                <div class="form-group ">
                                                        
                                                        <div class="input-group">
                                                                <input type="text" value="{{$dtvalue}}" class="form-control mydatepicker" name="start" placeholder="From">
                                    
                                                        </div>
                                                </div>
                                                <div class="form-group ">
                                                       
                                                       <div class="input-group">
                                                                <input type="text" name="end" value="{{$dtvalue2}}" class="form-control mydatepicker" placeholder="To">
                                    
                                                        </div>
                                                </div>
                                                <div class="form-group">
                                                     <button type="submit" class="btn btn-success waves-effect waves-light">GO</button>
                                        
                                                @php
                                                  $heads =  ["Ad ID"=>"id_ad",
                                                               "Traffic Source"=>"network_name",
                                                               "Source CPA($)"=>"",
                                                               "Telco"=>"op_name",
                                                               "Ad Categor"=>"",
                                                               "Advertiser Campaign Name"=>"",
                                                                "Country"=>"",
                                                               "Clicks Count"=>"clickcount",
                                                               "Conversion Inward"=>"",
                                                               "Conversion Outward"=>"",
                                                               "CR Inward"=>"",
                                                               "CR Outward"=>"",
                                                               "Unique Conversion"=>"",
                                                               "Adnetwork CR Goal"=>"",
                                                               "Source Cost $/Rs"=>"",
                                                               "Revenue (Rs.)"=>"",
                                                               "Profit (Rs.)"=>"",
                                                               "Remarks"=>""];

                                           @endphp

                                            {!!view('layouts.column', ['data' =>$heads])!!}
                                                       
                                                </div>
                                        </form>
                            </div>
    <div class="col-sm-12">
                    
                            
                            <div class="table-responsive1 mainTableInfo">
                                <table class="table color-table info-table scrollTable">
                                    <thead>
                                        {!!view('layouts.tablehead', ['data' =>$heads])!!}
                                    </thead>
                                    <tbody>
                                      @php
                                      $clickcount = 0;
                                            $conversion_count = 0;
                                            $clicks_active_count = 0;
                                            $cr_received = 0;
                                           
                                            $cr_given = 0;
                                             $conversion_count_unique = 0;$conversion_count_unique = 0;
                                            $cr_goal = 0;
                                              $sourcost = 0;
                                            $convCount = 0;
                                            $profit = 0;
                                    @endphp
                                    @foreach($data as $fetch_records)
                                        <tr>
                                            <td>{{$fetch_records->id_ad}}</td>
                                            <td><a href="/network-cr-update-single-network/{{$fetch_records->id_ad}}?start={{$dtvalue}}&end={{$dtvalue2}}">{{$fetch_records->network_name}}</a></td>
                                            <td>{{$fetch_records->network_cpa}}</td>
                                            <td>{{$fetch_records->op_name}}</td>
                                            <td>{{$fetch_records->traffic_type}}</td>
                                            <td>{{$fetch_records->adv_name}}</td>
                                            <td>{{array_key_exists($fetch_records->country_code,$ddData['country_dropdown'])?$ddData['country_dropdown'][$fetch_records->country_code]:""}}</td>
                                            <td>{{$fetch_records->clickcount}}</td>
                                            <td>{{$fetch_records->conversion_count}}</td>
                                            <td>{{$fetch_records->clicks_active_count}}</td>
                                            <td>{{$fetch_records->cr_received}} % </td>
                                            <td>{{$fetch_records->cr_given}} %</td>
                                            <td>{{$fetch_records->conversion_count_unique}}</td>
                                            <td> {{$fetch_records->cr_goal}} %</td>
                                        
                                            <td> {{$fetch_records->total_cost}}/{{round($fetch_records->total_cost * 65, 2)}}</td>
                                             <td> {{$fetch_records->cpa * $fetch_records->conversion_count}}</td>
                                           <td> {{$fetch_records->cpa * $fetch_records->conversion_count - round($fetch_records->total_cost * 65, 2)}}</td>
                                            <td><input class="form-control" type="text" value="" id="example-text-input"></td>
                                         
                                        </tr>
                                         @php 
                                            $clickcount += $fetch_records->clickcount;
                                            $conversion_count += $fetch_records->conversion_count;
                                            $clicks_active_count += $fetch_records->clicks_active_count;
                                            $cr_received += $fetch_records->total_cost; 
                                           
                                            $cr_given += $fetch_records->cr_given;
                                             $conversion_count_unique += $fetch_records->conversion_count_unique;
                                            $cr_goal += $fetch_records->cr_goal;
                                            $sourcost += $fetch_records->total_cost;
                                            $convCount += $fetch_records->cpa * $fetch_records->conversion_count;
                                            $profit += $fetch_records->cpa * $fetch_records->conversion_count - round($fetch_records->total_cost * 65, 2);
                                        @endphp
                                       @endforeach
                                         <tr>
                                            <td></td>
                                            <td>Total</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                              <td></td>
                                            <td></td>
                                             <td>{{$clickcount}}</td>
                                            <td>{{$conversion_count}}</td>
                                            <td>{{$clicks_active_count}}</td>
                                            <td>{{$cr_received}} % </td>
                                            <td>{{$cr_given}} %</td>
                                            <td>{{$conversion_count_unique}}</td>
                                            <td> {{$cr_goal}} %</td>
                                             <td>{{$sourcost}}</td>
                                            <td>{{$convCount}}</td>
                                            <td> {{$profit}}</td>
                                        </tr>
                                    </tbody>
                                </table>

                            </div> 
                            @if($total != "all")   
                             <div class="pagination-wrapper"> {!! $data->appends(['search' => Request::get('search'),'order' =>Request::get('order') ,'colorder'=>Request::get('colorder')])->render() !!} 
                            </div>      
                            @endif 
    </div>


@endsection
