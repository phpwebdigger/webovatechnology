@extends('layouts.app')


@section('heading')
  {{$header}}
@endsection
@section('custom_js')
<script src="../plugins/bower_components/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script type="text/javascript">
    jQuery('.mydatepicker, #datepicker').datepicker();
</script>
@endsection
@section('content')
      @if(sizeof($data) !== 0)  
       <div class="row">
            <div class="col-sm-12 pull-right"><strong class="text-danger">Last Updated Time : {{ $data[sizeof($data)-1]->create_time}}</strong></div>
        </div>
        @endif 
       <div class="m-b-15">
        <form class="form-inline" role="form" method="GET" action="{{route($routename)}}">
                        {{ csrf_field() }}    
                                               
                                               
                                               
                                                 <div class="form-group col-md-1">
                                                        
                                                        <div class="input-group">
                                                                <input type="text" value="{{$dtvalue}}" class="form-control mydatepicker" name="start" placeholder="From">
                                    
                                                        </div>
                                                </div>
                                                <div class="form-group col-md-1">
                                                       
                                                       <div class="input-group">
                                                                <input type="text" name="end" value="{{$dtvalue2}}" class="form-control mydatepicker" placeholder="To">
                                    
                                                        </div>
                                                </div>
                                                <div class="form-group col-md-2">
                                                     <button type="submit" class="btn btn-success waves-effect waves-light">GO</button>
                                        
                                                @php
                                                  $heads =  ["Id Ad",
                                                               "Id Channel",
                                                               "Advertiser Campaign Name",
                                                               "Adnetwork Name",
                                                               "Telco",

                                                               "Clicks Count",
                                                               "Conversion Inwards",
                                                               "Conversion Outward",
                                                               "CR Inwards",
                                                               "CR Outward",
                                                              
                                                               "CR Expected",
                                                               "Source Cost $"
                                                              ];
                                           @endphp

                                            {!!view('layouts.column', ['data' =>$heads])!!}
                                                       
                                                </div>
                                        </form>
                            </div>
    <div class="col-sm-12">
                    
                            
                            <div class="table-responsive mainTableInfo m-t-20">
                                <table class="table color-table info-table scrollTable">
                                    <thead>
                                        {!!view('layouts.tablehead', ['data' =>$heads])!!}
                                    </thead>
                                    <tbody>
                                    @php
                                       $totalClick = 0;
                                       $totalconversion = 0;
                                       $clicks_active_count = 0;
                                       $total_cost = 0;
                                       $final_profit = 0;
                                    @endphp
                                    
                                    @foreach($data as $fetch_records)
                                        <tr>
                                            <td>{{$fetch_records->id_ad}}</td>
                                             <td><a href="/network-cr-update-single-chanel?id_channel={{$fetch_records->id_channel}}?start={{$dtvalue}}&end={{$dtvalue2}}">{{$fetch_records->id_channel}}</a></td>
                                          
                                           
                                            <td>{{$fetch_records->name}}</td>
                                            <td>{{$fetch_records->network_name}}</td>
                                            <td>{{$fetch_records->op_name}}</td>
                                          
                                            <td>{{$fetch_records->clickcount}}</td>
                                            <td>{{$fetch_records->conversion_count}}</td>
                                            <td>{{$fetch_records->clicks_active_count}}</td>
                                            <td>{{$fetch_records->cr_received}}% </td>
                                            <td>{{$fetch_records->cr_given}}%</td>
                                            <td> {{$fetch_records->cr_goal}}%</td>
                                        
                                            <td> {{$fetch_records->total_cost}}</td>
                                             
                                         
                                        </tr>
                                        @php 
                                            $create_time = $fetch_records->create_time;
                                            $totalClick += $fetch_records->clickcount;
                                            $totalconversion += $fetch_records->conversion_count;
                                            $clicks_active_count += $fetch_records->clicks_active_count;
                                           
                                        @endphp
                                       @endforeach
                                       <tr>
                                            <td></td>
                                            <td>Total</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td>{{$totalClick}}</td>
                                            <td>{{$totalconversion}}</td>
                                            <td>{{$clicks_active_count}}</td>
                                            <td></td>  
                                            <td></td>
                                            <td></td>
                                            
                                            <td></td>
                                        </tr>
                                    </tbody>
                                </table>

                            </div>    
                                   
    </div>


@endsection
