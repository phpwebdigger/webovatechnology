@extends('layouts.app')
@section('heading')
  {{$header}}
@endsection
@section('custom_js')
<script src="../plugins/bower_components/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script type="text/javascript">
    jQuery('.mydatepicker').datepicker({
       format:"yyyy-mm-dd"
    });

  $(document).ready(function() {

        var data =   {!! json_encode($data1) !!};        
       createTableWithLazyLoad("#tableLazy",data,50);
       
    } );
  </script>
@endsection
@section('content')
        <div class="row">
         <div class="col-sm-12"><strong>Last Updated Time : {{ $update_time}}</strong></div> 
       </div>
       <div class="m-b-15  header-panel-form">
        <form class="form-inline" role="form" method="POST" action="{{route($routename)}}">
                        
                                        
                                                @php
                                                  $heads =  ["Ad ID",
                                                               "Traffic Source",
                                                               "Source CPA($)",
                                                               "Telco",
                                                               "Ad Categor",
                                                               "Advertiser Campaign Name",
                                                                "Country",
                                                               "Clicks Count",
                                                               "Actula Clicks",
                                                               "Conversion Inward",
                                                               "Conversion Outward",
                                                               "CR Inward",
                                                               "CR Outward",
                                                               "Unique Conversion"
                                                               ];
                                                   $heads2 =  ["Total",
                                                               "",
                                                               "",
                                                               "",
                                                               "",
                                                               "",
                                                                "",
                                                               $lastRow[0],
                                                               $lastRow[1],
                                                               $lastRow[2],
                                                               $lastRow[3],
                                                               "",
                                                               "",
                                                               $lastRow[4]
                                                             ];              


                                           @endphp

                                            {!!view('layouts.columnNew', ['data' =>$heads])!!}
                                                       
                                           </form>
                            </div>
    <div class="col-sm-12">
                    
                            
                            <div class="table-responsive mainTableInfo">
                                <table class="table color-table info-table scrollTable lazy" id="tableLazy">
                                   
                                        {!!view('layouts.tableheadNew', ['data' =>$heads,'class'=>""])!!}
                                        {!!view('layouts.tableheadNew', ['data' =>$heads2,'class'=>"new"])!!}
                                        {!!view('layouts.tablefoot', ['data' =>$heads,'class'=>"new"])!!}
                                   
                                </table>

                            </div>    
                                  
    </div>


@endsection
