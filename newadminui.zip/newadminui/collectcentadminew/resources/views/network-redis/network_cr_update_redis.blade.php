@extends('layouts.app')
@section('heading')
  {{$header}}
@endsection
@section('custom_js')
<script src="../plugins/bower_components/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script type="text/javascript">
    jQuery('.mydatepicker').datepicker({
       format:"yyyy-mm-dd"
    });

  $(document).ready(function() {

        var data =   {!! json_encode($data1) !!};        
       createTableWithLazyLoad("#tableLazy",data,50);
       $(".remark").keyup(function(){
        if(true){
            var id_ad = $(this).attr("myID");
            var content = $(this).val();
            var UrlToPass = 'action=remarks_data&remarks='+content+'&ad_id='+id_ad;
            // $.ajax({
                 
            //                     url : 'crc_network_campaign_ajax.php',
            //                     type : 'POST',
            //                     data : UrlToPass,
            //                        success: function(data){
            //                          $("#sucess").html(data);
            //                          $("#sucess").fadeOut();
            //                 }
            //             });
            // }
        }
       });
       
    } );
   function submitremarks(id_ad){
      var content = document.getElementById("remarks_"+id_ad).value;
      if(content=="")
      {
        alert("Nothings text");
        return false;
        //$("#remarks_"+id_ad).focus();
      }
      var UrlToPass = 'action=remarks_data&remarks='+content+'&ad_id='+id_ad;
      $.ajax({

                    url : 'crc_network_campaign_ajax.php',
                    type : 'POST',
                    data : UrlToPass,
                       success: function(data){
                         $("#sucess").html(data);
                         $("#sucess").fadeOut();
                }
            });
  }
  </script>
@endsection
@section('content')
       <div class="row">
         <div class="col-sm-12"><strong>Last Updated Time : {{ $update_time}}</strong></div> 
       </div> 
       <div class="m-b-15  header-panel-form">
        <form class="form-inline" role="form" method="POST" action="{{route($routename)}}">
                        {{ csrf_field() }}    
                                               <div class="form-group hide">
                                                         
                                                    <input type="text" class="form-control" value="{{$total}}" name="total">
                                                </div>

                                                <div class="form-group ">
                                                         
                                                    <select name='id_channel' data-preload="true" 
                                                     class="select2 mySelect form-control" id="chanel" >
                                                       <option value="0"> Network</option>
                                                       @foreach ($ddData['network_dropdown'] as $network_id => $network_name)
                                                       <option value="{{$network_id}}" {{$network_id == $id_channel ? "selected":""}}>{{$network_name}}</option>
                                                       @endforeach
                                                     </select>
                                                </div>
                            
                                                <div class="form-group ">
                                                  <select name="operator_id" class="mySelect select2 form-control"  id="operator_id" >
                                                   <option value="0"> Operator</option>
                                                     @foreach ($ddData['operator_dropdown'] as $operator_id1 => $operator_name)
                                                      <option value="{{$operator_id1}}" {{$operator_id1 == $operator_id ? "selected":""}}>{{$operator_name}}
                                                      </option>
                                                      @endforeach
                                                  </select>
                                                </div>
                                                <div class="form-group ">
                                                        <label class="control-label "></label> 
                                                        <select class="form-control full mySelect" name="traffic_type">
                                                            <option value="0">All Ad Category</option>
                                                             @foreach ($ddData['traffictype_dropdown'] as $traffic)
                                                              <option {{$traffic == $traffic_type ? "selected":""}} value="{{$traffic}}" >{{$traffic}}</option>
                                                              @endforeach
                                                 
                                                        </select>
                                                </div>
                                               
                                                <div class="form-group ">
                                                        <label class="control-label "></label> 
                                                        <select class="form-control full mySelect" name="country">
                                                            <option value="0">Select Country</option>
                                                             @foreach ($ddData['country_dropdown'] as $key =>$val)
                                                              <option value="{{$key}}" {{$key == $country ? "selected":""}} >{{$val}}</option>
                                                              @endforeach
                                                 
                                                        </select>
                                                </div>
                                                <div class="form-group">
                                                        
                                                        <div class="input-group">
                                                                <input type="text" value="{{$dtvalue}}" class="form-control mydatepicker" name="start" placeholder="From">
                                    
                                                        </div>
                                                </div>
                                                <div class="form-group ">
                                                       
                                                       <div class="input-group">
                                                                <input type="text" name="end" value="{{$dtvalue2}}" class="form-control mydatepicker" placeholder="To">
                                    
                                                        </div>
                                                </div>
                                                <div class="form-group ">
                                                     <button type="submit" class="btn btn-success waves-effect waves-light">GO</button>
                                        
                                                @php
                                                  $heads =  ["Ad ID",
                                                               "Traffic Source",
                                                               "Source CPA($)",
                                                               "Telco",
                                                               "Ad Category",
                                                               "Advertiser Campaign Name",
                                                               "Country",
                                                               "Os Type",
                                                               "Incent Type",
                                                               "Clicks Count",
                                                               "Actual Click",
                                                             
                                                               "Conversion Inward",
                                                               "Conversion Outward",
                                                               "CR Inward",
                                                               "CR Outward",
                                                               "Unique Conversion",
                                                             
                                                               "Source Cost $/Rs",
                                                               "Revenue (Rs.)",
                                                                "ECPM $/Rs.",
                                                               "Profit (Rs.)",
                                                               "Remarks"];
                                                 $heads2 =  ["Total",
                                                               "",
                                                               "",
                                                               "",
                                                               "",
                                                               "",
                                                               "",
                                                               "",
                                                                "",
                                                               $lastRow[0],
                                                               $lastRow[1],
                                                               $lastRow[2],
                                                               $lastRow[3],
                                                               "",
                                                               "",
                                                               $lastRow[4],
                                                             
                                                               $lastRow[5],
                                                               $lastRow[6],
                                                               $lastRow[7],
                                                               $lastRow[8],
                                                               ""];              


                                           @endphp

                                            {!!view('layouts.columnNew', ['data' =>$heads])!!}
                                          
                                                       
                                                </div>
                                        </form>
                            </div>
    <div class="col-sm-12">
                    
                            
                            <div class="table-responsive mainTableInfo">
                                <table class="table color-table info-table scrollTable lazy" id="tableLazy">
                                    
                                        {!!view('layouts.tableheadNew', ['data' =>$heads,'class'=>""])!!}
                                        {!!view('layouts.tableheadNew', ['data' =>$heads2,'class'=>"new"])!!}
                                        {!!view('layouts.tablefoot', ['data' =>$heads,'class'=>"new"])!!}   
                                    
                                </table>
                                <table>
                                
                                </table>

                            </div> 
                           
    </div>


@endsection
