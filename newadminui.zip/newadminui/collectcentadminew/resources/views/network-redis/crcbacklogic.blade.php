@extends('layouts.app')
@section('heading')
  {{$header}}
@endsection
@section('custom_js')

<script src="../plugins/bower_components/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script type="text/javascript">
    jQuery('.mydatepicker, #datepicker').datepicker();
    $(document).ready(function() {
          var  $heads =  ["text_40px",
                           "text_400px",
                           "text_40px",
                           "text_40px",
                           "text_40px",
                           "text_40px",
                           "text_40px",
                           "text_40px",
                          ];

        var data =   {!! json_encode($data1) !!};        
       createTableWithLazyLoad("#tableLazy",data,1000,$heads);
       
    });

</script>
@endsection
@section('content')
       <div class="m-b-15">
        <div class="row">
         <div class="col-sm-12"><span class="text-danger pull-right">Last Updated Time : {{ $update_time}}</span></div> 
        </div>
        <form class="form-inline" role="form" method="POST" action="{{route($routename,$id)}}">
          {{ csrf_field() }}    
              <div class="form-group col-md-1">
                <div class="input-group">
                  <input type="text" value="{{$dtvalue}}" class="form-control mydatepicker" name="start" placeholder="From">
                </div>
              </div>
              <div class="form-group col-md-1">
                <div class="input-group">
                  <input type="text" name="end" value="{{$dtvalue2}}" class="form-control mydatepicker" placeholder="To">
                </div>
              </div>
              <div class="form-group col-md-2">
              <button type="submit" class="btn btn-success waves-effect waves-light">GO</button>
              @php
              $heads =  ["Id Ad",
                          "Advertiser Campaign Name",
                           "Telco",
                           "Traffic Type",
                           "Clicks Count",
                           "Conversion Inwards",
                           "CR Inwards",
                           "Revenue $/Rs.",
                          ];
              $heads2 =  ["Total",
                             "",
                             "",
                             "",
                             $lastRow[0],
                             $lastRow[1],
                             "",
                             $lastRow[2]
                             ];              
                            @endphp
                  {!!view('layouts.column', ['data' =>$heads])!!}
                  </div>
                  </form>
              </div>
    <div class="col-sm-12">
                    
                            
                            <div class="table-responsive mainTableInfo">
                               <table class="table color-table info-table scrollTable lazy" id="tableLazy">
                                    {!!view('layouts.tableheadNew', ['data' =>$heads,'class'=>""])!!}
                                    {!!view('layouts.tableheadNew', ['data' =>$heads2,'class'=>"new"])!!}    
                                     {!!view('layouts.tablefoot', ['data' =>$heads,'class'=>"new"])!!}      
                                    
                                </table>
                                <table>
                                </table>  

                               

                            </div>    
                                   
    </div>


@endsection
