@extends('layouts.app')
@section('heading')
  {{$header}}
@endsection
@section('custom_js')
@php
        $coloredColumn[0]['column'] = '1,3,4,5,6,7,8';
        $coloredColumn[0]['classname'] = 'bg-success';
        $coloredColumn[1]['column'] = '1';
        $coloredColumn[1]['classname'] = 'bg-danger';
       
@endphp
<script src="../plugins/bower_components/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script type="text/javascript">
    jQuery('.mydatepicker').datepicker({
       format:"yyyy-mm-dd"
    });

  $(document).ready(function() {
        
        var data =   {!! json_encode($data1) !!};  
        var ColoredColumn = {!! json_encode($coloredColumn) !!};
        var  $heads =  ["text_60px",
                       "text_60px",
                       "text_60px",
                       "text_60px",
                       "text_60px",
                       "text_400px",
                       "text_30px",
                       "text_60px",
                       "text_60px",
                       "text_60px",
                       "text_60px",
                       "text_60px",
                       "text_60px",
                       "text_60px",
                       "text_60px",
                       "text_60px",
                       "text_60px",
                       "text_60px",
                       "text_60px",
                       "text_30px",
                       "text_60px"
                       ];
        
       createTableWithLazyLoad("#tableLazy",data,50,$heads);
       $(".remark").keyup(function(){
        if(true){
            var id_ad = $(this).attr("myID");
            var content = $(this).val();
            var UrlToPass = 'action=remarks_data&remarks='+content+'&ad_id='+id_ad;
          }
       });
       
    } );
   function submitremarks(id_ad){
      var content = document.getElementById("remarks_"+id_ad).value;
      if(content=="")
      {
        alert("Nothings text");
        return false;
        //$("#remarks_"+id_ad).focus();
      }
      var UrlToPass = 'action=remarks_data&remarks='+content+'&ad_id='+id_ad;
      $.ajax({

                    url : 'crc_network_campaign_ajax.php',
                    type : 'POST',
                    data : UrlToPass,
                       success: function(data){
                         $("#sucess").html(data);
                         $("#sucess").fadeOut();
                }
            });
     }
  </script>
@endsection
@section('content')
       <div class="row">
          <div class="col-sm-12"><span class="pull-right text-danger">Last Updated Time : {{ $update_time}}</span></div> 
        </div> 
       <div class="m-b-15  header-panel-form">
        <form class="form-inline" role="form" method="POST" action="{{route($routename)}}">
                        {{ csrf_field() }}    
                     <div class="form-group hide">
                          <input type="text" class="form-control" value="{{$total}}" name="total">
                      </div>
                        
                        <div class="form-group">
                            <div class="input-group">
                                <input type="text" value="{{$dtvalue}}" class="form-control mydatepicker" name="start" placeholder="From">
                            </div>
                        </div>
                              <div class="form-group ">
                                     
                                     <div class="input-group">
                                              <input type="text" name="end" value="{{$dtvalue2}}" class="form-control mydatepicker" placeholder="To">
                  
                                      </div>
                              </div>
                              <div class="form-group ">
                                   <button type="submit" class="btn btn-success waves-effect waves-light">GO</button>
                      
                              @php
                                $heads =  ["Ad ID",
                                             "Traffic Source",
                                             "Source CPA($)",
                                             "Telco",
                                             "Ad Cat",
                                             "Campaign Name",
                                             "Country",
                                             "Os Type",
                                             "Incent Type",
                                             "Clicks Count",
                                             "Actual Click",
                                             "Conv Inward",
                                             "Conv Outward",
                                             "CR Inward",
                                             "CR Outward",
                                             "Unique Conv",
                                             "Source Cost $/Rs",
                                             "Revenue (Rs.)",
                                             "ECPC $/Rs.",
                                             "Profit (Rs.)",
                                             "Remarks"];
                               $heads2 =  ["Total",
                                             "",
                                             "",
                                             "",
                                             "",
                                             "",
                                             "",
                                             "",
                                              "",
                                             $lastRow[0],
                                             $lastRow[1],
                                             $lastRow[2],
                                             $lastRow[3],
                                             "",
                                             "",
                                             $lastRow[4],
                                           
                                             $lastRow[5],
                                             $lastRow[6],
                                             $lastRow[7],
                                             $lastRow[8],
                                             ""];              


                         @endphp

                          {!!view('layouts.columnNew', ['data' =>$heads])!!}
                        
                                     
                              </div>
                      </form>
                            </div>
    <div class="col-sm-12">
                    
                            
                            <div class="table-responsive mainTableInfo"> 
                               
                                   <table id="tableLazy" class="table color-table info-table scrollTable lazy"> 
                                        {!!view('layouts.tableheadNew', ['data' =>$heads,'class'=>""])!!}
                                        {!!view('layouts.tableheadNew', ['data' =>$heads2,'class'=>"new" ])!!}
                                         {!!view('layouts.tablefoot', ['data' =>$heads,'class'=>"new"])!!}    
                                    
                                </table>
                               

                            </div> 
                           
    </div>


@endsection
