@extends('layouts.app')

@section('bread')
                        <ol class="breadcrumb">
                            <li><a href="#">Dashboard</a></li>
                            <li class="active">Query</li>
                        </ol>
@endsection

@section('heading')
  Execute Query
@endsection
@section('content')

<div class="container-fluid">
                
                <div class="row">
                    
                    <div class="col-sm-12 ">
                        <div class="white-box">
                            <form data-toggle="validator" method="POST" action="{{ route('query')}}">
                                {{ csrf_field() }}
                                <div class="form-group">
                                    <label for="inputName" class="control-label">Sql Query</label>
                                    <textarea name="querycheck" rows = "10" class="form-control" id="inputName" placeholder="input your query"required>{{$query}}</textarea>
                                    </div>
                                   
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-success">Execute</button>
                                        

                                    </div>
                                    
                            </form>
                           @if(count($results) != 0)
                            <div class="table-responsive">
                           <a id="dlink"  style="display:none;"></a>
                            <button type="button" class="btn btn-success pull-right" onclick="tableToExcel('downlaod', 'name', 'results.xls')" ><i class="fa fa-download" aria-hidden="true"></i></button>

                             @php
                                 $keyArray = [];
                                foreach($results[0] as $key => $value){
                               
                                    array_push($keyArray,$key);
                           
                                 }
                           
                                
                            @endphp
                                <table class="table color-table success-table info-table" id="downlaod">
                                    <thead>
                                        <tr>
                                        @foreach($keyArray as $value)
                                            <th>{{$value}}</th>
                                        @endforeach

                                        </tr>
                                    </thead>
                                    <tbody>
                                    @foreach ($results as $user)
                                        <tr>

                                            @foreach($keyArray as $k)
                                                <td>{{$user->$k}}</td>
                                             @endforeach
                            
                                            
                                        </tr>
                                     @endforeach
                                    </tbody>
                                </table>
                            </div>
                            @endif
                        </div>
                    </div>
                    
                    
                    
                   
                
@endsection
@section('custom_js')
    <script type="text/javascript">
   
       var tableToExcel = (function () {
        var uri = 'data:application/vnd.ms-excel;base64,'
        , template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>'
        , base64 = function (s) { return window.btoa(unescape(encodeURIComponent(s))) }
        , format = function (s, c) { return s.replace(/{(\w+)}/g, function (m, p) { return c[p]; }) }
        return function (table, name, filename) {
            if (!table.nodeType) table = document.getElementById(table)
            var ctx = { worksheet: name || 'Worksheet', table: table.innerHTML }

            document.getElementById("dlink").href = uri + base64(format(template, ctx));
            document.getElementById("dlink").download = filename;
            document.getElementById("dlink").click();

        }
    })()
       
    </script>
@endsection
