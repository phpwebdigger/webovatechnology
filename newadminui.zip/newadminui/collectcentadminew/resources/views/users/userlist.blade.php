@extends('layouts.app')
@section('custom_css')
<link rel="stylesheet" type="text/css" href="{{asset('plugins/bower_components/switchery/dist/switchery.min.css')}}" />
@endsection

@section('bread')
      <ol class="breadcrumb">
        <li><a href="#">Dashboard</a></li>
        <li class="active">Users</li>
       </ol>
@endsection

@section('heading')
 Users List
@endsection

@section('content')
    <div class="container-fluid">
                
                <div class="row">
                    
                    <div class="col-sm-12 ">
                            
                       <a href="/users/register"><button class="btn btn-success waves-effect waves-light pull-right" type="button" style="margin-bottom: 10px;"><span class="btn-label"><i class="fa fa-plus"></i></span>Add User</button></a>
                            
                            <div class="table-responsive">
                                <table class="table color-table success-table info-table">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Role</th>
                                            <th>Status</th>
                                            <th>Action</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($users as $user)
                                            <tr>
                                                <td>{{$user->id}}</td>
                                                <td>{{$user->name}}</td>
                                                <td>{{$user->email}}</td>
                                                 <td>{{$user->roles ?$user->roles->name:""}}</td>
                                                <td>
                                                   @if($user->status==1)
                                                    
                                                        <div class="label label-success">
                                                            <strong>Active</strong>
                                                        </div>
                                                    
                                                     @else 
                                                    
                                                        <div class="label label-danger">
                                                            <strong>Deactive</strong>
                                                        </div>
                                                    
                                                    @endif

                                                </td>
                                                <td><a href="/users/edit/{{$user->id}}"><button type="button" class="btn btn-danger btn-circle "><i class="fa fa-edit"></i> </button>
                                                </a>&nbsp;
                                                <a href="/users/delete/{{$user->id}}"><button type="button" class="btn btn-danger btn-circle"><i class="fa fa-times"></i> </button></a></td>
                                            </tr>
                                         @endforeach
                                    </tbody>
                                </table>
                                <div class="pagination-wrapper"> {!! $users->appends(['search' => Request::get('search')])->render() !!} 
                                </div>
                            </div>
                       
                    </div>
                </div>
    </div>

                
@endsection
