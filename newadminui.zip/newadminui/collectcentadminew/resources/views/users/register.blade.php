@extends('layouts.app')
@section('custom_css')
<link rel="stylesheet" type="text/css" href="{{asset('plugins/bower_components/switchery/dist/switchery.min.css')}}" />
@endsection
@section('bread')
    <ol class="breadcrumb">
        <li><a href="#">Dashboard</a></li>
        <li class="active">Add User</li>
    </ol>
@endsection
@section('heading')
  Add User
@endsection
@section('custom_js')
<script src="{{asset('plugins/bower_components/switchery/dist/switchery.min.js')}}" type="text/javascript"></script>
<script src="{{asset('js/validator.js')}}"></script>
<script type="text/javascript">
     var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
       $('.js-switch').each(function() {
           new Switchery($(this)[0], $(this).data());

       });
</script>
@endsection
@section('content')
    <div class="row">
                    
                    <div class="col-sm-6">
                        <div class="white-box">
                            
                            <form data-toggle="validator" method="POST" action="{{ url('users/register') }}">
                              {{ csrf_field() }}
                                <div class="form-group">
                                    <label for="inputName" class="control-label">Name</label>
                                    <input type="text"  name="name" value="" class="form-control" id="inputName" placeholder="input your name" required>
                                    <div class="help-block with-errors"></div>
                                     @if($errors->has('name'))
                                        <div class="help-block with-errors">{{ $errors->first('name') }}</div>
                                     @endif
                                </div>

                                <div class="form-group">
                                    <label for="inputEmail2" class="control-label">Email</label>
                                    <input type="email"  name="email" value="" class="form-control" id="inputEmail2" placeholder="abc@abc.com" data-error="Bruh, that email address is invalid" required>
                                    <div class="help-block with-errors"></div>
                                     @if ($errors->has('email'))
                                        <div class="help-block with-errors">{{ $errors->first('email') }}</div>
                                     @endif
                                </div>

                                <div class="form-group">
                                    <label for="inputPassword" class="control-label">Password</label>
                                    <div class="row">
                                        <div class="form-group col-sm-6">
                                            <input type="password" name="password" data-toggle="validator"  data-minlength="6" class="form-control" id="inputPassword" placeholder="Password" required>
                                            @if ($errors->has('password'))
                                                 <div class="help-block with-errors">{{ $errors->first('password') }}</div>
                                             @endif

                                            <span class="help-block">Minimum of 6 characters</span> </div>
                                        <div class="form-group col-sm-6">
                                            <input type="password"  name="password_confirmation" class="form-control" id="inputPasswordConfirm" data-match="#inputPassword" data-match-error="Whoops, these don't match" placeholder="Confirm Password" required>
                                            <div class="help-block with-errors"></div>
                                             
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                <label for="status" class="control-label">Status</label>
                                        <select name="status" class="form-control">
                                            <option value="1" > Active </option>
                                            <option value="0" > InActive </option>
                                        </select>              
                                      
                                </div>
                                <div class="form-group">
                                   <label for="role" class="control-label">Assign Role</label>
                                    <select name='role' class="col-md-2 select2 form-control" id="role" data-act="ajax-select" data-preload="true" data-post-text="name" data-post-id="id" data-post-key="name"  data-post-table="new_roles" data-placeholder="Assign Role" required></select>
         
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-success">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                                        
    </div>
@endsection
