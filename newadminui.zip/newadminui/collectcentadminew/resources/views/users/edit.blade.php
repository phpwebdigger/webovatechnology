@extends('layouts.app')
@section('custom_css')
<link rel="stylesheet" type="text/css" href="{{asset('plugins/bower_components/switchery/dist/switchery.min.css')}}" />
@endsection

@section('bread')
                            <ol class="breadcrumb">
                                <li><a href="#">Dashboard</a></li>
                                <li class="active">Edit {{$users->name}}</li>
                            </ol>
@endsection

@section('heading')
  Edit {{$users->name}}
@endsection

@section('custom_js')
<script src="{{asset('plugins/bower_components/switchery/dist/switchery.min.js')}}" type="text/javascript"></script>
<script type="text/javascript">
     var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
       $('.js-switch').each(function() {
           new Switchery($(this)[0], $(this).data());

       });
</script>
@endsection
@section('content')
    <div class="row">
                    
                    <div class="col-sm-6">
                        <div class="white-box">

                            <form data-toggle="validator" method="POST" action="{{ url('users/edit') }}">
                                 {{ csrf_field() }}
                                <div class="form-group">
                                    <input type="hidden" name="id" value="{{$users->id}}">
                                    <label for="inputName" class="control-label">Name</label>
                                    <input type="text"  name="name" value="{{ $users->name }}" class="form-control" id="inputName" placeholder="input your name" required>
                                    <div class="help-block with-errors"></div>
                                     @if ($errors->has('name'))
                                        <div class="help-block with-errors">{{ $errors->first('name') }}</div>
                                     @endif
                                </div>

                                <div class="form-group">
                                    <label for="inputEmail2" class="control-label">Email</label>
                                    <input type="email"  name="email" value="{{ $users->email }}" class="form-control" id="inputEmail2" placeholder="abc@abc.com" data-error="Bruh, that email address is invalid" required>
                                    <div class="help-block with-errors"></div>
                                     @if ($errors->has('email'))
                                        <div class="help-block with-errors">{{ $errors->first('email') }}</div>
                                     @endif
                                </div>

                                 <div class="form-group">
                                    <label for="inputPassword" class="control-label">Password</label>
                                    <div class="row">
                                        <div class="form-group col-sm-6">
                                            <input type="password" name="password" value="{{ $users->password }}"  data-toggle="validator" data-minlength="6" class="form-control" id="inputPassword" placeholder="Password" required>
                                            @if ($errors->has('password'))
                                                 <div class="help-block with-errors">{{ $errors->first('password') }}</div>
                                             @endif

                                            <span class="help-block"></span>
                                        </div>
                                        <div class="form-group col-sm-6">
                                            <input type="password"  name="password_confirmation" value="{{ $users->password }}" class="form-control" id="inputPasswordConfirm" data-match="#inputPassword" data-match-error="Whoops, these don't match" placeholder="Confirm Password" required>
                                            <div class="help-block with-errors"></div>
                                             
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group">
                                <label for="status" class="control-label">Status</label>
                                        <select name="status" class="form-control">
                                            <option value="1" {{$users->status == 1 ? "selected":""}}> Active </option>
                                            <option value="0" {{$users->status == 0 ? "selected":""}}> InActive </option>
                                        </select>              
                                      
                                </div>
                                <div class="form-group">
                                   <label for="role" class="control-label">Assign Role</label>
                                    <select name='role' class="col-md-2 select2 form-control" id="role" data-act="ajax-select" data-preload="true" data-post-text="name" data-post-id="id" data-post-key="name" data-initial-id ="{{$users->role_id}}" data-post-table="new_roles" data-placeholder="Assign Role" required></select>
         
                                </div>
                               
                                    </br>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-success" value="save" >update</button>
                                </div>
                            </form>
                        </div>
                    </div>
                                        
    </div>
@endsection
