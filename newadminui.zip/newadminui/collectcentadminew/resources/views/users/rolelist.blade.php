@extends('layouts.app')


@section('bread')
      <ol class="breadcrumb">
        <li><a href="#">Dashboard</a></li>
        <li class="active">Users</li>
        <li class="active">Roles</li>
       </ol>
@endsection

@section('heading')
 Role List
@endsection

@section('content')
    <div class="container-fluid">
                
                <div class="row">
                    
                    <div class="col-sm-12 ">
                            
                       <a href="/users/roles/register"><button class="btn btn-success waves-effect waves-light pull-right" type="button" style="margin-bottom: 10px;"><span class="btn-label"><i class="fa fa-plus"></i></span>Add Roles</button></a>
                            
                            <div class="table-responsive">
                                <table class="table color-table success-table info-table">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Name</th>
                                            
                                            <th>Action</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($roles as $rols)
                                            <tr>
                                                <td>{{$rols->id}}</td>
                                                <td>{{$rols->name}}</td>
                                               
                                            
                                                <td><a href="/users/roles/register/{{$rols->id}}"><button type="button" class="btn btn-danger btn-circle "><i class="fa fa-edit"></i> </button>
                                                </a>&nbsp;
                                                <a href="/role/delete/{{$rols->id}}"><button type="button" class="btn btn-danger btn-circle"><i class="fa fa-times"></i> </button></a></td>
                                            </tr>
                                         @endforeach
                                    </tbody>
                                </table>
                                <div class="pagination-wrapper"> {!! $roles->appends(['search' => Request::get('search')])->render() !!} 
                                </div>
                            </div>
                       
                    </div>
                </div>
    </div>

                
@endsection
