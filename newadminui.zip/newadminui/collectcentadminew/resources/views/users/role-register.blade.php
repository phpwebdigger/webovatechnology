@extends('layouts.app')


@section('bread')
                            <ol class="breadcrumb">
                                <li><a href="#">Dashboard</a></li>
                                <li class="active">Add User</li>
                            </ol>
@endsection

@section('heading')
  Add Roles
@endsection

@section('content')
    <div class="row">
                    
                   
                        <div class="white-box">
                            
                            <form data-toggle="validator" method="POST" action="{{ route('role-add') }}">
                              {{ csrf_field() }}
                              <input type="hidden" name="id" value="{{$users->id}}">
                              <div class="col col-md-6">
                                <div class="form-group">
                                    <label for="inputName" class="control-label">Name</label>
                                    <input type="text"  name="name" value="{{$users->name}}" class="form-control" id="inputName" placeholder="input your name" required>
                                    <div class="help-block with-errors"></div>
                                     @if ($errors->has('name'))
                                        <div class="help-block with-errors">{{ $errors->first('name') }}</div>
                                     @endif
                                </div>

                               
                                
                                <div class="form-group">
                                    <button type="submit" class="btn btn-success">Submit</button>
                                </div>
                                </div>
                                <div class="col-md-6">

                                @foreach (Config::get('role.all') as $key=>$value)
                               
                                <div class="col-md-6">
                                        <div class="form-check">
                                            @php
                                            if(Session::has('roles') && $users->id && in_array($value, explode(',',$users->permission))){
                                               $checked = "checked";
                                            }
                                            else{
                                               $checked = "";
                                            }
                                            @endphp
                                            <label class="custom-control custom-checkbox">
                                                <input type="checkbox" name="permissions[]" {{$checked}} value="{{$value}}" class="custom-control-input">
                                                <span class="custom-control-indicator"></span>
                                                <span class="custom-control-description">{{$key}}</span>
                                            </label>
                                        </div>
                                   
                                </div>
                              
                                 @endforeach
                                </div>
                            </form>

                        </div>
               
                                        
    </div>
@endsection
