@extends('layouts.app')
@section('custom_css')
<link rel="stylesheet" type="text/css" href="{{asset('plugins/bower_components/switchery/dist/switchery.min.css')}}" />
@endsection

@section('bread')
                            <ol class="breadcrumb">
                                <li><a href="#">Dashboard</a></li>
                            </ol>
@endsection

@section('heading')
  KEY 
@endsection

@section('custom_js')
<script src="{{asset('plugins/bower_components/switchery/dist/switchery.min.js')}}" type="text/javascript"></script>
<script type="text/javascript">
     var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
       $('.js-switch').each(function() {
           new Switchery($(this)[0], $(this).data());

       });
</script>
@endsection
@section('content')
    <div class="row">
                    
                    <div class="col-sm-12">
                        <div class="white-box">
                            <?php
//                            echo "Key = ".$key;
                            
                            ?>
                            @if(!empty($successMsg))
                                <div class="alert alert-success"> {{ $successMsg }}</div>
                            @endif
                            <div class="row">
                                <div class="col-sm-3"></div>
                                <div class="col-sm-6">
                                    <form data-toggle="validator" method="POST" action="{{ url('post-mac') }}">
                                        {{ csrf_field() }}
                                           
                                        <div class="form-group">
                                           <label for="inputName" class="control-label">First Name</label>
                                           <input type="text"  name="first_name" class="form-control" id="first_name" placeholder="Enter first name" required>
                                        </div>
                                        <div class="form-group">
                                           <label for="inputName" class="control-label">Last Name</label>
                                           <input type="text"  name="last_name" class="form-control" id="last_name" placeholder="Enter last name" required>
                                        </div>
                                        <div class="form-group">
                                           <label for="inputName" class="control-label">Mobile</label>
                                           <input type="text"  name="mobile_no" class="form-control" id="mobile_no" placeholder="Enter mobile number" required>
                                        </div>
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-success" value="save" >Save</button>
                                        </div>
                                   </form> 
                                </div>

                                <div class="col-sm-3"></div>
                            </div>
                            
                        </div>
                    </div>
                                        
    </div>
@endsection
