@extends('layouts.app')
@section('custom_css')
<link rel="stylesheet" type="text/css" href="{{asset('plugins/bower_components/switchery/dist/switchery.min.css')}}" />
@endsection

@section('bread')
<ol class="breadcrumb">
    <li><a href="#">Dashboard</a></li>
    <li class="active">Delivery Sale</li>
</ol>
@endsection

@section('heading')
  Delivery Sale Edit
@endsection

@section('content')
    <div class="row">
        <div class="col-sm-6">
            <div class="white-box">
                <form data-toggle="validator" method="POST" action="{{ route('DeliverySaleUpdate') }}">
                <input type="hidden" name="id" value="{{$delivery->id}}">
                  {{ csrf_field() }}
                    <div class="form-group">
                        <label for="inputName" class="control-label">CCZ *</label>
                        <div class="form-group">
                        <select name="ccz" id="ccz" class="form-control" required>
                        <option value="" disabled selected>[select CCZ]</option>
                            @foreach($data as $key => $val)
                            <option value="{{$val->ccz}}" {{$val->ccz == $delivery->id_zone?"selected":""}}>
                                {{$val->ccz}}({{$val->name}})
                            </option>
                            @endforeach
                        </select>
                        </div>
                        <div class="help-block with-errors"></div>
                    </div>
                     <div class="form-group">
                        <label for="inputName" class="control-label">CCA *</label>
                        <div class="form-group">
                               <select name="cca" id="ccz" class="form-control" required>
                                            <option value="" disabled selected>[select CCA]</option>
                                                @foreach($data1 as $key => $val)
                                                <option value="{{$val->id_ad}}"  {{$val->id_ad == $delivery->id_ad?"selected":""}}>
                                                    {{$val->id_ad}}({{$val->title}})
                                                    </option>
                                                @endforeach
                                            </select>            
                        </div>
                        <div class="help-block with-errors"></div>
                    </div>
                    <div class="form-group">
                        <label for="inputpostUrl" class="control-label">Post Back Url</label>
                            <div class="form-group col-sm-12">
                            <input type="text"  name="post_back_url"  value="{{$delivery->post_back_url}}" data-toggle="validator"   class="form-control" id="inputPassword" placeholder="Post back URL" required>
                            <div class="help-block with-errors"></div>
                            </div>
                    </div>
                    <div class="form-group">
                        <label for="inputpostUrl" class="control-label">Post Back Status</label>
                        <div class="form-inline">      
                                <div class="radio radio-info">
                                <input type="radio" name="postback_status" id="status1" value="1" {{$delivery->postback_status == 1 ? "checked":""}}>
                                <label for="status1">Active </label>
                                </div>
                                <div class="radio radio-info">
                                <input type="radio" name="postback_status" id="status2" value="0"{{$delivery->postback_status == 0 ? "checked":""}}>
                                <label for="status2">Deactive </label>
                                </div>
                            </div>
                     </div>
                    <div class="form-group">
                        <label for="inputpostUrl" class="control-label">Percentage *</label>
                       
                            <div class="form-group col-sm-12">
                                <input type="text"  name="lower_limit" value="{{$delivery->lower_limit}}" data-toggle="validator"   class="form-control" id="inputPassword" placeholder="Input Percentage" required>
                              
                                <div class="help-block with-errors"></div>
                                 
                            </div>
                      
                    </div>
                     <div class="form-group">
                        <label for="inputpostUrl" class="control-label">Higher Percentage *</label>
                       
                            <div class="form-group col-sm-12">
                                <input type="text" name="higher_limit" value="{{$delivery->higher_limit}}" data-toggle="validator"   class="form-control" id="inputPassword" placeholder="Input Percentage" required>
                              
                                <div class="help-block with-errors"></div>
                                 
                            </div>
                      
                    </div>
                    <div class="form-group">
                        <label for="inputpostUrl" class="control-label">Filter Status</label>
                        
                            <div class="form-inline">      
                                <div class="radio radio-info">
                                <input type="radio" name="filter_status" id="status3" value="1" {{$delivery->filter_status == 1 ? "checked":""}}>
                                <label for="status3">Active </label>
                                </div>
                                <div class="radio radio-info">
                                <input type="radio" name="filter_status" id="status4" value="0" {{$delivery->filter_status == 0 ? "checked":""}}>
                                <label for="status4">Deactive </label>
                                </div>
                            </div>
                     </div>
                    <br>
                    <div class="form-group">
                        <button type="submit" class="btn btn-success">Update</button>
                    </div>
                </form>
            </div>
        </div>
                                        
    </div>
@endsection
