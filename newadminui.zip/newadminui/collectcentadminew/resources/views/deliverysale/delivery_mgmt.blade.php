@extends('layouts.app')
@section('bread')
                         
@endsection
@section('heading')
  Delivery Management
@endsection
@section('custom_js')
<style type="text/css">
    #cover {
        
    text-align: center;
    background: url("http://www.aveva.com/Images/ajax-loader.gif") no-repeat scroll center center #FFF;
    position: fixed;
    /*margin: 10%;*/
    /*align-items: center;*/
    /*top: 0%;*/
    width: 100%;
    height: 10%;
    z-index: 9999;
}
</style>
<script type="text/javascript">
   $(document).ready(function() {
        $(document).ajaxStart(function(){
            $(".preloader").css("display", "block");
        });
        $(document).ajaxComplete(function(){
            $(".preloader").css("display", "none");
        });
        var col = [
                     'text_45px',
                    'text_30px',
                    'text_30px',
                    'text_50px',                    
                    'text_40px',
                    "text_50px",
                    "text_45px",
                    "text_70px",
//                    "text",
                    "text_60px",
                    "text_60px",
                    "text_60px",
                    "text_700px",
                ];
        var data =   {!! json_encode($data1) !!};        
        createTableWithLazyLoad("#tableLazy",data,50,col);
       
       $(".urltext").click(function(){
         var span = $(this).find("span").text();
         var inp = $(this).find("input").removeClass("hide").val();
         $(this).find("input").select();
         document.execCommand("copy");
         $(this).find("input").addClass("hide")
         alert("text copied");
       })
       
       $('input:checkbox[name=isSmart]').change(function() {
            var id_ad = $(this).attr('id');
            var checked_value;
            if($(this).prop('checked') === true){
                checked_value = '1';
            }else{
                checked_value = '0';
            }
            if(id_ad !='' && checked_value != ''){
            $.ajax({
                    url: "delivery-smtUrlStatus", // make sure you set an action attribute to your form
                    type: 'GET',
                    cache: false,
                    async:true,
                    dataType: 'JSON',
                    data: {'id_ad': id_ad,'check_value': checked_value},
                    success: function(data){
                        $("#cover").fadeOut("slow");
                        var obj = data;
                        if(obj.check_value == 1){
                            $('#isSmartValue_'+obj.id_ad).text("Active");
                        }else if(obj.check_value == 0){
                            $('#isSmartValue_'+obj.id_ad).text("Inactive");
                        }else{
                            $('#isSmartValue_'+obj.id_ad).text("");
                        }
                    }
                });
            }else{
                alert("Oops, something went wrong !!");
            }
        })
    });
   
  </script>
  @endsection
@section('content')
<div >
    <div style="text-align: center;">
        <div style="display: none;" id="cover"></div>            
    </div>
    <div class="m-b-15 header-panel-form">
              <form class="form-inline" role="form" method="POST" action="{{ route('deliverypost') }}">
                        {{ csrf_field() }}    
                                                <div class="form-group ">
                                                   <select name="ntname" class=" select2 form-control" id="publisher" data-act="ajax-select"  data-post-text="name" data-post-id="ccz" data-post-key="name" data-post-table="ad_network" data-min-input="3" data-placeholder="Network Name" ></select>
                                                </div>

		                                	
                                                <div class="form-group ">
                                                       <select name="ntname" class=" select2 form-control" id="publisher" data-act="ajax-select"  data-post-text="name" data-post-id="ccz" data-post-key="name" data-post-table="operator" data-min-input="2" data-placeholder="Operators" ></select>
                                                </div>
		                                	
                                                <div class="form-group ">
                                                     
                                                      <select name="filter_status " class="form-control full">
                                                        <option value="">Filter Status </option>
                                                        <option value="1">Active </option>
                                                        <option value="0">InActive </option>
                                                     </select>
                                                </div>
		                                	
                                                <div class="form-group ">
                                                        
                                                        <select name="postback_status  " class="form-control full">
                                                        <option value="">Postback Status</option>
                                                        <option value="1">Active </option>
                                                        <option value="0">InActive </option>
                                                        </select>
                                                </div>
                                            
                                                <div class="">
                                                     <button type="submit" class="btn btn-success waves-effect waves-light">Go</button>
                                                </div>
                                                <!--div class="form-group ">
                                                <a href="{{url('/delivery/add')}}" class="btn btn-success waves-effect waves-light m-r-10">Add New</a>
                                                </div-->
                                            
                                                <div class="text-right ">
                                                @php
                                                    $heads =  [
                                                                "ID",
                                                                "Action",
                                                                "Type",
                                                                "Smart Url Status",
                                                                "Is Child",                                                                
                                                                "Network Name",
                                                                "CCZ",
                                                                "CCA",
                                                                "Filter Pect",
                                                                "Filter Status",
                                                                "Status",
                                                                "Postback URL"

                                                                ];
                                                @endphp
                                                    <div class="text-right ">
                                                    {!!view('layouts.column', ['data' =>$heads])!!}
                                                </div>
                                                </div>
                                        </form>
                                            
                            </div>
    </div>


    <div class="col-sm-12">
                        <div class="table-responsive mainTableInfo">
                                <table class="table color-table info-table scrollTable lazy" id="tableLazy">
                                    
                                        {!!view('layouts.tableheadNew', ['data' =>$heads,'class'=>""])!!}
                                      
                                           
                                    
                                </table>
                                <table>
                                
                                </table>

                            </div>               
                            
                           
    </div>


@endsection
