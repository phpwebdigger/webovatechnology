@extends('layouts.app')
@section('custom_css')
<link rel="stylesheet" type="text/css" href="{{asset('plugins/bower_components/switchery/dist/switchery.min.css')}}" />
@endsection

@section('bread')
    <ol class="breadcrumb">
        <li><a href="#">Dashboard</a></li>
        <li class="active">Delivery Sale</li>
    </ol>
@endsection

@section('heading')
   Add Delivery
@endsection
@section('custom_js')
<script src="{{asset('plugins/bower_components/switchery/dist/switchery.min.js')}}" type="text/javascript"></script>
<script src="{{asset('js/validator.js')}}"></script>
<script type="text/javascript">
     var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
       $('.js-switch').each(function() {
           new Switchery($(this)[0], $(this).data());

       });
       $(".ischild").on('change',function(){
            if($(this).is(":checked")){
                $("#outW").removeClass("hide");
            }else{
                $("#outW").addClass("hide");
            }
       })

       function copyToClipboard(element) {
            var $temp = $("<input>");
            $("body").append($temp);
            $temp.val($(element).text()).select();
            document.execCommand("copy");
            $temp.remove();
            $("#post_back_url").val($(element).text());
            alert('text copied and move');
        }
       $(document).on('change','#ccz',function(){
            $(".loader").show();
            $id_zone = $(this).val();
            var ccz = $("#ccz option:selected").text();
            $title = ccz.split('('); 
            $("#title").val($title[0]); 
            $.ajax({
                url : '/delivery/get-adsbynetwork/',
                type: 'GET',
                async: true,
                data: "id_zone="+$id_zone+"&table=_sale"
            }).done(function (response){
                var adsData =  JSON.parse(response);
                var networks = '<option value="">select CCA</option>';    
                var postbackUrl = '<ul class="list-group"><li class="list-group-item"><b class="text-danger">Latest PostBacks</b></li>';
                if(adsData.cca.length > 0){
                    $(adsData.cca).each(function(key,network){
                        networks += '<option value="'+network.id_ad+'"">'+network.cca+'</option>';
                    });
                }
                if(adsData.deliveryPostBack.length > 0){
                    $(adsData.deliveryPostBack).each(function(key,delivery){
                        postbackUrl += '<li class="list-group-item" onclick="copyToClipboard(this)">'+delivery.post_back_url+'</li>';
                    });
                }else{
                    postbackUrl += '<li class="list-group-item">No post_back_url found</li>'; 
                } 
                if(postbackUrl){
                    $('.postback-url').html(postbackUrl);
                }
                postbackUrl +='</ul>';
                $("#cca").html(networks).select2();
                $(".loader").hide();      
            }).fail(function(){
                    alert('Data could not be loaded.');
                    $(".loader").hide();
            });
       });
       
         
         
</script>
@endsection
@section('content')
    <div class="row">
            <div class="error text text-center center text-danger col-sm-12" style="padding:20px;text-align: center;" >{{$errors??""}}</div>
                    <div class="col-sm-6">
                        <div class="white-box">
                            <form data-toggle="validator" method="POST" action="{{ url('delivery-sale/add') }}">
                              {{ csrf_field() }}
                                <div class="form-group">
                                    <label for="inputName" class="control-label">CCZ *</label>
                                    <div class="form-group">
                                    <select name="ccz" id="ccz" class=" select2 form-control"  data-act="ajax-select" data-preload="true" data-post-text="concat(name,'(',ccz,')')" data-post-id="ccz" data-post-key="name" data-post-table="ad_network" data-min-input="2" data-placeholder="type to search CCZ" required>
                                       <option> Select CCZ</option>
                                    </select>
                                    </div>
                                    <div class="help-block with-errors"></div>
                                    
                                </div>
                                 <div class="form-group">
                                    <label for="inputName" class="control-label">CCA *</label>
                                    <div class="form-group">
                                    <select name="cca" id="cca" class="select2 form-control" required>
                                      <option> Select CCA</option>
                                    </select>    
                                    </div>
                                    <div class="help-block with-errors"></div>
                                    
                                </div>
                                <div class="form-group">
                                    <label for="inputpostUrl" class="control-label">Is Child</label>
                                        <div class="form-group col-sm-5">
                                           Inactive  <input type="checkbox" name="isChild" class="ischild js-switch" /> Active
                                            <div class="help-block with-errors"></div>
                                        </div>
                                        <div class="form-group col-sm-5">
                                            <input id="outW" class="outHide hide form-control" type="text" name="childId"  />
                                        </div>
                                </div>
                              

                                <div class="form-group" style="clear: both;">
                                    <label for="inputpostUrl" class="control-label">Post Back Url</label>
                                   
                                        <div class="form-group col-sm-12">
                                            <input type="text"  name="post_back_url"  value="" data-toggle="validator"   class="form-control" id="post_back_url" placeholder="Post back URL" required>
                                          
                                            <div class="help-block with-errors"></div>
                                             
                                        </div>
                                  
                                </div>
                                 <div class="form-group">
                                    <label for="inputpostUrl" class="control-label">Post Back Status</label>
                                   
                                        <div class="form-group col-sm-12">
                                            Inactive <input name="postback_status"  type="checkbox" checked class="js-switch" /> Active
                                          
                                            <div class="help-block with-errors"></div>
                                             
                                        </div>
                                  
                                </div>
                                <div class="form-group">
                                    <label for="inputpostUrl" class="control-label">Percentage *</label>
                                   
                                        <div class="form-group col-sm-12">
                                            <input type="text"  name="lower_limit"  data-toggle="validator"   class="form-control" id="lower_limit" placeholder="Input Percentage" required>
                                          
                                            <div class="help-block with-errors"></div>
                                             
                                        </div>
                                  
                                </div>
                                 <div class="form-group">
                                    <label for="inputpostUrl" class="control-label">Higher Percentage *</label>
                                   
                                        <div class="form-group col-sm-12">
                                            <input type="text" name="higher_limit" data-toggle="validator"   class="form-control" id="higher_limit" placeholder="Input Percentage" value="100" required>
                                          
                                            <div class="help-block with-errors"></div>
                                             
                                        </div>
                                  
                                </div>
                                <div class="form-group">
                                    <label for="inputpostUrl" class="control-label">Filter Status</label>
                                        <div class="form-group col-sm-12">
                                            Inactive <input type="checkbox" name="filter_status" checked class="js-switch" /> Active
                                        <div class="help-block with-errors"></div>
                                        </div>
                                </div>
                                <div class="form-group">
                                    <label for="isCron" class="control-label">Want to insert in manual cron</label>
                                        <div class="form-group col-sm-12">
                                            Inactive <input type="checkbox" name="isCron" class="js-switch" /> Active
                                        <div class="help-block with-errors"></div>
                                        </div>
                                </div>
                                <div class="form-group">
                                    <input type="hidden" name="title" value="" id="title"> 
                                    <button type="submit" class="btn btn-success">Submit</button>
                                    <a href="/delivery-sale" class="btn btn-danger">Cancel</a>
                                </div>
                            </form>
                        </div>
                    </div>
            </div>
@endsection
