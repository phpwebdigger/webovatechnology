@extends('layouts.app')
@section('bread')
                            <ol class="breadcrumb">
                                <li><a href="#">Dashboard</a></li>
                                <li class="active">Rahul CPA List</li>
                            </ol>
@endsection

@section('heading')
  Rahul CPA List
@endsection

@section('content')
<div style=" padding-bottom: 51px;"">
    <a href=""><button class="btn btn-success waves-effect waves-light pull-right" type="button"><span class="btn-label"><i class="fa fa-plus"></i></span>Add New</button></a>
    
</div>

<div class="col-sm-12">
                            <div class="table-responsive">
                                <table class="table color-table info-table">
                                    <thead>
                                        <tr>
                                            <th>Id</th>
                                            <th>Id Zone</th>
                                            <th>Operator CODE</th>
                                            <th>Conversion Precentage</th>
                                            <th>Manage</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td>Nigam</td>
                                            <td>Eichmann</td>
                                            <td>@Sonu</td>
                                            <td><a href=""><button type="button" class="btn btn-danger btn-circle "><i class="fa fa-edit"></i> </button></a>&nbsp;
                                                <a href=""><button type="button" class="btn btn-danger btn-circle"><i class="fa fa-times"></i> </button></a></td>
                                            </tr>
                                        </tr>
                                       
                                    </tbody>
                                </table>
                            </div>           
    </div>


@endsection
