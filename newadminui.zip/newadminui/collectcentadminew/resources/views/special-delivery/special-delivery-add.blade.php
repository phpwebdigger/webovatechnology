@extends('layouts.app')
@section('custom_css')
<link rel="stylesheet" type="text/css" href="{{asset('plugins/bower_components/switchery/dist/switchery.min.css')}}" />

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css">

@endsection

@section('bread')

@endsection

@section('heading')
  Special Delivery Add 
@endsection


@section('custom_js')
<script type="text/javascript">
$(document).ready(function() {
//        alert(7);
var msg = $("#errormsg");
var post_back_url = $("#post_back_url");
var parent_cca = $("#parent_cca");
var id_zone = $("#id_zone");

    $("#submit").click(function ()
    {
        

        if(id_zone.val()=="" )
        {
            id_zone.focus();
            msg.html('<span class="alert alert-danger">Please select Zone !</span>');
            return false;
        }
        
        if(parent_cca.val()=="" )
        {
            parent_cca.focus();
            msg.html('<span class="alert alert-danger">Please select Parent CCA !</span>');
            return false;
        }
        
        if(post_back_url.val()=="" )
        {
            post_back_url.focus();
            msg.html('<span class="alert alert-danger">Please enter postback url !</span>');
            return false;
        } 

        if(parent_cca.val() !='' && id_zone.val() !='' && post_back_url.val() != '')
        {
            
            msg.html('<span class="alert alert-info">Please wait !!!!</span>');
            
            $.ajax({
                url: "/special_delivery_add", // make sure you set an action attribute to your form
                type: 'GET',
                cache: false,
                async:false,
                dataType: 'JSON',

                data: {'post_back_url': post_back_url.val(),'parent':parent_cca.val(),'id_zone':id_zone.val()},

                success: function(responseText){
//                    alert(responseText);
//                    var result = $.parseJSON(responseText);
//                    var result = JSON.parse(responseText);
//                    alert(result);
                    var result = responseText;
                    if(result.status == 1)
                    {
                        msg.html('<span class="alert alert-success">'+result.message+'</span>');
                        window.location = 'special-delivery';
                    }                        
                    else if(result.status == 2)
                    {
                        msg.html('<span class="alert alert-info" style="font-size:11px;">'+result.message+'</span>');
                    }
                    else if(result.status == 3)
                    {
                        msg.html('<span class="alert alert-info" style="font-size:11px;">'+result.message+'</span>');
                    }
                    else if(result.status == 4)
                    {
                        msg.html('<span class="alert alert-info" style="font-size:11px;">'+result.message+'</span>');
                    }
                    else if(result.status == 0)
                    {
                        msg.html('<span class="alert alert-info" style="font-size:11px;">'+result.message+'</span>');
                    }
                    else
                    {
                        msg.html('<span class="alert alert-danger">Oops, something went wrong!!!</span>');
                    }
                }
            });
        }
        else
        {
            msg.html('<span class="alert alert-info">Oops, Something went wrong !</span>');
        }
         
    });

    

});

</script>

  
  <!--<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>-->

  <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>

<!--<script src="{{asset('js/validator.js')}}"></script>-->

@endsection
@section('content')
    <div class="row">
        <div class="col-sm-12">
            <div class="white-box">                            
                <form data-toggle="validator" method="POST" action="{{ url('smart-interface-getcamp') }}">
                      {{ csrf_field() }}
                      <div id="errormsg" style="text-align: center;margin-bottom:20px;"></div>
                    <div class="row">
                        <div class="col-sm-3">
                            <label class="control-label">CCZ <span style="color: #F05355">*</span></label>

                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <input type="text" id="id_zone" name="id_zone" class="form-control">
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <label class="control-label">CCA <span style="color: #F05355">*</span></label>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <input type="text" id="parent_cca" name="parent_cca" class="form-control">
                            </div>
                        </div>
                        
                    </div>
                    <div class="row">
                        <div class="col-sm-3">
                            <label class="control-label">PostBack Url<span style="color: #F05355">*</span></label>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <input type="text" id="post_back_url" name="post_back_url" class="form-control">
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <div class="form-group" style="text-align: center;">
                                    <button type="button" class="btn btn-success" id="submit">Submit</button>
                                </div>
                            </div>
                        </div>
                        
                        
                    </div>

                </form>
            </div>
        </div>
                                        
    </div>
@endsection
