@extends('layouts.app')
@section('custom_css')
<link rel="stylesheet" type="text/css" href="{{asset('plugins/bower_components/switchery/dist/switchery.min.css')}}" />
<!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">-->
@endsection

@section('bread')

@endsection

@section('heading')
  Special Delivery
@endsection


@section('custom_js')
<script type="text/javascript">
    $(document).ready(function() {
        var col = ['text_80px',
                  '',
                  'text_140px',
                    'text_140px',
                    '',
                ];
        var data =   {!! json_encode($data1) !!};
        createTableWithLazyLoad("#tableLazy",data,50,col);
       
        $("#update_url").click(function()
        {
            var msgx = $("#errormsg_url");
            var cca = $("#url_cca");
            var ccz = $("#url_ccz");
            var url = $("#url_update_url");
            if(cca.val()!="" && ccz.val() != '' && url.val() != '')
            {
                msgx.html('<span class="alert alert-info">Please wait.. !!!</span>');
                $.ajax({
                    url: "/update_special_url", // make sure you set an action attribute to your form
                    type: 'GET',
                    cache: false,
                    async: true,
                    dataType: 'JSON',
                    data: {'cca': cca.val(),'ccz': ccz.val(),'url':url.val()},
                    success: function(responseText)
                    {
                        if(responseText.status == 3)
                        {
                            msgx.html('<span class="alert alert-danger">Oops, something went wrong!</span>');
                        }
                        else if(responseText.status == 1)
                        {
                            msgx.html('<span class="alert alert-success">sucsessfully url updated!</span>');
                            window.location.href=window.location.href;
                        }
                        else if(responseText.status == 2)
                        {
                                msgx.html('<span class="alert alert-info">Sorry please try again!</span>');                                        
                        }
                    }
                });
                
            }
            else
            {
                msgx.html('<span class="alert alert-danger">Oopss.. !!!</span>');
            }
        });
        
    });
    



function EditStatus(id,st)
{
//    alert(90909t);
    var msg1 = $("#errormsg_st");
    msg1.html('<span class="alert alert-info">Please wait!!!</span>');
    if(id !='')
    {
//        $("#status_id").val(id);
//        document.getElementById('edit_status').value='Select Status';
//        $('#EditStatus').modal({
//            backdrop: 'static',
//            keyboard: false,  // to prevent closing with Esc button (if you want this too)
//            show: true
//        });

        $.ajax({
            url: "/country-redirection-status-update", // make sure you set an action attribute to your form
            type: 'GET',
            cache: false,
            async:false,
            dataType: 'HTML',
//            dataType: 'JSON',

            data: {'id': id,'status':st},

            success: function(responseText){

                    if(responseText == 3){
                            msg1.html('<span class="alert alert-danger">Oops, something went wrong!</span>');
                    }
                    else if(responseText == 1){
                            msg1.html('<span class="alert alert-success">Sucsessfully Status updated!</span>');      
                            
//                            alert($('#smart_live_'+id.val()));
                            if($('#is_live_'+id).text() == "Live")
                            {
                                $('#is_live_'+id).text("NotLive");
                                $('#is_live_temp_'+id).css({
                                                    'color' : '#F05355'
                                                 });
                                                    msg1.html('');
                            }else
                            {
                                $('#is_live_'+id).text("Live");
                                $('#is_live_temp_'+id).css({
                                                    'color' : '#32CEA7'
                                                 });
                                                 msg1.html('');
                            }    
                        msg1.html('');
                    }
                    else if(responseText == 2){
                            msg1.html('<span class="alert alert-info">Sorry please try again!</span>');                                        
                    }
                        

            }
        });
    }
}

function EditUrl(_ccz, _cca)
{
//    alert(90909t);
//    var msg1 = $("#errormsg_st");
//    msg1.html('<span class="alert alert-info">Please wait!!!</span>');

        
    if(_ccz !='' && _cca !='' )
    {
        $("#url_cca").val(_cca);
        $("#url_ccz").val(_ccz);
//        $("#url_update_url").val(_url);
        $('#EditUrl').modal({
            backdrop: 'static',
            keyboard: false,  // to prevent closing with Esc button (if you want this too)
            show: true
        });

        
    }
}    
 
  </script>

<script src="{{asset('plugins/bower_components/switchery/dist/switchery.min.js')}}" type="text/javascript"></script>
<script src="{{asset('js/validator.js')}}"></script>

@endsection
@section('content')
    <div class="m-b-15 header-panel" style="text-align: center;">
        <div class="form-group">
            <div id="errormsg_st" style="text-align: center;margin-bottom:20px; margin-top: 4%;"></div>
        </div>
    </div>
    <div class="m-b-15 header-panel" style="text-align: center;">
        <div class="form-group">
            <a href="special-delivery-add"><button type="button" class="btn btn-success waves-effect waves-light">Add New</button></a>
        </div>
    </div>
    <div class="col-sm-12">
        <div class="text-right ">
            @php
                $heads =  [
                            "CCZ",
                            "CCA",
                            "Postback Url",
                            "Active Status",
                            "Action",
                        ];
            @endphp
                <div class="text-right ">
                {!!view('layouts.column', ['data' =>$heads])!!}
            </div>
            </div>
        <div class="table-responsive mainTableInfo">
            <table class="table color-table info-table scrollTable lazy" id="tableLazy">
                {!!view('layouts.tableheadNew', ['data' =>$heads,'class'=>""])!!}
            </table>
            <table>

            </table>

        </div> 
                           
    </div>


<!--Edit Url-->
<div class="modal fade" id="EditUrl" role="dialog">
    <div class="modal-dialog bd-example-modal-sm" style="margin-top: 15%">    
    <!-- Modal content-->
        <div class="modal-content col-sm-12">
            <div class="modal-header modal-header1">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title" style="text-align: center">Edit Url</h4>
            </div>
            
            <div id="errormsg_url" style="text-align: center;margin-bottom:20px; margin-top: 4%;"></div>
            
            <input type="hidden" id ="url_cca" name="url_cca"  class="form-control">
            <input type="hidden" id ="url_ccz" name="url_ccz"  class="form-control">
            
            <div class="row">
                <div class="col-sm-2" style="margin-top: 2%;">
                    <label class="control-label">Url</label>
                </div>
                <div class="col-sm-8" style="margin-top: 2%;">
                    <div class="form-group">
                        <textarea rows="4" style="width: 100%; resize: none;" name="url_update_url" id="url_update_url"></textarea>
                    </div>
                </div>
                
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-info" id="update_url">Update</button>
            </div>
      </div>      
    </div>
</div>

@endsection
