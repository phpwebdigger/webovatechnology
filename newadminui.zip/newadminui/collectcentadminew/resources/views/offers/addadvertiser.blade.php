@extends('layouts.app')


@section('content')
@section('heading')
Add Advertiser
@endsection


@section('custom_js')
<script>

//var countrylenght= $("#country").val().length;


$(document).ready(function(){

   
    $("#submit").on('click', function(){

      var password = $("#password").val();
      var cpassword = $("#cpassword").val();
      var passwordlenght= $("#password").val().length;

       if(passwordlenght<6)
       {
          alert("password atleast six character."); 
          $("#password").focus();  return false;

       }

      if(password!=cpassword)
      {
        alert("password and confirm password should be same.");
        $("#cpassword").focus();   return false;


      }


    })



  });

</script>

@endsection


@section('bread')
<ol class="breadcrumb">
    <a href="<?php echo URL::asset('/adv_list'); ?>" class="btn btn-success img-responsive add_offer pull-left m-r-10">Advertiser List</a>
</ol>
@endsection


@section('content')

   <div class="row">
        <div class="col-md-12">
            <div class="white-box">
               
                <div class="panel panel-info addoffer-info">



             @if(Session::has('advnameis'))
                    <div class="information_to ">{{ Session::get('advnameis') }}</div>
                    @endif

                    @if(Session::has('advemailis'))
                    <div class="information_to">{{ Session::get('advemailis') }}</div>
                    @endif
                    @if(Session::has('confirmpass'))
                    <div class="information_to">{{ Session::get('confirmpass') }}</div>
                    @endif
                                        @if(Session::has('advertisersuccess'))
                    <div class="alert alert-info ">{{ Session::get('advertisersuccess') }}</div>
                    @endif
         </div>

         <div   id="successadvertiser"></div>

       
    <form action="<?php echo URL::asset('/addadvertiser')  ?>" method="post">

            
            {{ csrf_field() }}  

             <input type="hidden" name="addadv" value="addadv" >
             <div class="form-group">
                <label for="message-text" class="control-label">TimeZone:</label>
                    <select name="time_zone" id="time_zone" required  class="col-md-2 mySelect form-control">
                        @foreach(Config::get('app.time_zone') as $pkey => $pvalue) 
                            <option value="{{$pkey}}">{{$pvalue}}</option>
                        @endforeach


                    </select>
              </div>
               <div class="form-group">
                  <label for="recipient-name" class="control-label">Advertiser Name:</label>
         <input type="text" class="form-control" name="advname" value="{{ old('advname') }}" id="advname" placeholder="Advertiser Name" required>
               </div>

               <div class="form-group">
                  <label for="recipient-name" class="control-label">Advertiser Email:</label>
         <input type="email" class="form-control" name="email" value="{{ old('email') }}" id="email" placeholder="Enter Email" required>
               </div>

<div class="form-group">
                  <label for="recipient-name" class="control-label">Phone:</label>
         <input type="number" min="0" class="form-control" name="phone" value="{{ old('phone') }}" id="phone" placeholder="Enter Phone" >
               </div>
               
               <div class="form-group">
                  <label for="recipient-name" class="control-label">Company Name:</label>
         <input type="text" class="form-control" name="company" value="{{ old('company') }}" id="company" placeholder="Company Name" required>
               </div>
<div class="form-group">
                  <label for="recipient-name" class="control-label">Address:</label>
         <input type="text" class="form-control" name="address" value="{{ old('address') }}" id="address" placeholder="Address" >
               </div>

               <div class="form-group">
                  <label for="recipient-name" class="control-label">Skype Id:</label>
         <input type="text" class="form-control" name="skype_id" value="{{ old('skype_id') }}" id="skype_id" placeholder="Skype Id" >
               </div>

<!--            <div class="form-group">
                  <div>
                  <label class="control-label">Placeholders For Postback</label>

                  <div class="dataTable_wrapper">
                  <table class="table table-striped table-bordered table-hover" style="font-size: 12px;" id="dataTables-example">

                  <thead style="background-color:#01c0c8;">
                  <tr>
                      <th style="color: #fff;">NAME</th>
                      <th style="color: #fff;">DESCRIPTION</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr><td>__NETWORKTOKEN__</td><td>Replaced with the value of publisher's unique id that was sent to us when a visitor redirects to our offer URL.</td></tr>
                  <tr><td>__COLLECCENTTOKEN__</td><td>Replaced witth Collectcent's uniq id[CCUID] which is generated when a visitor comes to our offer URL.</td></tr>

                  <tr><td>__PRICE__</td><td>Replaced your offers price</td></tr>


                  </tbody>
                  </table>
                  </div>
                  </div>
                @if(Session::has('posturl'))
                <div class="information_to ">{{ Session::get('posturl') }}</div>
                @endif

            <label for="recipient-name" class="control-label">Global Postback:</label>
            <input type="text" class="form-control" name="globalpost" value="{{ old('globalpost') }}" id="globalpost" placeholder="Enter Global Postback" required>
            </div>-->

<!--          <div class="form-group">
          <label for="recipient-name" class="control-label">Click parameter:</label>
          <input type="text" class="form-control" name="clickparameter" value="token" readonly placeholder="Enter Click Parameter" required>
          </div>-->

               <div class="form-group">
                  <label for="recipient-name" class="control-label">Password:</label>
         <input type="password" class="form-control" name="password" value="{{ old('password') }}" id="password" placeholder="Password"  required>
               </div>

               <div class="form-group">
                  <label for="recipient-name" class="control-label">Confirm Password:</label>
         <input type="password" class="form-control" name="cpassword" value="{{ old('cpassword') }}" id="cpassword" placeholder="Confirm Password" required >
               </div>

<!--                 <div class="form-group">
                  <label for="message-text" class="control-label">Api Name:</label>
                  <select name=" apiname" id="apiname" class="form-control select2" >
                    <option value="">None</option>
                    @foreach(Config::get('app.apiname') as $pkey => $pvalue) 
                <option <?php // if(old('apiname')==$pkey){ echo "selected"; } ?> value="{{$pkey}}">{{$pvalue}}</option>
                     @endforeach                    

                  </select>
               </div>-->

        <div style="clear: both" class="text-center">
        <button type="submit" id="submit"  class="btn btn-success waves-effect waves-light">Save</button>
         </div>


            </form>
        
</div>
</div></div></div>

   @endsection