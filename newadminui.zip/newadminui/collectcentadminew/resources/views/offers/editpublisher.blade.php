@extends('layouts.app')


@section('content')
@section('heading')
Edit Publisher
@endsection


@section('custom_js')
<script>

//var countrylenght= $("#country").val().length;


$(document).ready(function(){

   
    $("#submit").on('click', function(){

      var password = $("#password").val();
      var cpassword = $("#cpassword").val();
      var passwordlenght= $("#password").val().length;

       if(passwordlenght<6)
       {
          alert("password atleast six character."); 
          $("#password").focus();  return false;

       }

      if(password!=cpassword)
      {
        alert("password and confirm password should be same.");
        $("#cpassword").focus();   return false;


      }


    })



  });

</script>

@endsection


@section('bread')
<ol class="breadcrumb">
    <a href="<?php echo URL::asset('/publisherlist'); ?>" class="btn btn-success img-responsive add_offer pull-left m-r-10">Publisher List</a>
</ol>
@endsection


@section('content')
  <div class="row">
        <div class="col-md-12">
            <div class="white-box">
               
                <div class="panel panel-info addoffer-info">

            @if(Session::has('pubnameis'))
                    <div class="information_to ">{{ Session::get('pubnameis') }}</div>
                    @endif

                    @if(Session::has('pubemailis'))
                    <div class="information_to ">{{ Session::get('pubemailis') }}</div>
                    @endif
                    @if(Session::has('confirmpass'))
                    <div class="alert alert-info ">{{ Session::get('confirmpass') }}</div>
                    @endif
                                        @if(Session::has('publishersuccess'))
                    <div class="information_to ">{{ Session::get('publishersuccess') }}</div>
                    @endif
         </div>

         <div   id="successadvertiser"></div>

         <div class="">
    <form action="<?php echo URL::asset('/dopublisheredit')  ?>/<?php echo  $user_id; ?>" method="post">

            
            {{ csrf_field() }}  

             <input type="hidden" name="addpub" value="addpub" >
             <input type="hidden" name="id_zone" value="<?php echo $id_zone ?>" >
               <div class="form-group">
                  <label for="recipient-name" class="control-label">Publisher Name:</label>
                  <input type="text" class="form-control" name="pubname" value="<?php if(!empty($publisher->name)){ echo $publisher->name; } ?>" id="pubname" placeholder="Publisher Name" readonly>
               </div>

               <div class="form-group">
                  <label for="recipient-name" class="control-label">Publisher Email:</label>
         <input type="email" class="form-control" name="email" value="<?php if(!empty($publisher->email)){ echo $publisher->email; } ?>" id="email" placeholder="Enter Email" readonly>
               </div>

<div class="form-group">
                  <label for="recipient-name" class="control-label">Phone:</label>
         <input type="number" min="0" class="form-control" name="phone" value="<?php if(!empty($publisher->phone)){ echo $publisher->phone; } ?>" id="phone" placeholder="Enter Phone" readonly>
               </div>
               
               <div class="form-group">
                  <label for="recipient-name" class="control-label">Company Name:</label>
         <input type="text" class="form-control" name="company" value="<?php if(!empty($publisher->company_name)){ echo $publisher->company_name; } ?>" id="company" readonly placeholder="Company Name">
               </div>
<div class="form-group">
                  <label for="recipient-name" class="control-label">Address:</label>
         <input type="text" class="form-control" name="address" value="<?php if(!empty($publisher->address)){ echo $publisher->address; } ?>" id="address" placeholder="Address" readonly>
               </div>

               <div class="form-group">
                  <label for="recipient-name" class="control-label">Skype Id:</label>
         <input type="text" class="form-control" name="skype_id" value="<?php if(!empty($publisher->skype_id)){ echo $publisher->skype_id; } ?>" id="skype_id" placeholder="Skype Id" readonly>
               </div>

          <div class="form-group">
           
                  <div>
                  <label class="control-label">Placeholders For Postback</label>

                  <div class="dataTable_wrapper">
                  <table class="table table-striped table-bordered table-hover" style="font-size: 12px;" id="dataTables-example">

                  <thead style="background-color:#01c0c8;">
                  <tr>
                      <th style="color: #fff;">NAME</th>
                      <th style="color: #fff;">DESCRIPTION</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr><td>__NETWORKTOKEN__</td><td>Replaced with the value of publisher's unique id that was sent to us when a visitor redirects to our offer URL.</td></tr>
                  <tr><td>__COLLECCENTTOKEN__</td><td>Replaced witth Collectcent's uniq id[CCUID] which is generated when a visitor comes to our offer URL.</td></tr>

                  <tr><td>__PRICE__</td><td>Replaced your offers price</td></tr>


                  </tbody>
                  </table>
                  </div>
                  </div>

                  @if(Session::has('posturl'))
                <div class="information_to ">{{ Session::get('posturl') }}</div>
                @endif

          <label for="recipient-name" class="control-label">Global Postback:</label>
          <input type="text" class="form-control" name="globalpost" value="<?php if(!empty($publisher->global_postback)){ echo $publisher->global_postback; } ?>" id="globalpost" placeholder="Enter Global Postback" required>
          </div>

                    <div class="form-group">
          <label for="recipient-name" class="control-label">Click parameter:</label>
          <input type="text" class="form-control" name="clickparameter" value="token" readonly id="clickparameter" placeholder="Enter Click Parameter" required>
          </div>

        <div style="clear: both" class="text-center">
        <button type="submit" id="submit"  class="btn btn-success waves-effect waves-light">Save</button>
         </div>


            </form>
         </div>


         </div>
      </div>
   </div>


   @endsection