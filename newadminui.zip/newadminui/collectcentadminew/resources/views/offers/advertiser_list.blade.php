@extends('layouts.app')
@section('custom_css')
<link rel="stylesheet" type="text/css" href="{{asset('plugins/bower_components/switchery/dist/switchery.min.css')}}" />
@endsection
@section('bread')
<!--                        <ol class="breadcrumb">
                            <li><a href="#">Add Resources</a></li>
                            <li><a href="#">Advertiser</a></li>
                            <li class="active">List Advertiser Resources</li>
                        </ol>-->
@endsection

@section('heading')
  Advertiser Management 
@endsection

@section('custom_js')
<script src="{{ asset('plugins/bower_components/switchery/dist/switchery.min.js')}}" type="text/javascript"></script>
<script type="text/javascript">
      var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
        $('.js-switch').each(function() {
            new Switchery($(this)[0], $(this).data());

        });
        $(document).ready(function() {

        var data =   {!! json_encode($data1) !!};        
       createTableWithLazyLoad("#tableLazy",data,50);
       
    } );

</script>
@endsection
@section('content')
       <div class="m-b-15">
                <form class="form-inline" role="form" method="POST" action="{{url('/Resources/list-advertiser')}}">
                        {{ csrf_field() }}                     
                          <div class="form-group col-md-2">
                              @php
                                $heads =  ["Sr.No",
                                  "Advertiser Id",
                                   "Advertiser Name",
                                   "Country",
                                   "language",
                                   "Account Manager",
                                   "Advertiser Key",
                                   "Create time",
                                   "Status"
                                   ];
                                 @endphp

                                  {!!view('layouts.column', ['data' =>$heads])!!}
                          </div>

                  </form>
            </div>
            
                    <div class="col-sm-12">
                    
                            
                            <div class="table-responsive mainTableInfo">
                                <table class="table color-table info-table scrollTable lazy" id="tableLazy">
                                    
                                        {!!view('layouts.tableheadNew', ['data' =>$heads,'class'=>""])!!}
                                           
                                        <a href="/addadvertiser">
                                            <button type="button" name="pause" class="btn btn-danger pull-right">Add New</button>
                                        </a>
                                </table>
                            </div>  
                                  
    </div>
@endsection
