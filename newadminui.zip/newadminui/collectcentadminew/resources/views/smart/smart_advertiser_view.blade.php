@extends('layouts.app')
@section('custom_css')
<link rel="stylesheet" type="text/css" href="{{asset('plugins/bower_components/switchery/dist/switchery.min.css')}}" />
<!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">-->
@endsection
@section('bread')
@endsection
@section('heading')
  Offer Advertiser Wise
@endsection
@section('custom_js')
<script type="text/javascript">
    $(document).ready(function() {
       var role_id ={!! json_encode($role) !!}; 

      var role_data=["sapna.verma@collectcent.com","ben@collectcent.com","hadar@collectcent.com","jason.wang@collectcent.com"];
      if($.inArray(role_id,role_data) !== -1){
        
var col = ['text_65px',
                  'text_60px', 
                  'text_80px',
                  'text_80px',
                    'text_80px',
                    'text_80px',
                    'text_240px',
                    'text_40px',
                    'text_50px',
                    'text_40px',
                    'text_40px',     
                    '',     
                    "",
                    "",
                    "",
                    "",
                    "",
                    
                    
                ];

      }else{


     var col = ['text_65px',
                  'text_60px', 
                  'text_80px',
                  'text_80px',
                    'text_80px',
                    'text_80px',
                    'text_240px',
                    'text_40px',
                    'text_50px',
                    'text_40px',
                    'text_40px',     
                    '',     
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    
                ];
}
        var data =   {!! json_encode($data1) !!};        
        createTableWithLazyLoad("#tableLazy",data,200,col);
        $(".rupees").hide();    
        var column;
          var unCheckedColumn = ['1','3','4','5','9'];
            /* to hide coluun according to condition */
            $(unCheckedColumn).each(function(key,uncheckIndex){
             $('.new th[data-index="'+uncheckIndex+'"]').toggleClass("hide");
             column = tableLazyNew.column(uncheckIndex);
             column.visible(false); 
            });
            // unchecking checkboxes 
            $(".dropdown-menu li").each(function(key,element){
                if($(element).find('input[type="checkbox"]').is(":checked")){
                    var dataI = $(element).find('input[type="checkbox"]').attr('data-index');
                    if(unCheckedColumn.indexOf(dataI) != -1){
                        $(element).find('input[type="checkbox"]').removeAttr("checked");
                    }
                }

            }); 
        
    } );
    
    
 
  </script>
<style type="text/css">
    .open > .dropdown-menu {
    display: block;
    max-width: 286% !important ;
}
.mydatepicker {
    width: 289px !important;
}

</style>
<script src="{{asset('plugins/bower_components/switchery/dist/switchery.min.js')}}" type="text/javascript"></script>
<script src="{{asset('js/validator.js')}}"></script>
<script src="../plugins/bower_components/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script type="text/javascript">
     
    jQuery('.mydatepicker').datepicker({
       format:"yyyy-mm-dd"
    });
    jQuery(document).on('change','.currency',function(){
        if($(this).val() == 0){
            $(".dollar").show();
            $(".rupees").hide();
        }else{
            $(".dollar").hide();
            $(".rupees").show();
        }
    });
    
$("#resert").click(function() { 
                //$("#d").trigger("reset"); 
                //$("#d").get(0).reset(); 
                // $("#d")[0].reset();
                $(".selectpicker").val('').selectpicker("refresh");
            }); 

</script>
<style type="text/css"></style>
@endsection
@section('content')
    <div class="m-b-15 header-panel" style="text-align:center;">
        <div class="text-right">
            <select name="currency" class="currency btn btn-success">
                <option value="0">Dollar</option>
                <option value="1">Rupees</option>
            </select>    
        </div>
       </div>
    <div class="wrapper">
      <form class="form-inline" role="form" id="d" method="post" action="/offer-advertiserwise">
         {{ csrf_field() }}
            <div class="row first-row">
                <div class="col-sm-2">
                    <div><label>Choose Date</label></div>
                       <input type="text" value="{{$dtvalue}}" class="form-control mydatepicker" name="start" placeholder="From">
                </div>
                  <div class="col-sm-2">
                    <div><label>Choose Date</label></div>
                       <input type="text" name="end" value="{{$dtvalue2}}" class="form-control mydatepicker" placeholder="To">
                </div>
                <div class="col-sm-2">
                   <div><label>Country</label></div>
                    <select id="country" name="country[]" multiple class="selectpicker" data-live-search="true" data-actions-box="true" data-selected-text-format="count > 3" data-size="10" data-style="btn-warning">
                        <?php foreach($countryarray as $value){?>
                        <option value="<?php echo $value->iso;?>" <?php 
                            if(isset($select_country)){
                             echo in_array($value->iso,$select_country) ? "selected" :"";
                            }
                      
                         ?>><?php echo $value->name." (".$value->iso.")";?></option>
                        <?php } ?>
                    </select>
                </div>
               &nbsp;&nbsp;
                <div class="col-sm-2">
                <div><label>Operating System</label></div>
                <select id="operating_id" name="operating_id[]" multiple  class="selectpicker" data-live-search="true" data-actions-box="true" data-selected-text-format="count > 3" data-size="10" data-style="btn-warning">
                        <option value="all" <?php 
                             //echo ("all"==$select_opertings) ? "selected" :""
                          if(isset($select_opertings)){
                             echo in_array("all",$select_opertings) ? "selected" :"";
                            }
                            ?>>All</option>
                        <option value="android" <?php 
                             //echo ("android"==$select_opertings) ? "selected" :""
                         if(isset($select_opertings)){
                             echo in_array("android",$select_opertings) ? "selected" :"";
                            }
                            ?>>Android</option>
                       <option value="ios" <?php 
                            // echo ("ios"==$select_opertings) ? "selected" :""
                         if(isset($select_opertings)){
                             echo in_array("ios",$select_opertings) ? "selected" :"";
                            }
                            ?>>ios</option>
                       <option value="desktop"  <?php 
                            // echo ("desktop"==$select_opertings) ? "selected" :""
                        if(isset($select_opertings)){
                             echo in_array("desktop",$select_opertings) ? "selected" :"";
                            }
                            ?>>desktop</option>
                    </select>
                </div>
                 &nbsp;&nbsp;
                <div class="col-sm-2">
                 
                    <div><label>Vertical</label></div>     
                  <select id="vertical" name="vertical[]"  multiple class="selectpicker" data-live-search="true" data-actions-box="true" data-selected-text-format="count > 3" data-size="10" data-style="btn-success">
                    <?php 
                    $Vertical = config('constants.VERTICALS');
                    foreach($Vertical as $vertical){?>
                    <option value="<?php echo $vertical;?>"  <?php 
                        //echo ($vertical ==$selected_vertical) ? "selected" :""
                     if(isset($selected_vertical)){
                             echo in_array($vertical,$selected_vertical) ? "selected" :"";
                            }
                    ?>><?php echo $vertical; ?></option>
                    <?php } ?>
                    </select>
                </div> 
             <div><label>&nbsp;&nbsp;</label></div>  
                
                 <div class="col-sm-1">
                       <div><label></label></div>    
                  <button type="submit" class="btn btn-success waves-effect waves-light">GO</button>
              </div>
                 <div class="col-sm-1">
                  <button type="button"  id="resert" class="btn btn-warning waves-effect waves-light">Reset</button>
                </div>
   
            </div>
        </form>
    </div>
</br>

<?php 
//    echo "<pre>";
//    print_r($data1);
//    echo "</pre>";
//    die();
?>


    <div class="col-sm-12">
        <div class="text-right ">
            @php
 echo $role_id =$role; 

      $role_data=["sapna.verma@collectcent.com","ben@collectcent.com","hadar@collectcent.com","jason.wang@collectcent.com"];
      if(in_array($role_id,$role_data)){
          $heads =  [
          
                            "Advertiser Id",
                            "Network Name",
                            "Advertiser Name",
                            "Operator",
                            "Ads Type",
                            "Payout Type",                                                                
                            "Campaign Name",
                            "Country",
                            "Vertical",
                            "Os type",                            
                            "Cap",
                            "Install Cap",
                            "Clicks",
                            "Install",
                            "Event",
                            "CR In(%)",     
                            "Rev($)",  
                           
                            
                    ];
                            $heads2 =  ["Total",
                                "",
                                "",
                                "",
                                "",
                                "",
                                "",
                                "",
                                "",
                                "",
                                "",
                                "",
                                $lastRow[0],
                                $lastRow[1],
                                $lastRow[2],
                                "",                           
                                $lastRow[5],              
                            ];
      }else{
                $heads =  [
                            "Advertiser Id",
                            "Network Name",
                            "Advertiser Name",
                            "Operator",
                            "Ads Type",
                            "Payout Type",                                                                
                            "Campaign Name",
                            "Country",
                            "Vertical",
                            "Os type",
                            
                            "Cap",
                            "Install Cap",
                            "Clicks",
                             "Install",
                             "Event",
                            "Outwards",
                            "CR In(%)",
                            "CR Out(%)",
                            "Cost($)",       
                            "Rev($)",       
                        
                            "Profit($/INR)",       
                            
                            ];
                            $heads2 =  ["Total",
                                "",
                                "",
                                "",
                                "",
                                "",
                              
                                
                                "",
                                "",
                                "",
                               
                                "", "",  "",
                                $lastRow[0],
                                $lastRow[1],
                                $lastRow[2],
                                $lastRow[3],
                                "", "",
                                $lastRow[4],                                
                                $lastRow[5],                             
                                $lastRow[6]                             
                                ];
                              }
            @endphp
                <div class="text-left" style="margin-bottom:10px">
                    {!!view('layouts.column', ['data' =>$heads])!!}
                </div>
            </div>
        <div class="table-responsive mainTableInfo">
                <table class="table color-table info-table scrollTable lazy" id="tableLazy">
                    {!!view('layouts.tableheadNew', ['data' =>$heads,'class'=>""])!!}
                    {!!view('layouts.tableheadNew', ['data' =>$heads2,'class'=>"new"])!!}
                </table>


        </div> 
                           
    </div>


@endsection
