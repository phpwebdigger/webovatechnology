@extends('layouts.app-light')
@section('custom_css')
<link rel="stylesheet" type="text/css" href="{{asset('plugins/bower_components/switchery/dist/switchery.min.css')}}" />
<!--link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css"-->
@endsection
@section('heading')
  Smart Interface Add
@endsection
@section('custom_js')
<style type="text/css">
.listbox{width: 200px;}
</style>
<script type="text/javascript">
$(document).ready(function() {
    var all_adv_val = $("#all_adv_val");
    var all_country_val = $("#all_country_val");
    var all_opr_val = $("#all_opr_val");
    var all_advt_val = $("#select_advertiser");
    
    $("#select_adv_camp").change(function() {
        all_adv_val.val($(this).val());
    });
    $("#select_country").change(function() {
        all_country_val.val($(this).val());
    });
    $("#select_operator").change(function() {
        all_opr_val.val($(this).val());
    });

    $("#select_advertiser,#select_category").change(function() {
    $('#select_adv_camp').html('').selectpicker('refresh');
    var all_country_val = $("#all_country_val");
    var opr_list = $('#all_opr_val');
    var cat_list = $('#select_category');
    var adv_list = $('#select_advertiser');
    var msg = $('#errormsg');
    msg.html('<span class="alert alert-info">Please wait!</span>');
        $.ajax({
            url: "/smart-interface-get-list", 
            type: 'GET',
            cache: false,
            async: true,
            dataType: 'JSON',
            data: {'country': all_country_val.val(),'opr_list':opr_list.val(),'cat_list':cat_list.val(),'adv_list':adv_list.val(),'status':'1'},
            success: function(responseText){
                msg.html('');
                var list   = [];
                var result = responseText;
                if(result.status == 1){
                    list.push('<option value="">select campaign</option>');
                    $.each(result.data, function(key, value){
                        list.push('<option value="' + key + '" data-cat="'+ value.cat_id +'">' + value.name + '</option>');
                    });
                    $('#select_adv_camp').html(list.join(''));
                    $('#select_adv_camp').selectpicker('refresh');
                }else{
                    alert('There is no campaign available');
                }
            }
        });
    });


    $('#select_adv_camp').change(function(){
        let Category = $("#select_adv_camp option:selected").attr("data-cat");
        $("#ads_cat").val(Category); 
    });

    $("#update_status").click(function (){
        var msg = $('#errormsg');  // Get the msg result div
        var cat_list = $('#select_category');
        var country = $("#all_country_val").val();
        var operator = all_opr_val.val();
        var $operator_name = $("#select_operator option:selected").text();
        var waitage_percentage = $("#waitage_percentage").val();
        var waitage_type = $("#waitage_type").val();
        var waitage_time = $("#waitage_time").val();

        if(operator.indexOf('33') > -1 && country == ""){
            msg.html('<span class="alert alert-danger">Please select country !</span>');
            return false;
        }
        if(all_opr_val.val() == "" ){
            msg.html('<span class="alert alert-danger">Please select Operator !</span>');
            return false;
        }
        if(all_advt_val.val() == "" ){
            msg.html('<span class="alert alert-danger">Please select Advertiser !</span>');
            return false;
        }
        if(cat_list.val() == ""){
            msg.html('<span class="alert alert-danger">Please select category !</span>');
            return false;
        }
        if(all_adv_val.val() == "" ){
            msg.html('<span class="alert alert-danger">Please select Campaign !</span>');
            return false;
        }
        if(all_adv_val.val() !="" && $("#select_adv_camp option:selected").val()!="Select Campaign" && all_opr_val.val()!='' && all_advt_val.val() != "") {
            msg.html('<span class="alert alert-info">Please wait !!!!</span>');
            var all_country_val = $("#all_country_val");
            var adv_list = $('#select_advertiser');
            var opr_list = $('#all_opr_val');
            $.ajax({
                url: "smart-interface/store", 
                type: 'GET',
                cache: false,
                async: true,
                dataType: 'JSON',
                data: {'adv_camp_id': all_adv_val.val(),'country_id':all_country_val.val(),'opr_list':opr_list.val(),
                    'cat_list':cat_list.val(),'adv_list':adv_list.val(),'operator_name':$operator_name,'waitage_percentage':waitage_percentage,'waitage_type':waitage_type,'waitage_time':waitage_time},
                success: function(responseText){
                    var res = responseText;  
                    if(res.status == 3){
                            msg.html('<span class="alert alert-danger">'+res.message+'</span>');
                    }else if(res.status == 1){
                            msg.html('<span class="alert alert-success">sucsessfully added!</span>');
                            window.location = 'smart-interface-new';  
                    }else if(res.status == 2){
                            msg.html('<span class="alert alert-info">Sorry please try again!</span>');                                        
                    }
                    
                }, error: function (textStatus,errorThrown) {
                msg.html('<span class="alert alert-danger">Oops, Something went wrong !</span>');
            }
            });
         }
        });

});
</script>
@endsection
@section('content')
    <div class="row">
        <div class="col-sm-12">
            <div class="white-box">                            
                <form data-toggle="validator" method="" action="" class="smart-interface-form">
                    <h2>Add Smart Campaign</h2>
                      {{ csrf_field() }}
                      <div id="errormsg" style="text-align:center;margin-bottom:20px;">
                      </div>

                    <div class="row">
                        <div class="col-sm-3"></div>
                        <div class="col-sm-2">
                            <label class="control-label">Country</label>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                                <select class="selectpicker" name="select_country" id="select_country" data-live-search="true" data-width="75%">
                                   <option value="">Select Country</option>
                                   @foreach ($country as $country)
                                        <option value="{{$country->iso}}">{{$country->name}}({{$country->iso}})</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-3"></div>    
                        <div class="col-sm-2">
                            <label class="control-label">Operator <span style="color: #F05355">*</span> </label>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                                <select class="selectpicker" name="select_operator" id="select_operator" multiple="" data-live-search="true" data-actions-box="true" data-selected-text-format="count > 3" data-size="10" data-width="75%">
                                    @foreach ($operator as $op)
                                        <option value="{{$op->id}}" >{{$op->name}}({{$op->iso}})</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                    </div>    
                    <div class="row">
                        <div class="col-sm-3"></div>
                         <div class="col-sm-2">
                            <label class="control-label">Advertiser <span style="color: #F05355">*</span> </label>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                                <select name="select_advertiser" id="select_advertiser" class="selectpicker" data-live-search="true" data-actions-box="true" data-width="75%">
                                   <option value="">Select Advertiser</option>
                                   @foreach ($advertiser as $adv)
                                    <option value="{{$adv->id}}">{{$adv->name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>   
                    </div>
                    <div class="row">
                    <div class="col-sm-3"></div>    
                        <div class="col-sm-2">
                            <label class="control-label">Category <span style="color:#F05355">*</span></label>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                                <select name="select_category" id="select_category" class="selectpicker" data-width="75%">
                                   <option value="">Select Category</option>
                                   <option>A</option>
                                   <!--<option>B</option>-->
                                   <option>C</option>
                                   <!--<option>D</option>-->
                                   <!--<option>I</option>-->
                                   <!--<option>IG</option>-->
                                   <!--<option>WM</option>-->
                                   <!--<option>WG</option>-->
                                </select>
                            </div>
                        </div>
                    </div> 
                    <div class="row">
                        <div class="col-sm-3"></div>
                        <div class="col-sm-2">
                            <label class="control-label">Advertiser Campaign <span style="color: #F05355">*</span></label>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                               <select name="select_adv_camp" id="select_adv_camp" class="selectpicker" data-live-search="true" data-width="75%">
                                    <option value="">Select Campaign</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-3"></div>
                        <div class="col-sm-2">
                            <label class="control-label">Waitage Percentage<span style="color: #F05355">*</span></label>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                               <input type="number" name="waitage_percentage" id="waitage_percentage" class="form-control" value="">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-3"></div>
                        <div class="col-sm-2">
                            <label class="control-label">waitage type <span style="color: #F05355">*</span></label>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                               <select name="waitage_type" id="waitage_type" class="selectpicker" data-live-search="true" data-width="75%">
                                    <option value="manual">Manual</option>
                                    <option value="auto">Auto</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-3"></div>
                        <div class="col-sm-2">
                            <label class="control-label">Waitage time <span style="color: #F05355">*</span></label>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                               <select name="waitage_time" id="waitage_time" class="selectpicker" data-live-search="true" data-width="75%">
                                    <option value="0">0</option>
                                    <option value="15">15</option>
                                    <option value="30">30</option>
                                    <option value="45">55</option>
                                    <option value="60">60</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-5"></div>    
                        <div class="col-sm-2">
                            <div class="form-group" style="width: 100%;">
                                
                                <button type="button" class="btn btn-success btn-lg" id="update_status">Submit</button>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="form-group" style="text-align: center;">
                                <input type="hidden" id="all_country_val" name="all_country_val" class="form-control">
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group" style="text-align: center;">
                                <input type="hidden" id="all_adv_val" name="all_adv_val" class="form-control">
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group" style="text-align: center;">
                                <input type="hidden" id="all_opr_val" name="all_opr_val" class="form-control">
                                <input type="hidden" id="ads_cat" name="ads_cat" class="form-control">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
                                        
    </div>
@endsection
