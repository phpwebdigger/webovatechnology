@extends('layouts.app')
@section('custom_css')
<link rel="stylesheet" type="text/css" href="{{asset('plugins/bower_components/switchery/dist/switchery.min.css')}}" />
@endsection
@section('bread')
@endsection
@section('heading')
  {{$title}}
@endsection
@section('custom_css')
@endsection
@section('custom_js')
<script type="text/javascript">
    $(document).ready(function(){
        $(document).ajaxStart(function(){
            $(".preloader").css("display", "block");
        });
        $(document).ajaxComplete(function(){
            $(".preloader").css("display", "none");
        });
    });         
</script>
@endsection
@section('content')
    <div class="m-b-15 header-panel">
        <div class="form-group">
            <div class="alert-danger"></div>
        </div>
    </div>
    <div class="col-sm-12">
        <div class="text-left"></div>
        <div style="margin:0 auto;">
            <table width="95%" class="table table-dark table-bordered">
                <thead>
                    <tr>
                        <td>Network name</th>
                        <th>Campaign Id</th>
                        <th>Advertiser</th>
                        <th>Name</th>                                                                
                        <th>Waitage %</th>
                        <th>Ads Category</th>
                        <th>Country</th>
                        <th>Operator</th>
                        <th>Waitage Type</th>
                        <th>Waitage Time</th>
                        <th>Click Count</th>
                        <th>Conversions Count</th>
                        <th>Live Status</th>
                        <th>Start Date</th>
                        <th>End Date</th>       
                        <th>Desktop/Mobile</th>
                        <th>Smart Status</th>
                        <th>Is Fraud</th>
                        <th>Action</th>
                    </tr>
                </thead>
                @foreach($data as $item)
                   <tbody>
                       <tr>
                            <td>{{$item->id_zone}}</td>
                            <td>{{$item->AdvertiserCampaign->id}}</td>
                            <td>{{$item->AdvertiserCampaign->Advertiser['name']}}({{$item->AdvertiserCampaign->Advertiser->id}})</td>
                            <td>{{$item->AdvertiserCampaign->name}}</td>                                                                
                            <td>{{$item->waitage_percentage}} %</td>
                            <td>{{$item->ads_cat}}</td>
                            <td>{{$item->AdvertiserCampaign->country_code}}</td>
                            <td>{{$item->Operator->name}}</td>
                            <td>{{$item->waitage_type}}</td>
                            <td>{{$item->waitage_time}}</td>
                            <td>{{$item->cap_count_click}}</td>
                            <td>{{$item->cap_count_conversions}}</td>
                            <td>{{$item->smart_live}}</td>
                            <td>{{$item->start_date}}</td>
                            <td>{{$item->end_date}}</td>       
                            <td>{{$item->is_desktop}}</td>
                            <td>{{$item->smart_status}}</td>
                            <td>{{$item->AdvertiserCampaign->is_fraud}}</td>
                            <td>Action</td>
                       </tr>
                    </tbody>
                @endforeach    
            </table>
        </div>
        {{ $data->links() }} 
                           
    </div>
<!--Edit Desktop/Mobile-->
<div class="modal fade" id="EditDesktop" role="dialog">
    <div class="modal-dialog bd-example-modal-sm" style="margin-top: 15%">    
    <!-- Modal content-->
        <div class="modal-content col-sm-12">
            <div class="modal-header modal-header1">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title" style="text-align: center">Edit Desktop/Mobile</h4>
            </div>
            
            <div id="errormsg_des" style="text-align: center;margin-bottom:20px; margin-top: 4%;"></div>
            
            <input type="hidden" id ="desk_id" name="desk_id"  class="form-control">
            
            <div class="row">
                <div class="col-sm-6" style="margin-top: 2%;">
                    <label class="control-label">Change</label>
                </div>
                <div class="col-sm-6" style="margin-top: 2%;">
                    <div class="form-group">
                        <select name="edit_desk" id="edit_desk" class="form-control" >
                            <option value="Select Status">Select Option</option>
                            <option value="0">Mobile</option>
                            <option value="1">Desktop</option>
                            <option value="2">Both</option>
                            
                        </select>
                    </div>
                </div>
                
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-info" id="update_desktop">Update</button>
            </div>
      </div>      
    </div>
</div>


<!--Edit Waitage Modal-->
<div class="modal fade" id="EditWaitage" role="dialog">
    <div class="modal-dialog bd-example-modal-sm" style="margin-top: 15%">    
    <!-- Modal content-->
        <div class="modal-content col-sm-12">
            <div class="modal-header modal-header1">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title" style="text-align: center">Edit Waitage Type</h4>
            </div>
            
            <div id="errormsg_typ" style="text-align: center;margin-bottom:20px; margin-top: 4%;"></div>
            
            <input type="hidden" id ="waitage_id" name="waitage_id"  class="form-control">
            
            <div class="row">
                <div class="col-sm-6" style="margin-top: 2%;">
                    <label class="control-label">Waitage Type</label>
                </div>
                <div class="col-sm-6" style="margin-top: 2%;">
                    <div class="form-group">
                        <select name="edit_waitage" id="edit_waitage" class="form-control" >
                            <option value="WaitageType">Select Type</option>
                            <option value="auto">Auto</option>
                            <option value="manual">Manual</option>
                            
                        </select>
                    </div>
                </div>
                
            </div>
            <div class="row">
                <div class="col-sm-6" style="margin-top: 2%;">
                    <label class="control-label">Waitage Time</label>
                </div>
                <div class="col-sm-6" style="margin-top: 2%;">
                    <div class="form-group">
                        <select id="waitage_time" class="form-control" name="waitage_time">
                            <option value="">Waitage Time</option>
                            <option value="0">0</option>
                            <option value="15">15</option>
                            <option value="30">30</option>
                            <option value="45">45</option>
                            <option value="60">60</option>
                        </select>
                    </div>
                </div>
                
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-info" id="update_type">Update</button>
            </div>
      </div>      
    </div>
</div>

@endsection
