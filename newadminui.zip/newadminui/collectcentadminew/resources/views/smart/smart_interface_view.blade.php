@extends('layouts.app')
@section('custom_css')
<link rel="stylesheet" type="text/css" href="{{asset('plugins/bower_components/switchery/dist/switchery.min.css')}}" />
@endsection
@section('bread')
@endsection
@section('heading')
  {{$title}}
@endsection
@section('custom_css')
<style type="text/css">
    .new_textbox{
        width: 40px;
    }
    .new_textbox2{
        width: 80px;
    }
    .preloader
    {
        display: none !important;
    }
    .cssload-speeding-wheel
    {
        display: none !important;
    }
</style>
@endsection
@section('custom_js')
<script type="text/javascript">
    
    $(document).ready(function(){
        var col = [   'text_30px',
                      'text_80px',
                      '',
                        'text_40px',
                        'text_100px',
                        'text_150px',     
                         "",
                        'text_80px',
                        "text_80px",
                        "text_80px",
                        "text_80px",
                        "text_80px",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "",
                        "text_80px",
                        "text_80px",
                        "text_80px",
                        "text_700px",
                    ];
        var data =   {!! json_encode($data1) !!};        
        createTableWithLazyLoad("#tableLazy",data,250,col);
        
        /* model functionality for waitage*/
        var flag = 0;
        $('#edit_waitage').change(function () {
            $("#waitage_time").prop("disabled", false).val('');
             flag = 0;
            if ($(this).val() == 'manual') {
                $("#waitage_time").prop("disabled", true);
                flag = 1;
            }
        });
       
       
       $("#update_type").click(function(){
            var msg2 = $("#errormsg_typ");
            var id = $("#waitage_id");
            var var1 = $("#edit_waitage option:selected").val();
            var var2 = $("#waitage_time option:selected").val();
            if(var1 == "WaitageType" ){
                msg2.html('<span class="alert alert-danger">Please select waitage type !</span>');
                return false;
            }
            if(var2 == "" && flag == 0){
                msg2.html('<span class="alert alert-danger">Please select waitage time !</span>');
                return false;
            }
            if(var1 !="WaitageType" && id.val() != ''){
                $.ajax({
                    url: "/smart-interface-WaitageTypeUpdate", // make sure you set an action attribute to your form
                    type: 'GET',
                    cache: false,
                    async: true,
                    dataType: 'JSON',
                    data: {'id': id.val(),'waitage_type': var1,'waitage_time': var2},
                    success: function(res){
                        var responseText = res; 
                        if(responseText.status == 3){
                            msg2.html('<span class="alert alert-danger">Oops, something went wrong!</span>');
                        }else if(responseText.status == 1){
                            msg2.html('<span class="alert alert-success">sucsessfully waitage updated!</span>');                                        
                                if($("#waitage_time option:selected").val() == ''){
                                    $('#waitage_type_'+id.val()).text($("#edit_waitage option:selected").val());
                                    $('#waitage_time_'+id.val()).text('');
                                }else{
                                    $('#waitage_type_'+id.val()).text($("#edit_waitage option:selected").val());
                                    $('#waitage_time_'+id.val()).text($("#waitage_time option:selected").val());
                                }
                                $('#EditWaitage').modal('hide');
                        }else if(responseText.status == 2){
                                    msg2.html('<span class="alert alert-info">Sorry please try again!</span>');                                        
                        }
                    }
                });
            }else{
                msg2.html('<span class="alert alert-danger">Oopss.. !!!</span>');
            }
        })


        $("#update_desktop").click(function(){
            var msgx = $("#errormsg_des");
            var id = $("#desk_id");
            if($("#edit_desk option:selected").val()=="Select Status"){
                msgx.html('<span class="alert alert-danger">Please select option !</span>');
                return false;
            }
            if($("#edit_desk option:selected").val()!="Select Status" && id.val() != ''){
                msgx.html('<span class="alert alert-info">Please wait.. !!!</span>');
                $.ajax({
                    url: "/smart-interface-desktop_update", // make sure you set an action attribute to your form
                    type: 'GET',
                    cache: false,
                    async: true,
                    dataType: 'JSON',
                    data: {'id': id.val(),'option_type': $("#edit_desk option:selected").val()},
                    success: function(responseText){
                        if(responseText == 3){
                                msgx.html('<span class="alert alert-danger">Oops, something went wrong!</span>');
                        }else if(responseText == 1){
                                msgx.html('<span class="alert alert-success">sucsessfully waitage updated!</span>');                                        
                            if($("#edit_desk option:selected").val() == '0'){
                                $('#is_desktop_status_'+id.val()).text('Mobile');
                            }
                            else if($("#edit_desk option:selected").val() == '1'){
                                $('#is_desktop_status_'+id.val()).text('Desktop');
                            }
                            else if($("#edit_desk option:selected").val() == '2'){
                                $('#is_desktop_status_'+id.val()).text('Both');
                            }
                            $('#EditDesktop').modal('hide');
                        }else if(responseText == 2){
                                msgx.html('<span class="alert alert-info">Sorry please try again!</span>');                                        
                        }
                    }
                });
                
            }else{
                msgx.html('<span class="alert alert-danger">Oopss.. !!!</span>');
            }
        });
        
    });
    
    $(document).on("click",".cancel-fields",function(){
        var container_id = $(this).attr('data-id');
        var waitage_percentage = $(this).attr('data-val');
        $("#"+container_id).html(waitage_percentage);
    });

    $('.alert-dismissable').fadeOut();

    function EditPercent(id,camp_id,value,action){
        var msg = $("#errormsg_rm_st");
            if(id !='' && camp_id && value != 'undefined'){
            $("#waiting_percentage_temp1_"+id).removeClass("fa fa-edit");
            $("#waiting_percentage_"+id).html('<input type="text" id="waiting_percentage_temp_'+id+'" class="new_textbox" value="'+value+'"><br/><a id="waiting_percentage_temp_but_'+id+'" href="javascript:void(0);" class="pad5"><i class="glyphicon glyphicon-ok"></i></a>|<a href="javascript:void(0)" class="pad5"><span class="glyphicon glyphicon-remove cancel-fields" data-id="waiting_percentage_'+id+'" data-val="'+value+'"></span></a>');
            $("#waiting_percentage_temp_"+id).focus();
            $("#waiting_percentage_temp_but_"+id).click(function (){
                var temp_val = $("#waiting_percentage_temp_"+id);
                var waitage_percent = temp_val.val();
                if(temp_val.val() == value){
                    alert('Please change the value first');
                    return false;
                }
                if(temp_val.val()==""){
                    msg.html('<span class="alert alert-danger">Please enter % value</span>');
                    return false;
                }
                if(temp_val.val()!="" && id !=""){
                    msg.html('<span class="alert alert-info">Please wait !!!</span>');
                $.ajax({
                        url: "/smart-interface-percent_update", // make sure you set an action attribute to your form
                        type: 'GET',
                        cache: false,
                        async: false,
                        data: 'id='+id+'&waitage_percent='+waitage_percent,
                        success: function(response){
                            var res = JSON.parse(response);
                                if(res.status == 3){
                                msg.html('<span class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">x</button><strong>Failed</strong>Oops, something went wrong!</span>');
                                }else if(res.status == 1){
                                msg.html('<span class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert">x</button><strong>Success</strong>Successfully percentage updated</span>');
                                $('#waiting_percentage_'+id).text(temp_val.val());    
                                $("#waiting_percentage_temp1_"+id).addClass("fa fa-edit");
                                }else if(res.status == 2){
                                msg.html('<span class="alert alert-info alert-dismissable">Sorry please try again!</span>');                                        
                                }
                            }
                        });
                    }
                });
            }
    }   

    function EditDesktop(id,st){
        var msg1 = $("#errormsg_des");
        msg1.html('');
        if(id){
            $("#desk_id").val(id);
            document.getElementById('edit_desk').value='Select Status';
            $('#EditDesktop').modal({
                backdrop: 'static',
                keyboard: false,  // to prevent closing with Esc button (if you want this too)
                show: true
            });
        }
    }

    function EditStatus(id,campaign_id,is_live){
        var msg1 = $("#errormsg_rm_st");
        msg1.html('<span class="alert alert-info">Please wait!!!</span>');
        if(is_live == 1){
            is_live = 0;
        }else{
            is_live = 1;
        }
        if(id){
            $.ajax({
                url: "/smart-interface-livestatus_update", // make sure you set an action attribute to your form
                type: 'GET',
                cache: false,
                async: true,
                dataType: 'JSON',
                data: {'id':id,'is_live':is_live,'campaign_id':campaign_id},
                success: function(response){
                    var res = response; 
                    if(res.status == 3){
                    msg1.html('<span class="alert alert-danger">'+res.message+'</span>');
                    }else if(res.status == 1){
                        msg1.html('<span class="alert alert-success">'+res.message+'</span>');      
                        if($('#smart_live_'+id).text() == "Live"){
                            $('#smart_live_'+id).text("NotLive");
                            $('#smart_live_temp_'+id).css({'color':'#F05355'});
                        }else{
                            $('#smart_live_'+id).text("Live");
                            $('#smart_live_temp_'+id).css({'color':'#32CEA7'});
                        }
                        $('#smart_live_temp_'+id).attr("onclick",'EditStatus('+id+','+campaign_id+','+is_live+')');    
                        msg1.html('');
                    }else if(res.status == 2){
                        alert(res.message);
                        msg1.html('');                                        
                    }
                }
            });
        }
    }

    function EditFraud(id,st){
        var msg1 = $("#errormsg_rm_st");
        msg1.html('<span class="alert alert-info">Please wait!!!</span>');
        if(st == 1){
          status_live = 0;
        }else{
          status_live = 1;  
        }
        if(id){
            $.ajax({
                url: "/smart-interface-edit-fraud_update", // make sure you set an action attribute to your form
                type: 'GET',
                cache: false,
                async: true,
                dataType: 'JSON',
                data: {'id': id,'status':st},
                success: function(response){
                    var res = response;
                    if(res.status == 3){
                    msg1.html('<span class="alert alert-danger">'+res.message+'</span>');
                    }else if(res.status == 1){
                    msg1.html('<span class="alert alert-success">'+res.message+'</span>');      
                        if($('#is_fraud_'+id).text() == "True"){
                        $('#is_fraud_'+id).text("False");
                        $('#is_fraud_temp_'+id).css({'color':'#F05355'});
                        }else{
                        $('#is_fraud_'+id).text("True");
                        $('#is_fraud_temp_'+id).css({'color':'#32CEA7'});
                        }
                        $('#is_fraud_temp_'+id).attr("onclick",'EditFraud('+id+','+status_live+')');    
                    msg1.html('');
                    }else if(res.status == 2){
                        msg1.html('<span class="alert alert-info">'+res.message+'</span>');                                        
                    }
                }
            });
        }
    }    


    /* To remove campaign from smart table */ 
    function RemoveCamp(smartoperator_id,smart_status){
        if(confirm("Are you sure?")){
        var msg = $("#errormsg_rm_st");
        msg.html('<span class="alert alert-info">Please wait!!!</span>');   
        if(smartoperator_id){
            $.ajax({
                url: "/smart-interface-smartstatus_update", // make sure you set an action attribute to your form
                type: 'GET',
                cache: false,
                async: true,
                data: {'smart_status':smart_status,'smartoperator_id':smartoperator_id},
                success: function(response){
                     var res = JSON.parse(response);
                    if(res.status == 3){
                            msg.html('<span class="alert alert-danger">'+res.message+'</span>');
                    }else if(res.status == 1){
                            msg.html('<span class="alert alert-success">'+res.message+'</span>');                                        
//                            window.location.href=window.location.href;
                            $(this).parents(".record").animate("fast").animate({
                        opacity : "hide"
                    }, "slow");
                    }else if(res.status == 2){
                            msg.html('<span class="alert alert-info">'+res.message+'</span>');                                        
                    }
                }
            });
          }
        }
    }    

    function EditWaitage(id,typ){
        var msg2 = $("#errormsg_typ");
        msg2.html('');    
        if(id){
            $("#waitage_id").val(id);
            document.getElementById('waitage_time').value='';
            if(typ =='auto'){
                $("#waitage_time").prop("disabled", false);
                document.getElementById('edit_waitage').value=typ;
                $('#EditWaitage').modal({
                    backdrop: 'static',
                    keyboard: false,  // to prevent closing with Esc button (if you want this too)
                    show: true
                });
            }else if(typ ==''){
                $("#waitage_time").prop("disabled", false);
                document.getElementById('edit_waitage').value='WaitageType';
            $('#EditWaitage').modal({
                    backdrop: 'static',
                    keyboard: false,  // to prevent closing with Esc button (if you want this too)
                    show: true
                });
            }else{
                document.getElementById('edit_waitage').value=typ;
                $("#waitage_time").prop("disabled", true);            
                $('#EditWaitage').modal({
                    backdrop: 'static',
                    keyboard: false,  // to prevent closing with Esc button (if you want this too)
                    show: true
                });
            }
        }
    } 

    function EditClick(id,value){
        var msg_click = $("#errormsg_rm_st");
        if(id){
            $("#cap_count_click_temp1_"+id).removeClass("fa fa-edit");
            $("#cap_count_click_"+id).html('<input type="text" id="cap_count_click_temp_'+id+'" class="new_textbox2"><a id="cap_count_click_temp_but_'+id+'" href="javascript:void()"class="pad5"><i class="glyphicon glyphicon-ok"></i></a><a href="javascript:void(0)" class="pad5"><span class="glyphicon glyphicon-remove cancel-fields" data-id="cap_count_click_'+id+'" data-val="'+value+'"></span></a>');
            $("#cap_count_click_temp_but_"+id).focus();
            $("#cap_count_click_temp_but_"+id).click(function (){
                var temp_val = $("#cap_count_click_temp_"+id);
                if(value == temp_val.val()){
                    alert('Please change the value first');
                }
                if(temp_val.val()==""){
                    msg_click.html('<span class="aleinterfacert alert-danger">Please enter click count value</span>');
                return false;
                }
                if(temp_val.val()!="" && id !=""){
                    msg_click.html('<span class="alert alert-info">Please wait !!!</span>');
                    $.ajax({
                            url: "/smart-interface-click_update", // make sure you set an action attribute to your form
                            type: 'GET',
                            cache: false,
                            async: true,
                            dataType: 'HTML',
                            data: {'id': id,'click_count':temp_val.val()},
                            success: function(responseText){
                                if(responseText == 3){
                                    msg_click.html('<span class="alert alert-danger">Oops, something went wrong!</span>');
                                }else if(responseText == 1){
                                    msg_click.html('<span class="alert alert-success">Sucsessfully click count updated!</span>');
                                    $('#cap_count_click_'+id).text(temp_val.val());    
                                    $("#cap_count_click_temp1_"+id).addClass("fa fa-edit");
                                }else if(responseText == 2){
                                    msg_click.html('<span class="alert alert-info">Sorry please try again!</span>');                                        
                                }
                            }
                        });
                    }
                });
            }
    }       

        function EditConversion(id,con_count){
            var msg_conversion = $("#errormsg_rm_st");
            if(id){
                $("#cap_count_conversions_temp1_"+id).removeClass("fa fa-edit");
                $("#cap_count_conversions_"+id).html('<input type="text" id="cap_count_conversions_temp_'+id+'" class="new_textbox2"> | <button id="cap_count_conversions_temp_but_'+id+'"><i class="fa fa-check"></i></button> ');
                $("#cap_count_conversions_temp_but_"+id).focus();
                $("#cap_count_conversions_temp_but_"+id).click(function (){
                    var temp_val = $("#cap_count_conversions_temp_"+id);
                        if(temp_val.val()==""){
                            msg_conversion.html('<span class="alert alert-danger">Please enter conversion count value</span>');
                            return false;
                        }
                        if(temp_val.val()!="" && id !=""){
                            msg_conversion.html('<span class="alert alert-info">Please wait !!!</span>');
                            $.ajax({
                                url: "/smart-interface-conversion_update", // make sure you set an action attribute to your form
                                type: 'GET',
                                cache: false,
                                async: true,
                                dataType: 'HTML',
                                data: {'id': id,'conversion_count':temp_val.val()},
                                success: function(responseText){
                                    if(responseText == 3){
                                        msg_conversion.html('<span class="alert alert-danger">Oops, something went wrong!</span>');
                                    }else if(responseText == 1){
                                        msg_conversion.html('<span class="alert alert-success">Sucsessfully conversion count updated!</span>');
                                        $('#cap_count_conversions_'+id).text(temp_val.val());    
                                        $("#cap_count_conversions_temp1_"+id).addClass("fa fa-edit");
                                    }else if(responseText == 2){
                                        msg_conversion.html('<span class="alert alert-info">Sorry please try again!</span>');                                        
                                    }
                                }
                            });
                        }
                    });
                }
            }   

        $(document).ajaxStart(function(){
            $(".preloader").css("display", "none"); 
        });
        $(document).ajaxComplete(function(){
            $(".preloader").css("display", "none");
        });     
  </script>

<script src="{{asset('plugins/bower_components/switchery/dist/switchery.min.js')}}" type="text/javascript"></script>
<script src="{{asset('js/validator.js')}}"></script>

@endsection
@section('content')
    <div class="m-b-15 header-panel">
        <div class="form-group">
            <div id="errormsg_rm_st" style="margin-top:1%;text-align:center;"></div>
        </div>
    </div>
    <div class="col-sm-12">
        <div class="text-left">
            @php
                $heads =  [
                            "Network name",
                            "Campaign Id",
                            "Action",
                            "Advertiser Id",
                            "Advertiser",
                            "Name",                                                                
                            "Waitage %",
                            "Ads Category",
                            "Country",
                            "Operator",
                            "Waitage Type",
                            "Waitage Time",
                            "Click Count",
                            "Conversions Count",
                            "Live Status",
                            "Start Date",
                            "End Date",       
                            "Exclude Network",
                            "Include Network",
                            "Exclude SiteId",
                            "Include SiteId",
                            "Exclude Browser",
                            "Include Browser",
                            "Exclude OS",
                            "Include OS",
                            "Exclude Referrer",
                            "Include Referrer",
                            "Desktop/Mobile",
                            "Smart Status",
                            "Is Fraud",
                            "URL"
                           ];
            @endphp
                <div class="pad10">
                    <a href="smart-interface-add"><button type="button" class="btn btn-primary waves-effect waves-light">Add New</button></a>
                    {!!view('layouts.column', ['data' =>$heads])!!}
                </div>
            </div>
        <div class="table-responsive mainTableInfo">
            <table class="table color-table info-table scrollTable lazy" id="tableLazy">
                {!!view('layouts.tableheadNew', ['data' =>$heads,'class'=>""])!!}
            </table>
            <table>

            </table>

        </div> 
                           
    </div>
<!--Edit Desktop/Mobile-->
<div class="modal fade" id="EditDesktop" role="dialog">
    <div class="modal-dialog bd-example-modal-sm" style="margin-top: 15%">    
    <!-- Modal content-->
        <div class="modal-content col-sm-12">
            <div class="modal-header modal-header1">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title" style="text-align: center">Edit Desktop/Mobile</h4>
            </div>
            
            <div id="errormsg_des" style="text-align: center;margin-bottom:20px; margin-top: 4%;"></div>
            
            <input type="hidden" id ="desk_id" name="desk_id"  class="form-control">
            
            <div class="row">
                <div class="col-sm-6" style="margin-top: 2%;">
                    <label class="control-label">Change</label>
                </div>
                <div class="col-sm-6" style="margin-top: 2%;">
                    <div class="form-group">
                        <select name="edit_desk" id="edit_desk" class="form-control" >
                            <option value="Select Status">Select Option</option>
                            <option value="0">Mobile</option>
                            <option value="1">Desktop</option>
                            <option value="2">Both</option>
                            
                        </select>
                    </div>
                </div>
                
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-info" id="update_desktop">Update</button>
            </div>
      </div>      
    </div>
</div>


<!--Edit Waitage Modal-->
<div class="modal fade" id="EditWaitage" role="dialog">
    <div class="modal-dialog bd-example-modal-sm" style="margin-top: 15%">    
    <!-- Modal content-->
        <div class="modal-content col-sm-12">
            <div class="modal-header modal-header1">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title" style="text-align: center">Edit Waitage Type</h4>
            </div>
            
            <div id="errormsg_typ" style="text-align: center;margin-bottom:20px; margin-top: 4%;"></div>
            
            <input type="hidden" id ="waitage_id" name="waitage_id"  class="form-control">
            
            <div class="row">
                <div class="col-sm-6" style="margin-top: 2%;">
                    <label class="control-label">Waitage Type</label>
                </div>
                <div class="col-sm-6" style="margin-top: 2%;">
                    <div class="form-group">
                        <select name="edit_waitage" id="edit_waitage" class="form-control" >
                            <option value="WaitageType">Select Type</option>
                            <option value="auto">Auto</option>
                            <option value="manual">Manual</option>
                            
                        </select>
                    </div>
                </div>
                
            </div>
            <div class="row">
                <div class="col-sm-6" style="margin-top: 2%;">
                    <label class="control-label">Waitage Time</label>
                </div>
                <div class="col-sm-6" style="margin-top: 2%;">
                    <div class="form-group">
                        <select id="waitage_time" class="form-control" name="waitage_time">
                            <option value="">Waitage Time</option>
                            <option value="0">0</option>
                            <option value="15">15</option>
                            <option value="30">30</option>
                            <option value="45">45</option>
                            <option value="60">60</option>
                        </select>
                    </div>
                </div>
                
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-info" id="update_type">Update</button>
            </div>
      </div>      
    </div>
</div>

@endsection
