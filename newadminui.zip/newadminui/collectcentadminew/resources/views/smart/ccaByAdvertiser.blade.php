@extends('layouts.app')
@section('custom_css')
<link rel="stylesheet" type="text/css" href="{{asset('plugins/bower_components/switchery/dist/switchery.min.css')}}" />
<!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">-->
@endsection

@section('bread')

@endsection

@section('heading')
  Smart Interface
@endsection

@section('custom_js')
<script type="text/javascript">
    $(document).ready(function() {
    var col = ['text_65px',
                  'text_60px', 
                  'text_80px',
                  'text_80px',
                    'text_80px',
                    'text_40px',
                    'text_40px',
                    'text_250px',
                    'text_40px',
                    'text_40px',     
                    'text_50px',     
                    "text_40px",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    
                ];

        var data =   {!! json_encode($data1) !!};        
        createTableWithLazyLoad("#tableLazy",data,50,col);
        $(".rupees").hide();   
        
    } );
    
    
 
  </script>

<script src="{{asset('plugins/bower_components/switchery/dist/switchery.min.js')}}" type="text/javascript"></script>
<script src="{{asset('js/validator.js')}}"></script>
<script src="../plugins/bower_components/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script type="text/javascript">

    jQuery('.mydatepicker').datepicker({
       format:"yyyy-mm-dd"
    });
    jQuery(document).on('change','.currency',function(){
        if($(this).val() == 0){
            $(".dollar").show();
            $(".rupees").hide();
        }else{
            $(".dollar").hide();
            $(".rupees").show();
        }
    });


</script>

@endsection
@section('content')
    <div class="m-b-15 header-panel" style="text-align:center;">
        <div class="text-right">
            <select name="currency" class="currency btn btn-success">
                <option value="0">Dollar</option>
                <option value="1">Rupees</option>
            </select>    
        </div>
        <form class="form-inline" role="form" method="GET" action="/smart-interface-advertiser">
            <div class="form-group ">
                <div class="input-group" style="width: 20%">
                        <input type="text" value="{{$dtvalue}}" class="form-control mydatepicker" name="start" placeholder="From">
                </div>
             </div>
            <div class="form-group">
                <input type="hidden" name="12121" id="qwqw">
            </div>      
            <div class="form-group ">
                <div class="input-group">
                    <input type="text" name="end" value="{{$dtvalue2}}" class="form-control mydatepicker" placeholder="To">
                </div>
            </div>
            <div class="form-group">
                  <button type="submit" class="btn btn-success waves-effect waves-light">GO</button>
            </div>      
        </form>    
        
    </div>
    
    <div class="col-sm-12">
        <div class="text-right ">
            @php
                $heads =  [
                            "Parent CCA",
                            "Network Name",
                            "Advertiser Name",
                            "Operator",
                            "Ads Type",
                            "Payout Type",                                                                
                            "Campaign Name",
                            "Country",
                            "Type",
                            "Vertical",
                            "Os type",
                            "sale count",
                            "Clicks Count",
                            "Actual Click",
                            "Conversion Inwards",
                            "Conversion Outwards",
                            "CR Inwards",
                            "CR Outwards",
                            "Unique Conversion",
                            "CR Expected $",       
                            "Total Source Cost($/Rs.)",       
                            "Revenue($/INR)",       
                            "ECPM($/INR)",       
                            "Profit($/INR)",       
                            
                            ];
                            $heads2 =  ["Total",
                                "",
                                "",
                                "",
                                "",
                                "",
                                "",
                                "",
                                "",
                                "",
                                "",
                                "",
                                $lastRow[0],
                                $lastRow[1],
                                $lastRow[2],
                                $lastRow[3],
                                "",
                                "",
                                $lastRow[4],                                
                                "",                                
                                $lastRow[5],
                                $lastRow[6],
                                $lastRow[7],
                                ""];
            @endphp
                <div class="text-left" style="margin-bottom:10px">
                    {!!view('layouts.column', ['data' =>$heads])!!}
                </div>
            </div>
        <div class="table-responsive mainTableInfo">
                <table class="table color-table info-table scrollTable lazy" id="tableLazy">
                    {!!view('layouts.tableheadNew', ['data' =>$heads,'class'=>""])!!}
                    {!!view('layouts.tableheadNew', ['data' =>$heads2,'class'=>"new"])!!}
                </table>


        </div> 
                           
    </div>


@endsection
