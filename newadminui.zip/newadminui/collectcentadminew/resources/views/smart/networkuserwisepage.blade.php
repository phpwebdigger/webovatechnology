@extends('layouts.app')
@section('custom_css')
<link rel="stylesheet" type="text/css" href="{{asset('plugins/bower_components/switchery/dist/switchery.min.css')}}" />
<!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">-->
@endsection

@section('bread')

@endsection

@section('heading')
  Offer networkwise
@endsection

@section('custom_js')

<style type="text/css">
    .change_color
    {
        background-color:#c9eca9;color:#FFFFFF;
    }
</style>

<meta name="csrf-token" content="{{ csrf_token() }}">
<script src="/plugins/bower_components/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script type="text/javascript">
$(document).ready(function() {

 var col = ['text_35px',
                  'text_60px', 
                  'text_30px', 
                    'text_20px',
                    'text_20px',
                    'text_30px',
                    'text_30px',
                    '',
                    '',
                    'text_40px',     
                    'text_30px',     
                    "text_40px",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    
                ];

        var data =   {!! json_encode($data1) !!};    
       console.log(data);
        createTableWithLazyLoad("#tableLazy",data,500,col);
         $(".rupees").hide();
          var column;
          var unChecked =[];
          var unCheckedColumn=[];
           unCheckedColumn = ['24'];
          
           
        
            /* to hide coluun according to condition */
            $(unCheckedColumn).each(function(key,uncheckIndex){
             $('.new th[data-index="'+uncheckIndex+'"]').toggleClass("hide");
             column = tableLazyNew.column(uncheckIndex);
             column.visible(false); 
            });
            // unchecking checkboxes 
            $(".dropdown-menu li").each(function(key,element){
                if($(element).find('input[type="checkbox"]').is(":checked")){
                    var dataI = $(element).find('input[type="checkbox"]').attr('data-index');
                    if(unCheckedColumn.indexOf(dataI) != -1){
                        $(element).find('input[type="checkbox"]').removeAttr("checked");
                    }
                }

            }); 

  var moveLeft = 20;
  var moveDown = 0;

  $('span#trigger').hover(function(e) {
    $('div#pop-up').show()
      .css('top', e.pageY + moveDown)
      .css('left', e.pageX + moveLeft)
      .appendTo('body');
  }, function() {
    $('div#pop-up').hide();
  });

  $('span#trigger').mousemove(function(e) {
    $("div#pop-up").css('top', e.pageY + moveDown).css('left', e.pageX + moveLeft);
  });
  jQuery('.mydatepicker').datepicker({
       format:"yyyy-mm-dd"
    });
   });
  </script>

<script src="{{asset('plugins/bower_components/switchery/dist/switchery.min.js')}}" type="text/javascript"></script>
<script src="{{asset('js/validator.js')}}"></script>
<script src="../plugins/bower_components/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>

<style type="text/css">
    .lazy tr > td{
        text-align: center;
    }
    .modal-dialog {
    max-width: 1073px;
    margin: 30px auto;
}

input:focus {
         font-family:Verdana, Geneva, sans-serif;
    border-color:#9ecaed;
    box-shadow:0 0 5px #9ecaed;
}
div#pop-up {
  display: none;
  position: absolute;
  width: 380px;
  padding: 20px;
  background: #fff;
  color: #000000;
  border: 1px solid #1a1a1a;
  font-size: 90%;
}

.mainCollumn ul{
  column-count:6 ;
}
</style>

@endsection
@section('content')
    <div class="header-panel" style="text-align:center;">
        <form class="form-inline" role="form" method="post" action="/user_wiser_reports">
            {{ csrf_field() }}
            <div class="form-group col-sm-2">
                <div class="input-group">
                <input type="text" value="{{$dtvalue}}"  style="width:150% !important;" class="form-control mydatepicker" name="start" placeholder="From">
                </div>
             </div>
               
            <div class="form-group col-sm-2">
                <div class="input-group">
                    <input type="text" name="end" value="{{$dtvalue2}}"  style="width:150% !important;" class="form-control mydatepicker" placeholder="To">
                </div>
            </div>
                <div class="form-group col-sm-2">
                <div class="input-group">
          
                 <select name="user_account" class="form-control selectpicker" data-live-search="true"> 
                 <option>Select Account Name</option>
                 @foreach($account_manager as $key => $value)
                 <option value="{{$value}}" {{($role==$value) ? 'selected': ''}}>{{$value}}</option>
                 @endforeach
                 </select>   
                </div>
            </div>

            <div class="form-group col-sm-4">
                  <button type="submit" class="btn btn-success waves-effect waves-light">GO</button>
            </div>      
        </form>    
    
   
    <div class="col-sm-12">
        <div class="text-right">
          @php

                $heads =  
                [
                    
                    "CCA", 
                    "Account Manager",  
                    "Publisher",    
                    "CPA",                                             
                    "Ads Type",                                                              
                    "Campaign",
                    "Offer Name",
                    "Status",
                    "CAP Status",
                    "Vertical",
                    "Geo",
                    "Os",
                    "Clicks",
                    "Actual Click",
                    "Conversion",
                    "Install",
                    "Out",
                    "Sale",
                    "CR In",
                    "CR Out",
                    "Cost",   
                    "Rev",      
                    "Pro",  
                    "ECPM",
                    "Date"
                          
                      
                            
                ];
                            $heads2 =  ["Total",
                                "",
                                "",
                                "",
                                "",
                                "",
                                "",
                                "",
                                "",
                                "",
                                "","",
                                $lastRow[0],
                                $lastRow[1],
                                $lastRow[2],
                                $lastRow[3],                                                                                      
                                $lastRow[4],
                                $lastRow[5],
                                "",
                                "",
                                $lastRow[6],
                                $lastRow[7],
                                $lastRow[8],
                                "",
                                ""
                                ];
                              
            @endphp
                <div class="text-left" style="margin-bottom:10px">
                    {!!view('layouts.column', ['data' =>$heads])!!}
                </div>
            </div>
        <div class="table-responsive mainTableInfo">
                <table class="table color-table info-table scrollTable lazy" id="tableLazy">
                    {!!view('layouts.tableheadNew', ['data' =>$heads,'class'=>""])!!}
                    {!!view('layouts.tableheadNew', ['data' =>$heads2,'class'=>"new"])!!}
                </table>


        </div> 
                           
    </div>

@endsection

