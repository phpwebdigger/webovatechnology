@extends('layouts.app')
@section('custom_css')
<link rel="stylesheet" type="text/css" href="{{asset('plugins/bower_components/switchery/dist/switchery.min.css')}}" />
<!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">-->
@endsection

@section('bread')

@endsection

@section('heading')
  Smart Interface
@endsection

@section('custom_js')
<script type="text/javascript">
    $(document).ready(function() {
    var col = ['text_65px',
                  'text_60px', 
                  'text_60px', 
                    'text_20px',
                    'text_200px',
                    'text_40px',     
                    'text_50px',     
                    "text_40px",
                    "text_30px",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    
                ];

        var data =   {!! json_encode($data1) !!};        
        createTableWithLazyLoad("#tableLazy",data,50,col);
//        $(".rupees").hide();    
        var column;
          var unCheckedColumn = ['8'];
//          var unCheckedColumn = [];
            /* to hide coluun according to condition */
            $(unCheckedColumn).each(function(key,uncheckIndex){
             $('.new th[data-index="'+uncheckIndex+'"]').toggleClass("hide");
             column = tableLazyNew.column(uncheckIndex);
             column.visible(false); 
            });
            // unchecking checkboxes 
            $(".dropdown-menu li").each(function(key,element){
                if($(element).find('input[type="checkbox"]').is(":checked")){
                    var dataI = $(element).find('input[type="checkbox"]').attr('data-index');
                    if(unCheckedColumn.indexOf(dataI) != -1){
                        $(element).find('input[type="checkbox"]').removeAttr("checked");
                    }
                }

            }); 
        
    } );
    
    
 
  </script>

<script src="{{asset('plugins/bower_components/switchery/dist/switchery.min.js')}}" type="text/javascript"></script>
<script src="{{asset('js/validator.js')}}"></script>
<script src="/plugins/bower_components/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script type="text/javascript">

    jQuery('.mydatepicker').datepicker({
       format:"yyyy-mm-dd"
    });
//    jQuery(document).on('change','.currency',function(){
//        if($(this).val() == 0){
//            $(".dollar").show();
//            $(".rupees").hide();
//        }else{
//            $(".dollar").hide();
//            $(".rupees").show();
//        }
//    });
</script>

<style type="text/css">
    .lazy tr > td{
        text-align: center;
    }
</style>

@endsection
@section('content')
    <div class="m-b-15 header-panel" style="text-align:center;">
<!--        <div class="text-right">
            <select name="currency" class="currency btn btn-success">
                <option value="0">Dollar</option>
                <option value="1">Rupees</option>
            </select>    
        </div>-->
        <form class="form-inline" role="form" method="GET" action="/smart-interface-advertiser">
            <div class="form-group ">
                <div class="input-group" style="width: 20%">
                        <input type="text" value="{{$dtvalue}}" class="form-control mydatepicker" name="start" placeholder="From">
                </div>
             </div>
            <div class="form-group">
                <input type="hidden" name="12121" id="qwqw">
            </div>      
            <div class="form-group ">
                <div class="input-group">
                    <input type="text" name="end" value="{{$dtvalue2}}" class="form-control mydatepicker" placeholder="To">
                </div>
            </div>
            <div class="form-group">
                  <button type="submit" class="btn btn-success waves-effect waves-light">GO</button>
            </div>      
        </form>    
        
    </div>
    
    <div class="col-sm-12">
        <div class="text-right ">
            @php
                $heads =  [
                    "Parent",   
                    "Network Name", 
                    "Id Advertiser",                                                       
                    "Type",                                                              
                    "Campaign Name",
                    "Vertical",
                    "Geo",
                    "Os",
                    "Clicks Count",
                    "Actual Click",
                    "Install",
                    "Sale",
                    "CR In",
                    "Revenue",
                    "AVG CPA",
                    "ECPM($)"
                            
                ];
                            $heads2 =  ["Total",
                                "",
                                "",
                                "",
                                "",
                                "",
                                "",
                                "",
                                $lastRow[0],
                                $lastRow[1],
                                $lastRow[2],
                                $lastRow[3],
                                "", 
                                $lastRow[4],
                                "", 
                                ""
                                ];
            @endphp
                <div class="text-left" style="margin-bottom:10px">
                    {!!view('layouts.column', ['data' =>$heads])!!}
                </div>
            </div>
        <div class="table-responsive mainTableInfo">
                <table class="table color-table info-table scrollTable lazy" id="tableLazy">
                    {!!view('layouts.tableheadNew', ['data' =>$heads,'class'=>""])!!}
                    {!!view('layouts.tableheadNew', ['data' =>$heads2,'class'=>"new"])!!}
                </table>


        </div> 
                           
    </div>


@endsection
