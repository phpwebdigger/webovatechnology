@extends('layouts.app')
@section('custom_css')
<link rel="stylesheet" type="text/css" href="{{asset('plugins/bower_components/switchery/dist/switchery.min.css')}}" />
<!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">-->
@endsection

@section('bread')

@endsection

@section('heading')
  Offer networkwise
@endsection

@section('custom_js')

<style type="text/css">
    .change_color
    {
        background-color:#c9eca9;color:#FFFFFF;
    }
</style>

<meta name="csrf-token" content="{{ csrf_token() }}">
<script src="/plugins/bower_components/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<?php 
    $role_data=   config('app.dashboard_users');

?>
<script type="text/javascript">
$(document).ready(function() {

    var role_id ='<?php echo $role; ?>'; 

    var role_data='<?php $role_data; ?>';

    if($.inArray(role_id, role_data)==0)
    {
      var col = ['text_35px',
                  'text_60px', 
                  'text_30px', 
                    'text_40px',
                    'text_200px',
                    'text_100px',
                    'text_100px',
                    '',
                    'text_40px',     
                    'text_30px',     
                    "text_40px",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    ""
                    
                ];
    }
    else
    {
        var col = ['text_35px',
                  'text_60px', 
                  'text_30px', 
                    'text_40px',
                    'text_200px',
                    'text_100px',
                    'text_100px',
                    '',
                    'text_40px',     
                    'text_30px',     
                    "text_40px",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    "",
                    
                ];
    }
    

        var data =   {!! json_encode($data1) !!};    
//        console.log(data);
        createTableWithLazyLoad("#tableLazy",data,500,col);
         $(".rupees").hide();
          var column;
          var unChecked =[];
          var unCheckedColumn=[];
         
          if($.inArray(role_id, role_data)!=1)
          {
            unCheckedColumn = ['6','13','14'];
          } 
          if(role_id=='sanjeev@collectcent.com'){
            unCheckedColumn = ['13','14'];
          }
         
         console.log(unCheckedColumn + 'This');
          
           
        
            /* to hide coluun according to condition */
            $(unCheckedColumn).each(function(key,uncheckIndex){
             $('.new th[data-index="'+uncheckIndex+'"]').toggleClass("hide");
             column = tableLazyNew.column(uncheckIndex);
             column.visible(false); 
            });
            // unchecking checkboxes 
            $(".dropdown-menu li").each(function(key,element){
                if($(element).find('input[type="checkbox"]').is(":checked")){
                    var dataI = $(element).find('input[type="checkbox"]').attr('data-index');
                    if(unCheckedColumn.indexOf(dataI) != -1){
                        $(element).find('input[type="checkbox"]').removeAttr("checked");
                    }
                }

            }); 

  var moveLeft = 20;
  var moveDown = 0;

  $('span#trigger').hover(function(e) {
    $('div#pop-up').show()
      .css('top', e.pageY + moveDown)
      .css('left', e.pageX + moveLeft)
      .appendTo('body');
  }, function() {
    $('div#pop-up').hide();
  });

  $('span#trigger').mousemove(function(e) {
    $("div#pop-up").css('top', e.pageY + moveDown).css('left', e.pageX + moveLeft);
  });




  
  });


function display_pop(pacc,id_zone,camp){
$("#pop-up").html('');
  $.ajax({
    url:'display_popups',
    type:'get',
    data:'campaign_id='+pacc+"&id_zone="+id_zone,
    dataType : "html",
    success: function(response){
      
      $("#pop-up").html(response);
      
   }
  });


}

    
function changeTrfc(_cca, _ccz, _id)
{
   addmore(_id);
    var info_obj;
    var info_detail;
    var campaign_ids = [];
    var percentage_vals = [];
    var select=$("#campagin_name_diversion_1");
    $('#div_list').html('');
//    $("#campagin_name_diversion_1").val('');
    $("#add_more").html('');
    select.html('');
    
//    var inc = 2;
    if(_cca!='' && _ccz!='' && _id!='')
    {
        $('#parent_cca').val(_cca);
        $('#id_zone').val(_ccz);
        $('#camp_id').val(_id);
        
        $("#process2").show().html('<span class="alert alert-info">Please wait......</span>');
        
	$.ajax({
            url: '/getTrfcCampaign',
            type: 'get',
            data: 
            {
                id : _id, id_zone:_ccz,
            },
            cache: false,
            dataType: 'json',
            success: function(response)
            {
                if(response.is_direct == 1)
                {
                 $("input[name='is_offer_direct'][value='"+response.is_direct+"']").prop('checked', true);
                }
                else if(response.is_direct == 2){
                $("input[name='is_offer_direct'][value='"+response.is_direct+"']").prop('checked', true);
                }
                else if(response.is_direct == 3){
                $("input[name='is_offer_direct'][value='"+response.is_direct+"']").prop('checked', true);
                }

                  $("#op_id").val(response.op_id);

                  $("#country_code").val(response.country_code);

                $.each(response.campaigns,function(index,json){
                    select.append($("<option></option>").attr("value", json.campaign_id).text(json.offer_url+"{"+json.campaign_id+"}"));
                });
                
                $("#div_list").html(response.diversion_list);
                $("#process2").hide();  
         
             
            }

        });
        
        $('#changeTrfc').modal({
            backdrop: 'static',
            keyboard: false,  // to prevent closing with Esc button (if you want this too)
            show: true
        });
        
    }
} 
 

    $('#submit_trfc').click(function(event)
    {
        event.preventDefault();
        var error = '';
        var campaign_ids = [];
        var percentage_vals = [];
        
        $('.campagin_name_diversion').each(function(){
          var count = 2;
            if($(this).val() == 'Select Campagin')
            {
//                $('#process2').show().html('<span class="alert alert-info">Select Campaign Name column '+count+'</span>');
                $('#process2').show().html('<span class="alert alert-info">Select Campaign Name column</span>');
                error +='1';
                return false;
            }
            else
            {
                //campaign_ids.push($(this).val());
                
                
                
//                console.log($(this).val() +"caamp");/
                if($(this).val()!="")
                {
                   campaign_ids.push($(this).val());
                }
                
                
                
        //   error +='';
        //  return true;
            }
            count = count + 1;
        });
  
        $('.percentage').each(function()
        {
            var count = 2;
            if($(this).val() == '')
            {
                $('#process2').show().html('<span class="alert alert-info">Enter Percentage column '+count+'</span>');
                error +='1';
                return false;
            }
            else
            {
                console.log($(this).val() +"percentage");
                percentage_vals.push($(this).val());
                error +='';
                return true;
            }
            count = count + 1;
        });
        
        

        console.log(error+"hello");
        if(error=='')
        {
            var camp_id=$("#camp_id").val();
            var op_id=$("#op_id").val();
            var id_zone=$("#id_zone").val();
            var div_val=$("input[name='is_offer_direct']:checked").val();

            $('#process2').show().html('<span class="alert alert-info">Submitting data please wait......</span>');
                    
            info_detail = [];
            info_obj = {
                'campaign_id': campaign_ids,
                'percentage_value': percentage_vals,
            }
            info_detail.push(info_obj);
            console.log(JSON.stringify(info_detail)+"details");
            $.ajax({
                type: 'GET',
                data : { campaign_data: JSON.stringify(info_detail), camp_id: camp_id, zone: id_zone, is_offer_direct:div_val },
                dataType: "JSON",
                 cache: false,
                url: '/addTrfcCampaign',
                success: function(responseText)
                { // Get the result and asign to each cases
                    var result = responseText;
//                                alert(result);
                    if(result.status == 1){
                        $('#process2').show().html('<span class="alert alert-success">'+result.message+'</span>');
                        // window.location.href=window.location.href;
                        $('#changeTrfc').modal('hide');
                    }
                    else if(result.status == 2){
                        $('#process2').show().html('<span class="alert alert-info">'+result.message+'</span>');
                    } 
                }
//                        error: function(data){
//                                    alert("fail---->"+JSON.stringify(data));
//                        }    
            });
        }
    });


 function addmore(_id){
       var inc=2;         
   
    
         $('.add_more_field').on('click',function(event){
        event.preventDefault(); 

          $("#add_more").html();
               
                    $('#process2').show().html('<span class="alert alert-info">Please wait......</span>');
                
                     $.ajax({
                        url: '/addMoreRaw',
                        type: 'get',
                        data: {
                                id : _id, button_id :  inc++,
                        },
                        cache: false,
                        dataType: 'html',
                  
                        success: function(response)
                        {
                           $("#add_more").append(response);

                            $('.mySelects').each(function(){$(this).select2()});
                            $("#process2").hide();
                           
                        }

                    });
                });
 }


  $("#add_more").on("click",".remove",function(e){

       $(this).parents('table').remove();
  });




 function diablebutton( val ){
  // if(val ==1 || val==2){
  //   $(".percentage-edit,#submit_trfc,#add_diversion_row_new-1").hide();
    
  //  return false; 
  // }else{
  //    $(".percentage-edit,#submit_trfc,#add_diversion_row_new-1").show();
  //   return false; 
  // }


 }
 
 
function deleteTrfc(_jsoncam_id,_campaign_id,_id_zone)
{
    
    
    if(_jsoncam_id != '' && _campaign_id != '' && _id_zone != '')
    {
        $('#process2').show().html('<span class="alert alert-info">Please wait!!!</span>');
        
        $.ajax({
            url: "/delete_trfc", // make sure you set an action attribute to your form
            type: 'GET',
            cache: false,
            async: true,
            dataType: 'JSON',
            data: {'json_camp_id':_jsoncam_id,'campaign_id':_campaign_id,'id_zone':_id_zone},
            success: function(res)
            {
//                var res = response; 
                if(res.status == 1)
                {
                    $('#process2').show().html('<span class="alert alert-success">'+res.message+'</span>');
                    // window.location.href=window.location.href; _cca, _ccz, _id
                    changeTrfc(_campaign_id,_id_zone,_campaign_id);
                }
                else if (res.status == 2)
                {
                    $('#process2').show().html('<span class="alert alert-info">'+res.message+'</span>');
                }
            }
        });
    }
} 
 


   $(document).on('click',".percentage-edit",function(){
          if($(".outer-container").find('.percentage-container').is(':hidden')){
             $(".outer-container").each(function(){ 
             $(this).find('.percentage-container').show();
             var div_id = $(this).find('.percentage-container').attr('id');
              id = div_id.split('_'); 
              closeEditPercenatge(id[1]);
            });  
          } 
          $(this).hide();
          var div_id = $(this).attr('id'),
          id_zone = $(this).attr('data_id_zone'),
          Percentage = $(this).attr('data-value'),
          campain_data= $(this).attr('campain_data'),
          editPercentage = '';
          id =  div_id.split('-');
          var new_id =$(this).attr('campaign_id');
          $("#percentage-container_"+id[1]).hide();
          if(id_zone && Percentage){
          editPercentage += '&nbsp;<input type="text" class="percentage-text" campain_data='+campain_data+' data_id_zone='+ id_zone+' id="percentage-edit_'+campain_data+'"  size="4"  org_value="'+new_id+'" value="'+Percentage+'">&nbsp&nbsp<i class="glyphicon glyphicon-remove cancel-percent" data-id='+campain_data+' id="cancel-'+campain_data+'"></i>';
        

          }
          // $("#percentage-container_"+id[1]).hide();
          $("#"+div_id).after(editPercentage);
        });


     $(document).on('keypress',".percentage-text",function(e){
        $('#process2').show().html('<span class="alert alert-info">Please wait!!!</span>');
          if(e.keyCode == 13){
           var div_id =  $(this).attr('id');
           
           var id_zone = $(this).attr('data_id_zone');
           var row_campain_id = $(this).attr('campain_data'),
           id = div_id.split('_'),
           org_va= $(this).attr('org_value');

           var Percentage = $("#percentage-edit_"+id[1]).val();
            $.ajax({
            url : '/editofferwallTrfc',
            type: 'GET',
            data: 'new_value='+Percentage+'&id='+org_va+'&id_zone='+id_zone+'&row_campain_id='+row_campain_id,
            // async: false,
            dataType:'json',
            }).done(function (response) {
                
                if(response.status == 1){
                    $("#percentage_container_"+row_campain_id).html(response.hold_percentage);

                    $("#percentage-"+row_campain_id).attr('data-value',response.hold_percentage);
                    closeEditPercenatge(row_campain_id);
                      $('#process2').show().html('<span class="alert alert-success">'+response.message+'</span>');
                    
                }
                 $('#process2').delay(2000).fadeOut('slow');
               
            }).fail(function () {
                alert('Data could not be loaded.');
               
            });
          }     
        });

   var closeEditPercenatge = function(id){
             $("#percentage-"+id).show();
             $("#percentage-edit_"+id).remove();
             $("#cancel-"+id).remove();
             $('#save-'+id).remove();
             $("#percentage_container_"+id).show();
         }
 
          $(document).on('click',".cancel-percent",function(){
             var id =  $(this).attr('data-id');
             closeEditPercenatge(id);
         }); 


$("input[name='is_offer_direct']").change(function(){
      if($(this).val() == 1 || $(this).val()==2 || $(this).val()==3){
         $('#process2').show().html('<span class="alert alert-info">Please Wait</span>');
         var thsi_value=$(this).val();
       $.ajax({
            url : '/editofferwallTrfcis_offer_direct',
            type: 'GET',
            data: 'selected_value='+thsi_value+'&camp_id='+$("#camp_id").val()+'&id_zone='+$("#id_zone").val(),
            // async: false,
            dataType:'json',
            }).done(function (response) {
                 
                  if(response.status == 1){
                    $('#process2').show().html('<span class="alert alert-success">'+response.message+'</span>');
                      $('#process2').delay(5000).fadeOut('slow');
                       // window.location.href=window.location.href;
                  }else if(response.status == 3){
                    $('#process2').show().html('<span class="alert alert-success">'+response.message+'</span>');
                      $('#process2').delay(5000).fadeOut('slow');
                    
                       // window.location.href=window.location.href;
                  }else{
                     $('#process2').show().html('<span class="alert alert-danger">'+response.message+'</span>');
                    
                    $('#process2').delay(3000).fadeOut('slow');

                  }

            });
        }
 $('#process2').delay(3000).fadeOut('slow');

});
  var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

  $(document).on("change",".radiobox3", function(){
        var x=1;
        var count_array =0;
          var check = true;
            var id = $(this).attr("id");
            console.log(id);
                var is_selected = $("#"+id).attr('checked', true);
                 var is_smart = $("#"+id).val();
                 var index_count = id.slice(-1);
                 
                var advertiser_campaign="";
                if(is_smart == 'DEFAULT'){
                  $("#campagin_name_diversion_"+index_count).html('').selectpicker('refresh');
                   var cca = $("#parent_cca").val();
                   var id = cca;
                   var cco = $("#op_id").val();
                   $('#process2').show().html('<span class="alert alert-info">Submitting data please wait......</span>');
                  $.ajax({
                    url : 'editofferwallTrfcisofferlist',
                    type: 'post',
                        cache: false,
                    dataType: 'JSON',
                     async: true,
                    data: "conditon=default&cca="+id+"&cco="+cco+"&_token="+CSRF_TOKEN,
                      success: function(response){
                       if(response.status == 1){
                          if(response.advertiser_campaigns){
                              $(response.advertiser_campaigns).each(function(key,campaign){
                              advertiser_campaign += '<option value="'+campaign.id+'"">'+campaign.name+'-- ('+campaign.id+')</option>';
                              });
                            }else{
                            alert('there is no campaign');
                            }
                            $("#spinner").hide();
                            $("#campagin_name_diversion_"+index_count).html(advertiser_campaign).selectpicker('refresh');
                            }
                            $('#process2').delay(3000).fadeOut('slow');
                        }
                });
                
                } else{
                if(is_selected && is_smart){
                   $('#process2').show().html('<span class="alert alert-info">Submitting data please wait......</span>');
                    var cca = $("#parent_cca").val();
                    $.ajax({
                        url : 'editofferwallTrfcisofferlist',
                        type: 'post',
                        dataType: 'JSON',
                         async: true,
                        data: "conditon=nodefault&is_smart="+is_smart+"&cca="+cca+"&_token="+CSRF_TOKEN,
                      
                    }).done(function (responses){
                       console.log(responses.status+"resCPI");
                            if($.trim(responses.status)==1){
                                if($.trim(responses.advertiser_campaigns)){
                                    $(responses.advertiser_campaigns).each(function(key,campaign){
                                       advertiser_campaign += '<option value="'+campaign.id+'"">'+campaign.name+'-- ('+campaign.id+')</option>';
                                    });
                                 }
                                else{
                                    alert('there is no campaign'+is_smart);
                                 }
                               $("#campagin_name_diversion_"+index_count).html(advertiser_campaign).selectpicker('refresh');
                               // $("#addCampaignsByOperator").selectpicker();
                                $('#process2').delay(3000).fadeOut('slow');
                            }
                        
                    }).fail(function () {
                            alert('Data could not be loaded.');
                            $("#spinner").hide();
                    });
                }
                 }     
            });

                  //      $(".percentage-edit, #submit_trfc").css({'cursor':'not-allowed'});
                          // $(".percentage-edit").css({'cursor':'not-allowed'});
                          // $(".percentage-edit, #submit_trfc").attr("disabled", "disabled");
                          // $(".percentage-edit, #submit_trfc").hide();

  jQuery('.mydatepicker').datepicker({
       format:"yyyy-mm-dd"
    });
  </script>

<script src="{{asset('plugins/bower_components/switchery/dist/switchery.min.js')}}" type="text/javascript"></script>
<script src="{{asset('js/validator.js')}}"></script>
<script src="../plugins/bower_components/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>

<style type="text/css">
    .lazy tr > td{
        text-align: center;
    }
    .modal-dialog {
    max-width: 1073px;
    margin: 30px auto;
}

input:focus {
         font-family:Verdana, Geneva, sans-serif;
    border-color:#9ecaed;
    box-shadow:0 0 5px #9ecaed;
}
div#pop-up {
  display: none;
  position: absolute;
  width: 380px;
  padding: 20px;
  background: #fff;
  color: #000000;
  border: 1px solid #1a1a1a;
  font-size: 90%;
}
</style>

@endsection
@section('content')
    <div class="m-b-15 header-panel" style="text-align:center;">
<!--        <div class="text-right">
            <select name="currency" class="currency btn btn-success">
                <option value="0">Dollar</option>
                <option value="1">Rupees</option>
            </select>    
        </div>-->
        <form class="form-inline" role="form" method="GET" action="/offer-networkwise">
            <div class="form-group col-sm-2">
                <div class="input-group">
                <input type="text" value="{{$dtvalue}}"  style="width:150% !important;" class="form-control mydatepicker" name="start" placeholder="From">
                </div>
             </div>
            <div class="form-group">
                <input type="hidden" name="12121" id="qwqw">
            </div>      
            <div class="form-group col-sm-2">
                <div class="input-group">
                    <input type="text" name="end" value="{{$dtvalue2}}"  style="width:150% !important;" class="form-control mydatepicker" placeholder="To">
                </div>
            </div>
            <div class="form-group col-sm-4">
                  <button type="submit" class="btn btn-success waves-effect waves-light">GO</button>
            </div>      
        </form>    
        
    </div>
    
    <div class="col-sm-12">
        <div class="text-right">
            
          @php
          $role_id = $role; 

      
      if(in_array($role_id,$role_data))
      {
         $heads =  
                [
                    "CCA",   
                    "Publisher",    
                    "CPA",                                             
                    "Ads Type",                                                              
                    "Campaign",
                    "Offer Name",
                    "Div",
                    "Status",
                    "CAP Status",
                    "Vertical",
                    "Geo",
                    "Os",
                    "Clicks",
                    "Actual Click",
                    "Conversion",
                    "Install",
                    "Event",
                    "CR %",
                    "Revenue"
                          
                      
                            
                ];
                            $heads2 =  ["Total",
                                "",
                                "",
                                "",
                                "",
                                "",
                                "",
                                "",
                                "",
                                "",
                                "",
                                "",
                                $lastRow[0],
                                $lastRow[1],
                                $lastRow[2],                                                                                     
                                $lastRow[4],
                                $lastRow[5],
                                "",
                                $lastRow[7]
                                ];
      }else{
                $heads =  
                [
                    "CCA",   
                    "Publisher",    
                    "CPA",                                             
                    "Ads Type",                                                              
                    "Campaign",
                    "Offer Name",
                    "Div",
                    "Status",
                    "CAP Status",
                    "Vertical",
                    "Geo",
                    "Os",
                    "Clicks",
                    "Actual Click",
                    "Conversion",
                    "Install",
                    "Out",
                    "Sale",
                    "CR In",
                    "CR Out",
                    "Cost",   
                    "Rev",      
                    "Pro",  
                    "ECPM"
                          
                      
                            
                ];
                            $heads2 =  ["Total",
                                "",
                                "",
                                "",
                                "",
                                "",
                                "",
                                "",
                                "",
                                "",
                                "","",
                                $lastRow[0],
                                $lastRow[1],
                                $lastRow[2],
                                $lastRow[3],                                                                                      
                                $lastRow[4],
                                $lastRow[5],
                                "",
                                "",
                                $lastRow[6],
                                $lastRow[7],
                                $lastRow[8],
                                ""
                                ];
                              }
            @endphp
                <div class="text-left" style="margin-bottom:10px">
                    {!!view('layouts.column', ['data' =>$heads])!!}
                </div>
            </div>
        <div class="table-responsive mainTableInfo">
                <table class="table color-table info-table scrollTable lazy" id="tableLazy">
                    {!!view('layouts.tableheadNew', ['data' =>$heads,'class'=>""])!!}
                    {!!view('layouts.tableheadNew', ['data' =>$heads2,'class'=>"new"])!!}
                </table>


        </div> 
                           
    </div>

<div class="modal fade" id="changeTrfc" role="dialog" style="padding-top: 160px;">
    <div class="modal-dialog modal-dialog-center">    
        <!-- Modal content-->
        <div class="modal-content ">
            <div class="modal-header modal-header1 text-center" >
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title">TRFC</h4>
            </div>
            <div class="modal-body">
                <div class="form-group"><span id="process2" style="display: none;    margin-left: 397px;"></span>
                    {{-- <div id="errmsg_chng_postst" style="text-align: center;margin-bottom:20px;"></div> --}}
                    <input type="hidden" required class="form-control" name="parent_cca" id="parent_cca" readonly/>
                    <input type="hidden" required class="form-control" name="id_zone" id="id_zone" readonly/>
                    <input type="hidden" required class="form-control" name="camp_id" id="camp_id" readonly/>
                    <input type="hidden" required class="form-control" name="op_id" id="op_id" readonly/>
                    <input type="hidden" required class="form-control" name="country_code" id="country_code" readonly/>
                   
                    <form method="post" action="" name="offernetworkwiseedit"  id="offernetworkwiseedit" class="form-horizontal">
                           <div class="form-group col-sm-12">
                        <label class="radio-inline"><input type="radio" id="direct" value="1" name="is_offer_direct">Direct</label>
                        <label class="radio-inline"><input type="radio" id="nodirect"  value="2" name="is_offer_direct">No Direct</label>
                        <label class="radio-inline"><input type="radio" id="diversion" value="3" name="is_offer_direct" >Diversion</label>
                            </div>
                        <div class="form-group col-sm-12">
                            <div class="row">
                                <div class="table-responsive">  
                                    <table class="table table-bordered" id="dynamic_field_diversion">  
                                        <tr>
                                            <th>
                                                Campaign Name
                                            </th>
                                            <th>
                                                Is Smart
                                            </th>
                                            <th>
                                                Diversion Percentage
                                            </th>

                                          {{--   <th>
                                                Confirm
                                            </th> --}}
                                            <th>
                                                Add New Row
                                            </th>
                                        </tr>
                                        <tr>
                                            <td>
                                                <select  required name="campagin_name_diversion[]" id="campagin_name_diversion_1" class="form-control mySelect select2 campagin_name_diversion"> 
                                                    <!--<option value="">Select Campaign</option>-->
                                                </select>
                                            </td>
                                            <td>

                    <input type="radio" name="is_smart_1"  id="default_radio_1" class="radiobox3" value="DEFAULT" class="radiobox2" checked="checked">Default &nbsp;&nbsp;
                    <input type="radio" name="is_smart_1" id="is_smart_cpa_1" value="CPA" class="radiobox3">CPA
                    &nbsp;&nbsp;&nbsp;
                    <input type="radio" name="is_smart_1" id="is_smart_cpi_1" value="CPI" class="radiobox3">CPI 

                                            </td>
                                            <td>
                                                <input type="text" required class="form-control percentage" name="percentage[]" id='percentage_1'  value="10"/>
                                            </td>
                                            {{-- <td>
                                                <button type="button" name="confirm_1" id="confirm_1" class="btn btn-info confirm"><i class="fa fa-check" aria-hidden="true"></i></button>                                                
                                            </td> --}}
                                            <td>
                                                <button type="button" name="add_diversion_row_new_1" id="add_diversion_row_new-1" class="btn btn-success add_more_field">Add More</button>
                                            </td>
                                        </tr>                                                                               
                                    </table>
                                    <div id="add_more"></div>
                                    <div id="div_list"></div>                                    
                                </div>
                            </div>                        
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal" style="color:#fff; background-color: #FF414D; border-color: #FF414D">Cancel</button>

                    <button type="submit" class="btn btn-primary" style="color:#fff; background-color: #67C9E0; border-color: #67C9E0;" id="submit_trfc">Submit</button>
                </div>
            </div>      
        </div>
    </div>
</div>
<span id="process45"> </span>
<div id="pop-up"></div>
@endsection
