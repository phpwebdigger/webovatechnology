@extends('layouts.app')


@section('heading')
  {{$header}}
@endsection
@section('bread')
      <ol class="breadcrumb">
       @if(sizeof($data) !== 0)
        <li>Last Updated Time : {{ $data[sizeof($data)-1]->create_time}}</li>
       @endif 
       </ol>
@endsection

@section('custom_js')
<script src="../plugins/bower_components/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script type="text/javascript">
    jQuery('.mydatepicker').datepicker({
       format:"yyyy-mm-dd"
    });

</script>
@endsection
@section('content')
       <div class="m-b-15 header-panel-form">
        <form class="form-inline" role="form" method="POST" action="{{route($routename)}}">
                        {{ csrf_field() }}    
                                               

                                               
                                               <div class="form-group col-md-1">
                                                        
                                                        <div class="input-group">
                                                                <input type="text" value="{{$dtvalue}}" class="form-control mydatepicker" name="start" placeholder="From">
                                    
                                                        </div>
                                                </div>
                                                <div class="form-group col-md-1">
                                                       
                                                       <div class="input-group">
                                                                <input type="text" name="end" value="{{$dtvalue2}}" class="form-control mydatepicker" placeholder="To">
                                    
                                                        </div>
                                                </div>
                                                <div class="form-group col-md-2">
                                                     <button type="submit" class="btn btn-success waves-effect waves-light">GO</button>
                                        
                                                @php
                                                  $heads =  ["Traffic Source",
                                                               "Clicks Count",
                                                               "Conversion Inwards",
                                                               "Conversion Outward",
                                                               "CR Inwards",
                                                               "CR Outward"
                                                              ];
                                           @endphp

                                            {!!view('layouts.column', ['data' =>$heads])!!}
                                                       
                                                </div>
                                        </form>
                            </div>
    <div class="col-sm-12">
                    
                            
                            <div class="table-responsive mainTableInfo m-t-20">
                                <table class="table color-table info-table scrollTable lazy">
                                    <thead>
                                        {!!view('layouts.tablehead', ['data' =>$heads])!!}
                                    </thead>
                                    <tbody>
                                    @php
                                       $totalClick = 0;
                                       $totalconversion = 0;
                                       $clicks_active_count = 0;
                                      
                                    @endphp
                                    
                                    @foreach($data as $fetch_records)
                                        <tr>
                                            <td>{{$fetch_records->network_name}}</td>
                                            
                                            <td>{{$fetch_records->clickcount}}</td>
                                            <td>{{$fetch_records->conversion_count}}</td>
                                            <td>{{$fetch_records->clicks_active_count}}</td>
                                            <td>{{$fetch_records->cr_received}}</td>
                                            <td>{{$fetch_records->cr_given}}</td>
										   
                                        </tr>
                                        @php 
                                            $totalClick += $fetch_records->clickcount;
                                            $totalconversion += $fetch_records->conversion_count;
                                            $clicks_active_count += $fetch_records->clicks_active_count;
                                           
                                        @endphp
                                       @endforeach
                                       <tr>
                                            <td>Total</td>
                                            <td>{{$totalClick}}</td>
                                            <td>{{$totalconversion}}</td>
                                            <td>{{$clicks_active_count}}</td>
                                             <td></td>
                                              <td></td>
                                       </tr>
                                    </tbody>
                                </table>

                            </div>    
                                   
    </div>


@endsection
