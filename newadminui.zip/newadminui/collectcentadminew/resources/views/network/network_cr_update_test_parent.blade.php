@extends('layouts.simple')
@section('heading')
  {{$header}}
@endsection
@section('bread')
@endsection
@section('custom_js')
<script src="../plugins/bower_components/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script type="text/javascript">
    jQuery('.mydatepicker').datepicker({
       format:"yyyy-mm-dd"
    });

     var col = [
                    'text_30px',
                    'text_30px',
                    'text_40px',                    
                    'text_40px',
                    "text_20px",
                    "text_120px",
                    "text_20px",
//                    "text",
                    "text_60px",
                    "text_60px",
                    "text_30px",
                    "text_60px",
                    "text_30px",
                    'text_30px',
                    'text_30px',
                    'text_30px',
                    'text_30px',
                    'text_30px',
                    'text_30px',
                    'text_30px',
                    'text_30px',
                    'text_30px',
                    'text_30px',
                ]; 
             
   var data =   {!! json_encode($data1) !!}
   var column;
   var unCheckedColumn = ['7','8','12','18','20'];
    $(document).ready(function(){
        createTableWithLazyLoad("#tableLazy",data,50,col);
          /* to hide coluun according to condition */
            columnreset();
         $(".remark").keyup(function(){
          if(true){
              var id_ad = $(this).attr("myID");
              var content = $(this).val();
              var UrlToPass = 'action=remarks_data&remarks='+content+'&ad_id='+id_ad;
            }
         });

    });
      
      
      function submitremarks(id_ad){
      var content = document.getElementById("remarks_"+id_ad).value;
      if(content=="")
      {
        alert("Nothings text");
        return false;
        //$("#remarks_"+id_ad).focus();
      }
      var UrlToPass = 'action=remarks_data&remarks='+content+'&ad_id='+id_ad;
        $.ajax({ 
            url : 'crc_network_campaign_ajax.php',
            type : 'POST',
            data : UrlToPass,
            success: function(data){
                 $("#sucess").html(data);
                 $("#sucess").fadeOut();
                }
            });
        }
        
        $("#network-cr-filter").submit(function(e){
              $.ajax({
                  url: "/filter-network-cr-update-parent",
                  type: 'GET',
                  cache: false,
                  async: false,
                  dataType: 'JSON',
                  data:$("#network-cr-filter").serialize(),
                  success: function(res){
                    var response = res;
                    if(response.status == "1"){
                     $("#tableLazy").dataTable().fnClearTable();
                     $("#tableLazy").dataTable().fnDestroy();
                     $("#tableLazy .new").remove();
                     var head ='<thead class="new"><tr>';
                      $(response.lastRow).each(function(key,val){
                      head +='<th data-index="'+key+'" data-val="'+val+'">'+val+'</th>';
                      });
                      head +='</tr></thead>';
                     $("#tableLazy thead").after(head);
                     createTableWithLazyLoad("#tableLazy",response.data,200,col);
                     columnreset();  
                  }else if(response.status == "2"){
                             alert('Please search again there is no result');
                  }else{
                    alert('Please search again there is no result');  
                  }
                  }, 
                  error: function (textStatus,errorThrown){
                     alert('There is something went wrong');
                     $('.preloader').hide();   
                  }
              });
              e.preventDefault();
        });

        $('.reset').click(function(){
            $('.selectpicker2').selectpicker('deselectAll');
            $('.bg-primary').find("input").val("");
            $("#id_ad").val("");
            $("input[type=text]").change();
            $("#tableLazy").dataTable().fnClearTable();
            $("#tableLazy").dataTable().fnDestroy();
            createTableWithLazyLoad("#tableLazy",data,50,col);
            columnreset();
        });

          function columnreset(){
            $(unCheckedColumn).each(function(key,uncheckIndex){
             $('.new th[data-index="'+uncheckIndex+'"]').toggleClass("hide");
             column = tableLazyNew.column(uncheckIndex);
             column.visible(false); 
            });
            // unchecking checkboxes 
            $(".dropdown-menu li").each(function(key,element){
                if($(element).find('input[type="checkbox"]').is(":checked")){
                    var dataI = $(element).find('input[type="checkbox"]').attr('data-index');
                    if(unCheckedColumn.indexOf(dataI) != -1){
                        $(element).find('input[type="checkbox"]').removeAttr("checked");
                    }
                }
            });  
          }  

  </script>
@endsection
@section('content')
       <div class="row filter-panel">
         @php
                                $heads =  ["Parent CCA",
                                             "Network",
                                             "CPA($)",
                                             "Telco",
                                             "Ad Cat",
                                             "Campaign Name",
                                             "County",
                                             "Os Type",
                                             "Incent Type",
                                             "Clicks Count",
                                             "Actual Click",
                                             "Conv Inward",
                                             "Unique Conv",
                                             "Conv Out",
                                             "CR In",
                                             "CR Out",
                                             "Cost $/Rs",
                                             "Revenue (Rs.)",
                                             "ECPC $/Rs.",
                                             "Profit (Rs.)",
                                             "Remarks"];
                               $heads2 =  $lastRow ;
                                           /* 
                                            [
                                            "Total",
                                             "",
                                             "",
                                             "",
                                             "",
                                             "",
                                             "",
                                             "",
                                             "",
                                             $lastRow[0],
                                             $lastRow[1],
                                             $lastRow[4],
                                             $lastRow[2],
                                             $lastRow[3],
                                             "",
                                             "",
                                             $lastRow[5],
                                             $lastRow[6],
                                             $lastRow[7],
                                             $lastRow[8],
                                             ""]; 
                                          */  

                              $types = ['CPA','CPC','CPL','CPI','CPS','CPCV','CPICPA'];

                          @endphp
        <form class="form-inline" id="network-cr-filter" role="form" method="POST" action="{{route($routename)}}" >
          {{ csrf_field() }}
           <div class="row">
           <div class="hide">
                <input type="text" class="form-control" value="{{$total}}" name="total">
            </div>
            <div class="col-md-3">
                <select name='id_channel[]' id="id_channel" multiple class="selectpicker" data-style="btn-info" data-live-search="true" data-actions-box="true" data-selected-text-format="count > 3" data-size="10"  title="Network">
                @foreach ($ddData['network_dropdown'] as $network_id => $network_name)
                 <option value="{{$network_id}}"
                 <?php 
                  if(is_array($id_channel)){ 
                    if(in_array($network_id,$id_channel)){ 
                       echo "selected";
                     }
                  }
                  ?>
                  >
                 {{$network_name}}({{$network_id}})
                 </option>
                 @endforeach
               </select>
          </div>
                      <div class="col-md-3">
                          <select name="operator_id[]" id="operator_id" multiple class="selectpicker" data-live-search="true" data-actions-box="true" data-style="btn-danger" data-selected-text-format="count > 3" data-size="10" title="Operator">
                           @foreach ($ddData['operator_dropdown'] as $operator_id1 => $operator_name)
                              <option value="{{$operator_id1}}"
                              <?php
                              if(is_array($operator_id)){ 
                                if(in_array($operator_id1,$operator_id)){ 
                                    echo "selected";
                                }
                              }
                              ?>  
                              >{{$operator_name}}
                              </option>
                              @endforeach
                          </select>
                        </div>
                        <div class="col-md-3">
                          <select name="traffic_type[]" multiple class="selectpicker" data-style="btn-warning" data-live-search="true" data-actions-box="true" data-selected-text-format="count > 3" data-size="10" title="Ad Category">
                              @foreach ($ddData['traffictype_dropdown'] as $traffic)
                                <option value="{{$traffic}}" 
                                <?php
                                if(is_array($traffic_type)){ 
                                  if(in_array($traffic,$traffic_type)){ 
                                    echo "selected";
                                  }
                                }
                                ?>   
                                >{{$traffic}}</option>
                                @endforeach
                          </select>
                        </div>
                        <div class="col-md-3">
                                <select name="country[]" multiple class="selectpicker" data-live-search="true" data-actions-box="true" data-style="btn-success" data-selected-text-format="count > 3" data-size="10" title="Country">
                                    @foreach ($ddData['country_dropdown'] as $key =>$val)
                                      <option value="{{$key}}"  
                                      <?php
                                        if(is_array($country)){ 
                                          if(in_array($key,$country)){ 
                                            echo "selected";
                                          }
                                        }
                                      ?> 
                                      >{{$val}}</option>
                                      @endforeach
                         
                                </select>
                        </div>
                    </div>    
                      <div class="row margin10">
                        <div class="col-md-1">
                         {!!view('layouts.columnNew', ['data' =>$heads ])!!}
                        </div>
                        <div class="col-md-3">
                          <select name="type" class="selectpicker" data-style="btn-warning" 
                          data-live-search="true" data-actions-box="true"
                          data-size="10" title="Type">
                              <?php foreach($types as $type){ ?>
                                <option value="{{$type}}"> 
                                  {{$type}}
                                </option>
                              <?php } ?>                          
                            </select>
                        </div>
                        <div class="col-md-1">
                           <div class="input-group">
                                <input type="text" value="" class="form-control" name="id_ad" placeholder="parent CCA">
                            </div>
                        </div>  
                        <div class="col-md-1">
                          <button type="submit" class="btn btn-success waves-effect waves-light">Search</button>
                        </div>
                        <div class="col-md-2 form-group">
                            <div class="input-group">
                                <input type="text" value="{{$dtvalue}}" class="form-control mydatepicker" name="start" placeholder="From">
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="input-group">
                              <input type="text" name="end" value="{{$dtvalue2}}" class="form-control mydatepicker" placeholder="To">
                            </div>
                        </div>
                       <div class="col-md-1">
                        <a href="javascript:void;" class="btn btn-warning reset">Reset</a>
                    </div>
                       </div>
                        </form>
                   </div>     
                <div class="col-sm-4 col-offset-8">Last Updated Time : {{ $update_time}}</div>
                <div class="col-sm-12">
                    <table class="table" id="tableLazy">
                    {!!view('layouts.tableheadNew', ['data' =>$heads,'class'=>"btn-primary text-white"])!!}
                    {!!view('layouts.tableheadNew', ['data' =>$heads2,'class'=>"new"])!!}
                    </table>
                    {{-- $data->appends(request()->input())->links() --}} 
                </div>
              @endsection