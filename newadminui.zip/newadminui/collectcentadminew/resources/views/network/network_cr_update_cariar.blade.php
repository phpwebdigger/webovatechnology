@extends('layouts.simple')
@section('heading')
  {{$header}}
@endsection
@section('bread')
     
@endsection

@section('custom_js')
<script src="../plugins/bower_components/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script type="text/javascript">
    jQuery('.mydatepicker').datepicker({
       format:"yyyy-mm-dd"
    });
      var col = [
                    'text_30px',
                    'text_30px',
                    'text_40px',                    
                    'text_40px',
                    "text_30px",
                    "text_100px",
                    "text_40px",
//                    "text",
                    "text_60px",
                    "text_60px",
                    "text_30px",
                    "text_30px",
                    "text_30px",
                    'text_30px',
                    'text_30px',
                    'text_30px',
                    'text_30px',
                    'text_30px',
                    'text_60px',
                    
                ]; 
          $(document).ready(function() {
            var data =   {!! json_encode($data1) !!};        
            createTableWithLazyLoad("#tableLazy",data,50,col);
          });

          $("#carrier-specific-default").submit(function(e){
              $.ajax({
                  url: "/filteration-carrier-specific-default", 
                  type: 'GET',
                  cache: false,
                  async: false,
                  dataType: 'JSON',
                  data:$(this).serialize(),
                  success: function(res){
                    var response = res;
                    if(response.status == "1"){
                     $("#tableLazy").dataTable().fnClearTable();
                     $("#tableLazy").dataTable().fnDestroy();
                     $("#tableLazy .new").remove();
                     var head ='<thead class="new"><tr>';
                      $(response.lastRow).each(function(key,val){
                      head +='<th data-index="'+key+'" data-val="'+val+'">'+val+'</th>';
                      });
                      head +='</tr></thead>';
                     $("#tableLazy thead").after(head);
                     createTableWithLazyLoad("#tableLazy",response.data,200,col);
                     // columnreset();  
                  }else if(response.status == "2"){
                             alert('Please search again there is no result');
                  }else{
                    alert('Please search again there is no result');  
                  }
                  }, 
                  error: function (textStatus,errorThrown){
                     alert('There is something went wrong');
                     $('.preloader').hide();   
                  }
              });
              e.preventDefault();
          });

              $('.reset').click(function(){
                  $('.selectpicker2').selectpicker('deselectAll');
                  $('.bg-primary').find("input").val("");
                  $("#id_ad").val("");
                  $("input[type=text]").change();
                  $("#tableLazy").dataTable().fnClearTable();
                  $("#tableLazy").dataTable().fnDestroy();
                  createTableWithLazyLoad("#tableLazy",data,50,col);
                  columnreset();
              });

          function columnreset(){
            $(unCheckedColumn).each(function(key,uncheckIndex){
             $('.new th[data-index="'+uncheckIndex+'"]').toggleClass("hide");
             column = tableLazyNew.column(uncheckIndex);
             column.visible(false); 
            });
            // unchecking checkboxes 
            $(".dropdown-menu li").each(function(key,element){
                if($(element).find('input[type="checkbox"]').is(":checked")){
                    var dataI = $(element).find('input[type="checkbox"]').attr('data-index');
                    if(unCheckedColumn.indexOf(dataI) != -1){
                        $(element).find('input[type="checkbox"]').removeAttr("checked");
                    }
                }
            });  
          } 
  </script>
@endsection
@section('content')
        @php
              $heads =  [
                           "Parent CCA",
                           "Network",
                           "CPA($) ",
                           "Telco ",
                           "Cat",
                           "Campaign",
                           "Country",
                           "Clicks Count",
                           "Actual Clicks",
                           "Conv In",
                           "Conv Out",
                           "CR In",
                           "CR Out",
                           "Unique Conv",
                           "Cost $/Rs.",
                           "Revenue $/Rs.",
                           "Profit $/Rs.",
                           "Remarks"
                          ];
                        $heads2 =  $lastRow;
                                  /* [
                                       "Total",
                                       "",
                                       "",
                                       "",
                                       "",
                                       "",
                                       "",
                                       $lastRow[0],
                                       $lastRow[1],
                                       $lastRow[2],
                                       $lastRow[3],
                                       "",
                                       "",
                                       $lastRow[4],
                                       $lastRow[5],
                                       $lastRow[6],
                                       $lastRow[7],
                                       ""
                                  ];
                                  */              
                        @endphp
       <div class="row filter-panel">
                  <form class="form-inline" role="form" method="POST" action="{{route($routename)}}" id="carrier-specific-default">
                      <div class="row">  
                        {{ csrf_field() }}    
                         <div class="form-group hide">
                            <input type="text" class="form-control" value="{{$total}}" name="total">
                          </div>
                          <div class="form-group col-md-3">
                            <select name='id_channel' class="selectpicker" id="chanel"class="selectpicker" data-live-search="true" data-actions-box="true" data-style="btn-danger" data-selected-text-format="count > 3" data-size="10" title="Network" >
                               @foreach ($ddData['network_dropdown'] as $network_id => $network_name)
                               <option value="{{$network_id}}" {{$network_id == $id_channel ? "selected":""}}>{{$network_name}}</option>
                               @endforeach
                             </select>
                           </div>
                           <div class="form-group col-md-3">
                          <select name="operator_id" class="selectpicker"  id="operator_id" class="selectpicker" data-live-search="true" data-actions-box="true" data-style="btn-warning" data-selected-text-format="count > 3" data-size="10" title="Operator" >
                            @foreach ($ddData['operator_dropdown'] as $operator_id1 => $operator_name)
                              <option value="{{$operator_id1}}" {{$operator_id1 == $operator_id ? "selected":""}}>{{$operator_name}}
                              </option>
                              @endforeach
                          </select>
                           </div>
                          <div class="form-group col-md-3">
                                  <select class="selectpicker" name="traffic_type"  data-live-search="true" data-actions-box="true" data-style="btn-info" data-selected-text-format="count > 3" data-size="10" title="Ad category">
                                       @foreach ($ddData['traffictype_dropdown'] as $traffic)
                                        <option {{$traffic == $traffic_type ? "selected":""}} value="{{$traffic}}" >{{$traffic}}</option>
                                        @endforeach
                                    </select>
                          </div>
                          <div class="form-group col-md-3">
                                  <select class="selectpicker" name="country"  data-live-search="true" data-actions-box="true" data-style="btn-success" data-selected-text-format="count > 3" data-size="10" title="country">
                                      @foreach ($ddData['country_dropdown'] as $key =>$val)
                                        <option value="{{$key}}" {{$key == $country ? "selected":""}} >{{$val}}</option>
                                        @endforeach
                                  </select>
                          </div>
                        </div>
                        <div class="row margin10">
                          <div class="col-md-3">
                                Last Updated Time : {{ $update_time}}
                          </div>
                          <div class="col-md-1">
                                {!!view('layouts.columnNew', ['data' =>$heads])!!}
                          </div>
                          <div class="form-group col-md-3">
                                  <div class="input-group">
                                    <input type="text" value="{{$dtvalue}}" class="form-control mydatepicker" name="start" placeholder="From">
                                </div>
                          </div>
                          <div class="form-group col-md-3">
                               <div class="input-group">
                               <input type="text" name="end" value="{{$dtvalue2}}" class="form-control mydatepicker" placeholder="To">
                               </div>
                           </div>
                        <div class="form-group col-md-1">
                             <button type="submit" class="btn btn-success waves-effect waves-light">Search</button>
                        </div>
                  </div>
                </form>
              </div>
    <div class="col-sm-12">
          <table class="table color-table info-table scrollTable lazy" id="tableLazy">
            {!!view('layouts.tableheadNew', ['data' =>$heads,'class'=>"bg-primary"])!!}
            {!!view('layouts.tableheadNew', ['data' =>$heads2,'class'=>"new"])!!}
            {!!view('layouts.tablefoot', ['data' =>$heads,'class'=>"bg-primary"])!!}           
            </table>
    </div>  
    </div>


@endsection
