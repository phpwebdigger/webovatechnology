@extends('layouts.simple')
@section('heading')
  {{$header}}
@endsection
@section('custom_js')
<script src="../plugins/bower_components/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script type="text/javascript">
    jQuery('.mydatepicker, #datepicker').datepicker({
       format:"yyyy-mm-dd"
    });
    $(document).ready(function() {
         var  $heads =  [  
                           "text_350px",
                           "text_120px",
                           "text_70px",
                           "text_40px",
                           "text_40px",
                           "text_40px",
                           "text_40px",
                           "text_40px",
                           "text_40px",
                           "text_40px",
                           "text_40px",
                           "text_40px",
                           "text_40px",
                           "text_40px",
                           "text_40px",
                          ];
        var data =   {!! json_encode($data1) !!};        
       createTableWithLazyLoad("#tableLazy",data,50,$heads);
       
    });
</script>
@endsection
@section('content')
       <div class="row filter-panel">
        <form class="form-inline" role="form" method="POST" action="{{route($routename,$id)}}">
                        {{ csrf_field() }}
                                <div class="col-md-2">
                                <a href="/dashboard" class="btn btn-danger">Home</a>
                                </div>    
                                <div class="form-group col-md-2">
                                     <div class="input-group">
                                          <input type="text" value="{{$dtvalue}}" class="form-control mydatepicker" name="start" placeholder="From">
                                     </div>
                                </div>
                                <div class="form-group col-md-2">
                                    <div class="input-group">
                                          <input type="text" name="end" value="{{$dtvalue2}}" class="form-control mydatepicker" placeholder="To">
                                    </div>
                                </div>
                                <div class="form-group col-md-1">
                                <button type="submit" class="btn btn-success waves-effect waves-light">GO</button>
                                        @php
                                                  $heads =  [
                                                               "Campaign Name",
                                                               "Network",
                                                               "Parent CCa",
                                                               "Telco",
                                                               "Clicks Count",
                                                               "Conversion In",
                                                               "Unique Conv",
                                                               "Conversion Out",
                                                               "CR In",
                                                               "CR Out",
                                                               "Revenue $/Rs.",
                                                               "ECPM $/Rs.",
                                                               "Cost $/Rs.",
                                                               "Profit $/Rs.",
                                                               "Average Payout $/Rs."
                                                              ];
                                                  $heads2 =  [
                                                                "Total",
                                                                 "",
                                                                 "",
                                                                 "",
                                                                 $lastRow[0],
                                                                 $lastRow[1],
                                                                 $lastRow[6],
                                                                 $lastRow[2],
                                                                 "",
                                                                 "",
                                                                 $lastRow[3],
                                                                 "",
                                                                 $lastRow[4],
                                                                 $lastRow[5],
                                                                 "",
                                                                 ];              

            
                                           @endphp
                                      </div>
                                      <div class="col-md-2">{!!view('layouts.column', ['data' =>$heads])!!}</div>
                                      <div class="col-md-3 pull-right">
                                            Last Updated Time : {{ $update_time}}
                                      </div>    
                                        </form>
                            </div>
    <div class="col-sm-12">
          <table class="table" id="tableLazy">
              {!!view('layouts.tableheadNew', ['data' =>$heads,'class'=>"bg-primary"])!!}
              {!!view('layouts.tableheadNew', ['data' =>$heads2,'class'=>"new btn-danger"])!!}    
          </table>
    </div>


@endsection
