@extends('layouts.app')


@section('heading')
  {{$header}}
@endsection
@section('bread')
      <ol class="breadcrumb">
       @if(sizeof($data) !== 0)
        <li>Last Updated Time : {{ $data[sizeof($data)-1]->create_time}}</li>
       @endif 
       </ol>
@endsection

@section('custom_js')
<script src="../plugins/bower_components/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script type="text/javascript">
    jQuery('.mydatepicker').datepicker({
       format:"yyyy-mm-dd"
    });
    


</script>
@endsection
@section('content')
       <div class="m-b-15 header-panel-form">
        <form class="form-inline" role="form" method="POST" action="{{route($routename)}}">
                        {{ csrf_field() }}    
                                               
                                                <div class="form-group ">
                                                        
                                                        <div class="input-group">
                                                                <input type="text" value="{{$dtvalue}}" class="form-control mydatepicker" name="start" placeholder="From">
                                    
                                                        </div>
                                                </div>
                                                <div class="form-group ">
                                                       
                                                       <div class="input-group">
                                                                <input type="text" name="end" value="{{$dtvalue2}}" class="form-control mydatepicker" placeholder="To">
                                    
                                                        </div>
                                                </div>
                                                <div class="form-group ">
                                                     <button type="submit" class="btn btn-success waves-effect waves-light">GO</button>
                                        
                                                @php
                                                  $heads =  ["Ad ID",
                                                               "Traffic Source",
                                                               "Source CPA($) ",
                                                               "Telco ",
                                                               "Ad Category",
                                                               "Campaign",
                                                               "Clicks Count",
                                                               "Conversion Inwards",
                                                               "Conversion Outward",
                                                               "CR Inwards",
                                                               "CR Outward",
                                                               "Unique Conversion",
                                                               "CR Goal",
                                                               "Source Cost $/Rs.",
                                                               "Revenue (Rs.)",
                                                               "Profit (Rs.)",
                                                               "Remarks"];
                                           @endphp

                                            {!!view('layouts.column', ['data' =>$heads])!!}
                                                       
                                                </div>
                                        </form>
                            </div>
    <div class="col-sm-12">
                    
                            
                            <div class="table-responsive mainTableInfo m-t-20">
                                <table class="table color-table info-table scrollTable lazy" >
                                    <thead>
                                        {!!view('layouts.tablehead', ['data' =>$heads])!!}
                                    </thead>
                                    <tbody>
                                      @php
                                      $clickcount = 0;
                                            $conversion_count = 0;
                                            $clicks_active_count = 0;
                                            $cr_received = 0;
                                           
                                            $cr_given = 0;
                                             $conversion_count_unique = 0;
                                             $conversion_count_unique = 0;
                                            $cr_goal = 0;
                                              $sourcost = 0;
                                            $convCount = 0;
                                            $profit = 0;
                                    @endphp
                                    
                                    @foreach($data as $fetch_records)
                                        <tr>
                                            <td>{{$fetch_records->id_ad}}</td>
                                            <td><a href="/crcbacklogic/?id_ad={{$fetch_records->id_ad}}">{{$fetch_records->network_name}}</a></td>
                                            <td>{{$fetch_records->network_cpa}}</td>
                                            <td>
                                              {{$fetch_records->op_name}} 
                                              @if(!empty($fetch_records->op_name))
                                              ({{$fetch_records->country_code}})
                                              @endif
                                            </td>
                                            <td>{{$fetch_records->traffic_type}}</td>
                                            <td>{{$fetch_records->adv_name}}</td>
                                            <td>{{$fetch_records->clickcount}}</td>
                                            <td>{{$fetch_records->conversion_count}}</td>
                                            <td>{{$fetch_records->clicks_active_count}}</td>
                                            <td>{{$fetch_records->cr_received}} </td>
                                            <td>{{$fetch_records->cr_given}}</td>
                                            <td>{{$fetch_records->conversion_count_unique}}</td>
                                            <td> {{$fetch_records->cr_goal}}</td>
                                        
                                            <td> {{$fetch_records->total_cost}}/{{round($fetch_records->total_cost * 65, 2)}}</td>
                                             <td> {{$fetch_records->cpa * $fetch_records->conversion_count}}</td>
                                           <td> {{$fetch_records->cpa * $fetch_records->conversion_count - round($fetch_records->total_cost * 65, 2)}}</td>
                                            <td><input class="form-control" type="text" value="" id="example-text-input"></td>
                                         
                                        </tr>
                                        @php 
                                            $clickcount += $fetch_records->clickcount;
                                            $conversion_count += $fetch_records->conversion_count;
                                            $clicks_active_count += $fetch_records->clicks_active_count;
                                            $cr_received += $fetch_records->total_cost; 
                                           
                                            $cr_given += $fetch_records->cr_given;
                                             $conversion_count_unique += $fetch_records->conversion_count_unique;
                                            $cr_goal += $fetch_records->cr_goal;
                                            $sourcost += $fetch_records->total_cost;
                                            $convCount += $fetch_records->cpa * $fetch_records->conversion_count;
                                            $profit += $fetch_records->cpa * $fetch_records->conversion_count - round($fetch_records->total_cost * 65, 2);
                                        @endphp
                                       @endforeach
                                       <tr>
                                            <td></td>
                                            <td>Total</td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                             <td></td>
                                             <td>{{$clickcount}}</td>
                                            <td>{{$conversion_count}}</td>
                                            <td>{{$clicks_active_count}}</td>
                                            <td>{{$cr_received}} % </td>
                                            <td>{{$cr_given}} %</td>
                                            <td>{{$conversion_count_unique}}</td>
                                            <td> {{$cr_goal}} %</td>
                                             <td>{{$sourcost}}</td>
                                            <td>{{$convCount}}</td>
                                            <td> {{$profit}}</td>
                                        </tr>
                                    </tbody>
                                </table>

                            </div>    
                              @if($total != "all")   
                             <div class="pagination-wrapper"> {!! $data->appends(['search' => Request::get('search')])->render() !!} 
                            </div>   
                            @endif    
    </div>


@endsection
