@extends('layouts.app')
@section('custom_css')
<link rel="stylesheet" type="text/css" href="{{asset('plugins/bower_components/switchery/dist/switchery.min.css')}}" />
@endsection
@section('bread')
    <ol class="breadcrumb">
        <li><a href="#">Dashboard</a></li>
        <li class="active">DeliveryEvent</li>
    </ol>
@endsection
@section('heading')
  Delivery Edit
@endsection
@section('custom_js')
<script src="{{asset('plugins/bower_components/switchery/dist/switchery.min.js')}}" type="text/javascript"></script>
<script src="{{asset('js/validator.js')}}"></script>
<script type="text/javascript">
     var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
       $('.js-switch').each(function() {
           new Switchery($(this)[0], $(this).data());

       });
       function copyToClipboard(element) {
            var $temp = $("<input>");
            $("body").append($temp);
            $temp.val($(element).text()).select();
            document.execCommand("copy");
            $temp.remove();
            $("#inputPassword").val($(element).text());
            alert('text copied and move');
        }
    $(document).ready(function(){

        
        
        $(document).on('change','#cca',function(){
              var  ccas = $(this).val();
              console.log(ccas);
              ccas = ccas + '';
              if(ccas.indexOf(',') != -1){
               $("#is_child").hide();
               console.log('A');           
              }else{
                console.log('B');
                $("#is_child").show();
              }
        });   

       // $(document).on("change","#ccz",function(event){
       //  var networks;
       //  var network_id = $(this).val();

       //  if(network_id){ 
       //      $.ajax({
       //              url : '/getnetwork/',
       //              type: 'GET',
       //              async: true,
       //              data: "network_id="+network_id,
       //              beforeSend: function(msg){
       //                  $("#cca").hide();
       //              },    
       //          }).done(function (response){
       //              if(response.status==1){
       //                  $(response.data).each(function(key,value){
       //                      networks += '<option value="'+value.id_ad+'"">('+value.id_ad+')'+value.title+'</option>';
       //                      $("#cca").html(networks).show();
       //                  });
       //              }else if(response.status==0){
       //                  $("#cca").html('<option value="">select CCA</option>').show();
       //                  alert('No CCA found.');
       //              }
       //          }).fail(function () {
       //                  $("#cca").html('<option value="">select CCA</option>').show();
       //                  alert('Data could not be loaded.');
                        
       //          });
       //      }
       //  });
// $('#ccz').trigger('click');

     $('#ccz').on('click change',function(){
          var id = $(this,':selected').val();
          var ccz_default = $("#ccz_default").val();
          if(id == ccz_default){
           return false;
          }else{
          onchnage(id);
          }

        });
   });

     function onchnage( id_zone){

        var post_back_url = $("#inputPassword");
            post_back_url.val('');
            $(".preloader").show();
            $("#cca").html('');
            var ccz = $("#ccz option:selected").text();
            $title = ccz.split('('); 
            $("#title").val($title[0]); 
            $.ajax({
                url : '/delivery/get-eventadsbynetwork/',
                type: 'GET',
                async: true,
                data: "id_zone="+id_zone,
            }).done(function (response){
                var adsData =  JSON.parse(response);
                var networks = '<option value="">select CCA</option>';    
                var postbackUrl = '<ul class="list-group"><li class="list-group-item"><b class="text-danger">Latest PostBacks</b></li>';
                console.log(adsData.deliveryPostBack);
                $(adsData.cca).each(function(key,network){
                    networks += '<option value="'+network.id_ad+'"" data-title="'+network.title+'">'+network.cca+'</option>';
                });
                $("#cca").html(networks).selectpicker('refresh');
                $(adsData.deliveryPostBack).each(function(key,delivery){
          postbackUrl += '<li class="list-group-item"><div onclick="copyToClipboard(this)">'+delivery.post_back_url+'</div>Total:'+delivery.total+'</li>';
                });
                if(postbackUrl){
                    $('.postback-url').html(postbackUrl);
                }else{
                    $('.postback-url').html('<li class="list-group-item">Postback URL : No postback Url</li>');
                }
                postbackUrl +='</ul>';
                $(".preloader").hide();      
            }).fail(function(){
                    alert('Data could not be loaded.');
                    $(".preloader").hide();
            });
  
     }

       
</script>
@endsection
@section('content')
    <div class="row">
        <div class="col-sm-6">
            <div class="white-box">
                <form data-toggle="validator" method="POST" action="{{ route('DeliveryUpdateEvent') }}">
                    <input type="hidden" name="id" value="<?php echo $status['id']; ?>" readonly>
                    {{ csrf_field() }}
                        <div class="form-group">
                            <label for="inputName" class="control-label">CCZ <span style="color: red">*</span> :<?php //echo $status['id_zone']  ?>
                                <input type="text" id="ccz_default" name="ccz_name" value="<?php echo $status['id_zone']; ?>" readonly>
                            <div class="help-block with-errors"></div>
                            
                        </div>
                        <div class="form-group">
                            <label for="inputName" class="control-label">CCA <span style="color: red">*</span> </label>
                            <div class="form-group">
                                <select name="cca[]" id="cca" class="form-control selectpicker" data-live-search="true" data-actions-box="true" data-max-options="20" data-selected-text-format="count > 3" multiple required>
                                    @foreach($data1 as $key => $val)
                                    <option value="{{$val->id_ad}}" {{$val->id_ad == $status['id_ad'] ?"selected":""}} >
                                        {{trim($val->id_ad)}}({{trim($val->title)}})
                                    </option>
                                    @endforeach
                                </select>            
                            </div>
                            <div class="help-block with-errors"></div>
                        </div>
                        <div class="form-group">
                            <label for="inputpostUrl" class="control-label">Post Back Url</label>
                                <div class="form-group col-sm-12">
                                    <input type="text"  name="post_back_url"  value="<?php echo $status['post_back_url']; ?>" data-toggle="validator"   class="form-control" id="inputPassword" placeholder="Post back URL" required>
                                    <div class="help-block with-errors"></div>
                                </div>
                        </div>
                        <div class="form-group">
                           <label for="inputpostUrl" class="control-label">Post Back Status</label>
                           <div class="form-inline">      
                                   <div class="radio radio-info">
                                   <input type="radio" name="postback_status" id="status1" value="1" <?php echo $status['postback_status'] == 1 ? 'checked':'' ?>>
                                   <label for="status1">Active </label>
                                   </div>
                                   <div class="radio radio-info">
                                   <input type="radio" name="postback_status" id="status2" value="0" <?php echo $status['postback_status'] == 0 ? 'checked':'' ?>>
                                   <label for="status2">Deactive </label>
                                   </div>
                               </div>
                        </div>
                        <div class="form-group">
                           <label for="inputpostUrl" class="control-label">Id Advertiser *</label>
                               <div class="form-group col-sm-12">
                                   <input type="text" name="id_advertiser" value="<?php echo $status['id_advertiser']?>" data-toggle="validator"   class="form-control" id="id_advertiser" placeholder="" required>
                                       <div class="help-block with-errors"></div>
                               </div>
                        </div>
                        <div class="form-group">
                            <label for="inputpostUrl" class="control-label">Percentage *</label>
                                <div class="form-group col-sm-12">
                                    <input type="text"  name="lower_limit" value="<?php echo $status['lower_limit']?>" data-toggle="validator"   class="form-control" id="inputPassword" placeholder="Input Percentage" required>
                                    <div class="help-block with-errors"></div>
                                </div>
                        </div>
                        <div class="form-group">
                           <label for="inputpostUrl" class="control-label">Higher Percentage *</label>
                               <div class="form-group col-sm-12">
                                   <input type="text" name="higher_limit" value="<?php echo $status['higher_limit']?>" data-toggle="validator"   class="form-control" id="inputPassword" placeholder="Input Percentage" required>
                                       <div class="help-block with-errors"></div>
                               </div>
                        </div>
                        <div class="form-group">
                            <label for="inputpostUrl" class="control-label">Filter Status</label>
                            <div class="form-inline">      
                                    <div class="radio radio-info">
                                    <input type="radio" name="filter_status" id="status3" value="1" <?php echo $status['filter_status'] == 1 ? 'checked':'' ?>>
                                    <label for="status3">Active </label>
                                    </div>
                                    <div class="radio radio-info">
                                    <input type="radio" name="filter_status" id="status4" value="0" <?php echo $status['filter_status'] == 0 ? 'checked':'' ?>>
                                    <label for="status4">Deactive </label>
                                    </div>
                                </div>
                        </div>
                        <br>
                        <div class="form-group">
                            <input type="hidden" name="id_ad" value="<?php echo $status['id_ad']; ?>">
                            <button type="submit" class="btn btn-success">Update</button>
                        </div>
                </form>
            </div>
        </div>
                 <div class="col-sm-6 postback-url"></div>                           
    </div>
@endsection
