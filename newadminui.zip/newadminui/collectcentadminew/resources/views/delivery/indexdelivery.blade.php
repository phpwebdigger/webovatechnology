@extends('layouts.app-light')
@section('bread')
@endsection
@section('heading')
  Delivery 
@endsection
@section('content')
<?php 
$group_by = ['id_zone'=>'id zone','from_server'=>'server','siteid'=>'siteid','country'=>'country','click_hour'=>'hour','parent_cca'=>'parent cca'];
?>
<style>
.body{width:100%;}
.table-head{background-color:#3e96c9;color:#fff;}
</style>
@section('custom_js')
<script>
$(function() {

    function checkFields(form) {
    var checks_radios = form.find(':checkbox, :radio'),
        inputs = form.find(':input').not(checks_radios).not('[type="submit"],[type="button"],[type="reset"]'),
        checked = checks_radios.filter(':checked'),
        filled = inputs.filter(function(){
            if($(this).attr("name") == '_token'){
                return 0;
            }
            return $.trim($(this).val()).length > 0;
        });

    if(checked.length + filled.length === 0) {
        return false;
    }
    return true;
    }
        var col = [
                    'text_30px',
                    'text_30px',
                    'text_30px',
                    'text_30px',                    
                    'text_30px',
                    "text_30px",
                    "text_30px",
                    "text_30px",
                    "text_30px",
                    "text_60px",
                    "text_60px",
                    "text_60px",
                    "text_60px",
                    "text_60px",
                    "text_60px",
                    "text_60px",
                    "text_60px",
                ];
        var data =   {!! json_encode($data) !!};        
        createTableWithLazyLoad("#tableLazy",data,50,col);


    $("#filterform").submit(function(e) {
        var oneFilled = checkFields($(this))
        if(oneFilled == false){
          alert('Please select any of the field');
          return false; 
        }  
           $.ajax({
                url : '/delivery-filter',
                type: 'POST',
                async: true,
                data : $("#filterform").serialize(),
            }).done(function (data){
            response = JSON.parse(data);
            if(response.status == "1"){
            $("#tableLazy").dataTable().fnClearTable();
            $("#tableLazy").dataTable().fnDestroy();
            $("#tableLazy .new").remove();
            var head ='<thead class="new"><tr>';
            $(response.lastRow).each(function(key,val){
            head +='<th data-index="'+key+'" data-val="'+val+'">'+val+'</th>';
            });
            head +='</tr></thead>';
            $("#tableLazy thead").after(head);
            createTableWithLazyLoad("#tableLazy",response.data,200,col);
            $('#total_record').html(response.total);
            }

            }).fail(function(){
               
            });
            e.preventDefault(); // avoid to execute the actual submit of the form.
    });

    $(document).ajaxStart(function(){
        $(".preloader").css("display", "block");
    });
    $(document).ajaxComplete(function(){
        $(".preloader").css("display", "none");
    });
    
});
</script>
@endsection('custom_js')

    <!--div class="small-loader"></div-->
    <div class="wrapper text-center">
        <form action="" method="POST" id="filterform">
             {{ csrf_field() }}
            <div class="row">
                <div class="col-sm-3">
                    <div><label>Id Ad</label></div>
                    <input type="text" name="id_ad">
                </div>
                <div class="col-sm-3">
                    <div><label>Parent CCA</label></div>     
                    <input type="text" name="parent_cca">
                </div>
                <div class="col-sm-3">
                    <div><label>Id Zone</label></div>     
                    <input type="text" name="id_zone">
                </div>
                <div class="col-sm-3">
                 <div><label>Id Advertiser</label></div>
                    <input type="text" id="id_advertiser" name="id_advertiser">
                </div>
           </div>
            <div class="row">
                <div class="col-sm-3">
                    <div><label>Final url</label></div>
                    <textarea name="final_url"></textarea>
                </div>
                <div class="col-sm-3">
                    <div><label>Http Status</label></div>     
                    <input type="text" name="http_ status">
                </div>
                <div class="col-sm-3">
                    <div><label>Activation</label></div>     
                    <select name="activation_mode" class="form-control">
                        <option val="all">All</option>
                        <option val="Empty">Empty</option>
                        <option val="DELIVERY">DELIVERY</option>
                        <option val="MANUAL_CRON">MANUAL_CRON</option> 
                    </select>    
                </div>
           </div>
          <div class="row">
                <div class="col-sm-3">
                 <div><label>Pub id</label></div> 
                   <textarea id="pubid" name="pubid"></textarea> 
                </div> 
                <div class="col-sm-3">
                 <div><label>CC token</label></div>
                    <textarea id="cc_token" name="cc_token"></textarea>
                </div>
                <div class="col-sm-3">
                    <div><label>Network token</label></div>
                <textarea id="network_token" name="network_token"></textarea>
                </div>
                <div class="col-sm-3">
                   <div><label>Site id</label></div> 
                   <textarea id="siteid" name="siteid"></textarea>
                </div>
          </div>
          <div class="row">
             
             <div class="col-sm-3">
                    <div><label>Hour</label></div>     
                    <select id="click_hour" name="click_hour[]" multiple class="selectpicker" data-live-search="true" data-actions-box="true" data-selected-text-format="count > 3" data-size="10" data-style="btn-danger ">
                    @for($i=0;$i<24;$i++)
                    <option value="{{$i}}">{{$i}}</option>
                    @endfor
                    </select>
                </div>
                <div class="col-sm-3">
                    <div><label>Group By</label></div>     
                    <select id="group_by" name="group_by[]" multiple class="selectpicker" data-live-search="true" data-actions-box="true" data-selected-text-format="count > 3" data-size="10" data-style="btn-warning">
                    <?php foreach($group_by as $key=>$value){?>
                    <option value="<?php echo $key;?>"><?php echo $value; ?></option>
                    <?php } ?>
                    </select>
                </div>
                <div class="col-sm-3">
                 <div><label>Server</label></div>
                   <select id="from_server" name="from_server[]" multiple class="selectpicker" data-live-search="true" data-actions-box="true" data-selected-text-format="count > 3" data-size="10" data-style="btn-success">
                    @for($i=0;$i<43;$i++)
                    <option value="{{$i}}">{{$i}}</option>
                    @endfor
                    </select>
                </div>
                <div class="col-sm-12 m-t-md text-center">
                <input type="submit" name="search" id="search" class="btn btn-success" value="Search">
                </div>
            </div>
         </form>
         </div>
         <div class="row">
            <div class="col-sm-12 text-left">
                @php
                    $heads =  [
                                "Hour",
                                "Server",
                                "Country",
                                "CCA",
                                "Siteid",                                                                
                                "Delivery Count",
                                "Activation",
                                "id ad",
                                "id zone",
                                "Date time",
                                "id advertiser",
                                "Price",
                                "Doller Price",
                                "Network token",
                                "CC token",
                                "Pub id",
                                "Status"
                            ];
                @endphp
                <div class="text-left">
                {!!view('layouts.column', ['data' =>$heads])!!}
                </div>
            </div>
            <div class="col-md-12 pull-left">
                <b class="text-primary">Total record:</b><span id="total_record"> @php echo count($data)@endphp</span>
                <b class="text-danger">Last Updated:</b> <span id="lastupdated">{{$lastUpdated}}</span> 
            </div>
            <div class="col-sm-12">
                <div class="table-responsive mainTableInfo">
                <table class="table color-table info-table scrollTable lazy" id="tableLazy">
                        {!!view('layouts.tableheadNew', ['data' =>$heads,'class'=>""])!!}
                </table>
                </div>               
            </div>
         </div>            
 
@endsection
