@extends('layouts.app')
@section('custom_css')
<link rel="stylesheet" type="text/css" href="{{asset('plugins/bower_components/switchery/dist/switchery.min.css')}}" />
@endsection
@section('bread')
    <ol class="breadcrumb">
        <li><a href="#">Dashboard</a></li>
        <li class="active">Delivery</li>
    </ol>
@endsection
@section('heading')
   Add Delivery
@endsection


@section('custom_js')
<script src="{{asset('plugins/bower_components/switchery/dist/switchery.min.js')}}" type="text/javascript"></script>
<script src="{{asset('js/validator.js')}}"></script>
<script type="text/javascript">

     var elems = Array.prototype.slice.call(document.querySelectorAll('.js-switch'));
       $('.js-switch').each(function() {
           new Switchery($(this)[0], $(this).data());

       });
       $(".ischild").on('change',function(){
            if($(this).is(":checked")){
                $("#outW").removeClass("hide");
            }else{
                $("#outW").addClass("hide");
            }
       });

       function copyToClipboard(element) {
            var $temp = $("<input>");
            $("body").append($temp);
            $temp.val($(element).text()).select();
            document.execCommand("copy");
            $temp.remove();
            $("#post_back_url").val($(element).text());
            alert('text copied and move');
        }
        
        $(document).on('change','#cca',function(){
              var  ccas = $(this).val();
              console.log(ccas);
              ccas = ccas + '';
              if(ccas.indexOf(',') != -1){
               $("#is_child").hide();
               console.log('A');           
              }else{
                console.log('B');
                $("#is_child").show();
              }
        });   
       $(document).on('change','#ccz',function(){
           var post_back_url = $("#post_back_url");
            post_back_url.val('');
            $(".preloader").show();
            $id_zone = $(this).val();
            var ccz = $("#ccz option:selected").text();
            $title = ccz.split('('); 
            $("#title").val($title[0]); 
            $.ajax({
                url : '/delivery/get-eventadsbynetwork/',
                type: 'GET',
                async: true,
                data: "id_zone="+$id_zone
            }).done(function (response){
                var adsData =  JSON.parse(response);
                var networks = '<option value="">select CCA</option>';    
                var postbackUrl = '<ul class="list-group"><li class="list-group-item"><b class="text-danger">Latest PostBacks</b></li>';
                console.log(adsData.deliveryPostBack);
                $(adsData.cca).each(function(key,network){
                    networks += '<option value="'+network.id_ad+'"" data-title="'+network.title+'">'+network.cca+'</option>';
                });
                $("#cca").html(networks).selectpicker('refresh');
                $(adsData.deliveryPostBack).each(function(key,delivery){
                    postbackUrl += '<li class="list-group-item"><div onclick="copyToClipboard(this)">'+delivery.post_back_url+'</div>Total:'+delivery.total+'</li>';
                });
                if(postbackUrl){
                    $('.postback-url').html(postbackUrl);
                }else{
                    $('.postback-url').html('<li class="list-group-item">Postback URL : No postback Url</li>');
                }
                postbackUrl +='</ul>';
                $(".preloader").hide();      
            }).fail(function(){
                    alert('Data could not be loaded.');
                    $(".preloader").hide();
            });
   });

    

</script>
@endsection
@section('content')
    @php
       $class = '';
       if(isset($is_smart) &&  $is_smart == 'smart'){
            $class = 'hide';  
       }
    @endphp 
    
    <?php 
//    foreach ($data as $key => $value) {
//        echo "Id = ".$value->id."=== NAME = ".$value->name."<br>";
//    }
//    die();
    ?>
    
    <div class="row">
                   
                    <div class="error text text-center center text-success col-sm-12" style="padding:20px;text-align: center;" >{{$success??""}}</div>
                    <div class="error text text-center center text-danger col-sm-12" style="padding:20px;text-align: center;" >{{$errors??""}}</div>
                    <div class="col-sm-6">
                        <div class="white-box">
                            
                            <form data-toggle="validator" method="POST" action="{{ url('/add-delivery-event') }}">
                              {{ csrf_field() }}
                                <div class="form-group">
                                    <label for="inputName" class="control-label">CCZ *</label>
                                    <div class="form-group">

                                    <select name="ccz" id="ccz" class=" select2 form-control"  data-act="ajax-select" data-preload="true" data-post-text="concat(name,'(',ccz,')')" data-post-id="ccz" data-post-key="name" data-post-table="ad_network" data-min-input="2" data-placeholder="type to search CCZ" required>
                                       <option> Select CCZ</option>
                                    </select>
                                    </div>
                                    <div class="help-block with-errors"></div>
                                </div>
                                 <div class="form-group">
                                    <label for="inputName" class="control-label">CCA *</label>
                                    <div class="form-group">
                                        <select name="cca[]" id="cca" class="selectpicker form-control" data-style="btn btn-danger" data-live-search="true" data-placeholder="select CCA" multiple required>
                                          <option> Select CCA</option>
                                        </select>
                                    </div>
                                    <div class="help-block with-errors"></div>
                                </div>
                                <div class="form-group">
                                    <label for="inputName" class="control-label">Id Advertiser *</label>
                                    <div class="form-group">
                                        <div class="form-group">
                                            <select  name='id_advertiser' id="id_advertiser" class="selectpicker form-control" data-style="btn btn-primary" data-live-search="true" data-placeholder="select campaign" required>
                                                <option value="">Campaign Name</option>
                                                    @foreach($campaigns as $campaign)
                                                <option value="{{$campaign->id}}">[{{$campaign->id}}]{{$campaign->name}}</option> 
                                                    @endforeach
                                            </select>
                                      </div>
                                    </div>
                                    <div class="help-block with-errors"></div>
                                  </div>
                                <div class="form-group" style="clear: both;">
                                    <label for="inputpostUrl" class="control-label">Post Back Url</label>
                                        <div class="form-group col-sm-12">
                                            <input type="text"  name="post_back_url"  value="" data-toggle="validator"   class="form-control" id="post_back_url" placeholder="Post back URL">
                                            <div class="help-block with-errors"></div>
                                        </div>
                                </div>
                                 <div class="form-group">
                                    <label for="inputpostUrl" class="control-label">Post Back Status</label>
                                    <div class="form-group col-sm-12">
                                        Inactive <input name="postback_status"  type="checkbox" checked class="js-switch" /> Active
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="inputpostUrl" class="control-label">Percentage *</label>
                                        <div class="form-group col-sm-12">
                                            <input type="text"  name="lower_limit"  data-toggle="validator"   class="form-control" id="lower_limit" placeholder="Input Percentage" required>
                                            <div class="help-block with-errors"></div>
                                        </div>
                                </div>
                                 <div class="form-group">
                                    <label for="inputpostUrl" class="control-label">Higher Percentage *</label>
                                        <div class="form-group col-sm-12">
                                            <input type="text" name="higher_limit" data-toggle="validator"  value="100" class="form-control" id="higher_limit" placeholder="Input Percentage" required>
                                            <div class="help-block with-errors"></div>
                                        </div>
                                </div>
                                <div class="form-group">
                                    <label for="inputpostUrl" class="control-label">Filter Status</label>
                                    <div class="form-group col-sm-12">
                                        Inactive <input type="checkbox" name="filter_status" checked class="js-switch" /> Active
                                        <div class="help-block with-errors"></div>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <input type="hidden" name="title" value="" id="title"> 
                                    <button type="submit" class="btn btn-success">Submit</button>
                                    <a href="/delivery" class="btn btn-danger">Cancel</a> 
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="col-sm-6 postback-url">
                          
                    </div>
                                        
    </div>
@endsection
