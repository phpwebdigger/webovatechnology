@extends('layouts.app')
@section('custom_css')
<link rel="stylesheet" type="text/css" href="{{asset('plugins/bower_components/switchery/dist/switchery.min.css')}}" />
@endsection
@section('heading')
  Smart Delivery Management
@endsection
@section('custom_js')
<script type="text/javascript">
    $(document).ready(function(){
        $(document).ajaxStart(function(){
            $(".preloader").css("display", "block");
        });
        $(document).ajaxComplete(function(){
            $(".preloader").css("display", "none");
        });
        var col = [
                    'text_30px',
                    'text_30px',
                    'text_50px',                    
                    'text_40px',
                    'text_40px',
                    "text_50px",
                    "text_45px",
                    "text_70px",
//                    "text",
                    "text_60px",
                    "text_60px",
                    "text_30px",
                    "text_60px",
                    "text_700px",
                ];
        var data =   {!! json_encode($data1) !!};        
        createTableWithLazyLoad("#tableLazy",data,50,col);
       
       $(".urltext").click(function(){
         var span = $(this).find("span").text();
         var inp = $(this).find("input").removeClass("hide").val();
         $(this).find("input").select();
         document.execCommand("copy");
         $(this).find("input").addClass("hide")
         alert("text copied");
       })
       
       // $('input:checkbox[name=isSmart]').change(function(){
            $('.statusUpdate').change(function(){
            var id;
            var div_id = $(this).attr('id');
            div_id = div_id.split("_");
            if(div_id.length > 0){
               id = div_id['1'];
            } 
            var checked_value;
            if($(this).prop('checked') === true){
                checked_value = '1';
            }else{
                checked_value = '0';
            }
            if(id !='' && checked_value != ''){
            $.ajax({
                    url: "delivery-smtUrlStatus", // make sure you set an action attribute to your form
                    type: 'GET',
                    cache: false,
                    async:true,
                    dataType: 'JSON',
                    data: {'action': div_id[0],'id': id,'check_value': checked_value},
                    success: function(data){
                        $("#cover").fadeOut("slow");
                        var obj = data;
                        if(obj.check_value == 1){
                            $('#'+div_id[0]+'_status-'+obj.id_ad).text("On");
                        }else if(obj.check_value == 0){
                            $('#'+div_id[0]+'_status-'+obj.id_ad).text("Off");
                        }else{
                            $('#'+div_id[0]+'_status-'+obj.id_ad).text("");
                        }
                    }
                });
            }else{
                alert("Oops, something went wrong !!");
            }
        })
    });


    $(document).on('click','.saveLowerLimit',function(){
        var input = $(this).parent().find('input');
        var id = input.attr('data-id');
        var lower_limit = input.val();
        var actual_value = input.attr('data-value');
        if(actual_value == lower_limit){
            alert('Please change the value first');
            return false;
        } 
        if(id !='' && lower_limit != ''){
            $.ajax({
                    url: "delivery-limitupdate", // make sure you set an action attribute to your form
                    type: 'GET',
                    cache: false,
                    async: false,
                    dataType: 'JSON',
                    data: {'id': id,'lower_limit':lower_limit},
                   beforeSend: function() {
                       $(".preloader").css("display", "block");
                    },
                    success: function(data){
                        var obj = data;
                        if(obj.status == 1){
                           $("#inputLowerLimit_"+id).html("");
                           var content = lower_limit+'<a href="javascript:void(0)" class="edit-percentage" data-id="'+id+'" data-value="'+lower_limit+'"><span class="glyphicon glyphicon-pencil"></span></a>';
                           $("#lowerInnerContainer_"+id).html(content).show();
                        }else{
                           alert('There is some error');
                        }
                        $(".preloader").css("display", "none");
                    }
                });
            }else{
                alert("Oops, something went wrong !!");
            }
        });

         $(document).on('click','.edit-percentage', function(){
           var id = $(this).attr('data-id');
           var lower_limit = $(this).attr('data-value');
            if(id !='' && lower_limit != ''){
              $("#lowerInnerContainer_"+id).hide();  
              $input = '<input type="text" data-id="'+id+'" value="'+lower_limit+'"  data-value="'+lower_limit+'"class="lowerlimit" size="3">';
              $input  +='&nbsp<a href="javascript:void(0)" class="saveLowerLimit"><span class="glyphicon glyphicon-ok"></span></a>';
              $input  +='&nbsp<a href="javascript:void(0)" class="cancelLowerLimit" data-id="'+id+'"><span class="glyphicon glyphicon-remove"></span></a>';  
              $("#inputLowerLimit_"+id).html($input).show();    
            }
        }); 

        $(document).on('click','.cancelLowerLimit', function(){
             var id = $(this).attr('data-id');
             $("#inputLowerLimit_"+id).hide();
             $("#lowerInnerContainer_"+id).show();
        });  

  </script>
  @endsection
@section('content')
<div>

    <div class="m-b-15 header-panel-form">
              <form class="form-inline" role="form" method="POST" action="{{ route('smartdeliverypost2') }}">
                        {{ csrf_field() }}    
                        <input type="hidden" id="auth" name="auth" value="sanjeev">
                            <div class="form-group ">
                               <input type="text" name="id_ad" value="{{$id_ad}}" class="form-control" placeholder="CCA">  
                            </div>
                            <div class="form-group ">
                                <select name="ntname" id="ntname" class="col-md-2 select2 form-control" data-act="ajax-select"   data-initial-id="{{$ntname}}" data-preload="true" data-post-id="ccz" data-post-key="name" data-post-table="ad_network" data-min-input="2" data-placeholder="Network Name" data-post-text="concat(name,'(',ccz,')')">
                                <option value="0">Network Name</option>
                                </select>
                            </div>
                            <div class="form-group ">
                                   <select name="opname" class=" select2 form-control" id="opname" data-act="ajax-select"  data-post-text="concat(name,'-',country_code)" data-initial-id="{{$opname}}" data-post-id="id" data-post-key="name" data-post-table="operator" data-min-input="2" data-placeholder="Operators" ></select>
                            </div>
                    	    <div class="form-group ">
                                <select name="filter_status" class="form-control full">
                                    <option value="">Filter Status </option>
                                    <option value="1">Active </option>
                                    <option value="0">InActive </option>
                                </select>
                            </div>
                    	   <div class="form-group ">
                            <select name="postback_status" class="form-control full">
                                <option value="">Postback Status</option>
                                <option value="1">Active</option>
                                <option value="0">InActive</option>
                            </select>
                            </div>
                            <div class="">
                                 <button type="submit" class="btn btn-success waves-effect waves-light">Go</button>
                            </div>

                             <div class="m-r-10">
                                                     <button type="submit" class="btn btn-warning waves-effect waves-light" onClick="this.form.reset();">Reset</button>
                                                </div>



                            <div class="form-group ">
                            <a href="{{url('/smart-delivery/add')}}" class="btn btn-success waves-effect waves-light m-r-10">Add New</a>
                            </div>
                        
                            <div class="text-right ">
                            @php
                                $heads =  [
                                            "Type",
                                            "Is Child",                                                                
                                            "Network Name",
                                            "CCZ",
                                            "CCA",
                                            "Operator Name",
                                            "Filter Pect",
                                            "Filter Status",
                                            "Postback Status",
                                            "Smart Status",
                                            "Is offer",
                                            "Action",
                                            "Postback URL"  
                                            ];
                            @endphp
                                <div class="text-right ">
                                {!!view('layouts.column', ['data' =>$heads])!!}
                            </div>
                            </div>
                </form>
            </div>
    </div>
    <div class="col-sm-12">
        <div class="table-responsive mainTableInfo">
            <table class="table color-table info-table scrollTable lazy" id="tableLazy">
                {!!view('layouts.tableheadNew', ['data' =>$heads,'class'=>""])!!}
            </table>
            <table></table>
    </div>               
    </div>
    

@endsection
