@extends('layouts.app')
@section('bread')
        <ol class="breadcrumb">
            <li><a href="#">Dashboard</a></li>
            <li class="active">Users</li>
        </ol>
@endsection
@section('heading')
  Traffic Diversion
@endsection

@section('content')
<div class="container">
    <div class="col-sm-12">
                        <div class="table-responsive">
                                <table class="table ">
                                    <thead>
                                        <tr>
                                            <th>
                                                <div class="form-group">
                                                        <label class="control-label">Network Name</label> 
                                                        <select class="form-control">
                                                            <option value="">Select Network</option>
                                                            <option value="">xyz</option>
                                                        </select>
                                                </div>

                                            </th>
                                            <th>
                                                <div class="form-group">
                                                        <label class="control-label">Operater</label> 
                                                        <select class="form-control">
                                                            <option value="">All</option>
                                                            <option value="">XYZ</option>
                                                        </select>
                                                </div>
                                            </th>
                                            <th>
                                                <div class="form-group">
                                                        <label class="control-label">Status</label> 
                                                        <select class="form-control">
                                                            <option value="">Select </option>
                                                            <option value="">xyz</option>
                                                        </select>
                                                </div>

                                            </th>
                                           <th style="vertical-align: middle;">
                                                <div class="text-right">
                                                     <button type="submit" class="btn btn-success waves-effect waves-light m-r-10">Go</button>
                                                </div>
                                            </th>
                                            <th style="vertical-align: middle;">
                                                <div class="text-right">
                                                     <button type="submit" class="btn btn-success waves-effect waves-light m-r-10">Add New</button>
                                                </div>
                                            </th>
                                        </tr>
                                    </thead>
                                   
                                </table>
                            </div>
    </div>


    <div class="col-sm-12">
                       
                            
                            <div class="table-responsive">
                                <table class="table color-table info-table">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Action</th>
                                            <th>Network Name</th>
                                            <th>Operater</th>
                                            <th>CCZ</th>
                                            <th>Parent CCA</th>
                                            <th>CCA</th>
                                            <th>Campaign Name</th>
                                            <th>Percentage</th>
                                            <th>Is Child</th>
                                            <th>Status</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td style="padding-top: 9px;"><a href=""><button type="button" class="btn btn-success btn-circle "><i class="fa fa-edit"></i> </button>
                                                </a></td>
                                            <td>Eichmann</td>
                                            <td>@Sonu</td>
                                            <td>Eichmann</td>
                                            <td>23</td>
                                            <td>Eichmann</td>
                                            <td>@Sonu</td>
                                            <td>1</td>
                                            <td>Nigam</td>
                                            <td><div class="checkbox checkbox-danger checkbox-circle">
                                                <input id="checkbox8" type="checkbox" checked>
                                                <label for="checkbox8"> Active </label></td>
                                         
                                        </tr>
                                       
                                    </tbody>
                                </table>
                            </div>           
    </div>
</div>

@endsection
