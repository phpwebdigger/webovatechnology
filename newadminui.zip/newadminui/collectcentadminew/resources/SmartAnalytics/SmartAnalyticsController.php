<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Response;
use Illuminate\Support\Facades\Redis;
use Cache;
use App\SmartAnalytics;

class SmartAnalyticsController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

   

    public function index(Request $request,$type="",$page_name="Smart Analytics") 
    {
    
        $select = ['id_analytics','TrafficType','Country','Carrier','publisherId','subPublisherId','RefererUrl','Device','OS','Browser',
        'advertiserCampaignId',
    'ConversionPayOut','hour','date_time'
    ];
             $dtvalue = '2018-01-10';//$request->start;
            $dtvalue2 = '2018-01-10';// $request->end;
            
            
            if(is_null($dtvalue)){
                    $dtvalue = date('Y-m-d');
            }
            if(is_null($dtvalue2)){
                    $dtvalue2 = date('Y-m-d');
                    $enddate = date('Y-m-d',strtotime("+1 days"));
            }else{
                $enddate = date('Y-m-d',strtotime("+1 day", strtotime($dtvalue2)));

            }
        
        
        $condtion = [];
        $hour=$request->hour;
        
        if(is_null($hour)){
            $hour=date('H');
        }
        else{
             $hour=$request->hour;
        }

         array_push($condtion,['date_time','>=',$dtvalue]);
         array_push($condtion,['date_time','<=',$enddate]);
            
        $appends = [];
        $total = $request->total ? $request->total:50;
        $appends['hourssss']=$hour;
        $appends['total']=$request->total;
        
        $data = SmartAnalytics::where($condtion)->select($select)->orderBy('id_analytics','ASC')->get();
        $data1 = [];
        foreach ($data as $fetch_url) {
             array_push($array,
                    $fetch_url->id_analytics,
                    $fetch_url->TrafficType,
                    $fetch_url->Country,
                    $fetch_url->Carrier,
                    $fetch_url->publisherId,
                    $fetch_url->subPublisherId,
                    $fetch_url->RefererUrl,
                    $fetch_url->Device,
                    $fetch_url->OS,
                    $fetch_url->Browser,
                    $fetch_url->advertiserCampaignId,
                    $fetch_url->ConversionPayOut,
                    $fetch_url->hour,
                    $fetch_url->date_time
                  
                  );
               array_push($data1, $array);
        }
        $display_pages="SmartAnalytics.smart_analytics_index";
        return view($display_pages,compact('data1'));
    }
}
